import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { pushSchema } from "drizzle-kit/api";
import * as schema from "../src/schema";
import { assertSafePlan } from "./schema-policy.mjs";

// Development-only entry point, also used by post-merge. Never invoke on publish.
if (process.env.NODE_ENV === "production" || process.env.REPLIT_DEPLOYMENT === "1") {
  throw new Error("Schema sync is development-only; production is managed by Publish.");
}
const args = process.argv.slice(2);
if (args.some((arg) => arg !== "--check")) throw new Error("Only --check is supported; no force bypass.");
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required.");
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const client = await pool.connect();
try {
  // Planning cannot write even if a future Drizzle release changes behavior.
  await client.query("BEGIN READ ONLY");
  const plan = await pushSchema(schema, drizzle(client), ["public"]);
  await client.query("ROLLBACK");
  console.log(JSON.stringify({
    hasDataLoss: plan.hasDataLoss,
    warnings: plan.warnings,
    statements: plan.statementsToExecute,
  }, null, 2));
  assertSafePlan(plan);
  if (!args.includes("--check") && plan.statementsToExecute.length) {
    await client.query("BEGIN");
    await client.query("SET LOCAL lock_timeout = '5s'");
    for (const statement of plan.statementsToExecute) await client.query(statement);
    await client.query("COMMIT");
  }
  if (!args.includes("--check")) {
    // Verify the entire model, not just two relation names.
    await client.query("BEGIN READ ONLY");
    const remaining = await pushSchema(schema, drizzle(client), ["public"]);
    await client.query("ROLLBACK");
    if (remaining.statementsToExecute.length || remaining.hasDataLoss || remaining.warnings.length) {
      throw new Error("Schema drift remains after development sync.");
    }
    console.log("Development schema matches all exported tables.");
  }
} catch (error) {
  await client.query("ROLLBACK");
  throw error;
} finally {
  client.release();
  await pool.end();
}