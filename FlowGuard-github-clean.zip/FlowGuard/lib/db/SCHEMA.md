# Development schema ownership and safety

`src/schema/index.ts` is the complete desired public schema. `drizzle.config.ts`
uses that same barrel and the public schema; do not hide application tables with
table exclusions to make a diff disappear.

| Tables | Feature owner |
| --- | --- |
| anomalies | anomaly recording/resolution |
| excapper_delivery_outbox | Excapper delivery worker |
| excapper_binding_decisions | binding audit |
| manual_binding_blocks, manual_active_bindings, manual_bindings_import | manual fixture bindings |
| manual_league_aliases | operator-approved league aliases |
| scanner_tuner_state | adaptive tuner persistence |
| global_spike_outbox | `artifacts/api-server/src/lib/globalSpikeOutbox.ts` |
| manual_watchlist_volume_baseline, manual_watchlist_telegram_outbox | `artifacts/api-server/src/lib/manualWatchlistVolumeAlerts.ts` |

The last three tables were previously created only by runtime SQL and omitted
from Drizzle. They are application data, not disposable foreign tables.
Their nullable columns, double-precision volume values, timestamp time zones,
defaults and partial retry index are intentionally preserved. The league alias
pair is a named UNIQUE constraint, not a separately named unique index.

## Safe workflow

- `pnpm --filter @workspace/db run schema:check` computes a diff in a read-only
  transaction and prints SQL without applying it.
- `pnpm --filter @workspace/db run push` uses the same planner and refuses
  warnings, data-loss flags and all changes other than new tables/indexes.
  Approved additive statements run in one transaction with a short lock timeout.
  A second read-only diff must be empty for success.
- This deliberately blocks even benign ALTERs: inspect their SQL and obtain
  explicit approval for a separate development change. Do not add `--force`.
- `pnpm --filter @workspace/db run test:schema` tests the fail-closed policy.
- Never point these commands at production. Runtime deployment mode is rejected
  as an additional guard, not proof of a connection's identity. Post-merge uses
  the workspace development connection. Production remains Publish-managed.

## Development inspection (2026-09-24)

All nine existing public tables had database owner `postgres`. Feature ownership
is determined by the code above, not that shared database role. The three omitted
tables contained 83, 434 and 347 rows respectively (live worker counts can change).
After completing the models and matching the league-alias constraint, the only
remaining diff was CREATE TABLE for `manual_active_bindings` and
`manual_bindings_import`. No existing table/column/index needed dropping or
altering. These missing tables are created through the guarded development flow.

Legacy runtime bootstrap SQL remains unchanged to avoid mixing a schema repair
with changes to notification behavior; it is not an additional schema authority.
Future schema changes must update the Drizzle model as well.