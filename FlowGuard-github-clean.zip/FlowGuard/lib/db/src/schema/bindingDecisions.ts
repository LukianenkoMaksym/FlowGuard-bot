import { index, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export interface BindingFixtureEvidence {
  id: string | null;
  home: string | null;
  away: string | null;
  league: string | null;
  score: { home: number; away: number } | null;
  period: string | null;
  minute: number | null;
}

export const bindingDecisionsTable = pgTable("excapper_binding_decisions", {
  id: text("id").primaryKey(),
  matchId: text("match_id").notNull(),
  action: text("action").$type<"bind" | "reset">().notNull(),
  mode: text("mode").$type<"automatic" | "manual" | "manual_override">().notNull(),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull(),
  target: jsonb("target").$type<BindingFixtureEvidence>().notNull(),
  source: jsonb("source").$type<BindingFixtureEvidence>().notNull(),
  reason: text("reason").notNull(),
}, (table) => [
  index("excapper_binding_decisions_match_time").on(table.matchId, table.occurredAt),
]);