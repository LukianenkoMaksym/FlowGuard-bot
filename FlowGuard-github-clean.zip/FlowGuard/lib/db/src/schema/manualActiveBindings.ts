import { boolean, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const manualActiveBindingsTable = pgTable("manual_active_bindings", {
  nowgoalId: text("nowgoal_id").primaryKey(),
  excapperId: text("excapper_id").notNull(),
  boundAt: timestamp("bound_at", { withTimezone: true }).notNull(),
  status: text("status").$type<"Verified">().notNull(),
  autoBound: boolean("auto_bound").notNull(),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull(),
});

// A committed marker is required even when the old file is absent or empty:
// otherwise a later stale container could resurrect a reset binding.
export const manualBindingsImportTable = pgTable("manual_bindings_import", {
  name: text("name").primaryKey(),
  importedAt: timestamp("imported_at", { withTimezone: true }).notNull().defaultNow(),
});