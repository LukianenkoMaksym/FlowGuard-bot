import { sql } from "drizzle-orm";
import { index, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/** Durable queue owned by the API's globalSpikeOutbox worker. */
export const globalSpikeOutboxTable = pgTable("global_spike_outbox", {
  eventKey: text("event_key").primaryKey(),
  gameId: text("game_id").notNull(),
  transaction: jsonb("transaction").notNull(),
  message: text("message"),
  recipientState: jsonb("recipient_state"),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
  attempts: integer("attempts").notNull().default(0),
}, (table) => [
  index("global_spike_outbox_due_idx").on(table.nextAttemptAt).where(sql`${table.completedAt} IS NULL`),
]);