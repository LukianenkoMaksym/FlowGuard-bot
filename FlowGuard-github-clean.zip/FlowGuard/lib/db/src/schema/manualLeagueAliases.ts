import { pgTable, text, timestamp, unique } from "drizzle-orm/pg-core";

/**
 * Operator-approved league identity pairs. This table is deliberately not an
 * automated target-league allowlist; it is consulted only by manual fixture
 * binding.
 */
export const manualLeagueAliasesTable = pgTable(
  "manual_league_aliases",
  {
    canonicalLeft: text("canonical_left").notNull(),
    canonicalRight: text("canonical_right").notNull(),
    leftLabel: text("left_label").notNull(),
    rightLabel: text("right_label").notNull(),
    approvedAt: timestamp("approved_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique("manual_league_aliases_pair_unique").on(
      table.canonicalLeft,
      table.canonicalRight,
    ),
  ],
);

export type ManualLeagueAlias = typeof manualLeagueAliasesTable.$inferSelect;