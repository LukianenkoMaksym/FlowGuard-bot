import { doublePrecision, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/** Owned by manualWatchlistVolumeAlerts; keep compatible with its legacy bootstrap. */
export const manualWatchlistVolumeBaselineTable = pgTable("manual_watchlist_volume_baseline", {
  marketKey: text("market_key").primaryKey(),
  cumulativeEur: doublePrecision("cumulative_eur").notNull(),
  triggerBaselineEur: doublePrecision("trigger_baseline_eur"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const manualWatchlistTelegramOutboxTable = pgTable("manual_watchlist_telegram_outbox", {
  eventKey: text("event_key").primaryKey(),
  message: text("message").notNull(),
  parseMode: text("parse_mode").notNull().default("plain"),
  recipientState: jsonb("recipient_state").notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  attempts: integer("attempts").notNull().default(0),
  nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  oddsObservedAt: timestamp("odds_observed_at", { withTimezone: true }),
  evidence: jsonb("evidence"),
  volumeObservedAt: timestamp("volume_observed_at", { withTimezone: true }),
});