import { sql } from "drizzle-orm";
import { check, integer, jsonb, pgTable } from "drizzle-orm/pg-core";

/** Singleton tuner metadata; scanner filter values remain in their existing file. */
export const scannerTunerStateTable = pgTable(
  "scanner_tuner_state",
  {
    id: integer("id").primaryKey(),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull(),
  },
  (table) => [
    check("scanner_tuner_state_id_check", sql`${table.id} = 1`),
  ],
);

export type ScannerTunerState = typeof scannerTunerStateTable.$inferSelect;