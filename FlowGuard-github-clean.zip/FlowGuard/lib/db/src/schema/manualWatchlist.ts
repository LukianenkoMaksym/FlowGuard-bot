import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/** Environment-local operator pins; never seed production from development. */
export const manualWatchlistTable = pgTable("manual_watchlist", {
  key: text("key").primaryKey(),
  matches: jsonb("matches").$type<unknown[]>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});