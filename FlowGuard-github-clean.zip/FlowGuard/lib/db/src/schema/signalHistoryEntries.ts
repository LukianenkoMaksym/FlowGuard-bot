import { pgTable, text, serial, real, integer, timestamp, uniqueIndex, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/** Independent transport ledger; AWAITING_ACK rows are never included in history. */
export const signalHistoryEntriesTable = pgTable("signal_history_entries", {
  id: serial("id").primaryKey(),
  deliveryKey: text("delivery_key").notNull(),
  rawCard: text("raw_card").notNull(),
  matchId: text("match_id"),
  team1: text("team1").notNull().default(""),
  team2: text("team2").notNull().default(""),
  league: text("league").notNull().default(""),
  anomalyType: text("anomaly_type").notNull(),
  targetSide: text("target_side"),
  line: real("line"),
  minuteBucket: text("minute_bucket").notNull().default("unknown"),
  matchMinute: integer("match_minute"),
  homeScoreAtFire: integer("home_score_at_fire"),
  awayScoreAtFire: integer("away_score_at_fire"),
  oddsAtFire: real("odds_at_fire"),
  status: text("status").notNull().default("AWAITING_ACK"),
  finalHomeScore: integer("final_home_score"),
  finalAwayScore: integer("final_away_score"),
  finalTotal: integer("final_total"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
}, (t) => [
  uniqueIndex("signal_history_entries_key_idx").on(t.deliveryKey),
  index("signal_history_entries_status_idx").on(t.status),
  index("signal_history_entries_created_idx").on(t.createdAt),
]);
export const insertSignalHistoryEntrySchema = createInsertSchema(signalHistoryEntriesTable).omit({ id: true, createdAt: true, resolvedAt: true });
export type InsertSignalHistoryEntry = z.infer<typeof insertSignalHistoryEntrySchema>;
export type SignalHistoryEntry = typeof signalHistoryEntriesTable.$inferSelect;