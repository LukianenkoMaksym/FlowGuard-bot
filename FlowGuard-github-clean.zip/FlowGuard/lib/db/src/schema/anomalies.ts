import {
  pgTable,
  serial,
  text,
  real,
  integer,
  bigint,
  timestamp,
  index,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * Anomaly snapshots for the Dynamic Win-Rate Tracker.
 *
 * One row is written every time the scanner fires a user-facing anomaly alert
 * for a watchlist match (an odds-drop "Pro Alert" or an Excapper money-spike
 * "Large Volume" alert). Each row records the targeted Over/Under side and the
 * line at fire time, then a background resolver fills in the final score after
 * the match finishes and flips `status` to WIN / LOSS (resolved strictly by the
 * targeted side: OVER wins when the final total beats the line, UNDER wins when
 * it stays under).
 *
 * The aggregate of resolved rows powers the live, dynamically-adjusted win-rate
 * percentage surfaced in the Priority Watchlist.
 */
export const anomaliesTable = pgTable(
  "anomalies",
  {
    id: serial("id").primaryKey(),
    matchId: text("match_id").notNull(),
    team1: text("team1").notNull(),
    team2: text("team2").notNull(),
    league: text("league").notNull().default(""),
    // 'ODDS_DROP' | 'MONEY_SPIKE'
    anomalyType: text("anomaly_type").notNull(),
    // 'OVER' | 'UNDER' — the side the smart money targeted.
    targetSide: text("target_side").notNull(),
    // The Over/Under handicap line the alert fired on.
    line: real("line").notNull(),
    // Coarse match-phase bucket at fire time, used for the conditional
    // sub-bucket win-rate: 'prematch' | 'early' | 'mid' | 'late' | 'unknown'.
    minuteBucket: text("minute_bucket").notNull().default("unknown"),
    // Raw match minute at fire time when known (money-spike alerts carry it);
    // null for odds-drop alerts which don't expose a live minute.
    matchMinute: integer("match_minute"),
    homeScoreAtFire: integer("home_score_at_fire").notNull().default(0),
    awayScoreAtFire: integer("away_score_at_fire").notNull().default(0),
    // Entry odds (HK) on the targeted side at fire time, for later audit.
    oddsAtFire: real("odds_at_fire"),
    // Match kickoff as absolute epoch ms (already GMT+8→UTC normalized upstream).
    // The resolver anchors its eligibility / force / abandon windows on this so
    // alerts fired long before kickoff aren't mis-resolved off their fire time.
    // Null when the feed didn't expose a parseable kickoff at fire time.
    kickoffAtMs: bigint("kickoff_at_ms", { mode: "number" }),
    // 'PENDING' | 'WIN' | 'LOSS' | 'VOID'
    status: text("status").notNull().default("PENDING"),
    finalHomeScore: integer("final_home_score"),
    finalAwayScore: integer("final_away_score"),
    finalTotal: integer("final_total"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (t) => [
    index("anomalies_status_idx").on(t.status),
    index("anomalies_match_idx").on(t.matchId),
    index("anomalies_created_idx").on(t.createdAt),
  ],
);

export const insertAnomalySchema = createInsertSchema(anomaliesTable).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});
export type InsertAnomaly = z.infer<typeof insertAnomalySchema>;
export type Anomaly = typeof anomaliesTable.$inferSelect;
