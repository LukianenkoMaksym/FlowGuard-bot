import { pgTable, text, serial, real, integer, timestamp, uniqueIndex, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * Unused first development draft. Retained solely because the additive-only
 * schema synchronizer protects this already-created table from a DROP. Runtime
 * delivery/history uses signalHistoryEntriesTable instead. Defer cleanup until
 * a separately reviewed migration; never drop unknown data on startup/publish.
 */
export const deliveredSignalsTable = pgTable("delivered_signals", {
  id: serial("id").primaryKey(),
  deliveryKey: text("delivery_key").notNull(),
  matchId: text("match_id").notNull(),
  team1: text("team1").notNull(),
  team2: text("team2").notNull(),
  league: text("league").notNull(),
  anomalyType: text("anomaly_type").notNull(),
  targetSide: text("target_side").notNull(),
  line: real("line").notNull(),
  minuteBucket: text("minute_bucket").notNull().default("unknown"),
  matchMinute: integer("match_minute"),
  homeScoreAtFire: integer("home_score_at_fire").notNull(),
  awayScoreAtFire: integer("away_score_at_fire").notNull(),
  oddsAtFire: real("odds_at_fire"),
  status: text("status").notNull().default("PENDING"),
  finalHomeScore: integer("final_home_score"),
  finalAwayScore: integer("final_away_score"),
  finalTotal: integer("final_total"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
}, (t) => [
  uniqueIndex("delivered_signals_key_idx").on(t.deliveryKey),
  index("delivered_signals_status_idx").on(t.status),
  index("delivered_signals_created_idx").on(t.createdAt),
]);

export const insertDeliveredSignalSchema = createInsertSchema(deliveredSignalsTable).omit({ id: true, createdAt: true, resolvedAt: true });
export type InsertDeliveredSignal = z.infer<typeof insertDeliveredSignalSchema>;
export type DeliveredSignal = typeof deliveredSignalsTable.$inferSelect;