import {
  pgTable,
  text,
  boolean,
  integer,
  jsonb,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

/**
 * Durable delivery commit log for qualified Excapper alerts.
 *
 * Recipient identifiers intentionally live only in this private table's JSON
 * snapshot. They are never projected by an HTTP route or written to logs.
 */
export const excapperDeliveryOutboxTable = pgTable(
  "excapper_delivery_outbox",
  {
    eventKey: text("event_key").primaryKey(),
    message: text("message").notNull(),
    alertSnapshot: jsonb("alert_snapshot").notNull(),
    recipientState: jsonb("recipient_state").notNull(),
    diagnostic: boolean("diagnostic").notNull().default(false),
    qualifiedAt: timestamp("qualified_at", { withTimezone: true }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    primaryAckedAt: timestamp("primary_acked_at", { withTimezone: true }),
    activatedAt: timestamp("activated_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    attempts: integer("attempts").notNull().default(0),
    nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
    lastError: text("last_error"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("excapper_delivery_outbox_retry_idx").on(
      t.completedAt,
      t.cancelledAt,
      t.nextAttemptAt,
    ),
  ],
);

export type ExcapperDeliveryOutboxRow =
  typeof excapperDeliveryOutboxTable.$inferSelect;