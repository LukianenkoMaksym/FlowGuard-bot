import { pgTable, text, timestamp, unique } from "drizzle-orm/pg-core";

export const manualBindingBlocksTable = pgTable(
  "manual_binding_blocks",
  {
    diagnosticId: text("diagnostic_id").notNull(),
    gameId: text("game_id").notNull(),
    blockedAt: timestamp("blocked_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique("manual_binding_blocks_pair_unique").on(table.diagnosticId, table.gameId),
  ],
);