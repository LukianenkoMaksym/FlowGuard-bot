import { integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/** Durable RADAR score epoch, shared by scanner and directory-only 1X2 fixtures. */
export const radarScoreContextTable = pgTable("radar_score_context", {
  matchId: text("match_id").primaryKey(),
  homeScore: integer("home_score").notNull(),
  awayScore: integer("away_score").notNull(),
  observedAt: timestamp("observed_at", { withTimezone: true }).notNull(),
  goalAt: timestamp("goal_at", { withTimezone: true }),
  safeAfter: timestamp("safe_after", { withTimezone: true }).notNull(),
  revision: integer("revision").notNull(),
});

export type RadarScoreContextRow = typeof radarScoreContextTable.$inferSelect;