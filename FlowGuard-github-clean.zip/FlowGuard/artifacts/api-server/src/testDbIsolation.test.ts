import { describe, expect, it } from "vitest";
import { anomaliesTable, db, pool } from "@workspace/db";

describe("default test database isolation", () => {
  it("has no inherited PostgreSQL credentials or connection target", () => {
    for (const key of ["DATABASE_URL", "PGHOST", "PGPORT", "PGDATABASE", "PGUSER", "PGPASSWORD"]) {
      expect(process.env[key]).toBeUndefined();
    }
  });

  it("preserves schema exports but fails closed on any implicit query", () => {
    expect(anomaliesTable).toBeDefined();
    expect(() => pool.query("SELECT 1")).toThrow("Test DB isolation");
    expect(() => pool.connect()).toThrow("Test DB isolation");
    expect(() => db.insert).toThrow("Test DB isolation");
  });
});