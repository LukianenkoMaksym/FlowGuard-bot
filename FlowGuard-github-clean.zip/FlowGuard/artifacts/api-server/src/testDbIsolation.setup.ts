import { vi } from "vitest";

// No test should have an implicit PostgreSQL target. The explicit per-file
// @workspace/db mocks used by DB behavior tests may replace this default.
// Clearing the libpq fallback variables prevents a real Pool from connecting
// via PGHOST/PGDATABASE even if a module bypasses this mock.
for (const key of ["DATABASE_URL", "PGHOST", "PGPORT", "PGDATABASE", "PGUSER", "PGPASSWORD"]) {
  delete process.env[key];
}

vi.mock("@workspace/db", async () => {
  const schema = await import("../../../lib/db/src/schema");
  const denied = () => {
    throw new Error(
      "Test DB isolation: implicit database access denied; inject an explicit in-memory @workspace/db mock",
    );
  };
  return {
    ...schema,
    pool: {
      query: denied,
      connect: denied,
      end: denied,
    },
    db: new Proxy({}, { get: denied }),
  };
});