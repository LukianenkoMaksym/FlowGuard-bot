import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scannerRouter from "./scanner";
import watchlistRouter from "./watchlist";
import authRouter from "./auth";
import volumeConfigRouter from "./volumeConfig";
import winRateRouter from "./winrate";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

// Public — needed for deployment health checks.
router.use(healthRouter);

// Public — auth endpoints (login itself is rate-limited).
router.use(authRouter);

// Protected — everything else requires a valid signed session cookie.
router.use(requireAuth);
router.use(scannerRouter);
router.use(watchlistRouter);
router.use(volumeConfigRouter);
router.use(winRateRouter);

export default router;
