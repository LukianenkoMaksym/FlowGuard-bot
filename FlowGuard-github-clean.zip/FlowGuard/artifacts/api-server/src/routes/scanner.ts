import { Router } from "express";
import {
  scannerStats,
  config,
  runManualValidation,
  getHealthSnapshot,
  runSelfAnalysis,
  POLL_INTERVAL_MS,
  POLL_JITTER_MS,
  WATCHLIST_FAST_POLL_INTERVAL_MS,
  WATCHLIST_HYPER_POLL_INTERVAL_MS,
  getGlobalScannerPaused,
  setGlobalScannerPaused,
  forceRestartScanner,
  getScannerLoopDiagnostic,
  liveDiscoveryDiagnostics,
} from "../lib/scanner";
import { getWatchlistSnapshot } from "../lib/watchlist";
import { getControls, setControl } from "../lib/controls";
import { updateScannerConfig, getScannerConfigSources } from "../lib/scannerConfig";
import { autoTunerSnapshot, getAutoTunerStatus, setAutoTunerEnabled } from "../lib/autoTuner";
import {
  getLeaguePolicy,
  LeaguePolicyError,
  updateLeaguePolicy,
} from "../lib/targetLeagues";
import { sendPrimaryTelegramSystemCheck } from "../lib/telegram";
import { getScanCoordinatorStatus } from "../lib/scanCoordinator";

const router = Router();

router.get("/scanner/auto-tuner", async (_req, res) => {
  res.json(await getAutoTunerStatus());
});

router.patch("/scanner/auto-tuner", async (req, res) => {
  if (!req.body || typeof req.body !== "object" || Array.isArray(req.body) ||
      typeof req.body.enabled !== "boolean" || Object.keys(req.body).some((key) => key !== "enabled")) {
    res.status(400).json({ ...autoTunerSnapshot(), persisted: false, error: "Expected { enabled: boolean }." });
    return;
  }
  const result = await setAutoTunerEnabled(req.body.enabled);
  res.status(result.persisted ? 200 : 500).json(result);
});

router.get("/scanner/coordinator", (_req, res) => {
  res.json({ ok: true, coordinator: getScanCoordinatorStatus() });
});

function leaguePolicyEnvelope() {
  return { ok: true as const, policy: getLeaguePolicy() };
}

router.get("/scanner/league-policy", (_req, res) => {
  res.json(leaguePolicyEnvelope());
});

router.put("/scanner/league-policy", async (req, res) => {
  if (
    !req.body ||
    typeof req.body !== "object" ||
    Array.isArray(req.body) ||
    Object.keys(req.body as object).some((key) => key !== "names" && key !== "entries" && key !== "revision") ||
    (Object.hasOwn(req.body, "names") === Object.hasOwn(req.body, "entries"))
  ) {
    res.status(400).json({
      ok: false,
      error: "Ожидается revision и одно из полей: names или entries.",
    });
    return;
  }
  const body = req.body as { names?: unknown; entries?: unknown; revision?: unknown };
  try {
    const entriesMode = Object.hasOwn(body, "entries");
    const policy = await updateLeaguePolicy(entriesMode ? body.entries : body.names, body.revision, entriesMode);
    req.log.warn(
      { total: policy.total, leaguesRu: policy.entries.map((entry) => entry.displayNameRu) },
      `Белый список лиг сохранён. ВСЕГО: ${policy.total}.`,
    );
    res.json({ ok: true, policy });
  } catch (error) {
    if (error instanceof LeaguePolicyError) {
      const status = error.code === "conflict" ? 409 : error.code === "validation" ? 400 : 500;
      res.status(status).json({ ok: false, error: error.message });
      return;
    }
    res.status(500).json({ ok: false, error: "Не удалось обновить политику лиг." });
  }
});

router.post("/scanner/league-policy/log", (req, res) => {
  const policy = getLeaguePolicy();
  const labelsRu = policy.entries.map((entry) => entry.displayNameRu);
  const summaryRu = `Белый список лиг. ВСЕГО: ${policy.total}.`;
  req.log.info(
    { total: policy.total, leaguesRu: labelsRu, rulesRu: policy.rulesRu },
    summaryRu,
  );
  res.json({ ok: true, policy, summaryRu });
});

/**
 * Explicit authenticated operator action. Never invoked by startup and targets
 * only the configured primary chat (not the subscriber broadcast audience).
 */
router.post("/telegram/system-check", async (_req, res) => {
  const result = await sendPrimaryTelegramSystemCheck();
  if (result !== "ok") {
    res.status(502).json({ ok: false, delivery: result });
    return;
  }
  res.json({ ok: true, delivery: "ok" });
});

router.get("/scanner/health", (_req, res) => {
  res.json({ ok: true, ...getHealthSnapshot() });
});

router.post("/scanner/validate", async (req, res) => {
  const failover = req.query["failover"] === "1" || req.query["failover"] === "true";
  try {
    const result = await runManualValidation({ failover });
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

// Non-destructive on-demand health audit: probes every mirror, runs the
// validator, checks tick freshness, and emits a single structured log line.
// Does NOT trigger failover or mutate any scanner state.
//
// Guardrails (CRITICAL — one self-analysis fans out ~23 upstream requests
// across all 6 mirrors; without these guards, repeated clicks or multiple
// tabs can stack probes and raise IP-ban risk):
//   - Singleflight: if a run is in progress, subsequent callers wait on the
//     same promise instead of triggering a second fan-out.
//   - Cooldown (60s): after a successful run, reuse the cached report rather
//     than re-probing. Manual override would require a server restart.
let selfAnalysisInFlight: Promise<Awaited<ReturnType<typeof runSelfAnalysis>>> | null = null;
let selfAnalysisLastResult: { ranAtMs: number; report: Awaited<ReturnType<typeof runSelfAnalysis>> } | null = null;
const SELF_ANALYSIS_COOLDOWN_MS = 60_000;

router.post("/scanner/self-analysis", async (req, res) => {
  try {
    // Cached recent result wins — protects upstream + gives instant UX.
    if (
      selfAnalysisLastResult &&
      Date.now() - selfAnalysisLastResult.ranAtMs < SELF_ANALYSIS_COOLDOWN_MS
    ) {
      res.json({ ok: true, cached: true, report: selfAnalysisLastResult.report });
      return;
    }

    if (selfAnalysisInFlight === null) {
      selfAnalysisInFlight = runSelfAnalysis()
        .then((r) => {
          selfAnalysisLastResult = { ranAtMs: Date.now(), report: r };
          return r;
        })
        .finally(() => {
          selfAnalysisInFlight = null;
        });
    }
    const report = await selfAnalysisInFlight;
    req.log.info({ ok: report.ok, summary: report.summary }, "Self-analysis triggered via API");
    res.json({ ok: true, cached: false, report });
  } catch (err) {
    req.log.error({ err }, "Self-analysis failed");
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

/**
 * POST /api/scanner/toggle
 * Body (optional): { paused?: boolean }
 *   - If `paused` is provided, sets the flag to that value.
 *   - If omitted, toggles the current value.
 * Returns the resulting state.
 *
 * When paused, tick() short-circuits to hyper-focus mode: only the
 * primaryOu bulk endpoint is fetched, only watchlist matchIds are processed,
 * and the unified active cadence remains ~12s. No alerts fire. See scanner.ts
 * for details.
 */
router.post("/scanner/toggle", (req, res) => {
  const body = (req.body ?? {}) as { paused?: unknown };
  const target = typeof body.paused === "boolean" ? body.paused : !getGlobalScannerPaused();
  // Manual override: the user may pause/resume at will. The scanner still
  // BOOTS unpaused and nothing pauses it automatically.
  const next = setGlobalScannerPaused(target);
  req.log.warn({ requested: target, paused: next }, "Global scanner toggle via API (manual override)");
  res.json({
    ok: true,
    isGlobalScannerPaused: next,
    hyperFocusPollSec: Math.round(WATCHLIST_HYPER_POLL_INTERVAL_MS / 1000),
  });
});

/**
 * GET/POST /api/scanner/controls — manual subsystem switches.
 * POST body: { key: "alertsMuted" | "altStreamEnabled" | "scoreWatchdogEnabled", enabled: boolean }
 */
router.get("/scanner/controls", (_req, res) => {
  res.json({ ok: true, controls: getControls() });
});
router.post("/scanner/controls", async (req, res) => {
  const body = (req.body ?? {}) as { key?: unknown; enabled?: unknown };
  const validKeys = ["alertsMuted", "altStreamEnabled", "scoreWatchdogEnabled"] as const;
  const key = validKeys.find((k) => k === body.key);
  if (!key || typeof body.enabled !== "boolean") {
    res.status(400).json({ ok: false, error: "expected { key: <control name>, enabled: boolean }" });
    return;
  }
  const { controls, persisted } = await setControl(key, body.enabled);
  req.log.warn({ key, enabled: body.enabled, persisted }, "Manual control toggled via API");
  res.json({ ok: true, controls, persisted });
});

function buildConfigPayload() {
  return {
    sources: getScannerConfigSources(),
    dropThreshold: config.dropThreshold,
    maxSpread: config.maxSpread,
    tightSpread: config.tightSpread,
    benchmarkConfirmDrop: config.benchmarkConfirmDrop,
    minConfidence: config.minConfidence,
    requireDensity: config.requireDensity,
    requireLiquidityConfirmation: config.requireLiquidityConfirmation,
    lowLiqMaxSpread: config.lowLiqMaxSpread,
    bypassSpreadOnBigDrop: config.bypassSpreadOnBigDrop,
    absurdSpreadCap: config.absurdSpreadCap,
    pollIntervalSec: Math.round(
      (getGlobalScannerPaused()
        ? WATCHLIST_HYPER_POLL_INTERVAL_MS
        : getWatchlistSnapshot().count > 0
          ? WATCHLIST_FAST_POLL_INTERVAL_MS
          : POLL_INTERVAL_MS) / 1000,
    ),
    pollJitterSec: Math.round(POLL_JITTER_MS / 1000),
    watchlistFastPollSec: Math.round(WATCHLIST_FAST_POLL_INTERVAL_MS / 1000),
    watchlistHyperPollSec: Math.round(WATCHLIST_HYPER_POLL_INTERVAL_MS / 1000),
    watchlistGlobalPollSec: Math.round(POLL_INTERVAL_MS / 1000),
    isGlobalScannerPaused: getGlobalScannerPaused(),
    alertCooldownSec: 120,
    benchmarkWindowSec: 240,
    priorityLeagueIds: config.priorityLeagueIds,
  };
}

router.get("/scanner/status", (_req, res) => {
  res.json({
    ok: true,
    lastCheckAt: scannerStats.lastCheckAt,
    lastGlobalUpdateAt: scannerStats.lastGlobalUpdateAt,
    checksTotal: scannerStats.checksTotal,
    anomaliesFound: scannerStats.anomaliesFound,
    benchmarkConfirmedAlerts: scannerStats.benchmarkConfirmedAlerts,
    earlyBirdAlerts: scannerStats.earlyBirdAlerts,
    alertsSuppressedBySpread: scannerStats.alertsSuppressedBySpread,
    alertsSuppressedByConfidence: scannerStats.alertsSuppressedByConfidence,
    benchmarkCoverage: scannerStats.benchmarkCoverage,
    benchmarkName: scannerStats.benchmarkName,
    primaryFetchFailures: scannerStats.primaryFetchFailures,
    perBookFetch: scannerStats.perBookFetch,
    benchmarkFetchFailures: scannerStats.benchmarkFetchFailures,
    consecutiveFailures: scannerStats.consecutiveFailures,
    lastError: scannerStats.lastError,
    leaguesLoaded: scannerStats.leaguesLoaded,
    whitelistSize: getLeaguePolicy().total,
    scheduleMatchesSeen: scannerStats.scheduleMatchesSeen,
    liveMatchesConfirmed: scannerStats.liveMatchesConfirmed,
    liveDiscovery: liveDiscoveryDiagnostics.snapshot,
    liveMatchesTracked: scannerStats.liveMatchesTracked,
    minorMatchesTracked: scannerStats.minorMatchesTracked,
    majorMatchesSkipped: scannerStats.majorMatchesSkipped,
    lowLiquidityMatchesTracked: scannerStats.lowLiquidityMatchesTracked,
    lowLiquidityAlerts: scannerStats.lowLiquidityAlerts,
    config: buildConfigPayload(),
  });
});

router.patch("/scanner/config", async (req, res) => {
  const result = await updateScannerConfig(req.body);
  if (!result.persisted) {
    res.status(result.invalid ? 400 : 500).json({ ok: false, persisted: false, errors: result.errors });
    return;
  }
  res.json({ ok: true, persisted: true, config: buildConfigPayload() });
});

// POST /api/scanner/force-restart
// Freeze-recovery: aborts any hanging tick request, resets the loop's in-flight
// state, and fires an immediate fresh fetch. Returns a diagnostic naming the
// phase/bookmaker that was blocking the loop at the moment of restart.
router.post("/scanner/force-restart", (req, res) => {
  const result = forceRestartScanner();
  req.log.warn(
    { culprit: result.culprit, stalledMs: result.stalledMs, wasInFlight: result.wasInFlight },
    "Manual force-restart of scanner loop via API",
  );
  res.json({ ...result, diagnostic: getScannerLoopDiagnostic() });
});

// GET /api/scanner/loop-diagnostic
// Read-only liveness snapshot of the tick loop (phase, elapsed, watchdog stats)
// for the dashboard freeze-recovery panel. Never mutates state.
router.get("/scanner/loop-diagnostic", (_req, res) => {
  res.json({ ok: true, diagnostic: getScannerLoopDiagnostic() });
});

export default router;
