import { Router } from "express";
import {
  buildLogoutCookie,
  buildSessionCookie,
  checkPassword,
  isAuthenticated,
  issueSessionToken,
} from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

// Naive in-memory rate limiter to slow brute-force on /login.
// Tracks failed attempts per source IP within a sliding 10-minute window.
const failedAttempts = new Map<string, { count: number; firstFailureAt: number }>();
const MAX_ATTEMPTS = 8;
const WINDOW_MS = 10 * 60 * 1000;

function rateKey(ip: string): string {
  return ip || "unknown";
}

function isLockedOut(ip: string): boolean {
  const rec = failedAttempts.get(rateKey(ip));
  if (!rec) return false;
  if (Date.now() - rec.firstFailureAt > WINDOW_MS) {
    failedAttempts.delete(rateKey(ip));
    return false;
  }
  return rec.count >= MAX_ATTEMPTS;
}

function recordFailure(ip: string): void {
  const k = rateKey(ip);
  const rec = failedAttempts.get(k);
  if (!rec || Date.now() - rec.firstFailureAt > WINDOW_MS) {
    failedAttempts.set(k, { count: 1, firstFailureAt: Date.now() });
  } else {
    rec.count++;
  }
}

function clearFailures(ip: string): void {
  failedAttempts.delete(rateKey(ip));
}

// Don't cache auth responses — privacy hardening for shared proxies.
router.use(["/auth/login", "/auth/logout", "/auth/me"], (_req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

router.post("/auth/login", (req, res) => {
  const ip = req.ip ?? "";
  if (isLockedOut(ip)) {
    logger.warn({ ip }, "Login locked out (rate limit)");
    res.status(429).json({ ok: false, error: "too_many_attempts" });
    return;
  }

  const body = req.body as Record<string, unknown> | undefined;
  const password = typeof body?.["password"] === "string" ? body["password"] : "";

  if (!password || !checkPassword(password)) {
    recordFailure(ip);
    // Constant-ish delay to discourage brute-force timing.
    setTimeout(() => {
      logger.warn({ ip }, "Failed login attempt");
      res.status(401).json({ ok: false, error: "invalid_password" });
    }, 400);
    return;
  }

  clearFailures(ip);
  const token = issueSessionToken();
  res.setHeader("Set-Cookie", buildSessionCookie(token));
  logger.info({ ip }, "Successful login");
  res.json({ ok: true });
});

router.post("/auth/logout", (_req, res) => {
  res.setHeader("Set-Cookie", buildLogoutCookie());
  res.json({ ok: true });
});

router.get("/auth/me", (req, res) => {
  res.json({ ok: true, authenticated: isAuthenticated(req) });
});

export default router;
