import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";
import { getExcapperHealth } from "../lib/excapperBackoff";
import { getExcapperQueueStats } from "../lib/excapperSharedFetch";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json({
    ...data,
    excapperHealth: getExcapperHealth(),
    excapperQueue: getExcapperQueueStats(),
  });
});

export default router;
