import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Request, Response } from "express";

const history = vi.hoisted(() => vi.fn(async (_matchId: string) => []));
vi.mock("../lib/bindingDecisionAudit", async (importOriginal) => ({
  ...await importOriginal<typeof import("../lib/bindingDecisionAudit")>(),
  getBindingDecisionHistory: history,
}));
import router from "./watchlist";
import rootRouter from "./index";
import { requireAuth } from "../lib/auth";

const handler = router.stack.find((layer) =>
  layer.route?.path === "/excapper-binding/history",
)!.route!.stack[0]!.handle;

function response() {
  const res = { status: vi.fn(), json: vi.fn(), setHeader: vi.fn() };
  res.status.mockReturnValue(res);
  return res;
}

describe("read-only binding decision history route", () => {
  beforeEach(() => history.mockReset().mockResolvedValue([]));

  it("is mounted after authentication and rejects missing sessions", () => {
    const authIndex = rootRouter.stack.findIndex((layer) => layer.handle === requireAuth);
    const watchlistIndex = rootRouter.stack.findIndex((layer) => layer.handle === router);
    expect(authIndex).toBeGreaterThanOrEqual(0);
    expect(watchlistIndex).toBeGreaterThan(authIndex);
    const res = response();
    const next = vi.fn();
    requireAuth({ cookies: {} } as Request, res as unknown as Response, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  it.each([undefined, "", [], { nested: "value" }, "a\u0000b"])(
    "rejects invalid match identity %j",
    async (matchId) => {
      const res = response();
      await handler({ query: { matchId } } as unknown as Request, res as unknown as Response, vi.fn());
      expect(res.status).toHaveBeenCalledWith(400);
      expect(history).not.toHaveBeenCalled();
    },
  );

  it("accepts stable text identities independently of runtime candidate membership", async () => {
    const res = response();
    await handler({ query: { matchId: "manual-text:Home|Away" } } as unknown as Request,
      res as unknown as Response, vi.fn());
    expect(history).toHaveBeenCalledWith("manual-text:Home|Away");
    expect(res.json).toHaveBeenCalledWith({ decisions: [] });
    expect(res.setHeader).toHaveBeenCalledWith("Cache-Control", "no-store");
  });

  it("surfaces unavailable storage without leaking the database error", async () => {
    history.mockRejectedValueOnce(new Error("sensitive connection details"));
    const res = response();
    await handler({ query: { matchId: "123" } } as unknown as Request, res as unknown as Response, vi.fn());
    expect(res.status).toHaveBeenCalledWith(503);
    expect(JSON.stringify(res.json.mock.calls)).not.toContain("sensitive");
  });
});