import { Router } from "express";
import {
  parseWatchlistInput,
  addWatchlistEntry,
  removeWatchlistEntry,
  entrySignature,
  getNormalizedEntries,
} from "../lib/watchlist";
import {
  lookupMatchMetaById,
  getWatchlistLiveSnapshot,
  requestManualWatchlistRefresh,
  clearManualMatchVolumeBinding,
  clearManualTextMatchVolumeBinding,
  getRuntimeArchiveRows,
} from "../lib/scanner";
import { matchTargetLeague } from "../lib/targetLeagues";
import {
  requestManualExcapperHydration,
  approveResolvedManualLeagueAlias,
  LeagueAliasApprovalConflict,
  getExcapperBindingDiagnostic,
  releaseManualExcapperBinding,
  resetManualExcapperBinding,
  withExcapperBindingDiagnostics,
  ExcapperExplicitRefreshRateLimitError,
  forceManualExcapperBinding,
} from "../lib/excapper";
import { getExcapperHealth } from "../lib/excapperBackoff";
import { getRuntimeAudit } from "../lib/runtimeAudit";
import { getBindingDecisionHistory } from "../lib/bindingDecisionAudit";

const router = Router();

// Protected by the shared requireAuth middleware in routes/index.ts.
// This deliberately does not require present-day watchlist membership.
router.get("/excapper-binding/history", async (req, res) => {
  const matchId = req.query.matchId;
  if (typeof matchId !== "string" || !matchId.trim() || matchId.length > 1000 ||
      /[\u0000-\u001f]/.test(matchId)) {
    res.status(400).json({ error: "A valid matchId is required." });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  try {
    res.json({ decisions: await getBindingDecisionHistory(matchId) });
  } catch {
    res.status(503).json({ error: "Binding decision history is temporarily unavailable. Please retry." });
  }
});

function watchlistSnapshot() {
  const snapshot = getWatchlistLiveSnapshot();
  const enriched = withExcapperBindingDiagnostics(snapshot);
  return {
    ...enriched,
    savedEntries: snapshot.savedEntries.map((entry) => ({
      ...entry,
      excapperBinding: getExcapperBindingDiagnostic(
        entry.matchId ?? `manual-text:${entry.signature}`,
      ),
    })),
  };
}

function snapshotRow(
  snapshot: ReturnType<typeof watchlistSnapshot>,
  signature: string,
) {
  return snapshot.savedEntries.find((row) => row.signature === signature) ??
    snapshot.entries.find((row) => row.signature === signature) ??
    null;
}

const explicitRefreshInFlight = new Map<string, Promise<void>>();

function runExplicitRefresh(signature: string, matchId?: string): Promise<void> {
  const existing = explicitRefreshInFlight.get(signature);
  if (existing) return existing;
  const selector = matchId ?? `manual-text:${signature}`;
  const operation = (async () => {
    if (matchId) await requestManualWatchlistRefresh([matchId]);
    await requestManualExcapperHydration([selector], { fresh: true });
  })().finally(() => {
    if (explicitRefreshInFlight.get(signature) === operation) {
      explicitRefreshInFlight.delete(signature);
    }
  });
  explicitRefreshInFlight.set(signature, operation);
  return operation;
}

/**
 * GET /api/watchlist
 *
 * Returns the current watchlist plus, for each entry, the live tracked
 * match (if any) — team names, score, line, OU odds, recency. The dashboard
 * polls this so the user can sanity-check bot data against the live site.
 */
router.get("/watchlist", (_req, res) => {
  // Score column updates every ~7s server-side (per-match cache-bypass
  // refresh loop in scanner.ts). We must guarantee the client never
  // receives a 304 against a stale cached body when a goal lands.
  //
  // Express's `res.json()` generates an ETag during `send` (gated on
  // `app.get('etag fn')`), so calling `removeHeader('ETag')` beforehand
  // is ineffective — the ETag is re-added later in the pipeline. Bypass
  // it by serializing manually and using `res.end()`, which does not
  // touch ETag generation. Combined with `Cache-Control: no-store` this
  // gives us a hard guarantee: every poll receives the fresh body.
  // The payload is small (~few KB per poll) — the extra bandwidth vs.
  // a 304 is negligible compared to the user-visible cost of a stuck
  // live score.
  const body = JSON.stringify({
    ok: true,
    ...watchlistSnapshot(),
    excapperHealth: getExcapperHealth(),
    runtimeAudit: getRuntimeAudit(),
  });
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Pragma", "no-cache");
  res.end(body);
});

/**
 * Authenticated by the router-level middleware. This is a read-only operator
 * dump and intentionally performs no refresh, binding, or scanner mutation.
 */
router.post("/watchlist/runtime-audit", (req, res) => {
  const runtimeAudit = getRuntimeAudit();
  req.log.info(
    {
      matches: runtimeAudit.matches,
      totalTrackedCount: runtimeAudit.total,
      watchlistTotal: runtimeAudit.watchlistTotal,
    },
    `Активных матчей в списке наблюдения: ${runtimeAudit.watchlistTotal}`,
  );
  res.json({ ok: true, runtimeAudit });
});

router.get("/watchlist/runtime-archive", (_req, res) => {
  const matches = getRuntimeArchiveRows();
  res.setHeader("Cache-Control", "no-store");
  res.json({ ok: true, matches, total: matches.length });
});

/**
 * POST /api/watchlist
 *
 * Body: { input: string } — either plain text ("Dinamo vs Besiktas") or a
 * NowGoal26 match URL. We parse, optionally resolve a numeric match id
 * against the scanner's last-seen meta, append to config/watchlist.json,
 * and trigger an immediate hot-reload. The next scanner tick will treat
 * the match as priority (bypasses the global-pool throttle).
 */
router.post("/watchlist", async (req, res) => {
  const body = (req.body ?? {}) as { input?: unknown };
  const input = typeof body.input === "string" ? body.input : "";
  if (!input.trim()) {
    res.status(400).json({ ok: false, error: "Missing 'input' string in request body" });
    return;
  }

  const parsed = parseWatchlistInput(input);
  if (parsed.kind === "error") {
    res.status(400).json({ ok: false, error: parsed.error });
    return;
  }

  let entry: { label: string; teams: string[]; matchId?: string; league?: string };
  if (parsed.kind === "matchId") {
    // Always carry the numeric matchId so the scanner can look it up
    // directly in matchStates — no fuzzy text matching required, which
    // is critical for regional leagues whose team-name strings on the
    // site (e.g., "UNSW FC (W)") don't match the feed strings.
    const meta = lookupMatchMetaById(parsed.matchId);
    if (meta) {
      // Bonus: enrich with team names if we already have meta for this id.
      // Both will work — the id is the canonical lookup, fragments give a
      // friendly label and a fallback if the id is ever absent from a feed.
      entry = {
        label: `${meta.team1} vs ${meta.team2}`,
        teams: [meta.team1, meta.team2],
        matchId: parsed.matchId,
      };
      const canonicalLeague = matchTargetLeague(meta.leagueName);
      if (canonicalLeague) entry.league = canonicalLeague;
    } else {
      // Match not yet in feed (regional/minor league, or pre-kickoff). Store
      // it anyway — the next scanner tick that sees this id will populate
      // live odds, no extra HTTP call needed because the id is in the
      // existing bulk goal8.xml feed once it appears.
      entry = {
        label: `Match #${parsed.matchId}`,
        teams: [],
        matchId: parsed.matchId,
      };
    }
  } else {
    entry = {
      label: parsed.label,
      teams: parsed.teams,
      ...(parsed.matchId ? { matchId: parsed.matchId } : {}),
    };
  }

  try {
    const result = await addWatchlistEntry(entry);
    req.log.info(
      { entry, added: result.added, reason: result.reason },
      "Watchlist entry add requested",
    );
    const refreshId = entry.matchId ?? result.existingMatchId;
    if (refreshId) {
      // New and duplicate manual URL pins both mean "refresh this fixture".
      // scanner.ts coalesces concurrent requests and bounds the direct
      // enrichment fan-out; this does not create a second recurring loop.
      // Do not hold the mutation response open for slow upstream mirrors:
      // the dashboard can render/expand the persisted loading row immediately
      // while this bounded enrichment fills its score and bookmaker grid.
      void requestManualWatchlistRefresh([refreshId])
        .then(async () => {
          const result = await requestManualExcapperHydration([refreshId]);
          req.log.info(
            { matchId: refreshId, ...result },
            "Background manual Excapper binding/hydration completed",
          );
        })
        .catch((err) => {
          req.log.warn(
            { err, matchId: refreshId },
            "Background manual watchlist refresh/binding failed",
          );
        });
    }
    if (!result.added && result.reason === "already in watchlist") {
      res.status(200).json({
        ok: true,
        added: false,
        reason: result.reason,
        entry,
        signature: entrySignature(entry.teams, refreshId),
        snapshot: watchlistSnapshot(),
        excapperHealth: getExcapperHealth(),
      });
      return;
    }
    res.json({
      ok: true,
      added: result.added,
      entry,
      signature: entrySignature(entry.teams, entry.matchId),
      snapshot: watchlistSnapshot(),
      excapperHealth: getExcapperHealth(),
    });
  } catch (err) {
    req.log.error({ err, entry }, "Watchlist add failed");
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

/**
 * DELETE /api/watchlist/:signature
 *
 * Removes a watchlist entry by its fragment signature (the value returned
 * in the snapshot's `signature` field).
 */
router.delete("/watchlist/:signature", async (req, res) => {
  const sig = req.params["signature"] ?? "";
  if (!sig) {
    res.status(400).json({ ok: false, error: "Missing signature" });
    return;
  }
  try {
    const removedEntry = getNormalizedEntries().find(
      (candidate) => candidate.signature === sig,
    );
    if (removedEntry?.matchId) {
      // Detach before persistence removes manual membership; the hydration
      // writer also rechecks membership, so an in-flight fetch cannot restore it.
      clearManualMatchVolumeBinding(removedEntry.matchId);
      releaseManualExcapperBinding(removedEntry.matchId);
    } else {
      clearManualTextMatchVolumeBinding(removedEntry?.fragments ?? []);
      if (removedEntry) {
        releaseManualExcapperBinding(`manual-text:${removedEntry.signature}`);
      }
    }
    const result = await removeWatchlistEntry(sig);
    if (removedEntry?.matchId) {
      releaseManualExcapperBinding(removedEntry.matchId);
    } else if (removedEntry) {
      releaseManualExcapperBinding(`manual-text:${removedEntry.signature}`);
    }
    req.log.info({ signature: sig, removed: result.removed }, "Watchlist entry remove requested");
    res.json({
      ok: true,
      ...result,
      snapshot: watchlistSnapshot(),
      excapperHealth: getExcapperHealth(),
    });
  } catch (err) {
    req.log.error({ err, signature: sig }, "Watchlist remove failed");
    res.status(500).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

/**
 * POST /api/watchlist/:signature/refresh
 *
 * Force a bounded, cache-bypassing Excapper discovery for an existing manual
 * pin without changing watchlist membership. Numeric pins also refresh their
 * NowGoal score/events first; text pins run Excapper identity discovery only.
 */
router.post("/watchlist/:signature/refresh", async (req, res) => {
  const sig = req.params["signature"] ?? "";
  const entry = getNormalizedEntries().find((candidate) => candidate.signature === sig);
  if (!entry) {
    res.status(404).json({ ok: false, error: "Watchlist entry not found" });
    return;
  }
  try {
    await runExplicitRefresh(sig, entry.matchId);
    const snapshot = watchlistSnapshot();
    res.json({
      ok: true,
      refreshed: true,
      row: snapshotRow(snapshot, sig),
      snapshot,
      excapperHealth: getExcapperHealth(),
    });
  } catch (err) {
    req.log.error({ err, signature: sig }, "Watchlist deep refresh failed");
    const health = getExcapperHealth();
    if (
      err instanceof ExcapperExplicitRefreshRateLimitError ||
      health.lastErrorStatus === 429
    ) {
      const retryAfterMs = err instanceof ExcapperExplicitRefreshRateLimitError
        ? err.retryAfterMs
        : Math.max(0, (health.retryAt ?? Date.now()) - Date.now());
      const status = err instanceof ExcapperExplicitRefreshRateLimitError
        ? err.status
        : 429;
      res.status(status).json({
        ok: false,
        error: status === 429
          ? "Excapper is rate limited. Retry after the shared cooldown."
          : "Excapper is temporarily unavailable. Retry after the shared cooldown.",
        retryAfterMs,
        excapperHealth: health,
      });
      return;
    }
    res.status(502).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      excapperHealth: health,
    });
  }
});

/**
 * Persist a league-identity approval and bind the one exact server-resolved
 * fixture. The client supplies only the opaque candidate handle; all identity,
 * live-state and source fields are derived and revalidated server-side.
 */
router.post("/watchlist/:signature/league-alias-approval", async (req, res) => {
  const signature = req.params["signature"] ?? "";
  const entry = getNormalizedEntries().find((candidate) => candidate.signature === signature);
  if (!entry || entry.origin !== "manual") {
    res.status(409).json({
      ok: false,
      error: "The manual watchlist row no longer exists. No alias was saved.",
    });
    return;
  }
  const requestBody = req.body as {
    resolvedCandidate?: unknown;
    explicitConfirmation?: unknown;
  } | undefined;
  if (requestBody?.explicitConfirmation !== true) {
    res.status(400).json({ ok: false, error: "Explicit confirmation is required." });
    return;
  }
  const diagnosticId = entry.matchId ?? `manual-text:${entry.signature}`;
  try {
    let candidate = typeof requestBody?.resolvedCandidate === "string"
      ? requestBody.resolvedCandidate
      : "";
    if (!/^[A-Za-z0-9_-]{20,100}$/.test(candidate)) {
      await requestManualExcapperHydration(entry.matchId ? [entry.matchId] : undefined);
      const diagnostic = getExcapperBindingDiagnostic(diagnosticId);
      const discovered = diagnostic.candidates ?? [];
      if (discovered.length === 0 && diagnostic.resolvedCandidate) {
        candidate = diagnostic.resolvedCandidate;
      }
      if (!candidate && discovered.length !== 1) {
        throw new LeagueAliasApprovalConflict(
          discovered.length > 1
            ? "Multiple live candidates were found. Select a candidate and retry."
            : "No live Excapper event is available yet. Retry discovery when the event appears.",
        );
      }
      if (!candidate) candidate = discovered[0]!.ref;
    }
    const binding = await approveResolvedManualLeagueAlias(
      diagnosticId,
      candidate,
      true,
    );
    res.json({
      ok: true,
      approval: {
        saved: true,
        created: binding.created,
        scope: "manual_fixture_binding",
      },
      binding: {
        status: binding.status,
        volumePending: binding.status === "bound_pending",
        mode: getExcapperBindingDiagnostic(diagnosticId).bindingMode ?? "automatic",
      },
      row: watchlistSnapshot().entries.find(
        (row) => row.signature === entry.signature,
      ) ?? null,
    });
  } catch (err) {
    if (err instanceof LeagueAliasApprovalConflict) {
      const refreshed = getExcapperBindingDiagnostic(diagnosticId);
      res.status(409).json({
        ok: false,
        error: err.message,
        resolvedCandidate: refreshed.resolvedCandidate ?? null,
        candidates: refreshed.candidates ?? [],
      });
      return;
    }
    req.log.error({ err, signature }, "Manual league alias approval failed");
    res.status(500).json({
      ok: false,
      error: "The league alias could not be saved. Nothing was bound; please retry.",
    });
  }
});

/**
 * Explicit operator override. Unlike discovery approval, this route remains
 * usable after a displayed candidate has fallen out of the transient cache.
 */
router.post("/matches/bind", async (req, res) => {
  const body = req.body as Record<string, unknown> | undefined;
  const rawNowgoalId = body?.nowgoalId;
  const nowgoalId = typeof rawNowgoalId === "string"
    ? rawNowgoalId.trim()
    : typeof rawNowgoalId === "number" &&
        Number.isSafeInteger(rawNowgoalId) && rawNowgoalId >= 0
      ? rawNowgoalId
      : "";
  if (nowgoalId === "" || !/^\d+$/.test(String(nowgoalId))) {
    res.status(400).json({ success: false, ok: false, error: "NowGoal ID is required" });
    return;
  }
  if (body?.force !== true) {
    res.status(400).json({ success: false, ok: false, error: "Explicit force confirmation is required" });
    return;
  }
  const source = body?.source && typeof body.source === "object"
    ? body.source as Partial<{ team1: string; team2: string; league: string }>
    : undefined;
  try {
    const binding = await forceManualExcapperBinding({
      nowgoalId,
      ...(typeof body.excapperId === "string" || typeof body.excapperId === "number"
        ? { excapperId: body.excapperId } : {}),
      ...(typeof body.candidateId === "string" || typeof body.candidateId === "number"
        ? { candidateId: body.candidateId } : {}),
      ...(typeof body.suggestedId === "string" || typeof body.suggestedId === "number"
        ? { suggestedId: body.suggestedId } : {}),
      ...(typeof body.candidateExcapperId === "string" || typeof body.candidateExcapperId === "number"
        ? { candidateExcapperId: body.candidateExcapperId } : {}),
      ...(typeof body.signature === "string" ? { signature: body.signature } : {}),
      ...(source ? { source } : {}),
    });
    // Verification approves the NowGoal fixture independently of whether an
    // Excapper id has been discovered. Use the ordinary manual priority path;
    // never pass FORCE_MANUAL to either upstream.
    if (!getNormalizedEntries().some((entry) => entry.matchId === String(nowgoalId))) {
      const enrollment = await addWatchlistEntry({
        matchId: String(nowgoalId),
        teams: [],
        source: "manual",
      });
      if (!enrollment.added && !getNormalizedEntries().some(
        (entry) => entry.matchId === String(nowgoalId),
      )) {
        throw new Error(enrollment.reason ?? "Manual hydration enrollment failed");
      }
    }
    // Bounded single-flight hydration must not delay the confirmation on an
    // unavailable upstream. Existing scanner loops own subsequent refreshes.
    void requestManualWatchlistRefresh([String(nowgoalId)])
      .then(async () => {
        if (binding.excapperId !== "FORCE_MANUAL") {
          await requestManualExcapperHydration([String(nowgoalId)], { fresh: true });
        }
      }).catch((err) => {
        req.log.warn({ err, nowgoalId }, "Verified fixture source refresh failed");
      });
    res.json({
      success: true,
      ok: true,
      message: "Матч успешно привязан",
      binding,
    });
  } catch (error) {
    req.log.error({ err: error, nowgoalId: String(nowgoalId) }, "Force binding failed");
    res.status(500).json({
      success: false,
      ok: false,
      error: "Failed to complete force binding",
    });
  }
});

/** Clear one verified binding without deleting the watchlist row. */
router.post("/watchlist/:signature/excapper-binding/reset", async (req, res) => {
  const signature = req.params["signature"] ?? "";
  const entry = getNormalizedEntries().find((candidate) => candidate.signature === signature);
  if (!entry || entry.origin !== "manual" || !entry.matchId) {
    res.status(409).json({ ok: false, error: "The manual watchlist row no longer exists." });
    return;
  }
  try {
    await resetManualExcapperBinding(entry.matchId);
    res.json({
      ok: true,
      reset: true,
      row: watchlistSnapshot().entries.find((row) => row.signature === signature) ?? null,
    });
  } catch (err) {
    req.log.error({ err, signature }, "Manual Excapper binding reset failed");
    res.status(500).json({
      ok: false,
      error: "Reset could not be saved. The verified binding was kept unchanged.",
    });
  }
});

export default router;
