/**
 * Dashboard config endpoints for the Excapper / Betfair volume scanner.
 *
 *  GET  /api/config/volume   → current { minSingleSpikeEur, minCumulativeEur, linesToTrack }
 *  POST /api/config/volume   → patch any subset of the above.
 *  Deprecated numeric POST aliases minSingleSpikeUsd/minCumulativeUsd remain
 *  accepted for existing consumers. Responses always emit canonical EUR names,
 *  and aliases are relabeled without conversion.
 *
 * Both routes are mounted behind requireAuth in routes/index.ts. Hot path
 * (the global worker) reads via getVolumeConfig() on every tick, so a POST
 * here takes effect on the very next cycle — no restart needed.
 */
import { Router } from "express";
import { getVolumeConfig, updateVolumeConfig } from "../lib/volumeConfig";

const router = Router();

router.get("/config/volume", (_req, res) => {
  res.json({ ok: true, config: getVolumeConfig() });
});

router.post("/config/volume", async (req, res) => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  // Coerce strings → numbers for dashboard <input type="number"> values
  // which may arrive as strings depending on form serialization.
  const patch: {
    minSingleSpikeEur?: number;
    minCumulativeEur?: number;
    linesToTrack?: number[];
  } = {};
  const singleValue = body["minSingleSpikeEur"] ?? body["minSingleSpikeUsd"];
  if (singleValue !== undefined) {
    const n = typeof singleValue === "string" ? parseFloat(singleValue) : singleValue;
    if (typeof n === "number" && isFinite(n)) patch.minSingleSpikeEur = n;
  }
  // Deprecated aliases are accepted because older dashboard builds may still
  // POST them. They are numeric aliases only; no conversion is performed.
  const cumulativeValue = body["minCumulativeEur"] ?? body["minCumulativeUsd"];
  if (cumulativeValue !== undefined) {
    const n = typeof cumulativeValue === "string" ? parseFloat(cumulativeValue) : cumulativeValue;
    if (typeof n === "number" && isFinite(n)) patch.minCumulativeEur = n;
  }
  if ("linesToTrack" in body) {
    const raw = body["linesToTrack"];
    if (Array.isArray(raw)) {
      patch.linesToTrack = raw
        .map((x) => (typeof x === "number" ? x : parseFloat(String(x))))
        .filter((n) => isFinite(n));
    } else if (typeof raw === "string") {
      // Accept "1.5, 2.5, 3.5" comma/space-separated. Empty string = clear.
      patch.linesToTrack = raw
        .split(/[\s,]+/)
        .map((s) => parseFloat(s))
        .filter((n) => isFinite(n));
    }
  }

  try {
    const next = await updateVolumeConfig(patch);
    req.log.info({ patch, next }, "Volume config updated");
    res.json({ ok: true, config: next });
  } catch (err) {
    req.log.error({ err, patch }, "Volume config update failed");
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

export default router;
