/**
 * Read-only historical win-rate endpoints.
 *
 *  GET /api/winrate/stats   → overall aggregate across all recorded anomalies:
 *    counts by lifecycle status (pending/win/loss/void), the resolved-only
 *    win-rate percentage, and a per (type|side) breakdown.
 *
 *  GET /api/winrate/history → paginated list of individual anomaly snapshots,
 *    newest-first. Supports ?type=ODDS_DROP|MONEY_SPIKE, ?side=OVER|UNDER,
 *    ?status=PENDING|WIN|LOSS|VOID, ?days=N, ?limit=N, ?offset=N.
 *
 * Both endpoints are mounted behind requireAuth in routes/index.ts.
 */
import { Router } from "express";
import { getOverallStats, getAnomalyHistory, type AnomalyType, type TargetSide } from "../lib/winRate";

const router = Router();

router.get("/winrate/stats", async (req, res) => {
  try {
    const stats = await getOverallStats();
    res.json({ ok: true, stats });
  } catch (err) {
    req.log.error({ err }, "Failed to load win-rate stats");
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

const VALID_TYPES = new Set(["ODDS_DROP", "MONEY_SPIKE", "SMART_MONEY", "EXCAPPER", "RADAR_DROP", "RADAR_RISE", "RADAR_LINE", "RADAR_REVERT"]);
const VALID_SIDES = new Set(["OVER", "UNDER", "HOME", "AWAY"]);
const VALID_STATUSES = new Set(["PENDING", "WIN", "LOSS", "VOID"]);

router.get("/winrate/history", async (req, res) => {
  try {
    const { type, side, status, days, limit, offset } = req.query as Record<string, string | undefined>;

    const anomalyType = type && VALID_TYPES.has(type) ? (type as AnomalyType) : undefined;
    const targetSide = side && VALID_SIDES.has(side) ? (side as TargetSide | "HOME" | "AWAY") : undefined;
    const statusFilter = status && VALID_STATUSES.has(status) ? status : undefined;
    const daysNum = days ? Math.min(Math.max(1, parseInt(days, 10) || 30), 365) : undefined;
    const limitNum = limit ? Math.min(Math.max(1, parseInt(limit, 10) || 50), 200) : 50;
    const offsetNum = offset ? Math.max(0, parseInt(offset, 10) || 0) : 0;

    const result = await getAnomalyHistory({
      anomalyType,
      targetSide,
      status: statusFilter,
      days: daysNum,
      limit: limitNum,
      offset: offsetNum,
    });
    res.json({ ok: true, ...result });
  } catch (err) {
    req.log.error({ err }, "Failed to load win-rate history");
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

export default router;
