import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Request, Response } from "express";

const ctl = vi.hoisted(() => ({
  entries: [] as Array<{ matchId: string }>,
  bind: vi.fn(),
  add: vi.fn(),
  refresh: vi.fn(),
}));
vi.mock("../lib/excapper", async (original) => ({
  ...await original<typeof import("../lib/excapper")>(),
  forceManualExcapperBinding: ctl.bind,
}));
vi.mock("../lib/watchlist", async (original) => ({
  ...await original<typeof import("../lib/watchlist")>(),
  getNormalizedEntries: () => ctl.entries,
  addWatchlistEntry: ctl.add,
}));
vi.mock("../lib/scanner", async (original) => ({
  ...await original<typeof import("../lib/scanner")>(),
  requestManualWatchlistRefresh: ctl.refresh,
}));
import router from "./watchlist";

const handler = router.stack.find((layer) =>
  layer.route?.path === "/matches/bind",
)!.route!.stack[0]!.handle;

async function submit(body: Record<string, unknown>) {
  const res = { status: vi.fn(), json: vi.fn() };
  res.status.mockReturnValue(res);
  await handler({
    body, log: { error: vi.fn(), warn: vi.fn() },
  } as unknown as Request, res as unknown as Response, vi.fn());
  return res;
}

describe("operator-approved NowGoal hydration enrollment", () => {
  beforeEach(() => {
    ctl.entries = [];
    ctl.bind.mockReset().mockResolvedValue({ nowgoalId: "3094867", excapperId: "FORCE_MANUAL" });
    ctl.refresh.mockReset().mockResolvedValue(undefined);
    ctl.add.mockReset().mockImplementation(async ({ matchId }) => {
      ctl.entries.push({ matchId });
      return { added: true };
    });
  });

  it("enrolls and immediately refreshes a no-source-id approval", async () => {
    const res = await submit({ nowgoalId: "3094867", force: true });
    expect(ctl.add).toHaveBeenCalledWith({
      matchId: "3094867", teams: [], source: "manual",
    });
    expect(ctl.refresh).toHaveBeenCalledWith(["3094867"]);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ success: true }));
  });

  it("preserves existing pin metadata and still refreshes duplicate confirmation", async () => {
    ctl.entries = [{ matchId: "3094867" }];
    await submit({ nowgoalId: 3094867, force: true });
    expect(ctl.add).not.toHaveBeenCalled();
    expect(ctl.refresh).toHaveBeenCalledWith(["3094867"]);
  });

  it("does not enroll or refresh a rejected binding", async () => {
    ctl.bind.mockRejectedValueOnce(new Error("conflicting binding"));
    const res = await submit({ nowgoalId: "3094867", force: true });
    expect(res.status).toHaveBeenCalledWith(500);
    expect(ctl.add).not.toHaveBeenCalled();
    expect(ctl.refresh).not.toHaveBeenCalled();
  });

  it("rejects a non-fetchable NowGoal identity before binding", async () => {
    const res = await submit({ nowgoalId: "FORCE_MANUAL", force: true });
    expect(res.status).toHaveBeenCalledWith(400);
    expect(ctl.bind).not.toHaveBeenCalled();
  });
});