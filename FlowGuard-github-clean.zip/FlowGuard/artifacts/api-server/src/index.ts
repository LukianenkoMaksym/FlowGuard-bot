import app from "./app";
import { logger } from "./lib/logger";
import { initManualExcapperBindingBlocks } from "./lib/excapper";
import { startScanCoordinator } from "./lib/scanCoordinator";
import { initVolumeConfig } from "./lib/volumeConfig";
import { startTelegramBot } from "./lib/telegramBot";
import { startPreMatchAlerts } from "./lib/preMatchAlerts";
import { startGlobalLiveSpikeWatch } from "./lib/globalLiveSpikeWatch";
import { startOddsAnomalyRadar } from "./lib/oddsAnomalyRadar";
import { startWinRateTracker } from "./lib/winRate";
import { initControls } from "./lib/controls";
import { initScannerConfig, getScannerConfigSources } from "./lib/scannerConfig";
import { startAutoTuner, stopAutoTuner } from "./lib/autoTuner";
import { randomUUID } from "node:crypto";
import {
  registerManualVolumeFreshScoreValidator,
  startManualWatchlistVolumeAlertRecovery,
} from "./lib/manualWatchlistVolumeAlerts";
import { fetchFreshScoreNow } from "./lib/scanner";
import { initManualLeagueAliases } from "./lib/manualLeagueAliases";
import { initBindingDecisionAudit } from "./lib/bindingDecisionAudit";
import { TelegramDiagnostics, diagnosticsOwner, getExcapperDiagnostics, installTelegramDiagnostics, stopTelegramDiagnostics } from "./lib/telegramDiagnostics";
import { getScannerTelegramDiagnostics, getScannerConfig } from "./lib/scanner";
import { getRadarTelegramDiagnostics } from "./lib/oddsAnomalyRadar";
import { autoTunerSnapshot } from "./lib/autoTuner";
import { sendTelegramTo } from "./lib/telegram";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);
const bootId = randomUUID();
const bootAt = Date.now();

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Manual controls MUST be loaded before the HTTP server accepts requests and
// before the scanner starts: routes read/mutate them, telegram.ts consults
// alertsMuted on every broadcast, and scanner.ts gates the alt-stream /
// score-watchdog starts on them. A load failure falls back to defaults
// inside initControls() — boot never blocks on it.
initBindingDecisionAudit();
logger.info(`[BOOT] id=${bootId}`);
void Promise.all([
  initControls(),
  initScannerConfig(),
  initManualLeagueAliases(),
  initManualExcapperBindingBlocks(),
]).then(() =>
app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  const owner = diagnosticsOwner();
  if (!owner) logger.warn("[DIAGNOSTICS] TELEGRAM_OWNER_USER_ID missing or invalid; owner commands and watchdog disabled");
  installTelegramDiagnostics(new TelegramDiagnostics(owner, () => ({
    scanner: getScannerTelegramDiagnostics(),
    radar: getRadarTelegramDiagnostics(),
    excapper: getExcapperDiagnostics(),
    dropThreshold: getScannerConfig().dropThreshold,
    dropThresholdSource: getScannerConfigSources().dropThreshold,
    tunerState: autoTunerSnapshot().state,
  }), (recipient, text) => sendTelegramTo(recipient, text, { parseMode: "plain" }), bootId, bootAt));
  process.once("SIGTERM", stopTelegramDiagnostics);
  process.once("SIGINT", stopTelegramDiagnostics);
  registerManualVolumeFreshScoreValidator(fetchFreshScoreNow);
  // Durable alert recovery is independent of scanner rediscovery. Storage
  // failures are retained as health state and retried by its bounded worker.
  startManualWatchlistVolumeAlertRecovery();
  // One completion-anchored owner runs active work sequentially every 12s and
  // folds directory discovery into that chain no more often than every 60s.
  void Promise.all([initVolumeConfig(), startPreMatchAlerts()]).then(() => {
    startGlobalLiveSpikeWatch();
    startOddsAnomalyRadar();
    startScanCoordinator();
  });
  // Telegram /start subscription listener. Loads the persisted subscriber list
  // and long-polls for /start and /stop so alerts broadcast to every opted-in
  // chat (in addition to the admin chat). Safe to start unconditionally — it
  // no-ops when TELEGRAM_TOKEN is unset.
  void startTelegramBot();
  // Pre-match reminder scheduler. Polls the META feed for upcoming fixtures in a
  // curated set of target leagues and broadcasts a Telegram reminder ~24h, ~5h
  // and ~1h before kickoff (deduped + persisted). No-ops if Telegram is unset.
  // Dynamic Win-Rate Tracker: warms its in-memory caches from Postgres, then
  // runs a background resolver that settles PENDING anomaly snapshots to
  // WIN/LOSS after their match finishes. Feeds the live win-rate column shown
  // in the Priority Watchlist. Safe to start unconditionally.
  startWinRateTracker();
  startAutoTuner();
  process.once("SIGTERM", stopAutoTuner);
  process.once("SIGINT", stopAutoTuner);
}));
