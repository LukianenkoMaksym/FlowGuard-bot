/**
 * A bounded verification budget must rotate through every eligible ID, not
 * repeatedly verify the first ten schedule rows. Independent cursors prevent
 * manual pins or a large directory from starving the remaining feed.
 */
export function selectLiveVerificationIds(
  eligibleIds: readonly string[],
  manualIds: ReadonlySet<string>,
  discoveryIds: ReadonlySet<string>,
  limit: number,
  cursors: { manual: number; discovery: number; other: number },
): string[] {
  if (limit <= 0) return [];
  const manual: string[] = [];
  const discovery: string[] = [];
  const other: string[] = [];
  for (const id of eligibleIds) {
    if (manualIds.has(id)) manual.push(id);
    else if (discoveryIds.has(id)) discovery.push(id);
    else other.push(id);
  }
  const selected: string[] = [];
  const take = (ids: string[], key: keyof typeof cursors, count: number): void => {
    if (!ids.length) return;
    let visited = 0;
    let taken = 0;
    while (visited < ids.length && taken < count) {
      const id = ids[(cursors[key] + visited) % ids.length];
      visited++;
      if (selected.includes(id)) continue;
      selected.push(id);
      taken++;
    }
    cursors[key] = (cursors[key] + visited) % ids.length;
  };
  take(manual, "manual", Math.max(1, Math.floor(limit / 5)));
  take(discovery, "discovery", Math.max(1, Math.floor(limit * 3 / 5)) - selected.length);
  take(other, "other", Math.max(1, limit - selected.length));
  // Donate unused reservations to whichever group still has unvisited rows.
  for (const [ids, key] of [[manual, "manual"], [discovery, "discovery"], [other, "other"]] as const) {
    take(ids, key, limit - selected.length);
  }
  return selected;
}