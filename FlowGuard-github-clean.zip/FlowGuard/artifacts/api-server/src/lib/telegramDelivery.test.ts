import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./logger", () => ({
  logger: {
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));
let alertsMuted = false;
vi.mock("./controls", () => ({ getControls: () => ({ alertsMuted }) }));
vi.mock("./telegramBroadcastRecipients.json", () => ({ default: { chatIds: [] } }));
vi.mock("./telegramSubscribers", () => ({
  ensureSubscribersLoaded: vi.fn(async () => {}),
  listSubscriberChatIds: () => ["subscriber"],
  removeSubscriber: vi.fn(async () => true),
}));

let sendTelegram: typeof import("./telegram").sendTelegram;

beforeAll(async () => {
  vi.stubEnv("TELEGRAM_TOKEN", "test-token");
  vi.stubEnv("TELEGRAM_CHAT_ID", "primary");
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("REPLIT_DEPLOYMENT", "1");
  ({ sendTelegram } = await import("./telegram"));
});

describe("primary Telegram destination commit", () => {
  beforeEach(() => {
    alertsMuted = false;
  });

  it("does not commit on subscriber-only success and skips that subscriber on retry", async () => {
    let primaryCalls = 0;
    const attempted: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (_url: unknown, init?: RequestInit) => {
      const body = JSON.parse(String(init?.body)) as { chat_id: string };
      attempted.push(body.chat_id);
      if (body.chat_id === "primary" && primaryCalls++ < 2) {
        return new Response("primary failed", { status: 500 });
      }
      return new Response("{}", { status: 200 });
    }));

    const first = await sendTelegram("test", { deliveryKey: "stable-event" });
    expect(first).toMatchObject({
      status: "failed",
      reason: "primary_delivery_failed",
      primaryDelivered: false,
      delivered: 1,
    });

    attempted.length = 0;
    const retry = await sendTelegram("test", { deliveryKey: "stable-event" });
    expect(retry).toMatchObject({
      status: "delivered",
      primaryDelivered: true,
      skippedAlreadyDelivered: 1,
    });
    expect(attempted).toEqual(["primary"]);
  });

  it("attaches a timeout signal to every outbound request", async () => {
    const signals: AbortSignal[] = [];
    vi.stubGlobal("fetch", vi.fn(async (_url: unknown, init?: RequestInit) => {
      expect(init?.signal).toBeInstanceOf(AbortSignal);
      signals.push(init!.signal!);
      return new Response("failed", { status: 500 });
    }));

    await expect(sendTelegram("timeout test", { deliveryKey: "bounded-request" })).resolves.toMatchObject({
      status: "failed",
      reason: "all_deliveries_failed",
      attempted: 2,
      failed: 2,
    });
    // Markdown failures get one plain-text attempt per recipient as well.
    expect(signals).toHaveLength(4);
  });

  it("reports mute explicitly and performs no delivery attempt", async () => {
    alertsMuted = true;
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);

    await expect(sendTelegram("muted", { deliveryKey: "muted-event" })).resolves.toEqual({
      status: "muted",
      reason: "alerts_muted",
      primaryDelivered: false,
      delivered: 0,
      attempted: 0,
      skippedAlreadyDelivered: 0,
      failed: 0,
      blocked: 0,
    });
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("deduplicates a fully delivered event without weakening primary confirmation", async () => {
    const fetchMock = vi.fn(async () => new Response("{}", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(sendTelegram("once", { deliveryKey: "duplicate-event" })).resolves.toMatchObject({
      status: "delivered",
      primaryDelivered: true,
      delivered: 2,
    });
    fetchMock.mockClear();
    await expect(sendTelegram("once", { deliveryKey: "duplicate-event" })).resolves.toMatchObject({
      status: "delivered",
      primaryDelivered: true,
      delivered: 0,
      attempted: 0,
      skippedAlreadyDelivered: 2,
    });
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("uses only the canonical Telegram sendMessage endpoint", async () => {
    const urls: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (url: string | URL | Request) => {
      urls.push(String(url));
      return new Response("{}", { status: 200 });
    }));

    await sendTelegram("endpoint", { deliveryKey: "endpoint-policy-event" });
    expect(urls).toEqual([
      "https://api.telegram.org/bottest-token/sendMessage",
      "https://api.telegram.org/bottest-token/sendMessage",
    ]);
  });
});