import { describe, expect, it } from "vitest";
import { parseLiveDirectory } from "./liveDiscovery";
import { matchTargetLeague } from "./targetLeagues";

describe("data-only current match discovery", () => {
  const envelope = (data: string) => JSON.stringify({ ErrCode: 0, Data: data });
  const directory = "B[7]=[1398,'ECU','Liga Pro Ecuador Serie B'];";
  const row = (state: number, index = 7) =>
    `A[0]=[3071680,${index},1,2,'CD Independiente Juniors','Vinotinto de Ecuador','2026,8,24,22,00,00',${state},1,1];`;
  it("joins B index, not actual league ID, and never confers live authority", () => {
    const result = parseLiveDirectory(envelope(row(3) + directory));
    expect(result.candidates.get("3071680")).toMatchObject({
      leagueId: "1398", leagueName: "Liga Pro Ecuador Serie B", isLive: false,
    });
    expect(result.candidates.get("3071680")).not.toHaveProperty("state");
  });
  it("excludes finished, scheduled, and unresolved directory references", () => {
    for (const data of [row(0), row(-1), row(3, 1398)]) {
      expect(parseLiveDirectory(envelope(directory + data)).candidates.size).toBe(0);
    }
  });
  it("rejects executable fields instead of evaluating upstream code", () => {
    expect(parseLiveDirectory(envelope(directory + row(3).replace(",3,1,1", ",process.exit(),1,1"))).candidates.size).toBe(0);
  });
  it("recognizes only the approved exact Ecuador alias", () => {
    expect(matchTargetLeague("Liga Pro Ecuador Serie B")).toBe("Ecuadorian Serie B");
    for (const name of ["Liga Pro Ecuador Serie A", "Liga Pro Ecuador Serie B Women",
      "Liga Pro Ecuador Serie B U21", "Liga Pro Ecuador Serie B Cup", "Ecuador Serie B",
      "Other Liga Pro Ecuador Serie B"]) expect(matchTargetLeague(name)).toBeNull();
  });
});