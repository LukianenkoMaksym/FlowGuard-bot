import { randomUUID } from "node:crypto";
import { bindingDecisionsTable, db, type BindingFixtureEvidence } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { logger } from "./logger";
import path from "node:path";
import { BindingDecisionOutbox, type PendingBindingDecision } from "./bindingDecisionOutbox";

export type { BindingFixtureEvidence };
export interface BindingDecision {
  id: string;
  action: "bind" | "reset";
  mode: "automatic" | "manual" | "manual_override";
  occurredAt: string;
  target: BindingFixtureEvidence;
  source: BindingFixtureEvidence;
  reason: string;
}

export function createBindingDecision(
  input: Omit<BindingDecision, "id" | "occurredAt">,
): BindingDecision {
  // Snapshot only explicitly allowed evidence; never accept source responses,
  // request headers, cookies, URLs, credentials, or mutable runtime objects.
  const snapshot = (value: BindingFixtureEvidence): BindingFixtureEvidence => ({
    id: value.id ?? null, home: value.home ?? null, away: value.away ?? null,
    league: value.league ?? null,
    score: value.score ? { home: value.score.home, away: value.score.away } : null,
    period: value.period ?? null, minute: value.minute ?? null,
  });
  return {
    id: randomUUID(), occurredAt: new Date().toISOString(),
    action: input.action, mode: input.mode, reason: input.reason,
    target: snapshot(input.target), source: snapshot(input.source),
  };
}

export async function persistBindingDecision(matchId: string, decision: BindingDecision): Promise<void> {
  await db.insert(bindingDecisionsTable).values({
    ...decision, matchId, occurredAt: new Date(decision.occurredAt),
  }).onConflictDoNothing({ target: bindingDecisionsTable.id });
}

export async function getBindingDecisionHistory(matchId: string): Promise<BindingDecision[]> {
  // GET remains strictly read-only. The writer retries independently; do not
  // claim an empty/complete history while an event for this fixture is pending.
  if (outbox.entries().some((entry) => entry.matchId === matchId)) {
    throw new Error("Binding decision persistence is pending");
  }
  const rows = await db.select().from(bindingDecisionsTable)
    .where(eq(bindingDecisionsTable.matchId, matchId))
    .orderBy(desc(bindingDecisionsTable.occurredAt), desc(bindingDecisionsTable.id));
  return rows.map(({ matchId: _matchId, occurredAt, ...decision }) => ({
    ...decision, occurredAt: occurredAt.toISOString(),
  }));
}

let outbox = new BindingDecisionOutbox(path.resolve(process.cwd(), "config/binding-decision-outbox.json"));
let flushing: Promise<void> | null = null;
let retry: ReturnType<typeof setTimeout> | null = null;

/**
 * Never undo a safety reset or change matcher/approval behavior when audit
 * database storage is unavailable. A local outbox write failure throws before
 * the caller changes the runtime binding. Keep the event ID on every retry so an
 * uncertain database acknowledgement cannot create duplicate decisions.
 * History reads fail explicitly until outstanding writes have been saved.
 */
export function recordBindingDecision(matchId: string, decision: BindingDecision): void {
  recordBindingDecisions([{ matchId, decision }]);
}

export function recordBindingDecisions(entries: PendingBindingDecision[]): void {
  try {
    outbox.append(entries);
  } catch {
    throw new Error("Binding decision could not be saved locally. No binding state was changed; please retry.");
  }
  startFlush();
}

function startFlush(): void {
  void flushBindingDecisions().catch(() => {
    logger.error("Binding decision audit persistence failed; retry scheduled");
    if (!retry) {
      retry = setTimeout(() => {
        retry = null;
        startFlush();
      }, 5_000);
      retry.unref();
    }
  });
}

export function flushBindingDecisions(): Promise<void> {
  if (flushing) return flushing;
  flushing = (async () => {
    while (outbox.entries().length > 0) {
      const entry = outbox.entries()[0]!;
      await persistBindingDecision(entry.matchId, entry.decision);
      // Only remove after confirmed insert (or confirmed duplicate). An
      // acknowledgement write failure leaves the same ID ready for replay.
      outbox.acknowledge(entry.decision.id);
    }
  })().finally(() => { flushing = null; });
  return flushing;
}

export function initBindingDecisionAudit(): void {
  try {
    outbox.load();
  } catch {
    logger.error("Binding decision outbox could not be loaded; binding actions will fail closed");
  }
  startFlush();
}

export function __testOnlySetBindingDecisionOutbox(filePath: string): void {
  if (retry) clearTimeout(retry);
  retry = null;
  outbox = new BindingDecisionOutbox(filePath);
}