import { describe, expect, it } from "vitest";
import { parseExcapperLiveState } from "./excapperLiveState";

describe("parseExcapperLiveState", () => {
  it("parses direct score keys with explicit live period and elapsed minute", () => {
    expect(parseExcapperLiveState({
      homeScore: "2", awayScore: 1, period: "2nd half", elapsed: "67'",
    })).toEqual({
      score: { home: 2, away: 1 }, period: "second-half", minute: 67,
      isLive: true, rawFound: true,
    });
  });

  it.each([
    ["1st", "first-half"],
    ["first", "first-half"],
    ["2nd", "second-half"],
    ["second", "second-half"],
  ] as const)("supports exact period alias %s", (input, period) => {
    expect(parseExcapperLiveState({ period: input })).toMatchObject({ period, isLive: true });
  });

  it.each(["67", "67'"])("uses numeric matchTime as minute evidence: %s", (matchTime) => {
    expect(parseExcapperLiveState({ score: "1-0", matchTime })).toEqual({
      score: { home: 1, away: 0 }, period: null, minute: 67,
      isLive: true, rawFound: true,
    });
  });

  it.each(["1-2", "1 : 2"])("parses the supported score string %s", (score) => {
    expect(parseExcapperLiveState({ score, status: "LIVE" })).toMatchObject({
      score: { home: 1, away: 2 }, isLive: true, rawFound: true,
    });
  });

  it("supports score objects, aliases, and arrays", () => {
    expect(parseExcapperLiveState({ currentScore: { h: 3, a: "2" }, matchTime: "HT" }))
      .toMatchObject({ score: { home: 3, away: 2 }, period: "half-time" });
    expect(parseExcapperLiveState({ scores: [0, 1], status: "первый тайм" }))
      .toMatchObject({ score: { home: 0, away: 1 }, period: "first-half" });
  });

  it("finds a bounded nested same-event payload and tolerates cycles", () => {
    const event: Record<string, unknown> = {
      fixture: { live: { currentScore: { home: 4, away: 3 }, phase: "extra time", clock: "103" } },
    };
    event.self = event;
    expect(parseExcapperLiveState(event)).toEqual({
      score: { home: 4, away: 3 }, period: "extra-time", minute: 103,
      isLive: true, rawFound: true,
    });
  });

  it("rejects ambiguous arrays containing multiple event scoreboards", () => {
    expect(parseExcapperLiveState({
      fixtures: [
        { id: "a", score: "1-0", period: "first" },
        { id: "b", score: "2-2", period: "second" },
      ],
    })).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
  });

  it("parses labeled embedded JSON and HTML evidence used by dynamic pages", () => {
    const html = `<script>window.event={"currentScore":"2:0","status":"2-й тайм","elapsed":"71"};</script>`;
    expect(parseExcapperLiveState(html)).toEqual({
      score: { home: 2, away: 0 }, period: "second-half", minute: 71,
      isLive: true, rawFound: true,
    });
    expect(parseExcapperLiveState(
      `<div data-score="1-1" data-period="Перерыв" data-minute="45"></div>`,
    )).toEqual({
      score: { home: 1, away: 1 }, period: "half-time", minute: 45,
      isLive: true, rawFound: true,
    });
  });

  it("excludes comment-only attributes and script fields from all live evidence", () => {
    expect(parseExcapperLiveState(`<!-- <div data-score="2-1" data-period="second-half" data-minute="57" data-live="true"></div>
      <script>window.event={"score":"2-1","status":"FT","elapsed":"57"};</script> -->`)).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
    expect(parseExcapperLiveState(`<!-- <div data-period="second-half" data-minute="57"></div> -->
      <div data-score="0-1" data-period="first-half" data-minute="1"></div>`)).toEqual({
      score: { home: 0, away: 1 }, period: "first-half", minute: 1, isLive: true, rawFound: true,
    });
  });

  it("does not fabricate defaults when data is absent or only a score exists", () => {
    expect(parseExcapperLiveState(null)).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
    expect(parseExcapperLiveState({ teams: ["A", "B"] })).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
    expect(parseExcapperLiveState({ score: "0-0" })).toEqual({
      score: { home: 0, away: 0 }, period: null, minute: null, isLive: false, rawFound: true,
    });
  });

  it("recognizes terminal states without reporting them live", () => {
    expect(parseExcapperLiveState({ score: "2-1", status: "FT" })).toEqual({
      score: { home: 2, away: 1 }, period: "finished", minute: null,
      isLive: false, rawFound: true,
    });
    expect(parseExcapperLiveState({ status: "Матч завершён" })).toEqual({
      score: null, period: "finished", minute: null, isLive: false, rawFound: true,
    });
  });

  it("lets a parent terminal state override richer nested live evidence", () => {
    expect(parseExcapperLiveState({
      status: "finished",
      data: { currentScore: "3-2", period: "second-half", elapsed: 90 },
    })).toEqual({
      score: { home: 3, away: 2 }, period: "finished", minute: 90,
      isLive: false, rawFound: true,
    });
  });

  it("does not mine odds, transaction history, dates, or historic FT score", () => {
    expect(parseExcapperLiveState({
      odds: { score: "1-2", elapsed: 65 },
      transactions: [{ score: "3-2", matchMinute: "82" }],
      history: { ft: "4-3" },
      kickoff: "2026-09-22 18:30",
    })).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
    expect(parseExcapperLiveState(`<div>22-09-2026</div><span>odds 1-2</span>`)).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
    expect(parseExcapperLiveState(
      `<script>window.data={"transactions":[{"score":"2-1","matchMinute":"77"}]}</script>`,
    )).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
  });

  it("does not infer a period from unrelated digits", () => {
    expect(parseExcapperLiveState({ status: "scheduled 18:10", date: "2026-10-01" })).toEqual({
      score: null, period: null, minute: null, isLive: false, rawFound: false,
    });
  });

  it("retains partial explicit evidence without inventing missing fields", () => {
    expect(parseExcapperLiveState({ elapsed: "45+2" })).toEqual({
      score: null, period: null, minute: 47, isLive: true, rawFound: true,
    });
    expect(parseExcapperLiveState({ period: "penalties" })).toEqual({
      score: null, period: "penalties", minute: null, isLive: true, rawFound: true,
    });
  });
});