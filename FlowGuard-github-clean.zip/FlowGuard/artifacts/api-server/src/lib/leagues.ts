/**
 * MAJOR (sharp/efficient) leagues — these are the deeply liquid markets where
 * a 0.40 odds drop is rarely "informational". We DON'T use them as primary
 * targets; instead we use them as benchmark cross-checks elsewhere.
 *
 * Kept tight on purpose. Historically a broader name-pattern list was used
 * (e.g. `\bpremier league\b`) but that swept in 24+ emerging-market top
 * tiers (Kenya, Israel, Bahrain, Kuwait, Kazakhstan, Hong Kong, Malta,
 * Azerbaijan, Armenia, Malawi, every Australian state league...) which is
 * the OPPOSITE of the global-coverage goal. IDs only now.
 *
 * IDs cross-checked against the live upstream feed (`?type=6`).
 */
const MAJOR_LEAGUE_IDS = new Set([
  // Tier-1 European domestic
  "36",   // English Premier League
  "31",   // Spanish La Liga
  "7",    // Spanish La Liga 2 (Segunda — still very liquid)
  "11",   // France Ligue 1
  "33",   // Germany Bundesliga
  "32",   // Italy Serie A
  "30",   // Portugal Primeira Liga
  "29",   // Scottish Premiership
  "28",   // Netherlands Eredivisie
  "9",    // Belgian Pro League
  "12",   // Austrian Bundesliga
  "39",   // Turkey Super Lig
  "6",    // Poland Ekstraklasa
  "119",  // Ukrainian Premier League
  "131",  // Bulgaria First League

  // Tier-1 non-European domestic
  "44",   // Saudi Professional League
  "21",   // USA MLS
  "140",  // Mexico Liga MX
  "2",    // Argentine Primera
  "186",  // Copa do Brasil (top)
  "18",   // Japan J1 League
  "43",   // Australia A-League

  // International tournaments — IDs intentionally omitted because the
  // upstream feed reuses low single-digit IDs for regional leagues
  // (e.g. id 3 = Indonesia Super League, id 5 = Liga Super Malaysia).
  // The MAJOR_NAME_PATTERNS regex below catches UEFA / FIFA / Copa events
  // by name, which is unambiguous for those tournaments.
]);

/**
 * Narrow name fallback for international tournaments only — these are
 * unambiguous and don't false-positive on country names.
 */
const MAJOR_NAME_PATTERNS = [
  /\bfifa world cup\b/i,
  /\buefa\b.*(champions|europa|conference|euro|nations)\b/i,
  /\bcopa (america|libertadores|sudamericana)\b/i,
];

export function isMajorLeague(leagueId: string, leagueName: string): boolean {
  if (MAJOR_LEAGUE_IDS.has(leagueId)) return true;
  return MAJOR_NAME_PATTERNS.some((p) => p.test(leagueName));
}

/**
 * Startup assertion: no league ID may appear in both MAJOR and LOW_LIQUIDITY
 * sets. A collision means one of them is misclassified — major-check runs
 * first and would silently skip a league we wanted to track. We fail loud at
 * import time so this can never ship undetected.
 */
function assertNoLeagueIdCollisions(): void {
  // LOW_LIQUIDITY_LEAGUE_IDS is declared below; reference it lazily.
  const collisions: string[] = [];
  for (const id of MAJOR_LEAGUE_IDS) {
    if (LOW_LIQUIDITY_LEAGUE_IDS.has(id)) collisions.push(id);
  }
  if (collisions.length > 0) {
    throw new Error(
      `[leagues] League ID(s) appear in both MAJOR and LOW_LIQUIDITY sets: ${collisions.join(", ")}. ` +
        `Major classification runs first and will silently skip these matches.`
    );
  }
}

/**
 * Leagues that historically have low betting volume / liquidity, often making
 * them susceptible to suspicious price action (the "fixed match" signature).
 * For these leagues we relax the spread gate — wide spreads are normal and
 * shouldn't suppress an otherwise significant odds drop.
 *
 * Inventory taken from upstream feed (see `?type=6`):
 *   • South America lower divisions, women's, youth
 *   • Central America & Caribbean
 *   • Africa
 */
const LOW_LIQUIDITY_LEAGUE_IDS = new Set([
  // South America (lower / regional / women / youth)
  "37",   // Peru Liga 1
  "42",   // Liga AUF Uruguaya
  "47",   // Chile Primera Division
  "51",   // Liga Pro Ecuador Serie A
  "83",   // Primera Division de Paraguay
  "84",   // Primera Division de Venezuela
  "92",   // Bolivia Primera Division
  "94",   // Colombia Copa Cup
  "102",  // Argentine Division 2
  "105",  // Chile Primera B
  "132",  // Brazil Youth
  "143",  // Paraguayan Division 2
  "152",  // Brazil Brasiliense DF Division 1
  "157",  // Uruguay Segunda
  "160",  // Peru B League
  "166",  // Brazil Paulista Serie B
  "174",  // Argentina women's league
  "184",  // Argentina Reserve League
  "201",  // Chile Tercera
  "204",  // Chile Primera Division Women
  "213",  // Brazil U20 national
  "226",  // Brazil Women's Tournament
  "233",  // Peru Campeonato Nacional Women
  "242",  // Paraguayan Division 3
  "249",  // Brazil Campeonato Catarinense U20

  // Central America & Caribbean
  "91",   // Honduras Liga Nacional
  "161",  // Panama Liga Nacional de Ascenso
  "172",  // Dominican Republic Liga
  "189",  // Curacao League
  "203",  // Costa Rica Primera Division Women
  "232",  // Honduras Reserve League

  // Africa
  "46",   // South Africa Premier Soccer League
  "54",   // Kenya Premier League
  "87",   // Morocco Cup
  "151",  // Zimbabwe Premier
  "155",  // Angola Girabola
  "164",  // Kenya Cup
  "170",  // Malawi Premier League
  "202",  // Cameroon Women

  // India & Subcontinent (explicitly added — historically over-filtered)
  "50",   // Indian Super League (ISL)
  "122",  // India League Division 1 (I-League)
  "190",  // India I-League 2nd Division

  // Broader Asia (regional / women / youth / lower) — emerging markets
  "3",    // Indonesia Super League
  "5",    // Liga Super Malaysia
  "45",   // UAE Pro-League
  "52",   // Chinese FA Cup
  "66",   // Israel Premier League
  "75",   // Singapore League
  "80",   // Bahraini Premier League
  "81",   // Kuwaiti Premier League
  "86",   // Kazakhstan Premier League
  "88",   // Armenia Premier League
  "89",   // Malta Premier League
  "93",   // Azerbaijan Premier League
  "96",   // Korea Challengers League
  "97",   // Korea League 4
  "99",   // Japan Football League (lower)
  "103",  // Japan Women's Football League 1
  "107",  // Japan Women's Football League 2
  "108",  // Hong Kong Premier League
  "109",  // Chinese Women's Super League
  "125",  // Uzbekistan Cup
  "133",  // Israel Youth League
  "139",  // Thai League 2
  "141",  // Iraq Stars League
  "168",  // Japan Regional League
  "178",  // Philippines UFL
  "205",  // Taiwan Mulan League Women
  "207",  // Vietnam Cup Women
  "217",  // Japanese WE League
  "221",  // Vietnamese First Division
  "238",  // China U21 League
  "245",  // UAE U23

  // Oceania (Australian state leagues, NZ, Pacific) — almost all are
  // regional/semi-pro and were being mass-filtered by `\bpremier league\b`
  "49",   // VIC Premier League
  "53",   // Australia Cup
  "95",   // NSW Premier League
  "104",  // FFSA Premier League
  "106",  // NPL Western Australia
  "111",  // QLD Premier League
  "121",  // South Australian Premier League
  "135",  // Northern NSW Premier League
  "136",  // Queensland Premier League 3
  "138",  // Australia W-League
  "145",  // Belgium Women's Premier League
  "153",  // QLD State Women's Premier League
  "163",  // NZ Central League
  "167",  // NSW League 2
  "169",  // NZ Northern League
  "171",  // NZ Southern League
  "176",  // Victoria State League
  "185",  // National Primera Western Australia
  "196",  // QLD State Leagues
  "198",  // WA State League 1 Reserves
  "206",  // Darwin Premier League
  "208",  // Northern NSW Reserves
  "209",  // ACT U23 League
  "215",  // NPL Queensland U23
  "216",  // Northern NSW Women's Premier League
  "231",  // Queensland Premier League 2
  "239",  // NPL Victoria U23
  "240",  // Victoria PL 1 U23
  "246",  // WA U23 League
  "247",  // NSW U20 Super League

  // Other European lower / women / youth that were name-pattern false positives
  "82",   // Estonia Champions League (NOT UEFA — Estonian top tier)
  "146",  // Romania Liga 2
  "199",  // Faroe Islands Division 1
  "222",  // Austrian Frauen Bundesliga (women)
  "223",  // Eredivisie Cup Women
  "224",  // Poland Mloda Ekstraklasa (youth)
  "244",  // Austrian Frauen Bundesliga 2
]);

/**
 * Name-based fallback. Casts a wide net by region — the goal is global
 * coverage with relaxed liquidity filtering for emerging markets. False
 * positives here only cause a SPREAD-CAP RELAXATION (not auto-acceptance),
 * so the cost of over-tagging is low.
 */
const LOW_LIQUIDITY_NAME_PATTERNS = [
  // South & Central America
  /\b(uruguay|paraguay|venezuela|bolivia|ecuador|colombia|peru|costa rica|honduras|guatemala|el salvador|nicaragua|panama|dominican|curacao|jamaic|trinidad|haiti|cuba)\b/i,
  /\b(brasil|brazil)\b.*(serie [bcd]|youth|u\d{2}|women|reserve|sub|catarinense|paulista|carioca|gaucho|mineir|baian)/i,
  /\bargent.*(division 2|division 3|reserve|women|sub|primera b|copa)\b/i,
  /\bchile.*(primera b|tercera|women|sub|copa)\b/i,
  // Africa
  /\b(south africa|kenya|morocco|zimbabwe|angola|cameroon|nigeria|ghana|tunisia|egypt|algeria|senegal|ivory coast|sudan|ethiopia|tanzania|uganda|zambia|mali|burkina|gabon|libya|mozambique|namibia|botswana|malawi|rwanda|congo|togo|benin|niger|guinea)\b/i,
  // India & Subcontinent
  /\b(india|indian|i-league|isl|santosh|durand|calcutta|kolkata|bengaluru|kerala|chennai|jamshedpur|hyderabad|mumbai|goa|odisha|punjab|delhi)\b/i,
  /\b(bangladesh|sri lanka|nepal|pakistan|bhutan|maldives|afghan|myanmar)\b/i,
  // Southeast & East Asia (lower / regional / women / youth)
  /\b(thai|vietnam|cambod|laos|indones|malays|singapor|philip|hong kong|taiwan|macau|mongolia)\b/i,
  /\b(japan|japanese|korea|korean|china|chinese)\b.*(women|youth|u\d{2}|reserve|league [234]|division [234]|regional|challenger|we league|wome)/i,
  // Central Asia / Middle East emerging markets
  /\b(uzbek|kazakh|tajik|kyrgy|turkmen|azerbai|armen|georgi)\b/i,
  /\b(iraq|iran|jordan|bahrain|kuwait|oman|qatar|emirat|lebanon|palestine|syria|yemen|israel)\b/i,
  // Oceania
  /\b(new zealand|fiji|tahiti|samoa|tonga|vanuatu|solomon|papua)\b/i,
  /\baustral.*(state|nsw|qld|vic|wa|sa|nt|act|reserve|u\d{2}|women|w-league|premier league \d|northern|southern|capital|darwin|victoria|queensland|tasman)\b/i,
  // European lower / women / youth that aren't tier-1
  /\b(malta|estonia|faroe|gibraltar|andorra|liechtenstein|san marino|moldova|montenegro|kosovo|north macedonia|albania|belarus|latvia|lithuania|cyprus|luxembourg|iceland)\b/i,
  /\b(women|wome\\?n|frauen|femin)\b.*(league|liga|cup|division|bundesliga|eredivisie)/i,
  /\b(youth|u\s?\d{2}|reserve|sub-?\d{2})\b/i,
];

export function isLowLiquidityLeague(leagueId: string, leagueName: string): boolean {
  if (LOW_LIQUIDITY_LEAGUE_IDS.has(leagueId)) return true;
  return LOW_LIQUIDITY_NAME_PATTERNS.some((p) => p.test(leagueName));
}

assertNoLeagueIdCollisions();
