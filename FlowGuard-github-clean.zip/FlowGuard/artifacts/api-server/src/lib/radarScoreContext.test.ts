import { beforeEach, describe, expect, it, vi } from "vitest";

const storage = vi.hoisted(() => ({
  rows: new Map<string, {
    matchId: string; homeScore: number; awayScore: number; observedAt: Date;
    goalAt: Date | null; safeAfter: Date; revision: number;
  }>(),
  fail: false,
}));
vi.mock("drizzle-orm", () => ({ eq: (_field: unknown, id: string) => id }));
vi.mock("@workspace/db", () => ({
  radarScoreContextTable: { matchId: "match_id" },
  db: {
    transaction: async (run: (tx: unknown) => Promise<unknown>) => {
      if (storage.fail) throw new Error("durable storage unavailable");
      const tx = {
        insert: () => ({
          values: (row: NonNullable<ReturnType<typeof storage.rows.get>>) => ({
            onConflictDoNothing: async () => {
              if (!storage.rows.has(row.matchId)) storage.rows.set(row.matchId, row);
            },
          }),
        }),
        select: () => ({
          from: () => ({
            where: (id: string) => ({
              for: async () => [storage.rows.get(id)],
            }),
          }),
        }),
        update: () => ({
          set: (patch: Partial<NonNullable<ReturnType<typeof storage.rows.get>>>) => ({
            where: (id: string) => {
              const update = () => {
                const updated = { ...storage.rows.get(id)!, ...patch };
                storage.rows.set(id, updated);
                return updated;
              };
              return { then: (resolve: (value: unknown) => void) => resolve(update()),
                returning: async () => [update()] };
            },
          }),
        }),
      };
      return run(tx);
    },
  },
}));

import { observeRadarScore } from "./radarScoreContext";

describe("durable RADAR score epoch", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(1_800_000_000_000);
    storage.rows.clear();
    storage.fail = false;
  });

  it("boots cold even at 1:0, restores the same epoch, and extends after a goal", async () => {
    const first = await observeRadarScore("match", 1, 0, null);
    expect(first).toMatchObject({ home: 1, away: 0, revision: 1,
      goalAt: null, safeAfter: Date.now() + 300_000 });
    vi.setSystemTime(Date.now() + 60_000);
    const restored = await observeRadarScore("match", 1, 0, null);
    expect(restored.safeAfter).toBe(first.safeAfter);
    expect(restored.revision).toBe(1);
    const changed = await observeRadarScore("match", 2, 0, null);
    expect(changed).toMatchObject({ home: 2, goalAt: Date.now(),
      safeAfter: Date.now() + 300_000, revision: 2 });
  });

  it("uses a new protective window after a long observation gap", async () => {
    await observeRadarScore("match", 0, 0, null);
    vi.setSystemTime(Date.now() + 11 * 60_000);
    const resumed = await observeRadarScore("match", 0, 0, null);
    expect(resumed).toMatchObject({ revision: 2, safeAfter: Date.now() + 300_000 });
    expect(resumed.goalAt).toBeNull(); // no invented goal
  });

  it("uses a fresh quarantine after an outage without rewriting a delayed goal timestamp", async () => {
    await observeRadarScore("match", 0, 0, null);
    const marker = Date.now() + 9 * 60_000;
    vi.setSystemTime(Date.now() + 11 * 60_000);
    expect(await observeRadarScore("match", 0, 0, marker)).toMatchObject({
      goalAt: marker, safeAfter: Date.now() + 300_000, revision: 2,
    });
  });

  it("propagates scanner goal markers and rejects an inaccessible database", async () => {
    await observeRadarScore("match", 0, 0, null);
    vi.setSystemTime(Date.now() + 60_000);
    const marker = Date.now() - 1_000;
    const changed = await observeRadarScore("match", 0, 0, marker);
    expect(changed).toMatchObject({ revision: 2, goalAt: marker,
      safeAfter: marker + 300_000 });
    storage.fail = true;
    await expect(observeRadarScore("match", 0, 0, null))
      .rejects.toThrow("durable storage unavailable");
  });

  it("merges a delayed authoritative marker even after the score heartbeat advances", async () => {
    const initial = await observeRadarScore("match", 1, 0, null);
    const marker = Date.now() + 120_000;
    vi.setSystemTime(Date.now() + 180_000);
    await observeRadarScore("match", 1, 0, null); // heartbeat later than goal marker
    const merged = await observeRadarScore("match", 1, 0, marker);
    expect(merged).toMatchObject({
      home: 1, goalAt: marker, safeAfter: marker + 300_000, revision: 2,
    });
    expect(merged.safeAfter).toBeGreaterThan(initial.safeAfter);
    vi.setSystemTime(Date.now() + 30_000);
    const repeated = await observeRadarScore("match", 1, 0, marker);
    expect(repeated).toMatchObject({ goalAt: marker, safeAfter: merged.safeAfter, revision: 2 });
  });

  it("fails closed when persisted timestamps or revision are future-dated or corrupt", async () => {
    await observeRadarScore("match", 0, 0, null);
    const row = storage.rows.get("match")!;
    row.observedAt = new Date(Date.now() + 60_000);
    await expect(observeRadarScore("match", 0, 0, null))
      .rejects.toThrow("invalid persisted epoch");
    row.observedAt = new Date(Date.now());
    row.safeAfter = new Date(NaN);
    await expect(observeRadarScore("match", 0, 0, null))
      .rejects.toThrow("invalid persisted epoch");
    row.safeAfter = new Date(Date.now() + 300_000);
    row.revision = -1;
    await expect(observeRadarScore("match", 0, 0, null))
      .rejects.toThrow("invalid persisted epoch");
  });
});