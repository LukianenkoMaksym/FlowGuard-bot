/**
 * Pre-match Telegram reminders for a curated list of target leagues.
 *
 * A self-contained background scheduler that polls the NowGoal META feed
 * (type=12) for upcoming fixtures and fires a Telegram reminder at three marks
 * before kickoff: ~24h, ~5h and ~1h. It is deliberately independent of the live
 * scanner's `matchStates` map because the target leagues here are low-liquidity
 * regional competitions that the scanner SKIPS for pre-match tracking — and
 * because the scanner never stores a fixture's kickoff timestamp. We therefore
 * parse the feed ourselves (kickoff, league id, teams) and resolve league names
 * from the type=6 feed.
 *
 * Arm-at-discovery + catch-up (why 5h/1h used to be missed): we do NOT require a
 * poll to land inside a tight window around each mark. The old design fired a
 * mark only when a poll happened to fall in `(mark - FIRE_WINDOW_MS, mark]`; the
 * 24h mark survived because the fixture is fresh in the feed and densely polled
 * at discovery, but a process restart (frequent on this platform) or a META-feed
 * outage that stepped over the much narrower 5h/1h windows lost those marks for
 * good. Instead, when a fixture is first discovered we "arm" every mark still in
 * the future (a small FIRE_WINDOW_MS grace lets a mark discovered a few minutes
 * late still count, preserving the original 24h behavior). An armed mark then
 * fires on the FIRST poll after its crossing no matter how large the gap was —
 * so a missed tick, a restart, or a feed outage can no longer silently drop the
 * 5h/1h reminders. A mark already well past at discovery (e.g. the feed only
 * surfaces a fixture 12h out) is suppressed so we never send a "24h before" that
 * is really 12h. Catch-up reminders render the ACTUAL remaining time and a
 * "delayed reminder" note so a late 5h fire is never misread as on-time.
 *
 * Collapse on catch-up: in steady 3-minute polling exactly one mark crosses per
 * cycle, so all three tiers fire as their own timely reminders (they are fully
 * independent — separate dedup keys, evaluated every poll). Only after a gap can
 * several marks become eligible in a single cycle; we then SEND only the shortest
 * (most relevant) tier and mark the longer crossed tiers handled, so an imminent
 * kickoff never triggers a burst of stale "24h"/"5h" messages.
 *
 * Fixture caching: the type=12 META feed is a day-ahead schedule with KNOWN
 * coverage gaps — it reliably lists a fixture ~12-26h out but low-liquidity
 * regional matches (exactly the targets here) routinely drop out of it as
 * kickoff approaches. So once a target fixture is discovered we cache its
 * kickoff time and identity and evaluate ALL marks against the cache every poll
 * (even when the feed fetch itself fails), independent of whether the fixture is
 * still in the feed. The cache is persisted alongside the dedup state and pruned
 * after kickoff.
 *
 * Timezone: every comparison uses absolute epoch milliseconds. parseKickoffMs
 * converts the feed's GMT+8 wall-clock to a UTC epoch, and Date.now() is already
 * a UTC epoch, so Δt = kickoffMs − now is timezone-invariant — it does not
 * depend on the server's local zone, and "converting both into America/Winnipeg
 * before subtracting" would yield the identical delta (the offsets cancel).
 * America/Winnipeg is therefore applied only where it actually matters: rendering
 * the human-readable kickoff time in the reminder message.
 *
 * Deduplication: each (matchId, mark) fires exactly once. Sent keys are
 * persisted to disk (atomic temp-file + rename under a mutation lock, mirroring
 * telegramSubscribers.ts) so a restart never re-sends a reminder it already sent.
 * Stale keys are pruned once their kickoff is comfortably in the past.
 */
import { promises as fs } from "node:fs";
import path from "node:path";
import { logger } from "./logger";
import { fetchRaw } from "./scanner";
import { parseKickoffMs } from "./healthcheck";
import { currentBaseUrl, endpointsFor, withCacheBuster } from "./upstream";
import { sendTelegram, escapeMdV2, isTelegramConfigured } from "./telegram";
import {
  TARGET_LEAGUES,
  matchTargetLeague,
} from "./targetLeagues";

// Keep the scheduler's historical public seam while sharing the canonical
// policy with the live scanner and Excapper paths.
export { TARGET_LEAGUES };

const CONFIG_PATH = path.resolve(process.cwd(), "config/prematch-alerts.json");

/** How often to poll the META feed for upcoming fixtures. */
const POLL_MS = 3 * 60 * 1000;
/**
 * Discovery grace: a mark that is already at most this far past when a fixture is
 * FIRST seen is still armed (and fires immediately) rather than suppressed. This
 * keeps the original behavior of firing a mark discovered a few minutes late,
 * while anything well past at discovery is treated as stale. It does NOT bound
 * catch-up for an already-armed mark — that fires on the first poll after its
 * crossing no matter how long the gap.
 */
const FIRE_WINDOW_MS = 15 * 60 * 1000;
/** Re-fetch the league-name directory (type=6) at most this often. */
const LEAGUE_REFRESH_MS = 30 * 60 * 1000;
/** Drop dedup keys this long after kickoff so the state file stays small. */
const STATE_TTL_AFTER_KICKOFF_MS = 6 * 60 * 60 * 1000;

interface IntervalMark {
  /** Short key used in the dedup state and message header, e.g. "24h". */
  key: string;
  /** Human phrase for the message body, e.g. "24 hours". */
  phrase: string;
  ms: number;
}

/** Ordered longest-first; each fixture can fire each mark once. */
const INTERVAL_MARKS: IntervalMark[] = [
  { key: "24h", phrase: "24 hours", ms: 24 * 60 * 60 * 1000 },
  { key: "5h", phrase: "5 hours", ms: 5 * 60 * 60 * 1000 },
  { key: "1h", phrase: "1 hour", ms: 1 * 60 * 60 * 1000 },
];

// Re-export the matcher for existing scheduler tests and callers.  The
// canonical implementation accepts unknown values and fails closed.
export { matchTargetLeague };

interface UpcomingFixture {
  matchId: string;
  leagueId: string;
  home: string;
  away: string;
  kickoffMs: number;
}

/** Parse the type=12 META feed into upcoming (future-kickoff) fixtures. */
function parseUpcomingFixtures(text: string): UpcomingFixture[] {
  let json: { ErrCode: number; Data: string };
  try {
    json = JSON.parse(text) as { ErrCode: number; Data: string };
  } catch {
    return [];
  }
  if (json.ErrCode !== 0 || !json.Data) return [];

  const now = Date.now();
  const out: UpcomingFixture[] = [];
  for (const record of json.Data.split("!").filter(Boolean)) {
    const f = record.split("^");
    const matchId = f[0];
    if (!matchId || matchId.length < 5) continue;
    const kickoffMs = parseKickoffMs(f[3] ?? "");
    if (kickoffMs === null || kickoffMs <= now) continue; // upcoming only
    out.push({
      matchId,
      leagueId: f[4] ?? "",
      home: f[9] ?? "",
      away: f[10] ?? "",
      kickoffMs,
    });
  }
  return out;
}

/** Parse the type=6 league directory into an id -> name map. */
function parseLeagueNames(text: string): Map<string, string> {
  const map = new Map<string, string>();
  let json: { ErrCode: number; Data: string };
  try {
    json = JSON.parse(text) as { ErrCode: number; Data: string };
  } catch {
    return map;
  }
  if (json.ErrCode !== 0 || !json.Data) return map;
  const bRegex = /B\[(\d+)\]=\[([^\]]+)\]/g;
  let m: RegExpExecArray | null;
  while ((m = bRegex.exec(json.Data)) !== null) {
    const fields = m[2].split(",");
    const id = fields[0]?.trim();
    const fullName = fields[2]?.replace(/'/g, "").trim();
    if (id && fullName) map.set(id, fullName);
  }
  return map;
}

// ---------- Dedup state (persisted) ----------

interface SentRecord {
  /** `${matchId}:${markKey}` */
  key: string;
  kickoffMs: number;
  sentAt: string;
  /**
   * True when this key was recorded WITHOUT sending a message — either the mark
   * was already stale when the fixture was discovered, or it was superseded by a
   * shorter tier during a catch-up cycle. Dedup treats sent and suppressed keys
   * identically (both mean "never fire this mark"); the flag is for observability.
   */
  suppressed?: boolean;
}

/**
 * A target fixture we have discovered in the feed. Cached so the 5h/1h marks can
 * still fire after the fixture drops out of the type=12 schedule near kickoff.
 * Keyed by matchId in `trackedFixtures`.
 */
interface CachedFixture {
  matchId: string;
  leagueId: string;
  /** Matched target label (message uses the raw feed name below). */
  leagueLabel: string;
  /** Raw league name resolved from the type=6 directory at discovery time. */
  leagueName: string;
  home: string;
  away: string;
  kickoffMs: number;
  /** Epoch ms when this fixture was first discovered (used only for logging). */
  firstSeenMs: number;
}

const sentKeys = new Map<string, SentRecord>();
const trackedFixtures = new Map<string, CachedFixture>();
let stateLoaded = false;

let mutationChain: Promise<unknown> = Promise.resolve();
function withMutationLock<T>(fn: () => Promise<T>): Promise<T> {
  const next = mutationChain.then(fn, fn);
  mutationChain = next.catch(() => undefined);
  return next;
}

async function atomicWriteJson(filePath: string, payload: string): Promise<void> {
  const dir = path.dirname(filePath);
  const tmp = path.join(dir, `.${path.basename(filePath)}.tmp-${process.pid}-${Date.now()}`);
  const fh = await fs.open(tmp, "w");
  try {
    await fh.writeFile(payload, "utf8");
    await fh.sync();
  } finally {
    await fh.close();
  }
  await fs.rename(tmp, filePath);
}

async function persistState(): Promise<void> {
  const payload = {
    sent: [...sentKeys.values()],
    fixtures: [...trackedFixtures.values()],
  };
  await atomicWriteJson(CONFIG_PATH, JSON.stringify(payload, null, 2));
}

async function loadState(): Promise<void> {
  if (stateLoaded) return;
  try {
    const raw = await fs.readFile(CONFIG_PATH, "utf8");
    const parsed = JSON.parse(raw) as { sent?: SentRecord[]; fixtures?: CachedFixture[] };
    for (const r of parsed.sent ?? []) {
      if (r && typeof r.key === "string" && typeof r.kickoffMs === "number") {
        sentKeys.set(r.key, {
          key: r.key,
          kickoffMs: r.kickoffMs,
          sentAt: typeof r.sentAt === "string" ? r.sentAt : new Date().toISOString(),
          ...(r.suppressed === true ? { suppressed: true } : {}),
        });
      }
    }
    for (const fx of parsed.fixtures ?? []) {
      if (
        fx &&
        typeof fx.matchId === "string" &&
        typeof fx.kickoffMs === "number" &&
        typeof fx.leagueLabel === "string"
      ) {
        trackedFixtures.set(fx.matchId, {
          matchId: fx.matchId,
          leagueId: typeof fx.leagueId === "string" ? fx.leagueId : "",
          leagueLabel: fx.leagueLabel,
          // Never fall back to the persisted canonical label for policy
          // evaluation. Older cache records can contain a stale/mislabeled
          // label (or no raw directory name at all); those records remain
          // stored for history but cannot emit a reminder without current
          // raw league evidence.
          leagueName: typeof fx.leagueName === "string" ? fx.leagueName : "",
          home: typeof fx.home === "string" ? fx.home : "",
          away: typeof fx.away === "string" ? fx.away : "",
          kickoffMs: fx.kickoffMs,
          firstSeenMs: typeof fx.firstSeenMs === "number" ? fx.firstSeenMs : fx.kickoffMs,
        });
      }
    }
    logger.info(
      { sent: sentKeys.size, fixtures: trackedFixtures.size },
      "[PRE-MATCH] Loaded dedup + fixture state",
    );
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") {
      logger.info("[PRE-MATCH] No dedup state file yet — starting fresh");
    } else {
      logger.error({ err }, "[PRE-MATCH] Failed to load dedup state — starting fresh");
    }
  } finally {
    stateLoaded = true;
  }
}

/** Remove dedup keys and cached fixtures whose kickoff is comfortably in the past. Returns true if anything changed. */
function pruneState(now: number): boolean {
  let changed = false;
  for (const [key, rec] of sentKeys) {
    if (now - rec.kickoffMs > STATE_TTL_AFTER_KICKOFF_MS) {
      sentKeys.delete(key);
      changed = true;
    }
  }
  for (const [matchId, fx] of trackedFixtures) {
    if (now - fx.kickoffMs > STATE_TTL_AFTER_KICKOFF_MS) {
      trackedFixtures.delete(matchId);
      changed = true;
    }
  }
  return changed;
}

// ---------- Message ----------

/**
 * Kickoff rendered in the user's local timezone (Central Time, America/Winnipeg),
 * e.g. "2026-05-30 09:00 CDT". Using a named IANA zone lets the runtime apply
 * CST/CDT daylight-saving automatically, and the abbreviation keeps it unambiguous.
 */
const KICKOFF_TIME_ZONE = "America/Winnipeg";
function formatKickoff(kickoffMs: number): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: KICKOFF_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZoneName: "short",
  }).formatToParts(new Date(kickoffMs));
  const get = (type: Intl.DateTimeFormatPartTypes): string =>
    parts.find((p) => p.type === type)?.value ?? "";
  const hour = get("hour") === "24" ? "00" : get("hour");
  return `${get("year")}-${get("month")}-${get("day")} ${hour}:${get("minute")} ${get("timeZoneName")}`;
}

/** Human-readable remaining time, e.g. "23 hours" or "47 minutes". */
function humanizeRemaining(ms: number): string {
  const totalMin = Math.max(0, Math.round(ms / 60000));
  if (totalMin < 90) return `${totalMin} minute${totalMin === 1 ? "" : "s"}`;
  const hours = Math.round(ms / (60 * 60 * 1000));
  return `${hours} hour${hours === 1 ? "" : "s"}`;
}

/**
 * `now` lets the lead line reflect the ACTUAL time to kickoff. In normal,
 * on-time operation that equals the mark and we use the mark's phrase; when a
 * mark fires late via catch-up (after a restart/outage), we show the real
 * remaining time and a "delayed reminder" note so it is never misread.
 */
function buildMessage(
  mark: IntervalMark,
  leagueName: string,
  home: string,
  away: string,
  kickoffMs: number,
  now: number,
): string {
  const header = `⏰ *Pre\\-Match Reminder \\(${escapeMdV2(mark.key)}\\)*`;
  const league = `🏆 *${escapeMdV2(leagueName)}*`;
  const fixture = `⚽️ ${escapeMdV2(home)} vs ${escapeMdV2(away)}`;
  const kickoff = `🕒 Kickoff: ${escapeMdV2(formatKickoff(kickoffMs))}`;
  const remaining = kickoffMs - now;
  const onTime = Math.abs(remaining - mark.ms) <= FIRE_WINDOW_MS;
  const lead = onTime
    ? escapeMdV2(`⏳ Starts in ~${mark.phrase}`)
    : escapeMdV2(`⏳ Starts in ~${humanizeRemaining(remaining)} (delayed reminder)`);
  return [header, "", league, fixture, kickoff, lead].join("\n");
}

// ---------- Scheduler ----------

let running = false;
let pollTimer: ReturnType<typeof setTimeout> | null = null;
let leagueNames = new Map<string, string>();
let lastLeagueRefresh = 0;

async function refreshLeagueNamesIfStale(now: number): Promise<void> {
  if (leagueNames.size > 0 && now - lastLeagueRefresh < LEAGUE_REFRESH_MS) return;
  try {
    const text = await fetchRaw(endpointsFor(currentBaseUrl()).leagues);
    const parsed = parseLeagueNames(text);
    if (parsed.size > 0) {
      leagueNames = parsed;
      lastLeagueRefresh = now;
      logger.info({ count: leagueNames.size }, "[PRE-MATCH] League names refreshed");
    }
  } catch (err) {
    logger.warn({ err }, "[PRE-MATCH] Failed to refresh league names");
  }
}

interface PendingSend {
  matchId: string;
  league: string;
  mark: IntervalMark;
  message: string;
  kickoffMs: number;
}

/**
 * Pure discovery + evaluation over the cached fixture set. Mutates the module
 * maps (trackedFixtures, sentKeys) and returns the marks that crossed this cycle
 * plus whether any persisted state changed. Network-free so it can be unit
 * tested directly. `now` is injected for determinism.
 */
function evaluateFixtures(
  fixtures: UpcomingFixture[],
  now: number,
): { pending: PendingSend[]; stateChanged: boolean } {
  const pending: PendingSend[] = [];
  let stateChanged = false;

  // 1) DISCOVERY: upsert every target fixture currently in the feed into the
  // cache. We refresh on every sighting so a later, more complete feed entry
  // can correct teams/league-name/kickoff. This is the ONLY place a fixture
  // enters the cache, so a mark can never fire for a match we never saw.
  for (const fx of fixtures) {
    const leagueName = leagueNames.get(fx.leagueId) ?? "";
    const matchedLabel = matchTargetLeague(leagueName);
    if (!matchedLabel) continue;

    const prev = trackedFixtures.get(fx.matchId);
    const isNew = !prev;
    if (
      !prev ||
      prev.kickoffMs !== fx.kickoffMs ||
      prev.leagueName !== leagueName ||
      prev.home !== fx.home ||
      prev.away !== fx.away
    ) {
      trackedFixtures.set(fx.matchId, {
        matchId: fx.matchId,
        leagueId: fx.leagueId,
        leagueLabel: matchedLabel,
        leagueName,
        home: fx.home,
        away: fx.away,
        kickoffMs: fx.kickoffMs,
        firstSeenMs: prev?.firstSeenMs ?? now,
      });
      stateChanged = true;
    }

    // ARM: only on the very first sighting. Each of the three tiers is handled
    // independently. A tier still in the future (with a small grace) is "armed"
    // and will fire when crossed — even across a restart or feed outage (the
    // catch-up). A tier already well past at discovery is suppressed so we never
    // send a "24h" that is really 12h for a fixture the feed surfaced late.
    if (isNew) {
      const remaining = fx.kickoffMs - now;
      for (const mark of INTERVAL_MARKS) {
        const key = `${fx.matchId}:${mark.key}`;
        if (sentKeys.has(key)) continue;
        if (remaining < mark.ms - FIRE_WINDOW_MS) {
          sentKeys.set(key, {
            key,
            kickoffMs: fx.kickoffMs,
            sentAt: new Date(now).toISOString(),
            suppressed: true,
          });
          stateChanged = true;
        } else {
          // Debug: the explicit per-job scheduling line requested for verifying
          // that all three timers are registered and active.
          logger.info(
            {
              matchId: fx.matchId,
              league: matchedLabel,
              mark: mark.key,
              fireAt: formatKickoff(fx.kickoffMs - mark.ms),
              kickoff: formatKickoff(fx.kickoffMs),
            },
            `[Scheduler] Job scheduled for match ${fx.matchId} (${mark.key}) at ${formatKickoff(
              fx.kickoffMs - mark.ms,
            )}`,
          );
        }
      }
    }
  }

  // 2) EVALUATION: evaluate marks against the CACHE, not just this poll's feed,
  // so a fixture that dropped out of the type=12 schedule near kickoff is still
  // evaluated. remaining is computed from absolute UTC epochs on both sides, so
  // it is timezone-invariant (see file header).
  for (const fx of trackedFixtures.values()) {
    // Re-check the raw directory league on every evaluation. The persisted
    // `leagueLabel` is display/history metadata, not proof that this fixture
    // belongs to the target competition (e.g. old Sikkim/Thimphu rows).
    if (!matchTargetLeague(fx.leagueName)) continue;
    const remaining = fx.kickoffMs - now;
    // Never fire a pre-match tier once kickoff has passed; pruneState removes the
    // fixture later. (remaining can go negative if the process was down across
    // kickoff.)
    if (remaining <= 0) continue;

    // CATCH-UP: a tier is eligible the FIRST poll after its crossing
    // (remaining <= mark.ms) with no lower window bound, so a missed tick or a
    // long gap can no longer drop it. Dedup + arm-time suppression guarantee each
    // tier fires at most once and stale tiers never fire.
    const crossed = INTERVAL_MARKS.filter(
      (mark) => remaining <= mark.ms && !sentKeys.has(`${fx.matchId}:${mark.key}`),
    );
    if (crossed.length === 0) continue;

    // INTERVAL_MARKS is longest-first, so the last crossed entry is the shortest
    // (most relevant) tier. In steady polling exactly one tier crosses per cycle
    // and is sent normally. Only after a gap do several cross at once; we then
    // send just the shortest and mark the longer ones handled so an imminent
    // kickoff never produces a burst of stale "24h"/"5h" messages.
    const shortest = crossed[crossed.length - 1];
    for (const mark of crossed) {
      const key = `${fx.matchId}:${mark.key}`;
      const send = mark === shortest;
      sentKeys.set(key, {
        key,
        kickoffMs: fx.kickoffMs,
        sentAt: new Date(now).toISOString(),
        ...(send ? {} : { suppressed: true }),
      });
      stateChanged = true;
      if (send) {
        pending.push({
          matchId: fx.matchId,
          league: fx.leagueLabel,
          mark,
          message: buildMessage(mark, fx.leagueName, fx.home, fx.away, fx.kickoffMs, now),
          kickoffMs: fx.kickoffMs,
        });
      } else {
        logger.info(
          { matchId: fx.matchId, mark: mark.key, supersededBy: shortest.key },
          `[Scheduler] Catch-up: ${mark.key} for match ${fx.matchId} superseded by closer tier ${shortest.key}`,
        );
      }
    }
  }

  return { pending, stateChanged };
}

async function poll(): Promise<void> {
  const now = Date.now();
  await refreshLeagueNamesIfStale(now);

  // A feed hiccup must NOT skip evaluation: we still run the cache below so the
  // catch-up path can fire any tier whose time passed during the outage. On
  // failure we simply skip discovery (no new fixtures) by using an empty list.
  let fixtures: UpcomingFixture[] = [];
  try {
    const text = await fetchRaw(withCacheBuster(endpointsFor(currentBaseUrl()).meta));
    fixtures = parseUpcomingFixtures(text);
  } catch (err) {
    logger.warn({ err }, "[PRE-MATCH] META fetch failed this cycle — evaluating cache only");
  }

  // We deliberately PERSIST committed dedup keys BEFORE issuing any send (below):
  // the requirement is strict no-double-fire, so the correct failure mode is
  // at-most-once. If the process dies between persist and send we may miss a
  // reminder, but we will never re-send a committed one. (sendTelegram already
  // retries 429s and falls back to plain text, so a transient hiccup rarely
  // loses a message anyway.)
  const { pending, stateChanged: evalChanged } = evaluateFixtures(fixtures, now);
  let stateChanged = evalChanged;

  if (pruneState(now)) stateChanged = true;

  // Durability barrier: persist the committed dedup keys to disk and WAIT for it
  // before issuing a single send, so a crash can never resurrect a sent mark.
  if (stateChanged) {
    try {
      await withMutationLock(persistState);
    } catch (err) {
      // If we can't persist, do NOT send — otherwise a restart would re-fire
      // everything queued this cycle. Roll back the in-memory keys we just added
      // so a later cycle can retry cleanly once the disk is writable again.
      for (const p of pending) sentKeys.delete(`${p.matchId}:${p.mark.key}`);
      logger.error({ err }, "[PRE-MATCH] Failed to persist dedup state — skipping sends this cycle");
      return;
    }
  }

  for (const p of pending) {
    // Fire-and-forget: a slow/failed broadcast must not stall the poll loop; the
    // dedup key is already durably persisted so we never double-send.
    void sendTelegram(p.message).catch((err) =>
      logger.error({ err, matchId: p.matchId, mark: p.mark.key }, "[PRE-MATCH] send failed"),
    );
    const lateMs = p.mark.ms - (p.kickoffMs - now);
    const catchUp = lateMs > FIRE_WINDOW_MS;
    logger.info(
      {
        matchId: p.matchId,
        league: p.league,
        mark: p.mark.key,
        catchUp,
        lateMin: catchUp ? Math.round(lateMs / 60000) : 0,
      },
      catchUp
        ? `[Scheduler] Catch-up reminder fired for match ${p.matchId} (${p.mark.key}, ~${Math.round(
            lateMs / 60000,
          )} min late)`
        : "[PRE-MATCH] reminder queued",
    );
  }
  if (pending.length > 0) logger.info({ fired: pending.length }, "[PRE-MATCH] poll cycle complete");
}

/**
 * Start the pre-match reminder scheduler. Safe to call once at boot; no-ops if
 * already running or if Telegram is not configured.
 */
export async function startPreMatchAlerts(): Promise<void> {
  if (running) return;
  if (!isTelegramConfigured()) {
    logger.warn("[PRE-MATCH] Telegram not configured — scheduler not started");
    return;
  }
  running = true;
  await loadState();
  logger.info(
    { pollMs: POLL_MS, targets: TARGET_LEAGUES.length },
    "[PRE-MATCH] Scheduler started",
  );

  // scanCoordinator invokes the single-run adapter. Reminder evaluation and
  // persisted catch-up/dedup semantics are unchanged.
}

export async function runPreMatchAlertCycle(
  sharedLeagueNames?: ReadonlyMap<string, string>,
): Promise<void> {
  if (!running) return;
  if (sharedLeagueNames && sharedLeagueNames.size > 0) {
    leagueNames = new Map(sharedLeagueNames);
    lastLeagueRefresh = Date.now();
  }
  await poll();
}

export function stopPreMatchAlerts(): void {
  running = false;
  if (pollTimer) {
    clearTimeout(pollTimer);
    pollTimer = null;
  }
}

/**
 * Test-only seam: exposes the pure evaluation core and the in-memory state so a
 * unit test can drive the scheduler deterministically without booting the server
 * or touching the network. Not imported by production code.
 */
export const __testOnly = {
  evaluateFixtures,
  setLeagueNames(map: Map<string, string>): void {
    leagueNames = map;
  },
  reset(): void {
    sentKeys.clear();
    trackedFixtures.clear();
    leagueNames = new Map();
  },
  trackedFixtures,
  sentKeys,
};
