/**
 * Owner-only diagnostics. No upstream reads, subscriber discovery or broadcast
 * path: the lifecycle owner injects synchronous, in-memory snapshot readers.
 */
import { logger } from "./logger";

export const STALL_MS = 5 * 60_000;
export const REPEAT_MS = 30 * 60_000;
export interface ComponentHealth {
  expectedActive: boolean;
  lastCompletedAt: number | null;
}
export interface DiagnosticsSnapshot {
  scanner: ComponentHealth & { matchesTracked: number; liveNow: number; lastAlertAt: number | null };
  radar: ComponentHealth & { cooldownSignals: number };
  excapper: ComponentHealth & { lastStartedAt: number | null; transactionsOver500: number; lastCardAt: number | null };
  dropThreshold: number;
  dropThresholdSource?: "env" | "file" | "default";
  tunerState: string;
}
type Send = (owner: string, text: string) => Promise<unknown>;

/** A broadcast chat id is NOT evidence of an owner's user identity. */
export function diagnosticsOwner(env: Record<string, string | undefined> = process.env): string | null {
  const value = env["TELEGRAM_OWNER_USER_ID"]?.trim();
  return value && /^[1-9]\d*$/.test(value) && Number.isSafeInteger(Number(value)) ? value : null;
}

let excapperExpected = true;
let excapperStart: number | null = null;
let excapperComplete: number | null = null;
let excapperCard: number | null = null;
const OBSERVATION_HOUR_MS = 3_600_000;
const GAME_RETENTION_MS = 24 * OBSERVATION_HOUR_MS;
const MAX_DIAGNOSTIC_GAMES = 1_000;
const MAX_GAME_TRANSACTION_IDS = 20_000;
type ObservedTransaction = { id: string; change: number };
/** Exact identities are retained independently of the one-hour count. At the
 * per-game bound we stop counting new rows (rather than evicting identities and
 * accidentally recounting historical rows). Evicted/expired games re-baseline.
 * No inference about the source's unknown timezone is made here.
 */
export class ExcapperObservationCounter {
  private games = new Map<string, { lastSeen: number; seen: Set<string>; observed: Map<string, number>; saturated: boolean }>();
  private prune(now: number): void {
    for (const [gameId, game] of this.games) {
      if (now - game.lastSeen > GAME_RETENTION_MS) this.games.delete(gameId);
      else for (const [id, at] of game.observed) if (at <= now - OBSERVATION_HOUR_MS) game.observed.delete(id);
    }
  }
  record(gameId: string, rows: readonly ObservedTransaction[], observedAt: number): void {
    if (!gameId || !Number.isFinite(observedAt)) return;
    this.prune(observedAt);
    let game = this.games.get(gameId);
    const baseline = !game;
    if (!game) {
      if (this.games.size >= MAX_DIAGNOSTIC_GAMES) {
        const oldest = [...this.games].reduce((a, b) => a[1].lastSeen <= b[1].lastSeen ? a : b);
        this.games.delete(oldest[0]);
      }
      game = { lastSeen: observedAt, seen: new Set(), observed: new Map(), saturated: false };
      this.games.set(gameId, game);
    }
    // Cached or out-of-order transport snapshots must not introduce new events.
    if (!baseline && observedAt <= game.lastSeen) return;
    game.lastSeen = observedAt;
    for (const row of rows) {
      if (!row.id || game.seen.has(row.id)) continue;
      if (game.seen.size >= MAX_GAME_TRANSACTION_IDS) {
        if (!game.saturated) logger.warn("[DIAGNOSTICS] Excapper per-game identity limit reached; observation count may undercount until re-baseline");
        game.saturated = true;
        break;
      }
      game.seen.add(row.id);
      if (!baseline && Number.isFinite(row.change) && row.change >= 500) game.observed.set(row.id, observedAt);
    }
  }
  count(now: number): number {
    this.prune(now);
    let total = 0;
    for (const game of this.games.values()) for (const at of game.observed.values()) {
      if (at > now - OBSERVATION_HOUR_MS && at <= now) total++;
    }
    return total;
  }
}
const transactions = new ExcapperObservationCounter();
export function recordExcapperPollStart(at = Date.now()): void { excapperStart = at; }
export function recordExcapperPollComplete(at = Date.now()): void { excapperComplete = at; }
export function setExcapperDiagnosticsActive(active: boolean): void { excapperExpected = active; }
/** All parsed rows before alert filters/compaction; timestamp is transport time. */
export function recordExcapperSnapshot(gameId: string, rows: readonly ObservedTransaction[], observedAt: number): void {
  transactions.record(gameId, rows, observedAt);
}
/** Only invoke AFTER confirmed successful SMART EXCAPPER delivery. */
export function recordExcapperCardDelivered(at = Date.now()): void { excapperCard = at; }
export function getExcapperDiagnostics(now = Date.now()): DiagnosticsSnapshot["excapper"] {
  return { expectedActive: excapperExpected, lastStartedAt: excapperStart, lastCompletedAt: excapperComplete,
    transactionsOver500: transactions.count(now), lastCardAt: excapperCard };
}

const age = (at: number | null, now: number) => at === null ? "never" : `${Math.max(0, Math.floor((now - at) / 1000))}s ago`;
const time = (at: number | null) => at === null ? "never" : new Date(at).toISOString();
function health(row: ComponentHealth, now: number, bootAt: number): string {
  return !row.expectedActive ? "paused" : now - (row.lastCompletedAt ?? bootAt) > STALL_MS ? "stalled" : "alive";
}
export function formatDiagnostics(snapshot: DiagnosticsSnapshot, bootId: string, bootAt: number, now: number, enabled: boolean): string {
  const { scanner: s, radar: r, excapper: e } = snapshot;
  return [
    `STATUS · diagnostics ${enabled ? "ON" : "OFF"}`,
    `Odds scanner: ${health(s, now, bootAt)} · last scan ${age(s.lastCompletedAt, now)} · matches tracked ${s.matchesTracked} · live now ${s.liveNow} · last alert ${time(s.lastAlertAt)}`,
    `ODDS RADAR: ${health(r, now, bootAt)} · last check ${age(r.lastCompletedAt, now)} · signals in cooldown ${r.cooldownSignals}`,
    `Excapper monitor: ${health(e, now, bootAt)} · last poll ${age(e.lastCompletedAt, now)} · observed >=€500 tx in last hour ${e.transactionsOver500} (per-game baseline since boot) · last SMART EXCAPPER card ${time(e.lastCardAt)}`,
    `Boot id: ${bootId} · uptime ${Math.max(0, Math.floor((now - bootAt) / 1000))}s`,
    `dropThreshold: ${snapshot.dropThreshold.toFixed(2)} (source: ${snapshot.dropThresholdSource ?? "default"}) · tuner state: ${snapshot.tunerState}`,
  ].join("\n");
}

export class TelegramDiagnostics {
  private enabled = true;
  private timer: ReturnType<typeof setInterval> | null = null;
  private checking = false;
  private warnings = new Map<keyof Pick<DiagnosticsSnapshot, "scanner" | "radar" | "excapper">, number>();
  constructor(private readonly owner: string | null, private readonly read: () => DiagnosticsSnapshot,
    private readonly send: Send, private readonly bootId: string, private readonly bootAt = Date.now()) {}

  async command(message: { from?: { id?: number }; chat: { id: number; type?: string } }, command: string): Promise<boolean> {
    if (!["/status", "/diagnostics_off", "/diagnostics_on"].includes(command)) return false;
    if (!this.owner || String(message.from?.id) !== this.owner ||
      message.chat.type !== "private" || String(message.chat.id) !== this.owner) return true;
    if (command === "/status") {
      await this.send(this.owner, formatDiagnostics(this.read(), this.bootId, this.bootAt, Date.now(), this.enabled));
    } else {
      this.enabled = command === "/diagnostics_on";
      await this.send(this.owner, `Diagnostics ${this.enabled ? "ON" : "OFF"}${this.enabled ? "" : " until /diagnostics_on"}.`);
    }
    return true;
  }

  async check(now = Date.now()): Promise<void> {
    if (!this.owner || !this.enabled || this.checking) return;
    this.checking = true;
    try {
      const snapshot = this.read();
      for (const key of ["scanner", "radar", "excapper"] as const) {
        if (!this.enabled) break;
        const row = snapshot[key];
        // Intentional operator pause is not a stall or a recovery.
        if (!row.expectedActive) continue;
        const previous = this.warnings.get(key);
        if (health(row, now, this.bootAt) === "stalled") {
          if (previous !== undefined && now - previous < REPEAT_MS) continue;
          const result = await this.send(this.owner, `⚠️ Diagnostics: ${key} stalled · last completion ${age(row.lastCompletedAt, now)}`);
          if (result !== "failed" && result !== "blocked") this.warnings.set(key, now);
        } else if (previous !== undefined && row.lastCompletedAt !== null && row.lastCompletedAt > previous) {
          const result = await this.send(this.owner, `✅ Diagnostics: ${key} recovered.`);
          if (result !== "failed" && result !== "blocked") this.warnings.delete(key);
        }
      }
    } finally { this.checking = false; }
  }
  start(): void {
    if (!this.owner || this.timer) return;
    this.timer = setInterval(() => { void this.check().catch((err: unknown) => {
      logger.warn({ err }, "[DIAGNOSTICS] Watchdog check failed; retrying next interval");
    }); }, 30_000);
    this.timer.unref?.();
  }
  stop(): void { if (this.timer) clearInterval(this.timer); this.timer = null; }
}

let diagnostics: TelegramDiagnostics | null = null;
export function installTelegramDiagnostics(instance: TelegramDiagnostics): void { diagnostics?.stop(); diagnostics = instance; instance.start(); }
export function stopTelegramDiagnostics(): void { diagnostics?.stop(); }
export async function handleDiagnosticsCommand(message: Parameters<TelegramDiagnostics["command"]>[0], command: string): Promise<boolean> {
  if (!diagnostics) return ["/status", "/diagnostics_off", "/diagnostics_on"].includes(command);
  return diagnostics.command(message, command);
}