import { promises as fs } from "node:fs";
import path from "node:path";
import { db, manualActiveBindingsTable, manualBindingBlocksTable, manualBindingsImportTable, bindingDecisionsTable } from "@workspace/db";
import { and, eq, or, sql } from "drizzle-orm";
import type { BindingDecision } from "./bindingDecisionAudit";

export interface PersistedManualBinding {
  nowgoalId: string;
  diagnosticId?: string;
  excapperId: string;
  boundAt: string;
  status: "Verified";
  autoBound: boolean;
  signature?: string;
  source?: { team1: string; team2: string; league: string };
  [key: string]: unknown;
}

interface ManualBindingsFile {
  bindings: PersistedManualBinding[];
}

let filePath = path.resolve(process.cwd(), "data/active_bindings.json");
let legacyFilePath: string | null = path.resolve(process.cwd(), "config/manual-bindings.json");
let bindings = new Map<string, PersistedManualBinding>();
let retainedRecords: unknown[] = [];
let operation: Promise<unknown> = Promise.resolve();
let testFileBackend = false;

function values(binding: PersistedManualBinding) {
  return {
    nowgoalId: binding.nowgoalId, excapperId: binding.excapperId,
    boundAt: new Date(binding.boundAt), status: binding.status,
    autoBound: binding.autoBound, payload: binding,
  };
}

async function loadDatabase(): Promise<readonly PersistedManualBinding[]> {
  const marker = await db.select({ name: manualBindingsImportTable.name })
    .from(manualBindingsImportTable).where(eq(manualBindingsImportTable.name, "active_bindings_v1"));
  if (!marker.length) {
    let imported: Map<string, PersistedManualBinding>;
    try {
      imported = (await readStore(filePath)).valid;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
      // The legacy config snapshot predates operator resets. Only the
      // canonical active snapshot may be imported into durable authority.
      imported = new Map();
    }
    await db.transaction(async (tx) => {
      const claimed = await tx.insert(manualBindingsImportTable)
        .values({ name: "active_bindings_v1" }).onConflictDoNothing()
        .returning({ name: manualBindingsImportTable.name });
      if (!claimed.length) return;
      const ids = [...new Set([...imported.values()].flatMap((binding) =>
        [binding.nowgoalId, binding.diagnosticId ?? binding.nowgoalId]))].sort();
      for (const id of ids) {
        await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${id}, 53))`);
      }
      for (const binding of imported.values()) {
        const blocked = await tx.select({ gameId: manualBindingBlocksTable.gameId })
          .from(manualBindingBlocksTable).where(and(
            eq(manualBindingBlocksTable.diagnosticId, binding.diagnosticId ?? binding.nowgoalId),
            or(eq(manualBindingBlocksTable.gameId, binding.excapperId),
              eq(manualBindingBlocksTable.gameId, "*")),
          ));
        if (!blocked.length) {
          await tx.insert(manualActiveBindingsTable).values(values(binding)).onConflictDoNothing();
        }
      }
    });
  }
  const rows = await db.select({ payload: manualActiveBindingsTable.payload })
    .from(manualActiveBindingsTable);
  bindings = new Map(rows.map(({ payload }) => {
    if (!validRecord(payload)) throw new Error("Invalid manual binding stored in PostgreSQL");
    return [payload.nowgoalId, payload];
  }));
  return [...bindings.values()];
}

function validRecord(value: unknown): value is PersistedManualBinding {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<PersistedManualBinding>;
  return typeof item.nowgoalId === "string" && !!item.nowgoalId &&
    typeof item.excapperId === "string" && !!item.excapperId &&
    typeof item.boundAt === "string" && item.status === "Verified" &&
    typeof item.autoBound === "boolean";
}

async function write(
  snapshot: Map<string, PersistedManualBinding>,
  destination = filePath,
  retained = retainedRecords,
): Promise<void> {
  const dir = path.dirname(destination);
  const tmp = path.join(dir, `.manual-bindings.json.tmp-${process.pid}-${Date.now()}`);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(
    tmp,
    JSON.stringify({ bindings: [...snapshot.values(), ...retained] }, null, 2) + "\n",
    "utf8",
  );
  await fs.rename(tmp, destination);
}

async function readStore(source: string): Promise<{
  valid: Map<string, PersistedManualBinding>;
  retained: unknown[];
}> {
  const parsed = JSON.parse(await fs.readFile(source, "utf8")) as Partial<ManualBindingsFile>;
  if (!Array.isArray(parsed.bindings)) {
    throw new Error(`Invalid manual bindings file: ${source}`);
  }
  return {
    valid: new Map(parsed.bindings.filter(validRecord)
      .map((binding) => [binding.nowgoalId, binding])),
    // Keep records from newer/unknown schemas byte-for-value in subsequent
    // writes instead of silently erasing data this version cannot understand.
    retained: parsed.bindings.filter((binding) => !validRecord(binding)),
  };
}

async function initialize(): Promise<readonly PersistedManualBinding[]> {
  try {
    const canonical = await readStore(filePath);
    bindings = canonical.valid;
    retainedRecords = canonical.retained;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    let migrated = {
      valid: new Map<string, PersistedManualBinding>(),
      retained: [] as unknown[],
    };
    if (legacyFilePath) {
      try {
        migrated = await readStore(legacyFilePath);
      } catch (legacyError) {
        if ((legacyError as NodeJS.ErrnoException).code !== "ENOENT") throw legacyError;
      }
    }
    // Migration is copy-first: the legacy file remains untouched, and runtime
    // state changes only after the canonical atomic rename succeeds.
    await write(migrated.valid, filePath, migrated.retained);
    bindings = migrated.valid;
    retainedRecords = migrated.retained;
  }
  return [...bindings.values()];
}

export function initManualBindingsStore(): Promise<readonly PersistedManualBinding[]> {
  const run = operation.then(() => testFileBackend ? initialize() : loadDatabase());
  operation = run.catch(() => undefined);
  return run;
}

export function getPersistedManualBindings(): readonly PersistedManualBinding[] {
  return [...bindings.values()];
}

export function manualBindingsUseTestFile(): boolean {
  return testFileBackend;
}

export function forgetPersistedManualBinding(nowgoalId: string): void {
  bindings.delete(nowgoalId);
}

export function savePersistedManualBinding(
  binding: PersistedManualBinding,
  decision?: BindingDecision,
  decisionMatchId = binding.diagnosticId ?? binding.nowgoalId,
  clearBlocks = false,
): Promise<PersistedManualBinding | undefined> {
  const run = operation.then(async () => {
    const previous = bindings.get(binding.nowgoalId);
    if (testFileBackend) {
      const next = new Map(bindings);
      next.set(binding.nowgoalId, binding);
      await write(next);
      bindings = next;
    } else {
      await db.transaction(async (tx) => {
        for (const id of new Set([
          binding.nowgoalId, decisionMatchId,
          ...(binding.excapperId === "FORCE_MANUAL" ? [] : [`excapper:${binding.excapperId}`]),
        ].sort())) {
          await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${id}, 53))`);
        }
        if (binding.excapperId !== "FORCE_MANUAL") {
          const owner = await tx.select({ nowgoalId: manualActiveBindingsTable.nowgoalId })
            .from(manualActiveBindingsTable).where(eq(manualActiveBindingsTable.excapperId, binding.excapperId));
          if (owner.some((row) => row.nowgoalId !== binding.nowgoalId))
            throw new Error("This Excapper game is already bound to another NowGoal fixture");
        }
        if (!clearBlocks) {
          const blocked = await tx.select({ gameId: manualBindingBlocksTable.gameId })
            .from(manualBindingBlocksTable).where(and(
              eq(manualBindingBlocksTable.diagnosticId, decisionMatchId),
              or(eq(manualBindingBlocksTable.gameId, binding.excapperId),
                eq(manualBindingBlocksTable.gameId, "*")),
            ));
          if (blocked.length) throw new Error("Binding was reset; automatic reattachment is blocked");
        }
        await tx.insert(manualActiveBindingsTable).values(values(binding))
          .onConflictDoUpdate({
            target: manualActiveBindingsTable.nowgoalId,
            set: values(binding),
          });
        if (decision) {
          await tx.insert(bindingDecisionsTable).values({
            ...decision, matchId: decisionMatchId, occurredAt: new Date(decision.occurredAt),
          }).onConflictDoNothing({ target: bindingDecisionsTable.id });
          if (clearBlocks) await tx.delete(manualBindingBlocksTable).where(and(
              eq(manualBindingBlocksTable.diagnosticId, binding.nowgoalId),
              or(eq(manualBindingBlocksTable.gameId, binding.excapperId),
                eq(manualBindingBlocksTable.gameId, "*")),
            ));
        }
      });
      bindings.set(binding.nowgoalId, binding);
    }
    return previous;
  });
  operation = run.catch(() => undefined);
  return run;
}

export function removePersistedManualBinding(nowgoalId: string): Promise<void> {
  const run = operation.then(async () => {
    if (testFileBackend) {
      if (!bindings.has(nowgoalId)) return;
      const next = new Map(bindings);
      next.delete(nowgoalId);
      await write(next);
      bindings = next;
    } else {
      await db.delete(manualActiveBindingsTable).where(eq(manualActiveBindingsTable.nowgoalId, nowgoalId));
      bindings.delete(nowgoalId);
    }
  });
  operation = run.catch(() => undefined);
  return run;
}

export function __testOnlySetManualBindingsFile(nextPath: string): void {
  testFileBackend = true;
  filePath = nextPath;
  // Tests using the historical single-path override must never inspect or
  // migrate production records from config/manual-bindings.json.
  legacyFilePath = null;
  bindings = new Map();
  retainedRecords = [];
  operation = Promise.resolve();
}

export function __testOnlySetManualBindingsPaths(
  canonicalPath: string,
  legacyPath: string | null,
): void {
  testFileBackend = true;
  filePath = canonicalPath;
  legacyFilePath = legacyPath;
  bindings = new Map();
  retainedRecords = [];
  operation = Promise.resolve();
}

export function __testOnlyUseManualBindingsDatabase(): void {
  testFileBackend = false;
  bindings = new Map();
  operation = Promise.resolve();
}