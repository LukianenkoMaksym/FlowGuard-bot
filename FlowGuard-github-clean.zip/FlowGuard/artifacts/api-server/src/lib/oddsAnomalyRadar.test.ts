import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const deps = vi.hoisted(() => ({
  rows: [] as Array<{
    matchId: string;
    meta: {
      leagueName: string; leagueId: string; kickoffMs: number | null;
      team1: string; team2: string; isLive: boolean;
      state: number | null; homeScore: number; awayScore: number;
      updatedAt: number; clockLabel: string;
    };
    current: { ts: number; line: number; overDecimal: number; underDecimal: number };
    history: Array<{ ts: number; line: number; overDecimal: number; underDecimal: number }>;
    lastScoreChangeAt: number | null;
    needsVerification?: boolean;
  }>,
  muted: false,
  configured: true,
  send: vi.fn(),
  oneX2: vi.fn(),
  dynamic: vi.fn(),
  score: null as null | { state: number; isLive: boolean; homeScore: number; awayScore: number; clockLabel: string },
  contexts: new Map<string, { home: number; away: number; observedAt: number; goalAt: number | null; safeAfter: number; revision: number }>(),
  storeFailure: false,
  trustNewFixtures: true,
}));
vi.mock("./radarScoreContext", () => ({
  observeRadarScore: vi.fn(async (id: string, home: number, away: number, marker: number | null) => {
    if (deps.storeFailure) throw new Error("database unavailable");
    const now = Date.now();
    const old = deps.contexts.get(id);
    const changed = old && (old.home !== home || old.away !== away);
    const external = old && marker != null && marker > old.observedAt &&
      marker <= now && (old.goalAt == null || marker > old.goalAt);
    const next = !old ? { home, away, observedAt: now, goalAt: null,
      safeAfter: now + 300_000, revision: 1 } :
      changed || external ? { home, away, observedAt: now,
        goalAt: changed ? now : marker!, safeAfter: Math.max(old.safeAfter, (changed ? now : marker!) + 300_000),
        revision: old.revision + 1 } : old;
    deps.contexts.set(id, next);
    return { ...next };
  }),
}));
vi.mock("./scanner", () => ({
  GOAL_BLACKOUT_MS: 90_000,
  getOddsRadarSnapshot: vi.fn(() => structuredClone(deps.rows)),
  getOddsRadarFixtureSnapshot: vi.fn(() => structuredClone(deps.rows.map(({ matchId, meta, lastScoreChangeAt, needsVerification }) =>
    ({ matchId, meta, lastScoreChangeAt, needsVerification })))),
  fetchFreshScoreNow: vi.fn(async (id: string) => deps.score ??
    (deps.rows.find((r) => r.matchId === id && !r.needsVerification)
      ? { state: 1, isLive: true,
        homeScore: deps.rows.find((r) => r.matchId === id)!.meta.homeScore,
        awayScore: deps.rows.find((r) => r.matchId === id)!.meta.awayScore,
        clockLabel: "45" }
      : null)),
}));
vi.mock("./bet365OneX2", () => ({
  fetchBet365OneX2: deps.oneX2,
}));
vi.mock("./radarBookMarkets", () => ({
  refreshRadarBooks: deps.dynamic,
}));
vi.mock("./targetLeagues", () => ({
  matchTargetLeague: (league: string) => league === "Allowed League" ? league : null,
}));
vi.mock("./controls", () => ({ getControls: () => ({ alertsMuted: deps.muted }) }));
vi.mock("./telegram", () => ({
  isTelegramConfigured: () => deps.configured,
  sendTelegram: deps.send,
  escapeMdV2: (text: string) => text.replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, "\\$1"),
}));
vi.mock("./config", () => ({ nowgoalMatchUrl: (id: string) => `https://example.com/match/${id}` }));
vi.mock("./logger", () => ({
  logger: { warn: vi.fn(), info: vi.fn() },
}));

import { runOddsAnomalyRadarCycle, startOddsAnomalyRadar, stopOddsAnomalyRadar } from "./oddsAnomalyRadar";
import { logger } from "./logger";
import * as scanner from "./scanner";
import { formatUnifiedAlert } from "./unifiedAlert";
import { ANOMALY_ODDS_FLOOR } from "./winRate";

const START = 1_800_000_000_000;
function row(id = "1") {
  return {
    matchId: id,
    meta: { leagueName: "Allowed League", leagueId: "123", kickoffMs: null,
      team1: "Home", team2: "Away",
      isLive: true, state: 1, homeScore: 0, awayScore: 0,
      updatedAt: Date.now(), clockLabel: "45" },
    current: { ts: Date.now(), line: 2.5, overDecimal: 1.80, underDecimal: 1.85 },
    history: [],
    lastScoreChangeAt: null,
  };
}
async function cycle() {
  for (const r of deps.rows) {
    if (deps.trustNewFixtures && !deps.contexts.has(r.matchId)) deps.contexts.set(r.matchId, {
      home: r.meta.homeScore, away: r.meta.awayScore, observedAt: START - 3600_000,
      goalAt: null, safeAfter: START - 3300_000, revision: 1,
    });
    r.meta.updatedAt = Date.now();
    r.current.ts = Date.now();
    r.history.push({ ...r.current });
    r.history = r.history.filter((point) => Date.now() - point.ts <= 6 * 60_000);
  }
  await runOddsAnomalyRadarCycle();
}
function advance(ms = 60_000) { vi.setSystemTime(Date.now() + ms); }

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(START);
  vi.mocked(scanner.getOddsRadarFixtureSnapshot).mockReset().mockImplementation(() =>
    structuredClone(deps.rows.map(({ matchId, meta, lastScoreChangeAt, needsVerification }) =>
      ({ matchId, meta, lastScoreChangeAt, needsVerification }))));
  vi.mocked(scanner.fetchFreshScoreNow).mockReset().mockImplementation(async (id: string) =>
    deps.score ?? (deps.rows.find((r) => r.matchId === id && !r.needsVerification)
      ? { state: 1, isLive: true,
        homeScore: deps.rows.find((r) => r.matchId === id)!.meta.homeScore,
        awayScore: deps.rows.find((r) => r.matchId === id)!.meta.awayScore,
        clockLabel: "45" } : null));
  deps.rows = [row()];
  deps.muted = false;
  deps.configured = true;
  deps.send.mockReset();
  deps.oneX2.mockReset();
  deps.oneX2.mockResolvedValue(null);
  deps.dynamic.mockReset();
  // Adapt pre-existing detector regressions to the dynamic contract. The
  // fixture below is synthetic test evidence, never a production fallback.
  deps.dynamic.mockImplementation(async () => {
    const markets = new Map<string, unknown[]>();
    for (const fixture of deps.rows) {
      const current = await deps.oneX2(fixture.matchId);
      const rows: unknown[] = [];
      if (current) for (const [side, property] of [
        ["HOME", "home"], ["AWAY", "away"],
      ] as const) {
        const history = current.history.filter((point: { ts: number; home: number | null; away: number | null }) =>
          point[property] != null).map((point: { ts: number; home: number | null; away: number | null }) =>
          ({ ts: point.ts, line: null, odds: point[property] }));
        if (history.length) rows.push({ cid: "8", bookmaker: "Bet365", side, line: null,
          observedAt: current.observedAt, current: history.at(-1), history, timeSource: "upstream" });
      }
      if (fixture.history.length) for (const [side, property] of [
        ["OVER", "overDecimal"], ["UNDER", "underDecimal"],
      ] as const) {
        const history = fixture.history.map((point) => ({
          ts: point.ts, line: point.line, odds: point[property],
        }));
        rows.push({ cid: "8", bookmaker: "Bet365", side, line: fixture.current.line,
          observedAt: Date.now(), current: history.at(-1), history, timeSource: "observed" });
      }
      if (rows.length) markets.set(fixture.matchId, rows);
    }
    return markets;
  });
  deps.score = null;
  deps.storeFailure = false;
  deps.trustNewFixtures = true;
  deps.contexts.clear();
  // Existing non-startup tests have a trusted, long-established score epoch.
  for (const fixture of deps.rows) deps.contexts.set(fixture.matchId, {
    home: fixture.meta.homeScore, away: fixture.meta.awayScore,
    observedAt: START - 3600_000, goalAt: null,
    safeAfter: START - 3300_000, revision: 1,
  });
  deps.send.mockResolvedValue({ primaryDelivered: true, status: "delivered" });
  // Restored by the last test that overrides the snapshot implementation.
  startOddsAnomalyRadar();
});
afterEach(() => {
  stopOddsAnomalyRadar();
  vi.useRealTimers();
  delete process.env["RADAR_DROP_THRESHOLD"];
  delete process.env["RADAR_RISE_THRESHOLD"];
  delete process.env["RADAR_COOLDOWN_MS"];
});

describe("odds anomaly radar", () => {
  it.each([
    ["OVER", "drop", 2.20, 1.90],
    ["UNDER", "rise", 1.70, 2.05],
    ["HOME", "drop", 2.20, 1.90],
    ["AWAY", "rise", 2.20, 2.55],
  ] as const)("keeps goal-driven %s %s silent for the full five-minute window, then measures a new segment", async (side, kind, before, after) => {
    const scanner = await import("./scanner");
    const goalAt = Date.now();
    const points: Array<{ ts: number; line: number | null; odds: number }> =
      [{ ts: goalAt - 30_000, line: side === "OVER" || side === "UNDER" ? 2.5 : null, odds: before }];
    const market = () => ({
      cid: "8", bookmaker: "Bet365", side, line: points[0]!.line,
      observedAt: Date.now(), current: points.at(-1), history: [...points],
      timeSource: "upstream",
    });
    deps.dynamic.mockImplementation(async () => new Map([
      ["1", [market()]],
      ["2", [{
        cid: "8", bookmaker: "Bet365", side: "OVER", line: 2.5,
        observedAt: Date.now(), current: { ts: Date.now() - 5_000, line: 2.5, odds: 1.55 },
        history: [{ ts: Date.now() - 30_000, line: 2.5, odds: 1.80 },
          { ts: Date.now() - 5_000, line: 2.5, odds: 1.55 }],
      }]],
    ]));
    deps.rows[0]!.lastScoreChangeAt = goalAt;
    deps.rows[0]!.meta.homeScore = 1;
    // The other fixture's signal must not be silenced by this match's goal.
    deps.rows.push(row("2"));
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("match/2");
    deps.rows = [deps.rows[0]!];
    advance(91_000);
    points.push({ ts: Date.now() - 1_000, line: points[0]!.line, odds: after });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance(5 * 60_000 - 91_000 + 1_000);
    await cycle(); // old goal quote is still available in the bookmaker's history
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance(60_000);
    points.push({ ts: Date.now() - 1_000, line: points[0]!.line, odds: after });
    await cycle(); // establishes the first valid post-goal baseline
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance(60_000);
    const next = kind === "drop" ? after - 0.25 : after + 0.25;
    points.push({ ts: Date.now() - 1_000, line: points[0]!.line, odds: next });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[1]![0]).toContain(kind === "drop" ? "📉" : "📈");
    expect(deps.send.mock.calls[1]![0]).not.toContain(before.toFixed(2).replace(".", "\\."));
    expect(vi.mocked(scanner.fetchFreshScoreNow)).toHaveBeenCalledWith("1");
  });

  it("does not revive an old excursion as spike-and-revert after a goal", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance();
    deps.rows[0]!.lastScoreChangeAt = Date.now();
    deps.rows[0]!.meta.homeScore = 1;
    deps.rows[0]!.current.overDecimal = 1.80;
    await cycle();
    advance(5 * 60_000 + 1_000);
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send.mock.calls.join(" ")).not.toContain("⚡");
  });

  it("refuses dispatch when a fresh authoritative score detects a goal before scanner metadata", async () => {
    const scanner = await import("./scanner");
    const before = { ts: Date.now() - 60_000, line: null, odds: 2.50 };
    const after = { ts: Date.now() - 5_000, line: null, odds: 2.15 };
    deps.dynamic.mockResolvedValue(new Map([["1", [{
      cid: "8", bookmaker: "Bet365", side: "HOME", line: null,
      observedAt: Date.now(), current: after, history: [before, after],
    }]]]));
    vi.mocked(scanner.fetchFreshScoreNow).mockResolvedValueOnce({
      state: 1, isLive: true, homeScore: 1, awayScore: 0, clockLabel: "45",
    });
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("detects a locally observed live-only bookmaker move but displays only from→to", async () => {
    const now = Date.now();
    const history = [{ ts: now - 60_000, odds: 2.50, line: null },
      { ts: now - 5_000, odds: 2.16, line: null }];
    deps.dynamic.mockResolvedValue(new Map([["1", [{
      cid: "71", bookmaker: "Live Only", side: "HOME", line: null,
      observedAt: now, current: history[1], history, timeSource: "observed",
    }]]]));
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("Live Only");
    expect(deps.send.mock.calls[0]![0]).toContain("2\\.50 → 2\\.16");
    expect(deps.send.mock.calls[0]![0]).not.toContain("Как шёл кэф");
    const admitted = vi.mocked(logger.info).mock.calls.map(([fields]) => fields as {
      matchId?: string; reason?: string; firstAt?: number; lastAt?: number;
    }).filter((fields) => fields.reason === "admit" && fields.matchId === "1").at(-1);
    expect(admitted).toMatchObject({ firstAt: now - 60_000, lastAt: now - 5_000 });
  });

  it("a dynamically discovered non-Bet365 bookmaker alone triggers one 1X2 card; quiet books and draw never appear", async () => {
    const now = Date.now();
    const history = [{ ts: now - 60_000, odds: 2.50, line: null },
      { ts: now - 5_000, odds: 2.16, line: null }];
    deps.dynamic.mockResolvedValue(new Map([["1", [
      { cid: "93", bookmaker: "New House", side: "HOME", line: null,
        observedAt: now, current: history[1], history },
      { cid: "8", bookmaker: "Bet365", side: "HOME", line: null, observedAt: now,
        current: { ts: now - 5_000, odds: 2.50, line: null },
        history: [{ ts: now - 60_000, odds: 2.50, line: null },
          { ts: now - 5_000, odds: 2.50, line: null }] },
      { cid: "1107", bookmaker: "Small Move", side: "HOME", line: null, observedAt: now,
        current: { ts: now - 5_000, odds: 2.48, line: null },
        history: [{ ts: now - 60_000, odds: 2.50, line: null },
          { ts: now - 5_000, odds: 2.48, line: null }] },
    ]]]));
    const scanner = await import("./scanner");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => []);
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("New House");
    expect(deps.send.mock.calls[0]![0]).toContain("Small Move");
    expect(deps.send.mock.calls[0]![0]).not.toContain("Bet365");
    expect(deps.send.mock.calls[0]![0]).not.toContain("Ничья");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => structuredClone(deps.rows));
  });

  it("does not compare OU prices across line changes and does not apply OU guard to 1X2", async () => {
    const now = Date.now();
    deps.dynamic.mockResolvedValue(new Map([["1", [
      { cid: "93", bookmaker: "New House", side: "OVER", line: 3.5, observedAt: now,
        current: { ts: now - 5_000, odds: 1.50, line: 3.5 },
        history: [{ ts: now - 55_000, odds: 1.95, line: 2.5 },
          { ts: now - 5_000, odds: 1.50, line: 3.5 }] },
      { cid: "93", bookmaker: "New House", side: "AWAY", line: null, observedAt: now,
        current: { ts: now - 5_000, odds: 1.50, line: null },
        history: [{ ts: now - 55_000, odds: 1.95, line: null },
          { ts: now - 5_000, odds: 1.50, line: null }] },
    ]]]));
    const scanner = await import("./scanner");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => []);
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("Победа гостей");
    expect(deps.send.mock.calls[0]![0]).not.toContain("Тотал больше");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => structuredClone(deps.rows));
  });

  it("uses an authentic baseline, peak, return and source duration on spike-and-revert", async () => {
    const scanner = await import("./scanner");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => []);
    const start = Date.now();
    const points = [
      { ts: start - 55_000, odds: 2.20, line: null },
      { ts: start - 5_000, odds: 1.90, line: null },
    ];
    deps.dynamic.mockImplementation(async () => new Map([["1", [{
      cid: "519", bookmaker: "Live Company", side: "HOME", line: null,
      observedAt: Date.now(), current: points.at(-1), history: [...points],
    }]]]));
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance(60_000);
    points.push({ ts: Date.now() - 5_000, odds: 2.18, line: null });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[1]![0]).toContain("⚡");
    expect(deps.send.mock.calls[1]![0]).toContain("Live Company");
    const admitted = vi.mocked(logger.info).mock.calls.map(([fields]) => fields as {
      reason?: string; firstAt?: number; lastAt?: number;
    }).filter((fields) => fields.reason === "admit");
    expect(admitted.at(-1)).toMatchObject({
      firstAt: start - 55_000, lastAt: Date.now() - 5_000,
    });
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => structuredClone(deps.rows));
  });

  it("alerts 1X2 home and away from verified Bet365 history without any OU quote, never draw", async () => {
    const scanner = await import("./scanner");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => []);
    deps.oneX2.mockImplementation(async () => {
      const previous = { ts: Date.now() - 60_000, home: 2.2, away: 2.4 };
      const current = { ts: Date.now() - 5_000, home: 1.8, away: 2.8 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current,
        history: [previous, current] };
    });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[0]![0]).toContain("Победа хозяев");
    expect(deps.send.mock.calls[0]![0]).toContain("Bet365");
    expect(deps.send.mock.calls[0]![0]).toContain("📉");
    expect(deps.send.mock.calls[1]![0]).toContain("Победа гостей");
    expect(deps.send.mock.calls[1]![0]).toContain("📈");
    expect(deps.send.mock.calls.join(" ")).not.toContain("Ничья");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => structuredClone(deps.rows));
  });

  it("verifies metadata-only fixtures via authoritative state when the OU feed has no match", async () => {
    const scanner = await import("./scanner");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => []);
    deps.rows[0]!.meta.isLive = false;
    deps.rows[0]!.meta.state = null;
    deps.rows[0]!.needsVerification = true;
    deps.score = { state: 2, isLive: true, homeScore: 0, awayScore: 0, clockLabel: "45" };
    deps.oneX2.mockImplementation(async () => {
      const current = { ts: Date.now() - 5_000, home: 1.8, away: 2.4 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current,
        history: [{ ts: Date.now() - 55_000, home: 2.2, away: 2.4 }, current] };
    });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(vi.mocked(scanner.fetchFreshScoreNow)).toHaveBeenCalledWith("1");
    vi.mocked(scanner.getOddsRadarSnapshot).mockImplementation(() => structuredClone(deps.rows));
  });

  it("preserves the shared goal timestamp for a directory-only 1X2 fixture with an unchanged verified score", async () => {
    const fixture = deps.rows[0]!;
    fixture.needsVerification = true;
    fixture.meta.isLive = false;
    fixture.meta.state = null;
    fixture.meta.homeScore = 1; // discovery already observed the goal
    fixture.lastScoreChangeAt = Date.now();
    deps.score = { state: 2, isLive: true, homeScore: 1, awayScore: 0, clockLabel: "45" };
    let fromAt = Date.now() - 30_000;
    let from = 2.20;
    let to = 1.85;
    deps.oneX2.mockImplementation(async () => {
      const current = { ts: Date.now() - 5_000, home: to, away: 2.4 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current,
        history: [{ ts: fromAt, home: from, away: 2.4 }, current] };
    });
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    advance(91_000);
    await cycle(); // cached verification still sees the same score
    expect(deps.send).not.toHaveBeenCalled();
    advance(5 * 60_000 - 91_000 + 1_000);
    await cycle(); // price still references the pre-goal quote
    expect(deps.send).not.toHaveBeenCalled();
    advance(60_000);
    fromAt = Date.now() - 55_000; // entirely post-goal, after the extended blackout
    from = 1.85;
    to = 1.53;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("Победа хозяев");
  });

  it("does not block an AWAY signal because the independent HOME or DRAW quote is missing", async () => {
    deps.oneX2.mockImplementation(async () => {
      const current = { ts: Date.now() - 5_000, home: null, away: 2.8 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current,
        history: [{ ts: Date.now() - 55_000, home: null, away: 2.4 }, current] };
    });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("Победа гостей");
  });

  it("applies the shared micro-odds floor to the current 1X2 side without OU-specific value guards", async () => {
    let home = ANOMALY_ODDS_FLOOR - 0.05;
    deps.oneX2.mockImplementation(async () => {
      const current = { ts: Date.now() - 5_000, home, away: 2.40 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current,
        history: [{ ts: Date.now() - 55_000, home: home + 0.30, away: 2.40 }, current] };
    });
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    advance();
    home = ANOMALY_ODDS_FLOOR;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("Победа хозяев");
  });

  it("1X2 respects cooldown by outcome+kind and marks a later market repeat only after primary ack", async () => {
    let home = 1.7;
    let baseline = 2.1;
    let quoteAt = Date.now() - 5_000;
    deps.oneX2.mockImplementation(async () => {
      const before = { ts: quoteAt - 50_000, home: baseline, away: 2.40 };
      const current = { ts: quoteAt, home, away: 2.40 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current, history: [before, current] };
    });
    deps.send.mockResolvedValueOnce({ primaryDelivered: false, status: "failed" });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).not.toContain("повторный сигнал");
    advance();
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[1]![0]).not.toContain("повторный сигнал");
    advance();
    home = 1.35; baseline = 1.7;
    quoteAt = Date.now() - 5_000;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2); // same kind, still cooling
    advance(31 * 60_000);
    baseline = 1.65;
    home = 1.32;
    quoteAt = Date.now() - 5_000;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(3);
    expect(deps.send.mock.calls[2]![0]).toContain("🔁 повторный сигнал");
  });

  it("1X2 rejects stale source snapshots, finished games, and recent goals", async () => {
    deps.oneX2.mockImplementation(async () => {
      const before = { ts: Date.now() - 90_000, home: 2.2, away: 2.4 };
      const current = { ts: Date.now() - 130_000, home: 1.8, away: 2.4 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current, history: [before, current] };
    });
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    deps.rows[0]!.meta.state = -1;
    await cycle();
    deps.rows[0]!.meta.state = 1;
    deps.rows[0]!.lastScoreChangeAt = Date.now();
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("retains 1X2 cooldown through a feed gap, blackout and temporary missing fixture", async () => {
    let home = 1.8;
    deps.oneX2.mockImplementation(async () => {
      const current = { ts: Date.now() - 5_000, home, away: 2.4 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current,
        history: [{ ts: Date.now() - 55_000, home: home + 0.35, away: 2.4 }, current] };
    });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance();
    deps.oneX2.mockResolvedValueOnce(null);
    await cycle();
    advance();
    deps.rows[0]!.lastScoreChangeAt = Date.now();
    await cycle();
    deps.rows = [];
    advance();
    await cycle();
    deps.rows = [row()];
    home = 1.4;
    advance(91_000);
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance(31 * 60_000);
    home = 1.2;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[1]![0]).toContain("🔁 повторный сигнал");
  });

  it("rechecks fixture and goal blackout before each HOME and AWAY dispatch", async () => {
    deps.oneX2.mockImplementation(async () => {
      const current = { ts: Date.now() - 5_000, home: 1.8, away: 2.8 };
      return { bookmaker: "Bet365", observedAt: Date.now(), current,
        history: [{ ts: Date.now() - 55_000, home: 2.2, away: 2.4 }, current] };
    });
    deps.send.mockImplementationOnce(async () => {
      deps.rows[0]!.meta.homeScore = 1;
      deps.rows[0]!.lastScoreChangeAt = Date.now();
      return { primaryDelivered: true, status: "delivered" };
    });
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("Победа хозяев");
  });
  it.each([
    ["drop", 1.58, "📉"],
    ["rise", 2.02, "📈"],
  ])("sends a compact exact-line %s note", async (type, price, text) => {
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = price as number;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    const message = deps.send.mock.calls[0]![0] as string;
    expect(message).toContain("ODDS RADAR");
    expect(message).toContain(text);
    expect(message).toContain("Тотал больше 2\\.5");
    expect(message).toContain("0:0");
    expect(message).toContain("Match Details");
    expect(message).not.toContain("SMART MONEY");
    expect(message).not.toContain("Excapper Inflow");
    expect(type).toBeTruthy();
  });

  it.each([
    ["drop", [1.72, 1.64, 1.55], "📉"],
    ["rise", [1.88, 1.96, 2.05], "📈"],
  ])("accumulates a gradual %s across multiple 60s ticks on the same line", async (_type, prices, label) => {
    await cycle();
    for (const [index, price] of prices.entries()) {
      advance();
      deps.rows[0]!.current.overDecimal = price;
      await cycle();
      expect(deps.send).toHaveBeenCalledTimes(index === prices.length - 1 ? 1 : 0);
    }
    expect(deps.send.mock.calls[0]![0]).toContain(label);
    expect(deps.send.mock.calls[0]![0]).toContain("1\\.80");
  });

  it("uses authentic recent scanner history immediately at bootstrap", async () => {
    deps.rows[0]!.history.push({
      ts: Date.now() - 120_000, line: 2.5, overDecimal: 1.80, underDecimal: 1.85,
    });
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("📉");
  });

  it("does not invent a line move from the five-minute history cutoff at bootstrap", async () => {
    deps.rows[0]!.history.push({
      ts: Date.now() - 5 * 60_000 - 30_000,
      line: 2.5, overDecimal: 1.80, underDecimal: 1.85,
    });
    await cycle(); // identical line and prices throughout the feed
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("ignores a real line transition older than the five-minute window", async () => {
    deps.rows[0]!.history.push(
      { ts: Date.now() - 6 * 60_000, line: 1.5, overDecimal: 1.80, underDecimal: 1.85 },
      { ts: Date.now() - 5 * 60_000 - 30_000, line: 2.5, overDecimal: 1.80, underDecimal: 1.85 },
    );
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("does not compare a former price across a line change and return", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.line = 3.5;
    deps.rows[0]!.current.overDecimal = 1.80;
    await cycle(); // changed line does not emit a signal
    advance();
    deps.rows[0]!.current.line = 2.5;
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it.each([
    ["0.15 HK", 1.98, 1.83],
    ["above threshold", 2.12, 1.83],
  ])("does not resurrect an old OVER baseline on an observed A→B→A return (%s)", async (_case, initial, returned) => {
    const fixture = deps.rows[0]!;
    fixture.current.overDecimal = initial;
    await cycle();
    advance();
    fixture.current.line = 2.75; // NowGoal 2.5/3
    fixture.current.overDecimal = 1.92;
    await cycle();
    advance();
    fixture.current.line = 2.5;
    fixture.current.overDecimal = returned;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    advance();
    fixture.current.overDecimal = returned - 0.22;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("📉");
    expect(deps.send.mock.calls[0]![0]).toContain(returned.toFixed(2).replace(".", "\\."));
  });

  it("discards an A excursion across B without losing the sent-kind and market cooldowns", async () => {
    const fixture = deps.rows[0]!;
    await cycle();
    advance();
    fixture.current.overDecimal = 1.55; // A excursion and delivered drop
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance();
    fixture.current.line = 2.75;
    fixture.current.overDecimal = 1.95;
    await cycle();
    advance();
    fixture.current.line = 2.5;
    fixture.current.overDecimal = 1.80; // old baseline: not an old excursion revert
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance();
    fixture.current.overDecimal = 1.52; // genuinely new A drop, but old drop cooldown remains
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
    advance();
    fixture.current.overDecimal = 1.80; // new A excursion's revert is a distinct unsent kind
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[1]![0]).toContain("⚡");
  });

  it.each(["OVER", "UNDER"] as const)(
    "uses the source's uninterrupted %s segment even when B happens between polls, independently per match and book",
    async (side) => {
      deps.rows.push(row("2"));
      if (side === "UNDER") for (const fixture of deps.rows) fixture.meta.homeScore = 1;
      if (side === "UNDER") for (const fixture of deps.rows) deps.contexts.set(fixture.matchId, {
        home: 1, away: 0, observedAt: START - 3600_000,
        goalAt: null, safeAfter: START - 3300_000, revision: 1,
      });
      const at = Date.now();
      const points = [
        { ts: at - 55_000, line: 2.5, odds: 2.12 },
        { ts: at - 5_000, line: 2.5, odds: 1.83 },
      ];
      const other = [
        { ts: at - 55_000, line: 2.5, odds: 2.12 },
        { ts: at - 5_000, line: 2.5, odds: 1.83 },
      ];
      const market = (cid: string, history: typeof points) => ({
        cid, bookmaker: `Book ${cid}`, side, line: history.at(-1)!.line,
        observedAt: Date.now(), current: history.at(-1)!, history: [...history],
        timeSource: "upstream" as const,
      });
      deps.dynamic.mockImplementation(async () => new Map([
        ["1", [market("8", points), market("93", other)]],
        ["2", [market("8", other)]],
      ]));
      await cycle();
      expect(deps.send).toHaveBeenCalledTimes(2); // first match groups its two books
      deps.send.mockClear();
      advance();
      // Source history shows B even though no RADAR poll observed it.
      points.push({ ts: Date.now() - 35_000, line: 2.75, odds: 1.90 },
        { ts: Date.now() - 5_000, line: 2.5, odds: 2.11 });
      other.push({ ts: Date.now() - 5_000, line: 2.5, odds: 2.11 });
      await cycle();
      expect(deps.send).toHaveBeenCalledTimes(2); // other book and match may genuinely revert
      expect(deps.send.mock.calls[0]![0]).toContain("Book 93");
      expect(deps.send.mock.calls[0]![0]).not.toContain("Book 8");
      expect(deps.send.mock.calls[1]![0]).toContain("match/2");
      deps.send.mockClear();
      advance();
      points.push({ ts: Date.now() - 5_000, line: 2.5, odds: 1.82 });
      await cycle();
      expect(deps.send).not.toHaveBeenCalled(); // fresh drop respects match 1's cooldown
    });

  it("reports a changed line without comparing prices across lines", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.line = 3.5;
    deps.rows[0]!.current.overDecimal = 1.40;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("classifies a full fast reversal as a bad-quote revert", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.80;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[1]![0]).toContain("⚡");
    expect(deps.send.mock.calls[1]![0]).not.toContain("📈");
    expect(deps.send.mock.calls[1]![0]).not.toContain("повторный сигнал"); // still inside market cooldown
  });

  it("expires a former excursion so a later same-direction burst can revert", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    advance(11 * 60_000);
    await cycle(); // steady market; the first excursion is now over 10m old
    advance();
    deps.rows[0]!.current.overDecimal = 1.30;
    await cycle(); // another drop, still inside the drop cooldown
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(deps.send.mock.calls[1]![0]).toContain("⚡");
  });

  it("blocks goals, stale quotes, closed and unsafe markets", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.57;
    deps.rows[0]!.lastScoreChangeAt = Date.now();
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    advance(91_000);
    await cycle(); // rebaseline after blackout
    advance();
    deps.rows[0]!.current.overDecimal = 1.35;
    deps.rows[0]!.meta.homeScore = 3;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    deps.rows[0]!.meta.homeScore = 0;
    deps.rows[0]!.meta.state = -1;
    advance();
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    deps.rows[0]!.meta.state = 1;
    deps.rows[0]!.current.overDecimal = 1.10;
    advance();
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    deps.rows[0]!.current.overDecimal = 1.80;
    advance();
    await cycle();
    deps.rows[0]!.current.overDecimal = 1.55;
    advance();
    // Authentic odds timestamp is stale, despite fresh metadata.
    deps.rows[0]!.current.ts = Date.now() - 130_000;
    deps.rows[0]!.meta.updatedAt = Date.now();
    await runOddsAnomalyRadarCycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("filters non-whitelist matches and muted/unconfigured cycles", async () => {
    deps.rows[0]!.meta.leagueName = "Other";
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.50;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    deps.rows[0]!.meta.leagueName = "Allowed League";
    deps.muted = true;
    await cycle();
    deps.muted = false;
    deps.configured = false;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("suppresses a repeated type, permits a new type, and expires cooldown", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.58;
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.80;
    await cycle(); // reverse excursion: revert is a new type
    expect(deps.send).toHaveBeenCalledTimes(2);
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle(); // second drop is in cooldown
    expect(deps.send).toHaveBeenCalledTimes(2);
    advance(31 * 60_000);
    await cycle(); // old observation cannot trigger; baseline reset
    advance();
    deps.rows[0]!.current.overDecimal = 1.12; // micro-odds, not eligible
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    deps.rows[0]!.current.overDecimal = 1.80;
    advance();
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.57;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(3);
    expect(deps.send.mock.calls[2]![0]).toContain("🔁 повторный сигнал");
  });

  it("retries unsuccessful delivery on the unchanged quote without consuming cooldown", async () => {
    deps.send.mockResolvedValueOnce({ primaryDelivered: false, status: "failed" });
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    advance();
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
    advance();
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(2);
  });

  it("revalidates the current score and quote before dispatch", async () => {
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    // Revalidate the authoritative fixture score before sending, even though
    // scanner's separate Bet365 quote is no longer the source of RADAR prices.
    const scanner = await import("./scanner");
    let calls = 0;
    vi.mocked(scanner.getOddsRadarFixtureSnapshot).mockImplementation(() => {
      calls++;
      const copied = structuredClone(deps.rows.map(({ matchId, meta, lastScoreChangeAt, needsVerification }) =>
        ({ matchId, meta, lastScoreChangeAt, needsVerification }))) as ReturnType<typeof scanner.getOddsRadarFixtureSnapshot>;
      if (calls >= 2) copied[0]!.meta.homeScore = 3;
      return copied;
    });
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    vi.mocked(scanner.getOddsRadarFixtureSnapshot).mockImplementation(() =>
      structuredClone(deps.rows.map(({ matchId, meta, lastScoreChangeAt, needsVerification }) =>
        ({ matchId, meta, lastScoreChangeAt, needsVerification }))));
  });

  it("honors independent threshold settings and does not overlap sends", async () => {
    process.env["RADAR_DROP_THRESHOLD"] = "0.30";
    process.env["RADAR_RISE_THRESHOLD"] = "0.10";
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.62;
    await cycle(); // below custom drop threshold
    expect(deps.send).not.toHaveBeenCalled();
    let release!: (value: { primaryDelivered: boolean }) => void;
    deps.send.mockImplementationOnce(() => new Promise((resolve) => { release = resolve; }));
    advance();
    deps.rows[0]!.current.overDecimal = 1.92;
    const first = cycle();
    for (let i = 0; i < 200 && !release; i++) await Promise.resolve();
    expect(release).toBeTypeOf("function");
    await cycle(); // a concurrent cycle must not double-send
    expect(deps.send).toHaveBeenCalledTimes(1);
    release({ primaryDelivered: true });
    await first;
  });

  it("invalidates an in-flight cycle on stop/restart", async () => {
    deps.rows.push(row("2"));
    await cycle();
    advance();
    for (const r of deps.rows) r.current.overDecimal = 1.55;
    let release!: (value: { primaryDelivered: boolean }) => void;
    deps.send.mockImplementationOnce(() => new Promise((resolve) => { release = resolve; }));
    const inFlight = cycle();
    for (let i = 0; i < 200 && !release; i++) await Promise.resolve();
    expect(release).toBeTypeOf("function");
    stopOddsAnomalyRadar();
    startOddsAnomalyRadar();
    release({ primaryDelivered: true });
    await inFlight;
    expect(deps.send).toHaveBeenCalledTimes(1);
  });

  it("continues scheduling after an unexpected snapshot failure", async () => {
    const scanner = await import("./scanner");
    const before = vi.mocked(scanner.getOddsRadarFixtureSnapshot).mock.calls.length;
    vi.mocked(scanner.getOddsRadarFixtureSnapshot).mockImplementationOnce(() => {
      throw new Error("fixture snapshot unavailable");
    });
    await vi.advanceTimersByTimeAsync(60_000);
    await vi.advanceTimersByTimeAsync(60_000);
    expect(vi.mocked(scanner.getOddsRadarFixtureSnapshot).mock.calls.length - before).toBeGreaterThanOrEqual(2);
  });

  it("keeps bounded state, prunes absent fixtures, and never polls or auto-pins", async () => {
    deps.rows = Array.from({ length: 2_100 }, (_, i) => row(String(i)));
    await cycle();
    deps.rows = [row("fresh")];
    await cycle();
    advance();
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send).toHaveBeenCalledTimes(1);
  });

  it("protects a cold 1:0 boot and excludes stale Ladbrokes/12Bet quotes after blackout", async () => {
    deps.rows[0]!.meta.homeScore = 1;
    deps.contexts.clear();
    deps.trustNewFixtures = false;
    const old = START;
    const quotes = [
      { ts: old - 60_000, line: null, odds: 4.80 },
      { ts: old + 60_000, line: null, odds: 11.00 },
    ];
    const twelve = [
      { ts: old + 120_000, line: null, odds: 13.00 },
      { ts: old + 180_000, line: null, odds: 12.00 },
    ];
    deps.dynamic.mockImplementation(async () => new Map([["1", [
      { cid: "1", bookmaker: "Ladbrokes", side: "AWAY", line: null,
        observedAt: Date.now(), current: quotes.at(-1), history: [...quotes], timeSource: "upstream" },
      { cid: "2", bookmaker: "12Bet", side: "AWAY", line: null,
        observedAt: Date.now(), current: twelve.at(-1), history: [...twelve], timeSource: "upstream" },
    ]]]));
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    expect(deps.contexts.get("1")).toMatchObject({
      home: 1, away: 0, safeAfter: START + 300_000,
    });
    stopOddsAnomalyRadar();
    startOddsAnomalyRadar(); // simulates volatile detector state loss, durable context survives
    advance(301_000);
    quotes.push({ ts: Date.now(), line: null, odds: 11.00 });
    twelve.push({ ts: Date.now(), line: null, odds: 11.00 });
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    advance(60_000);
    twelve.push({ ts: Date.now() - 1000, line: null, odds: 10.75 });
    await cycle(); // first post-boundary observation is a new comparable baseline
    expect(deps.send).toHaveBeenCalledTimes(1);
    expect(deps.send.mock.calls[0]![0]).toContain("12Bet");
    expect(deps.send.mock.calls[0]![0]).not.toContain("13\\.00");
  });

  it("persists a new goal discovered at preflight and cancels dispatch", async () => {
    const scanner = await import("./scanner");
    deps.rows[0]!.current.overDecimal = 1.55;
    deps.rows[0]!.history = [{
      ts: Date.now() - 55_000, line: 2.5, overDecimal: 1.80, underDecimal: 1.85,
    }];
    vi.mocked(scanner.fetchFreshScoreNow)
      .mockImplementationOnce(async () => ({ state: 1, isLive: true,
        homeScore: 0, awayScore: 0, clockLabel: "45" }))
      .mockImplementationOnce(async () => ({ state: 1, isLive: true,
        homeScore: 1, awayScore: 0, clockLabel: "45" }));
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    expect(deps.contexts.get("1")).toMatchObject({
      home: 1, away: 0, goalAt: Date.now(),
      safeAfter: Date.now() + 300_000, revision: 2,
    });
  });

  it("fails closed on durable context loss without sending", async () => {
    deps.storeFailure = true;
    deps.rows[0]!.history = [{
      ts: Date.now() - 55_000, line: 2.5, overDecimal: 1.80, underDecimal: 1.85,
    }];
    deps.rows[0]!.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("shares the durable epoch when a scanner fixture becomes directory-only", async () => {
    const fixture = deps.rows[0]!;
    deps.contexts.set("1", {
      home: 0, away: 0, observedAt: Date.now(), goalAt: null,
      safeAfter: Date.now() - 60_000, revision: 1,
    });
    fixture.needsVerification = true;
    fixture.meta.homeScore = 1;
    deps.score = { state: 1, isLive: true, homeScore: 1, awayScore: 0, clockLabel: "45" };
    fixture.history = [{ ts: Date.now() - 55_000, line: 2.5,
      overDecimal: 1.80, underDecimal: 1.85 }];
    fixture.current.overDecimal = 1.55;
    await cycle();
    expect(deps.send).not.toHaveBeenCalled();
    const epoch = deps.contexts.get("1")!;
    expect(epoch).toMatchObject({ home: 1, safeAfter: Date.now() + 300_000, revision: 2 });
    fixture.needsVerification = false;
    advance(60_000);
    await cycle();
    expect(deps.contexts.get("1")!.revision).toBe(epoch.revision);
    expect(deps.send).not.toHaveBeenCalled();
  });

  it("leaves the original formatter untouched for scanner cards", () => {
    const message = formatUnifiedAlert({
      matchId: "1", league: "Allowed League", home: "Home", away: "Away",
      isLive: true, homeScore: 0, awayScore: 0, minute: "45",
      side: "OVER", line: 2.5, timeline: [], link: null,
    });
    expect(message).toContain("SMART MONEY");
    expect(message).not.toContain("ODDS RADAR");
  });
});