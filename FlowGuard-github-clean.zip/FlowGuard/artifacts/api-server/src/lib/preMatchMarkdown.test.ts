import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("./scanner", () => ({ fetchRaw: vi.fn() }));
vi.mock("./healthcheck", () => ({ parseKickoffMs: vi.fn() }));
vi.mock("./logger", () => ({
  logger: { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() },
}));
vi.mock("./telegramSubscribers", () => ({
  listSubscriberChatIds: () => [],
  removeSubscriber: vi.fn(),
  ensureSubscribersLoaded: vi.fn(),
}));

// Reconstructed from the cached fixture 2935301 and the pre-fix formatter.
// Production 2026-09-25 18:02:01.721Z: msgLen=167, "~" at UTF-8 byte 170.
// Pre-match reminders are not stored in signal_history_entries.raw_card.
const original = [
  "⏰ *Pre\\-Match Reminder \\(24h\\)*",
  "",
  "🏆 *Argentina Primera C Metropolitana*",
  "⚽️ Victoriano Arenas vs Juventud Unida",
  "🕒 Kickoff: 2026\\-09\\-26 13:00 CDT",
  "⏳ Starts in ~24 hours",
].join("\n");
const HOUR = 3_600_000;
const kickoffMs = Date.parse("2026-09-26T18:00:00Z");
const fixture = {
  matchId: "2935301", leagueId: "1461",
  home: "Victoriano Arenas", away: "Juventud Unida", kickoffMs,
};

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

async function setup() {
  vi.resetModules();
  // All requests are mocked BEFORE simulating production; no real transport.
  const fetchMock = vi.fn(async (_url: unknown, _init?: RequestInit) =>
    new Response("{}", { status: 200 }));
  vi.stubGlobal("fetch", fetchMock);
  vi.stubEnv("TELEGRAM_TOKEN", "test-token");
  vi.stubEnv("TELEGRAM_CHAT_ID", "test-chat");
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("REPLIT_DEPLOYMENT", "1");
  const telegram = await import("./telegram");
  const { __testOnly: scheduler } = await import("./preMatchAlerts");
  scheduler.reset();
  scheduler.setLeagueNames(new Map([["1461", "Argentina Primera C Metropolitana"]]));
  return { telegram, scheduler, fetchMock };
}

describe("pre-match MarkdownV2 production regression", () => {
  it("matches the original error and preserves the existing plain-text fallback", async () => {
    const { telegram, fetchMock } = await setup();
    expect(original.length).toBe(167);
    expect(Buffer.byteLength(original.slice(0, original.indexOf("~")))).toBe(170);
    fetchMock.mockResolvedValueOnce(new Response(JSON.stringify({
      ok: false, error_code: 400,
      description: "Bad Request: can't parse entities: Can't find end of Strikethrough entity at byte offset 170",
    }), { status: 400 }));
    expect(await telegram.sendTelegramTo("test-chat", original)).toBe("ok");
    expect(fetchMock).toHaveBeenCalledTimes(2);
    const fallback = JSON.parse(fetchMock.mock.calls[1]![1]!.body as string);
    expect(fallback).not.toHaveProperty("parse_mode");
    expect(fallback.text).toContain("⏳ Starts in ~24 hours");
    expect(fallback.text).toContain("2026-09-26 13:00 CDT");
  });

  it("sends the corrected original on the first MarkdownV2 attempt", async () => {
    const { telegram, scheduler, fetchMock } = await setup();
    const { pending } = scheduler.evaluateFixtures([fixture], Date.parse("2026-09-25T18:02:01.409Z"));
    expect(pending).toHaveLength(1);
    expect(pending[0]!.message).toBe(original.replace("~", "\\~"));
    expect(await telegram.sendTelegramTo("test-chat", pending[0]!.message)).toBe("ok");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(JSON.parse(fetchMock.mock.calls[0]![1]!.body as string)).toMatchObject({
      parse_mode: "MarkdownV2", text: original.replace("~", "\\~"),
    });
  });

  it.each([24, 5, 1])("escapes the approximate time for the on-time %ih tier", async (hours) => {
    const { scheduler } = await setup();
    scheduler.evaluateFixtures([fixture], kickoffMs - 25 * HOUR);
    const { pending } = scheduler.evaluateFixtures([], kickoffMs - hours * HOUR);
    expect(pending).toHaveLength(1);
    expect(pending[0]!.message).toContain(`Starts in \\~${hours} hour${hours === 1 ? "" : "s"}`);
  });

  it("escapes the delayed reminder, dynamic names, and kickoff punctuation", async () => {
    const { scheduler, telegram } = await setup();
    const home = "A_~[B](C)*+-.!\\";
    scheduler.evaluateFixtures([{ ...fixture, home }], kickoffMs - 25 * HOUR);
    const { pending } = scheduler.evaluateFixtures([], kickoffMs - 4 * HOUR);
    expect(pending).toHaveLength(1);
    expect(pending[0]!.message).toContain("Starts in \\~4 hours \\(delayed reminder\\)");
    expect(pending[0]!.message).toContain(telegram.escapeMdV2(home));
    expect(pending[0]!.message).toContain("2026\\-09\\-26");
  });
});