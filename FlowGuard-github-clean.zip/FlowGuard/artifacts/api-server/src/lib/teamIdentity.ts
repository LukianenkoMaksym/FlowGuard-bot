const TEAM_IDENTITY_NOISE = new Set([
  "fk",
  "fc",
  "cf",
  "cd",
  "sc",
  "club",
  "futbol",
  "football",
  "cundinamarca",
  "sub20",
  "u20",
  "u21",
]);

/**
 * Deterministic, alias-free team-name normalization shared by Excapper and
 * NowGoal identity paths.
 */
export function canonicalExplicitTeamAlias(value: string): string {
  const key = value.normalize("NFKD").replace(/\p{Diacritic}/gu, "")
    .toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
  // Exact club identities, not a rule stripping AD, PB or Desportiva globally.
  return ({
    "ad picuiense": "Picuiense",
    "ad guarabira": "Desportiva Guarabira PB",
  } as Record<string, string>)[key] ?? value;
}

export function normalizedTeamName(value: string): string {
  const lexical = canonicalExplicitTeamAlias(value)
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
  const rawTokens = lexical ? lexical.split(" ") : [];
  const tokens: string[] = [];
  for (let index = 0; index < rawTokens.length; index++) {
    const token = rawTokens[index]!;
    if (token === "sub" && rawTokens[index + 1] === "20") {
      index++;
      continue;
    }
    if (TEAM_IDENTITY_NOISE.has(token)) continue;
    tokens.push(token);
  }
  return tokens.join(" ");
}