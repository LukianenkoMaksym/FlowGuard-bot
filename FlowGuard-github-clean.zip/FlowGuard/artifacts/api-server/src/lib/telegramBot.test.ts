import { afterEach, describe, it, expect, vi } from "vitest";
import { resolvePollingMode } from "./telegramBot";

vi.mock("./logger", () => ({
  logger: {
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));
vi.mock("./telegram", () => ({ sendTelegramTo: vi.fn(async () => "ok") }));
vi.mock("./telegramSubscribers", () => ({
  addSubscriber: vi.fn(async () => true),
  removeSubscriber: vi.fn(async () => true),
  getLastUpdateId: vi.fn(() => 0),
  setLastUpdateId: vi.fn(async () => {}),
  ensureSubscribersLoaded: vi.fn(async () => {}),
  subscriberCount: vi.fn(() => 1),
}));

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

// ---------------------------------------------------------------------------
// Unit tests for the polling-mode guard in telegramBot.ts.
//
// resolvePollingMode() is a pure function that accepts an env map so all four
// decision branches can be exercised without touching the module-level cached
// value or spawning a real poll loop.
// ---------------------------------------------------------------------------

describe("resolvePollingMode", () => {
  it("disables polling in a dev workspace (no special env vars)", () => {
    const result = resolvePollingMode({});
    expect(result.shouldPoll).toBe(false);
    expect(result.reason).toMatch(/dev workspace/);
  });

  it("enables polling when REPLIT_DEPLOYMENT=1 (production instance)", () => {
    const result = resolvePollingMode({ REPLIT_DEPLOYMENT: "1", NODE_ENV: "production" });
    expect(result.shouldPoll).toBe(true);
    expect(result.reason).toMatch(/REPLIT_DEPLOYMENT=1/);
  });

  it("does not allow an override to poll outside production", () => {
    const result = resolvePollingMode({ TELEGRAM_POLLING: "enabled" });
    expect(result.shouldPoll).toBe(false);
  });

  it("enables polling with an override in production", () => {
    const result = resolvePollingMode({ TELEGRAM_POLLING: "enabled", REPLIT_DEPLOYMENT: "1", NODE_ENV: "production" });
    expect(result.shouldPoll).toBe(true);
    expect(result.reason).toMatch(/forced on/);
  });

  it("force-disables polling when TELEGRAM_POLLING=disabled, even in production", () => {
    // The explicit override wins over REPLIT_DEPLOYMENT=1.
    const result = resolvePollingMode({ TELEGRAM_POLLING: "disabled", REPLIT_DEPLOYMENT: "1", NODE_ENV: "production" });
    expect(result.shouldPoll).toBe(false);
    expect(result.reason).toMatch(/forced off/);
  });

  it("is case-insensitive for the TELEGRAM_POLLING override value", () => {
    expect(resolvePollingMode({ TELEGRAM_POLLING: "ENABLED", REPLIT_DEPLOYMENT: "1", NODE_ENV: "production" }).shouldPoll).toBe(true);
    expect(resolvePollingMode({ TELEGRAM_POLLING: "Disabled", REPLIT_DEPLOYMENT: "1", NODE_ENV: "production" }).shouldPoll).toBe(false);
  });

  it("ignores REPLIT_DEPLOYMENT values other than '1'", () => {
    // Only the literal string "1" triggers the deployed-instance branch.
    expect(resolvePollingMode({ REPLIT_DEPLOYMENT: "true" }).shouldPoll).toBe(false);
    expect(resolvePollingMode({ REPLIT_DEPLOYMENT: "yes" }).shouldPoll).toBe(false);
    expect(resolvePollingMode({ REPLIT_DEPLOYMENT: "" }).shouldPoll).toBe(false);
  });
});

describe("Telegram polling lifecycle", () => {
  it("aborts the old long poll and allows a clean restart", async () => {
    vi.resetModules();
    vi.stubEnv("TELEGRAM_TOKEN", "test-token");
    vi.stubEnv("TELEGRAM_POLLING", "enabled");
    vi.stubEnv("NODE_ENV", "production");
    vi.stubEnv("REPLIT_DEPLOYMENT", "1");

    const signals: AbortSignal[] = [];
    vi.stubGlobal("fetch", vi.fn((_url: unknown, init?: RequestInit) =>
      new Promise<Response>((_resolve, reject) => {
        const signal = init?.signal;
        expect(signal).toBeInstanceOf(AbortSignal);
        signals.push(signal!);
        signal!.addEventListener("abort", () =>
          reject(Object.assign(new Error("aborted"), { name: "AbortError" })),
        );
      }),
    ));

    const bot = await import("./telegramBot");
    await bot.startTelegramBot();
    expect(signals).toHaveLength(1);

    bot.stopTelegramBot();
    expect(signals[0]?.aborted).toBe(true);

    await bot.startTelegramBot();
    expect(signals).toHaveLength(2);
    expect(signals[1]?.aborted).toBe(false);
    bot.stopTelegramBot();
  });
});
