import { parseExcapperLiveState, type ExcapperLivePeriod } from "./excapperLiveState";

export interface ExcapperBatchMarket {
  line: number;
  over: number;
  under: number;
  overOdds?: number;
  underOdds?: number;
  collectedAt?: number;
}

export interface ExcapperBatchDetail {
  gameId: string;
  score: { home: number; away: number } | null;
  period: ExcapperLivePeriod | null;
  minute: number | null;
  markets: ExcapperBatchMarket[];
}

export interface ExcapperBatchIdentityRow {
  gameId: string;
  team1: string;
  team2: string;
  league: string;
  totalVolume: number;
  isLive?: boolean;
  activity?: "live" | "scheduled" | "unknown";
}

export interface ExcapperBatchSnapshot<Row> {
  rows: Row[];
  details: Map<string, ExcapperBatchDetail>;
  observedAt: number;
  stale: boolean;
  detailCapable: boolean;
}

const MAX_TEXT_BYTES = 2_000_000;
const MAX_OBJECTS = 1_000;
const MAX_DEPTH = 8;
const MIN_INTERVAL_MS = 12_300;
const JITTER_MS = 500;

let inFlight: Promise<ExcapperBatchSnapshot<unknown>> | null = null;
let cached: ExcapperBatchSnapshot<unknown> | null = null;
let nextFetchAt = 0;
let lastError: unknown = null;

function finite(value: unknown): number | null {
  const parsed = typeof value === "number" ? value :
    typeof value === "string" && /^\s*\d+(?:\.\d+)?\s*$/.test(value) ? Number(value) : NaN;
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

function idOf(value: Record<string, unknown>): string | null {
  const candidate = value.gameId ?? value.game_id ?? value.eventId ?? value.event_id ?? value.matchId;
  return (typeof candidate === "string" || typeof candidate === "number") &&
    /^[A-Za-z0-9_-]{1,100}$/.test(String(candidate)) ? String(candidate) : null;
}

function marketsOf(value: Record<string, unknown>, observedAt: number): ExcapperBatchMarket[] {
  const source = value.markets ?? value.lines ?? value.overUnder ?? value.over_under;
  if (!Array.isArray(source)) return [];
  const markets: ExcapperBatchMarket[] = [];
  for (const item of source.slice(0, 50)) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const line = finite(row.line ?? row.total ?? row.handicap);
    const over = finite(row.over ?? row.overVolume ?? row.over_volume);
    const under = finite(row.under ?? row.underVolume ?? row.under_volume);
    if (line === null || over === null || under === null) continue;
    const overOdds = finite(row.overOdds ?? row.over_odds);
    const underOdds = finite(row.underOdds ?? row.under_odds);
    markets.push({
      line, over, under,
      ...(overOdds !== null ? { overOdds } : {}),
      ...(underOdds !== null ? { underOdds } : {}),
      collectedAt: observedAt,
    });
  }
  return markets;
}

function jsonValues(html: string): unknown[] {
  const bounded = html.slice(0, MAX_TEXT_BYTES);
  const values: unknown[] = [];
  try {
    values.push(JSON.parse(bounded));
  } catch {
    // HTML pages continue through bounded application/json extraction.
  }
  for (const match of bounded.matchAll(
    /<script\b[^>]*type=["']application\/(?:json|ld\+json)["'][^>]*>([\s\S]*?)<\/script>/gi,
  )) {
    try {
      values.push(JSON.parse(match[1]!));
    } catch {
      // An invalid script is not evidence.
    }
  }
  return values;
}

/** Extract only structured, game-id-scoped evidence; never match free-form page numbers. */
export function parseExcapperBatchDetails(
  html: string,
  observedAt: number,
): Map<string, ExcapperBatchDetail> {
  const details = new Map<string, ExcapperBatchDetail>();
  const seen = new WeakSet<object>();
  let visited = 0;
  const visit = (value: unknown, depth: number): void => {
    if (!value || typeof value !== "object" || depth > MAX_DEPTH || visited >= MAX_OBJECTS) return;
    if (seen.has(value)) return;
    seen.add(value);
    visited++;
    if (Array.isArray(value)) {
      for (const item of value) visit(item, depth + 1);
      return;
    }
    const object = value as Record<string, unknown>;
    const gameId = idOf(object);
    if (gameId) {
      const live = parseExcapperLiveState(object);
      const markets = marketsOf(object, observedAt);
      if (live.rawFound || markets.length > 0) {
        const current = details.get(gameId);
        const candidate: ExcapperBatchDetail = {
          gameId,
          score: live.score,
          period: live.period,
          minute: live.minute,
          markets,
        };
        if (!current ||
          Number(Boolean(candidate.score)) + Number(Boolean(candidate.period)) +
          Number(candidate.minute !== null) + Number(candidate.markets.length > 0) >
          Number(Boolean(current.score)) + Number(Boolean(current.period)) +
          Number(current.minute !== null) + Number(current.markets.length > 0)) {
          details.set(gameId, candidate);
        }
      }
    }
    for (const child of Object.values(object)) visit(child, depth + 1);
  };
  for (const value of jsonValues(html)) visit(value, 0);
  return details;
}

export function parseExcapperStructuredRows(raw: string): ExcapperBatchIdentityRow[] {
  const rows = new Map<string, ExcapperBatchIdentityRow>();
  const seen = new WeakSet<object>();
  let visited = 0;
  const visit = (value: unknown, depth: number): void => {
    if (!value || typeof value !== "object" || depth > MAX_DEPTH || visited >= MAX_OBJECTS) return;
    if (seen.has(value)) return;
    seen.add(value);
    visited++;
    if (Array.isArray(value)) {
      for (const item of value) visit(item, depth + 1);
      return;
    }
    const object = value as Record<string, unknown>;
    const gameId = idOf(object);
    const home = object.team1 ?? object.homeTeam ?? object.home_team ?? object.home;
    const away = object.team2 ?? object.awayTeam ?? object.away_team ?? object.away;
    const league = object.league ?? object.competition ?? object.tournament;
    if (gameId && typeof home === "string" && typeof away === "string" &&
      typeof league === "string" && home.trim() && away.trim() && league.trim()) {
      const activityValue = String(object.activity ?? object.status ?? "").toLowerCase();
      const isLive = object.isLive === true || /^(?:live|in[- ]?play|playing)$/.test(activityValue);
      rows.set(gameId, {
        gameId,
        team1: home.trim(),
        team2: away.trim(),
        league: league.trim(),
        totalVolume: finite(object.totalVolume ?? object.total_volume ?? object.money) ?? 0,
        isLive,
        activity: isLive ? "live" : activityValue ? "scheduled" : "unknown",
      });
    }
    for (const child of Object.values(object)) visit(child, depth + 1);
  };
  for (const value of jsonValues(raw)) visit(value, 0);
  return [...rows.values()].slice(0, 1_000);
}

/**
 * One process-wide root snapshot. Manual refreshes and the coordinator share
 * this promise and cannot bypass its 12.3–12.8 second completion interval.
 */
export function loadExcapperBatchSnapshot<Row>(
  loadRoot: () => Promise<string>,
  parseRows: (html: string) => Row[],
): Promise<ExcapperBatchSnapshot<Row>> {
  const now = Date.now();
  if (cached && now < nextFetchAt) {
    const remaining = nextFetchAt - now;
    if (remaining > 800) return Promise.resolve(cached as ExcapperBatchSnapshot<Row>);
  } else if (!cached && lastError && now < nextFetchAt) {
    return Promise.reject(lastError);
  }
  if (inFlight) return inFlight as Promise<ExcapperBatchSnapshot<Row>>;
  const request = (async (): Promise<ExcapperBatchSnapshot<Row>> => {
    try {
      const remaining = nextFetchAt - Date.now();
      if (remaining > 0 && remaining <= 800) {
        await new Promise((resolve) => setTimeout(resolve, remaining));
      }
      const html = await loadRoot();
      const observedAt = Date.now();
      const rows = parseRows(html).slice(0, 1_000);
      const allowedIds = new Set(rows.flatMap((row) => {
        const gameId = (row as Record<string, unknown>)["gameId"];
        return typeof gameId === "string" ? [gameId] : [];
      }));
      const details = new Map(
        [...parseExcapperBatchDetails(html, observedAt)]
          .filter(([gameId]) => allowedIds.has(gameId)),
      );
      const snapshot: ExcapperBatchSnapshot<Row> = {
        rows,
        details,
        observedAt,
        stale: false,
        detailCapable: details.size > 0,
      };
      cached = snapshot as ExcapperBatchSnapshot<unknown>;
      nextFetchAt = observedAt + MIN_INTERVAL_MS + Math.floor(Math.random() * (JITTER_MS + 1));
      lastError = null;
      return snapshot;
    } catch (error) {
      lastError = error;
      nextFetchAt = Math.max(nextFetchAt, Date.now() + 25_000);
      if (cached) {
        cached = { ...cached, stale: true };
        return cached as ExcapperBatchSnapshot<Row>;
      }
      throw error;
    } finally {
      inFlight = null;
    }
  })();
  inFlight = request as Promise<ExcapperBatchSnapshot<unknown>>;
  return request;
}

export function __testOnlyResetExcapperBatchCache(): void {
  inFlight = null;
  cached = null;
  nextFetchAt = 0;
  lastError = null;
}

export function getExcapperBatchStatus(): {
  detailCapable: boolean;
  stale: boolean;
  observedAt: number | null;
  nextFetchAt: number | null;
} {
  return {
    detailCapable: cached?.detailCapable ?? false,
    stale: cached?.stale ?? false,
    observedAt: cached?.observedAt ?? null,
    nextFetchAt: nextFetchAt || null,
  };
}