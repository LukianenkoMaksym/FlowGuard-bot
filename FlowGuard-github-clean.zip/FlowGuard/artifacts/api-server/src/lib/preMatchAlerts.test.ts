import { describe, it, expect, beforeEach, vi } from "vitest";

// ---------------------------------------------------------------------------
// Regression coverage for the pre-match reminder scheduler.
//
// The bug: the 24h reminder fired but the 5h and 1h reminders were "completely
// missed". Root cause — the scheduler re-derived every fixture from the type=12
// META feed each poll, but that feed is a day-ahead schedule with known coverage
// gaps: a low-liquidity regional match (exactly the alert targets) is present at
// the 24h crossing but drops out of the feed before the 5h/1h crossings, so
// those marks never had a fixture to evaluate.
//
// The fix: once a target fixture is discovered it is cached, and marks are
// evaluated against the cache every poll — so 5h and 1h still fire after the
// fixture leaves the feed. These tests drive the pure `evaluateFixtures` core
// via the `__testOnly` seam, with sibling modules stubbed so nothing touches the
// network, Telegram, or the filesystem.
// ---------------------------------------------------------------------------

vi.mock("./logger", () => {
  const noop = () => {};
  const log = {
    debug: noop,
    info: noop,
    warn: noop,
    error: noop,
    fatal: noop,
    trace: noop,
    child: () => log,
  };
  return { logger: log };
});

vi.mock("./telegram", () => ({
  sendTelegram: vi.fn(async () => {}),
  isTelegramConfigured: () => false,
  escapeMdV2: (s: string) => s,
}));

vi.mock("./scanner", () => ({
  fetchRaw: vi.fn(async () => ""),
}));

vi.mock("./healthcheck", () => ({
  parseKickoffMs: vi.fn(() => null),
}));

vi.mock("./upstream", () => ({
  currentBaseUrl: () => "https://example.test",
  endpointsFor: () => ({ meta: "meta", leagues: "leagues" }),
  withCacheBuster: (u: string) => u,
}));

import { __testOnly } from "./preMatchAlerts";

const HOUR = 60 * 60 * 1000;
const KAKKONEN_LEAGUE_ID = "100";

// A target fixture: leagueId resolves to a name that matches the Kakkonen target.
function fixture(kickoffMs: number) {
  return {
    matchId: "2987515",
    leagueId: KAKKONEN_LEAGUE_ID,
    home: "FC Honka 2",
    away: "EIF",
    kickoffMs,
  };
}

describe("preMatchAlerts scheduler", () => {
  beforeEach(() => {
    __testOnly.reset();
    __testOnly.setLeagueNames(new Map([[KAKKONEN_LEAGUE_ID, "Finland Kakkonen"]]));
  });

  it("fires the 24h mark when a target fixture is first discovered", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 24 * HOUR;

    const { pending } = __testOnly.evaluateFixtures([fixture(kickoff)], now);

    expect(pending.map((p) => p.mark.key)).toEqual(["24h"]);
    expect(__testOnly.trackedFixtures.has("2987515")).toBe(true);
  });

  it("CORE REGRESSION: 5h and 1h still fire after the fixture drops out of the feed", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 24 * HOUR;

    // Discovery poll at 24h — fixture present in feed, 24h fires and is cached.
    const first = __testOnly.evaluateFixtures([fixture(kickoff)], now);
    expect(first.pending.map((p) => p.mark.key)).toEqual(["24h"]);

    // Feed no longer lists the fixture (empty feed) but the cache still has it.
    // 5h crossing — must still fire purely from the cache.
    const at5h = __testOnly.evaluateFixtures([], kickoff - 5 * HOUR);
    expect(at5h.pending.map((p) => p.mark.key)).toEqual(["5h"]);

    // 1h crossing — also from the cache, feed still empty.
    const at1h = __testOnly.evaluateFixtures([], kickoff - 1 * HOUR);
    expect(at1h.pending.map((p) => p.mark.key)).toEqual(["1h"]);

    // All three marks are now recorded exactly once.
    expect([...__testOnly.sentKeys.keys()].sort()).toEqual([
      "2987515:1h",
      "2987515:24h",
      "2987515:5h",
    ]);
  });

  it("never fires a mark twice (dedup) on repeated polls in the same window", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 24 * HOUR;

    __testOnly.evaluateFixtures([fixture(kickoff)], now);
    // Poll again a few minutes later, still inside the 24h window.
    const again = __testOnly.evaluateFixtures([fixture(kickoff)], now + 5 * 60 * 1000);
    expect(again.pending).toHaveLength(0);
  });

  it("cannot fire for a match it never discovered (empty cache + empty feed)", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const { pending } = __testOnly.evaluateFixtures([], now);
    expect(pending).toHaveLength(0);
    expect(__testOnly.trackedFixtures.size).toBe(0);
  });

  it("does not cache or fire for non-target leagues", () => {
    __testOnly.setLeagueNames(new Map([[KAKKONEN_LEAGUE_ID, "English Premier League"]]));
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 24 * HOUR;

    const { pending } = __testOnly.evaluateFixtures([fixture(kickoff)], now);
    expect(pending).toHaveLength(0);
    expect(__testOnly.trackedFixtures.size).toBe(0);
  });

  it("rechecks cached raw league names instead of trusting a stored target label", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 5 * HOUR;
    __testOnly.trackedFixtures.set("historical-sikkim", {
      matchId: "historical-sikkim",
      leagueId: "1467",
      // Historical cache rows may have been mislabeled by an older matcher.
      leagueLabel: "Singapore Premier League",
      leagueName: "India Sikkim S-League",
      home: "Sikkim United",
      away: "Sikkim FC",
      kickoffMs: kickoff,
      firstSeenMs: now,
    });

    const { pending } = __testOnly.evaluateFixtures([], now);
    expect(pending).toHaveLength(0);
    // Keep the historical row in memory; only its reminder output is gated.
    expect(__testOnly.trackedFixtures.has("historical-sikkim")).toBe(true);
  });

  it("CATCH-UP: fires a tier on the first poll AFTER its mark when the exact window was missed", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 24 * HOUR;

    // Discovery at 24h arms all three tiers and fires 24h.
    const first = __testOnly.evaluateFixtures([fixture(kickoff)], now);
    expect(first.pending.map((p) => p.mark.key)).toEqual(["24h"]);

    // No poll lands at the 5h mark (process was down / feed outage). The next
    // poll happens at 4h before kickoff — well past the old 15-min window. The 5h
    // tier must still fire via catch-up; 1h is not yet due.
    const at4h = __testOnly.evaluateFixtures([], kickoff - 4 * HOUR);
    expect(at4h.pending.map((p) => p.mark.key)).toEqual(["5h"]);
  });

  it("CATCH-UP COLLAPSE: when multiple tiers cross in one cycle, only the closest is sent", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 24 * HOUR;

    // Arm all tiers (24h fires).
    __testOnly.evaluateFixtures([fixture(kickoff)], now);

    // Process down across BOTH the 5h and 1h marks; next poll at 30 min out.
    // Only the closest (1h) tier should be sent; 5h is suppressed (handled),
    // never producing a stale "5 hours" message right before kickoff.
    const at30m = __testOnly.evaluateFixtures([], kickoff - 30 * 60 * 1000);
    expect(at30m.pending.map((p) => p.mark.key)).toEqual(["1h"]);

    const rec5h = __testOnly.sentKeys.get("2987515:5h");
    expect(rec5h?.suppressed).toBe(true);
    // All three keys recorded exactly once, none can re-fire.
    expect([...__testOnly.sentKeys.keys()].sort()).toEqual([
      "2987515:1h",
      "2987515:24h",
      "2987515:5h",
    ]);
  });

  it("STALE SUPPRESSION: a fixture surfacing late never sends an out-of-date longer tier", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 12 * HOUR; // only discovered 12h out

    // 24h is already past at discovery -> suppressed (no fake "24h" reminder).
    const first = __testOnly.evaluateFixtures([fixture(kickoff)], now);
    expect(first.pending).toHaveLength(0);
    expect(__testOnly.sentKeys.get("2987515:24h")?.suppressed).toBe(true);

    // 5h and 1h are still in the future and must fire normally.
    const at5h = __testOnly.evaluateFixtures([], kickoff - 5 * HOUR);
    expect(at5h.pending.map((p) => p.mark.key)).toEqual(["5h"]);
    const at1h = __testOnly.evaluateFixtures([], kickoff - 1 * HOUR);
    expect(at1h.pending.map((p) => p.mark.key)).toEqual(["1h"]);
  });

  it("GRACE: a mark discovered a few minutes late still fires; well past is suppressed", () => {
    // Within the 15-min discovery grace of the 24h mark -> still fires (locks the
    // original 24h behavior).
    const kickoffA = Date.UTC(2026, 5, 1, 12, 0, 0);
    const nowA = kickoffA - (24 * HOUR - 10 * 60 * 1000); // 23h50m before kickoff
    const a = __testOnly.evaluateFixtures([fixture(kickoffA)], nowA);
    expect(a.pending.map((p) => p.mark.key)).toEqual(["24h"]);

    __testOnly.reset();
    __testOnly.setLeagueNames(new Map([[KAKKONEN_LEAGUE_ID, "Finland Kakkonen"]]));

    // Beyond the grace (discovered 23h40m out) -> 24h suppressed, never sent.
    const kickoffB = Date.UTC(2026, 5, 2, 12, 0, 0);
    const nowB = kickoffB - (24 * HOUR - 20 * 60 * 1000); // 23h40m before kickoff
    const b = __testOnly.evaluateFixtures([fixture(kickoffB)], nowB);
    expect(b.pending).toHaveLength(0);
    expect(__testOnly.sentKeys.get("2987515:24h")?.suppressed).toBe(true);
  });

  it("never fires any tier once kickoff has passed", () => {
    const now = Date.UTC(2026, 5, 1, 12, 0, 0);
    const kickoff = now + 24 * HOUR;
    __testOnly.evaluateFixtures([fixture(kickoff)], now); // arm + fire 24h

    // Poll resumes 10 min AFTER kickoff (process was down across it).
    const afterKickoff = __testOnly.evaluateFixtures([], kickoff + 10 * 60 * 1000);
    expect(afterKickoff.pending).toHaveLength(0);
  });

  it("is timezone-invariant: the same kickoff/now epochs fire regardless of server TZ", () => {
    // Δt is computed from absolute UTC epochs, so the result must not depend on
    // process.env.TZ. We assert the 1h mark fires for the same epoch inputs.
    const kickoff = Date.UTC(2026, 5, 1, 12, 0, 0);
    const now = kickoff - 1 * HOUR;

    // Seed the cache via a discovery poll well before, then evaluate at 1h.
    __testOnly.evaluateFixtures([fixture(kickoff)], kickoff - 24 * HOUR);
    const at1h = __testOnly.evaluateFixtures([], now);
    expect(at1h.pending.map((p) => p.mark.key)).toContain("1h");
  });
});
