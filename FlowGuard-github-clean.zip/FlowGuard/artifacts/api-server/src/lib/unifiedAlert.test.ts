import { beforeEach, describe, expect, it } from "vitest";
import {
  claimUnifiedAlertEvent,
  formatUnifiedAlert,
  getRecentUnifiedInflow,
  normalizeFixtureClock,
  recordUnifiedInflow,
  resolvePositiveOddsDrop,
  resolveUnifiedAlertMinute,
  resetUnifiedAlertStateForTests,
  type UnifiedAlertInput,
} from "./unifiedAlert";

const start = Date.parse("2026-09-21T07:02:00Z");

function alertInput(): UnifiedAlertInput {
  return {
    matchId: "3068862",
    league: "Finland Kakkonen",
    home: "Alpha FC",
    away: "Beta United",
    isLive: true,
    homeScore: 0,
    awayScore: 0,
    minute: "12",
    side: "OVER",
    line: 3.5,
    timeline: [
      { ts: start, line: 3.5, odds: 2.1 },
      { ts: start + 60_000, line: 3.5, odds: 1.9 },
      { ts: start + 2 * 60_000, line: 3.5, odds: 1.7 },
      { ts: start + 3 * 60_000, line: 3.5, odds: 1.65 },
    ],
    inflow: {
      matchId: "3068862",
      line: 3.5,
      side: "OVER",
      single: 3163,
      total: 4834,
      minute: "12",
      observedAt: start + 3 * 60_000,
    },
    link: "https://www.nowgoal26.com/match/live-3068862.html",
  };
}

describe("RADAR card direction isolation", () => {
  it.each(["drop", "rise"] as const)("keeps only %s books and their history, without a display threshold", (type) => {
    const at = start + 60_000;
    const from = 2;
    const to = type === "drop" ? 1.99 : 2.01;
    const opposite = type === "drop" ? "rise" : "drop";
    const input: UnifiedAlertInput = {
      ...alertInput(), source: "odds-radar", alertAt: at,
      radarMovement: { type, from, to },
      radarBooks: [
        { cid: "1", bookmaker: "Same", type, from, to, percent: 0.5,
          quoteAt: at, history: [{ ts: start, odds: from }, { ts: at, odds: to }] },
        { cid: "2", bookmaker: "Opposite", type: opposite, from: 3,
          to: type === "drop" ? 5 : 1.5, percent: 50, quoteAt: at,
          history: [{ ts: start, odds: 3 }, { ts: at, odds: 5 }] },
      ],
    };
    const card = formatUnifiedAlert(input);
    expect(card).toContain(`${type === "drop" ? "📉" : "📈"} Тотал больше 3\\.5 · Same:`);
    expect(card).toContain("Как шёл кэф \\(Same\\)");
    expect(card).not.toContain("Opposite");
    expect(card).not.toContain("5\\.00");
    expect(formatUnifiedAlert({ ...input, source: "scanner" })).toContain("Opposite");
    const empty = formatUnifiedAlert({ ...input, radarBooks: input.radarBooks!.slice(1) });
    expect(empty).not.toContain("Opposite");
    expect(empty).not.toContain("Как шёл кэф");
  });

  it("keeps only confirmed revert books and selects history from that filtered set", () => {
    const at = start + 4 * 60_000;
    const input: UnifiedAlertInput = {
      ...alertInput(), source: "odds-radar", alertAt: at,
      radarMovement: { type: "revert", from: 2.4, to: 2.02 },
      radarBooks: [
        { cid: "drop", bookmaker: "OrdinaryDrop", type: "drop", from: 6, to: 2,
          percent: -66, quoteAt: at, history: [{ ts: start, odds: 6 }, { ts: at, odds: 2 }] },
        { cid: "rise", bookmaker: "OrdinaryRise", type: "rise", from: 2, to: 6,
          percent: 200, quoteAt: at, history: [{ ts: start, odds: 2 }, { ts: at, odds: 6 }] },
        { cid: "revert", bookmaker: "OwnRevert", type: "revert", baseline: 2,
          peak: 2.5, from: 2.4, to: 2.02, percent: -15.8, durationMs: 120_000,
          quoteAt: at, history: [
            { ts: start, odds: 2 }, { ts: start + 2 * 60_000, odds: 2.5 },
            { ts: start + 3 * 60_000, odds: 2.4 }, { ts: at, odds: 2.02 },
          ] },
      ],
    };
    const card = formatUnifiedAlert(input);
    expect(card).toContain("⚡ Тотал больше 3\\.5 · OwnRevert: скачок 2\\.00 → 2\\.50 → 2\\.02 за 2 мин");
    expect(card).toContain("Как шёл кэф \\(OwnRevert\\)");
    expect(card).toContain("07:04 · 2\\.50 📈");
    expect(card).toContain("07:06 · 2\\.02 📉");
    expect(card).not.toContain("OrdinaryDrop");
    expect(card).not.toContain("OrdinaryRise");
    expect(card).not.toContain("6\\.00");

    const ordinaryOnly = formatUnifiedAlert({
      ...input, radarBooks: input.radarBooks!.slice(0, 2),
      bookmaker: "OrdinaryRise",
    });
    expect(ordinaryOnly).toContain("📊 Рынок: Тотал больше 3\\.5");
    expect(ordinaryOnly).not.toContain("OrdinaryRise");
    expect(ordinaryOnly).not.toContain("Как шёл кэф");
    expect(formatUnifiedAlert({ ...input, source: "scanner" })).toContain("OrdinaryRise");
  });

  it("does not attribute a revert to a book without complete, consistent excursion evidence", () => {
    const at = start + 60_000;
    const input: UnifiedAlertInput = {
      ...alertInput(), source: "odds-radar", alertAt: at,
      radarMovement: { type: "revert", from: 2.4, to: 2.02 },
      radarBooks: [
        { cid: "missing", bookmaker: "MissingPeak", type: "revert",
          baseline: 2, from: 2.4, to: 2.02, percent: -15, durationMs: 60_000,
          quoteAt: at, history: [{ ts: start, odds: 2.4 }, { ts: at, odds: 2.02 }] },
        { cid: "wrong", bookmaker: "StillSpiking", type: "revert",
          baseline: 2, peak: 2.5, from: 2.4, to: 2.6, percent: 8, durationMs: 60_000,
          quoteAt: at, history: [{ ts: start, odds: 2.4 }, { ts: at, odds: 2.6 }] },
      ],
    };
    const card = formatUnifiedAlert(input);
    expect(card).toContain("📊 Рынок: Тотал больше 3\\.5");
    expect(card).not.toContain("MissingPeak");
    expect(card).not.toContain("StillSpiking");
    expect(card).not.toContain("Как шёл кэф");
    expect(formatUnifiedAlert({ ...input, radarBooks: undefined, bookmaker: "MissingPeak" }))
      .not.toContain("MissingPeak");
    expect(formatUnifiedAlert({ ...input, source: "scanner" })).toContain("MissingPeak");
  });
});

beforeEach(resetUnifiedAlertStateForTests);

describe("unified Telegram alert", () => {
  it("does not name a quiet bookmaker or invent an attributable price for empty movement evidence", () => {
    const at = start + 60_000;
    const quiet = formatUnifiedAlert({
      ...alertInput(), source: "odds-radar", bookmaker: "Bet365",
      radarMovement: { type: "revert", from: 2, to: 2 },
      radarBooks: [{ cid: "8", bookmaker: "Bet365", type: "revert",
        from: 2, to: 2, percent: 0, quoteAt: at,
        history: [{ ts: start, odds: 2 }] }],
      timeline: [], alertAt: at,
    });
    expect(quiet).toContain("📊 Рынок: Тотал больше 3\\.5");
    expect(quiet).not.toContain("Bet365");
    expect(quiet).not.toContain("Как шёл кэф");
    expect(quiet).not.toContain("2\\.00 → 2\\.00");

    const empty = formatUnifiedAlert({
      ...alertInput(), source: "scanner", radarBooks: [], bookmaker: "QuietBook",
      timeline: [{ ts: start, line: 3.5, odds: 2 }, { ts: at, line: 3.5, odds: 1.8 }],
      alertAt: at,
    });
    expect(empty).toContain("📊 Рынок: Тотал больше 3\\.5");
    expect(empty).not.toContain("QuietBook");
    expect(empty).not.toContain("2\\.00 → 1\\.80");
    expect(empty).not.toContain("Как шёл кэф");
  });

  it("renders only independently moving books and five real slices from the strongest one", () => {
    const at = start + 7 * 60_000;
    const message = formatUnifiedAlert({
      ...alertInput(), source: "odds-radar", market: { kind: "1X2", outcome: "HOME" },
      radarMovement: { type: "drop", from: 2.5, to: 2.2 },
      alertAt: at + 2 * 60_000, quoteAt: at, timeline: [],
      radarBooks: [
        { cid: "42", bookmaker: "18Bet", type: "rise", from: 2.45, to: 2.55,
          percent: 4, quoteAt: at, history: [] },
        { cid: "8", bookmaker: "Bet365", type: "drop", from: 2.5, to: 2.2,
          percent: 12, quoteAt: at, history: [
            ...Array.from({ length: 7 }, (_, i) =>
              ({ ts: start + i * 60_000, odds: 2.7 - i * 0.07 })),
            { ts: at, odds: 2.2 },
            { ts: at + 60_000, odds: 1.8 },
          ] },
      ],
    });
    expect(message).toContain("📉 Победа хозяев · Bet365: 2\\.50 → 2\\.20 \\(\\-12\\.0%\\)");
    expect(message).not.toContain("18Bet");
    expect(message).toContain("Как шёл кэф \\(Bet365\\)");
    expect(message).not.toContain("07:02 ·");
    expect(message).not.toContain("07:03 ·");
    expect(message).not.toContain("07:04 ·");
    expect(message).toContain("07:05 ·");
    expect(message).toContain("07:09 · 2\\.20 📉");
    expect(message).not.toContain("07:10 ·");
    expect(message).not.toContain("1\\.80 📉");
    expect((message.match(/· \d\\\.\d\d (?:📉|📈|→|—)/g) ?? []).length).toBe(5);
    expect(message).not.toContain("188Bet");
  });

  it("shows the whole evidenced spike and return duration, without inventing a five-minute cash window", () => {
    const spike = formatUnifiedAlert({
      ...alertInput(), source: "odds-radar", side: "UNDER", line: 2.5,
      radarMovement: { type: "revert", from: 2.6, to: 1.95 },
      radarBooks: [{ cid: "8", bookmaker: "Bet365", type: "revert", baseline: 1.9, from: 2.2,
        peak: 2.6, to: 1.95, durationMs: 240_000, percent: 36.8,
        quoteAt: start, history: [] }],
      alertAt: start,
    });
    expect(spike).toContain("⚡ Тотал меньше 2\\.5 · Bet365: скачок 1\\.90 → 2\\.60 → 1\\.95 за 4 мин");
    expect(spike).not.toContain("Как шёл кэф");
    const cash = formatUnifiedAlert({ ...alertInput(), source: "excapper-global",
      timeline: [], currentQuote: null, alertAt: start });
    expect(cash).toContain("💎 SMART EXCAPPER");
    expect(cash).toContain("📊 Рынок: Тотал больше 3\\.5");
    expect(cash).toContain("Вливание: \\+€3,163 за раз / €4,834 всего");
    expect(cash.indexOf("💰 Вливание:")).toBeLessThan(cash.indexOf("📊 Рынок:"));
    expect(cash).not.toContain("за 5 мин");
    const actualFiveMin = formatUnifiedAlert({ ...alertInput(), source: "excapper-global",
      timeline: [], currentQuote: null, alertAt: start, volumeWindowMs: 300_000 });
    expect(actualFiveMin).toContain("Вливание: \\+€3,163 за 5 мин");
  });

  it("shows the same structured card for 1X2, both odds directions, and a repeat after cooldown", () => {
    const timeline = Array.from({ length: 8 }, (_, index) => ({
      ts: start + index * 60_000, odds: 1.5 + index * 0.1,
    }));
    const card = formatUnifiedAlert({
      ...alertInput(), source: "odds-radar",
      market: { kind: "1X2", outcome: "AWAY" }, bookmaker: "Bet365",
      radarMovement: { type: "rise", from: 2, to: 2.2 },
      oneX2Timeline: timeline, timeline: [],
      isRepeat: true, alertAt: start + 7 * 60_000, quoteAt: start + 7 * 60_000,
    });
    expect(card).toContain("📈 Победа гостей · Bet365: 2\\.00 → 2\\.20 \\(\\+10\\.0%\\)");
    expect(card).toContain("🔁 повторный сигнал");
    expect((card.match(/· \d\\\.\d\d (?:📉|📈|→|—)/g) ?? []).length).toBe(5);
    expect(card).not.toContain("1\\.50");
    expect(card).not.toContain("Тотал больше");
    const revert = formatUnifiedAlert({
      ...alertInput(), source: "odds-radar", market: { kind: "1X2", outcome: "HOME" },
      radarMovement: { type: "revert", from: 2.2, to: 2.02 }, oneX2Timeline: [],
      radarBooks: [{ cid: "8", bookmaker: "Bet365", type: "revert",
        baseline: 2, peak: 2.4, from: 2.2, to: 2.02, durationMs: 60_000,
        percent: -8.2, quoteAt: start, history: [] }],
      isRepeat: false, bookmaker: "Bet365", alertAt: start,
    });
    expect(revert).toContain("⚡ Победа хозяев · Bet365: скачок 2\\.00 → 2\\.40 → 2\\.02 за 1 мин");
    expect(revert).not.toContain("Как шёл кэф");
    expect(revert).not.toContain("повторный сигнал");
    expect(revert).not.toContain("П1");
  });

  it("rejects a line-change alert rather than formatting it as a price movement", () => {
    expect(() => formatUnifiedAlert({
      ...alertInput(), source: "odds-radar",
      radarMovement: { type: "line", from: 2.75, to: 2.5 },
    })).toThrow(/price drop, rise or revert/);
  });

  it("includes the trigger quote even if unchanged from the previous slice, not the later quote", () => {
    const card = formatUnifiedAlert({
      ...alertInput(), source: "odds-radar",
      market: { kind: "1X2", outcome: "HOME" }, bookmaker: "Bet365",
      radarMovement: { type: "drop", from: 2.4, to: 2 },
      oneX2Timeline: [
        { ts: start, odds: 2.4 },
        { ts: start + 60_000, odds: 2 },
        { ts: start + 2 * 60_000, odds: 2 },
        { ts: start + 3 * 60_000, odds: 1.8 },
      ],
      timeline: [],
      quoteAt: start + 2 * 60_000, alertAt: start + 4 * 60_000,
    });
    expect(card).toContain("07:04 · 2\\.00 →");
    expect(card).not.toContain("07:05 ·");
    expect(card).not.toContain("1\\.80 📉");
    expect(card).toContain("📉 Победа хозяев · Bet365: 2\\.40 → 2\\.00 \\(\\-16\\.7%\\)");
    expect(card).not.toContain("нет предыдущих срезов");
  });

  it("renders a cutoff pre-bet wave and an explicit building note only on global cards", () => {
    const prebet = {
      betTime: start + 4 * 60_000, inflow15m: 120, inflow60m: 140,
      betCount15m: 3, observationDepth: 3, firstObservedAt: start,
    };
    const timeline = [
      { ts: start, line: 3.5, odds: 1.8 },
      { ts: start + 2 * 60_000, line: 3.5, odds: 1.65 },
      { ts: start + 4 * 60_000, line: 3.5, odds: 1.48 },
      { ts: start + 5 * 60_000, line: 3.5, odds: 1.3 },
    ];
    const card = formatUnifiedAlert({ ...alertInput(), source: "excapper-global",
      timeline, currentQuote: timeline[3], prebet });
    expect(card).toContain("1\\.80 → 1\\.48 \\(\\-17\\.8%\\)");
    expect(card).toContain("Как шёл кэф:");
    expect(card).toContain("07:06 · 1\\.48 📉");
    expect(card).toContain("Вливание: \\+€3,163 за раз / €4,834 всего");
    expect(card).not.toContain("1\\.30");
    const building = formatUnifiedAlert({ ...alertInput(), source: "excapper-global",
      timeline: timeline.slice(0, 1), currentQuote: timeline[0],
      prebet: { ...prebet, observationDepth: 1 } });
    expect(building).toContain("— → 1\\.80 \\(—\\)");
    expect(building).not.toContain("Как шёл кэф");
    const scanner = formatUnifiedAlert({ ...alertInput(), source: "scanner",
      timeline: timeline.slice(0, 3), prebet });
    expect(scanner).toContain("Как шёл кэф:");
    expect(scanner).not.toContain("1\\.30");
  });
  it.each([
    [undefined, "🔴 SMART MONEY"],
    ["scanner", "🔴 SMART MONEY"],
    ["excapper-global", "💎 SMART EXCAPPER"],
  ] as const)("uses the correct %s alert header", (source, header) => {
    const message = formatUnifiedAlert({ ...alertInput(), source });
    expect(message.split("\n")[0]).toMatch(new RegExp(`^${header} · \\d\\d:\\d\\d$`));
  });

  it("shows only the authentic exact-line current decimal quote in a global card without history", () => {
    const input: UnifiedAlertInput = {
      ...alertInput(),
      source: "excapper-global",
      timeline: [],
      currentQuote: { ts: start, line: 3.5, odds: 1.91 },
    };
    const message = formatUnifiedAlert(input);
    expect(message).toContain("— → 1\\.91 \\(—\\)");
    expect(message).not.toContain("Как шёл кэф");
    expect(message).not.toContain("0\\.0%");
    expect(claimUnifiedAlertEvent(input, start)).toBe(false);

    // Scanner without authentic baseline cannot infer a price movement.
    const scanner = formatUnifiedAlert({ ...input, source: "scanner" });
    expect(scanner).toContain("— → 1\\.91 \\(—\\)");
  });

  it.each([
    ["wrong-line", { ts: start, line: 2.5, odds: 1.91 }],
    ["invalid-decimal", { ts: start, line: 3.5, odds: 1 }],
    ["invalid-timestamp", { ts: Number.NaN, line: 3.5, odds: 1.91 }],
  ] as const)("never shows a %s global quote", (_label, currentQuote) => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      source: "excapper-global",
      timeline: [],
      currentQuote,
    });
    expect(message).toContain("📊 Рынок: Тотал больше 3\\.5");
    expect(message).not.toContain("1\\.91");
  });

  it("renders the requested structured drop, authentic inflow, reverse timeline and link", () => {
    const message = formatUnifiedAlert(alertInput());

    expect(message.startsWith("🔴 SMART MONEY · ")).toBe(true);
    expect(message).toContain("Finland Kakkonen");
    expect(message).toContain("Alpha FC");
    expect(message).toContain("0:0 \\(12'\\)");
    expect(message).toContain("Тотал больше 3\\.5");
    expect(message).toContain("букмекер неизвестен");
    expect(message).toContain("2\\.10 → 1\\.65 \\(\\-21\\.4%\\)");
    expect(message).toContain("Excapper \\+€3,163 за раз / €4,834 всего");
    expect(message.indexOf("07:02 · 2\\.10")).toBeLessThan(message.indexOf("07:04 · 1\\.70"));
    expect(message).toContain("live-3068862.html");
  });

  it("marks inflow unavailable when no real Excapper transaction exists", () => {
    const message = formatUnifiedAlert({ ...alertInput(), inflow: null });
    expect(message).toContain("Excapper — за раз / — всего");
    expect(message).not.toContain("€0");
  });

  it("safely escapes hostile team and league text for native MarkdownV2", () => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      league: "Bad_[League](https://evil.invalid)",
      home: "Home *admin*",
      away: "Away | injected",
    });
    expect(message).toContain("Bad\\_\\[League\\]\\(https://evil\\.invalid\\)");
    expect(message).toContain("Home \\*admin\\* — Away \\| injected");
    expect(message).toContain("[Match Details](https://www.nowgoal26.com/match/live-3068862.html)");
  });

  it("never invents odds, times, drop, duration, or speed when unavailable", () => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      timeline: [],
      inflow: null,
    });
    expect(message).toContain("— → — \\(—\\)");
    expect(message).not.toContain("Как шёл кэф");
    expect(message).not.toContain("€0");
    expect(message).not.toContain("0\\.0%");
  });

  it("renders an unknown single as unavailable, while preserving an observed total", () => {
    const input = alertInput();
    input.inflow = { ...input.inflow!, single: 0, total: 12_000 };
    const message = formatUnifiedAlert(input);
    expect(message).toContain("Excapper — за раз / €12,000 всего");
    expect(message).not.toContain("\\+€0");
  });

  it("uses only the requested line in message history", () => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      line: 2.5,
      timeline: [
        { ts: start, line: 3.5, odds: 2.2 },
        { ts: start + 30_000, line: 3.5, odds: 1.7 },
      ],
    });
    expect(message).toContain("— → — \\(—\\)");
    expect(message).not.toContain("2\\.20");
    expect(message).not.toContain("1\\.70");
  });

  it("captures a transaction once without sending and does not refresh a duplicate", () => {
    expect(
      recordUnifiedInflow({
        matchId: "3068862",
        line: 3.5,
        side: "OVER",
        single: 3163,
        total: 4834,
        minute: "12",
        observedAt: start,
      }),
    ).toBe(true);
    expect(
      recordUnifiedInflow({
        matchId: "3068862",
        line: 3.5,
        side: "OVER",
        single: 3163,
        total: 4834,
        minute: "12",
        observedAt: start + 10_000,
      }),
    ).toBe(false);
    expect(getRecentUnifiedInflow("3068862", 3.5, "OVER", start + 60_000)).toMatchObject({
      single: 3163,
      total: 4834,
      observedAt: start,
    });
  });

  it("displays a huge native EUR amount without conversion", () => {
    const huge = Number.MAX_SAFE_INTEGER;
    const input = alertInput();
    input.inflow = { ...input.inflow!, single: huge, total: huge };
    const message = formatUnifiedAlert(input);
    expect(message).toContain("Excapper \\+€9,007,199,254,740,991 за раз / €9,007,199,254,740,991 всего");
  });

  it("claims the same consolidated odds event only once across scans", () => {
    const input = alertInput();
    expect(claimUnifiedAlertEvent(input, start + 3 * 60_000)).toBe(true);
    expect(claimUnifiedAlertEvent(input, start + 3 * 60_000 + 7_000)).toBe(false);
  });

  it("uses the quote nearest five minutes prior, not an all-time high", () => {
    const timeline = [
      { ts: start, line: 3.5, odds: 2.2 },
      // Unchanged consecutive polls must retain the original baseline time.
      { ts: start + 60_000, line: 3.5, odds: 2.2 },
      ...Array.from({ length: 9 }, (_, index) => ({
        ts: start + (index + 2) * 60_000,
        line: 3.5,
        odds: 2.15 - index * 0.0625,
      })),
    ];
    const input = { ...alertInput(), timeline, inflow: null };
    const message = formatUnifiedAlert(input);

    expect(message).toContain("1\\.96 → 1\\.65 \\(\\-15\\.9%\\)");
    expect(message).toContain("Как шёл кэф:");
    expect(message).not.toContain("2\\.20");

    expect(claimUnifiedAlertEvent(input, start + 10 * 60_000)).toBe(true);
    // Changing an out-of-window quote cannot manufacture a distinct event.
    const differentBaseline = {
      ...input,
      timeline: [{ ts: start, line: 3.5, odds: 2.3 }, ...timeline.slice(2)],
    };
    expect(claimUnifiedAlertEvent(differentBaseline, start + 10 * 60_000)).toBe(false);
  });

  it("uses the authoritative fixture clock and never invents elapsed minutes", () => {
    expect(
      resolveUnifiedAlertMinute(
        { isLive: true, kickoffMs: start, clockLabel: "38'" },
        "42",
        start + 11 * 60_000,
      ),
    ).toBe("38");
    expect(
      resolveUnifiedAlertMinute({ isLive: true, kickoffMs: start, state: 2 }, "42", start),
    ).toBe("HT");
    expect(
      resolveUnifiedAlertMinute({ isLive: true, kickoffMs: null, state: 3 }, null, start),
    ).toBe("Live");
    expect(
      resolveUnifiedAlertMinute({ isLive: false, kickoffMs: null }, "42", start),
    ).toBe("42");
  });

  it("normalizes fixture-header minute and phase variants", () => {
    expect(normalizeFixtureClock("72'")).toBe("72");
    expect(normalizeFixtureClock("HT")).toBe("HT");
    expect(normalizeFixtureClock("45+2'")).toBe("45+2");
    expect(normalizeFixtureClock("secondhalf")).toBe("2H");
    expect(normalizeFixtureClock("")).toBeNull();
  });

  it.each([
    ["UNDER", 4.5, 1.08],
    ["OVER", 3.5, 1.91],
  ] as const)("does not manufacture a flat current/current %s %.1f history", (side, line, odds) => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      side,
      line,
      timeline: [],
      currentQuote: { ts: start, line, odds },
    });
    expect(message).toContain("— → 1\\.08 \\(—\\)".replace("1\\.08", side === "UNDER" ? "1\\.08" : "1\\.91"));
    expect(claimUnifiedAlertEvent({
      ...alertInput(), side, line, timeline: [],
      currentQuote: { ts: start, line, odds },
    }, start)).toBe(false);
  });

  it("does not render an authentic flat quote as a moving bookmaker", () => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      line: 4.5,
      side: "UNDER",
      timeline: [
        { ts: start, line: 4.5, odds: 1.08 },
        { ts: start + 30_000, line: 4.5, odds: 1.08 },
      ],
      currentQuote: { ts: start + 60_000, line: 4.5, odds: 1.08 },
    });
    expect(message).toContain("📊 Рынок: Тотал меньше 4\\.5");
    expect(message).not.toContain("1\\.08 → 1\\.08");
  });

  it("combines one real baseline tick with a newer current quote", () => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      timeline: [{ ts: start, line: 3.5, odds: 2 }],
      currentQuote: { ts: start + 60_000, line: 3.5, odds: 1.8 },
    });
    expect(message).toContain("2\\.00 → 1\\.80 \\(\\-10\\.0%\\)");
  });

  it("calculates the true decimal percentage and converts HK odds exactly once", () => {
    const decimal = {
      ...alertInput(),
      timeline: [{ ts: start, line: 3.5, odds: 2 }],
      currentQuote: { ts: start + 60_000, line: 3.5, odds: 1.8 },
    };
    expect(resolvePositiveOddsDrop(decimal, start + 60_000)?.percent).toBeCloseTo(10, 10);
    // HK 1.0 -> 0.8 is decimal 2.0 -> 1.8; conversion occurs at the boundary.
    const fromHk = {
      ...decimal,
      timeline: [{ ts: start, line: 3.5, odds: 1 + 1 }],
      currentQuote: { ts: start + 60_000, line: 3.5, odds: 0.8 + 1 },
    };
    expect(resolvePositiveOddsDrop(fromHk, start + 60_000)?.percent).toBeCloseTo(10, 10);
  });

  it.each([
    ["flat", 2, 2],
    ["rising", 1.8, 2],
  ] as const)("rejects a %s exact-market sequence", (_label, initial, current) => {
    const input = {
      ...alertInput(),
      timeline: [
        { ts: start, line: 3.5, odds: initial },
        { ts: start + 60_000, line: 3.5, odds: current },
      ],
    };
    expect(resolvePositiveOddsDrop(input, start + 60_000)).toBeNull();
    expect(claimUnifiedAlertEvent(input, start + 60_000)).toBe(false);
  });

  it("rejects single-point, cross-line, out-of-window, and stale evidence", () => {
    expect(resolvePositiveOddsDrop({
      ...alertInput(), timeline: [{ ts: start, line: 3.5, odds: 1.8 }],
    }, start)).toBeNull();
    expect(resolvePositiveOddsDrop({
      ...alertInput(),
      timeline: [
        { ts: start, line: 2.5, odds: 2 },
        { ts: start + 60_000, line: 3.5, odds: 1.8 },
      ],
    }, start + 60_000)).toBeNull();
    expect(resolvePositiveOddsDrop({
      ...alertInput(),
      timeline: [
        { ts: start, line: 3.5, odds: 2 },
        { ts: start + 5 * 60_000, line: 3.5, odds: 1.8 },
      ],
    }, start + 5 * 60_000)?.percent).toBeCloseTo(10, 10);
    expect(resolvePositiveOddsDrop({
      ...alertInput(),
      timeline: [
        { ts: start, line: 3.5, odds: 2 },
        { ts: start + 5 * 60_000 + 1, line: 3.5, odds: 1.8 },
      ],
    }, start + 5 * 60_000 + 1)).toBeNull();
    expect(resolvePositiveOddsDrop({
      ...alertInput(),
      timeline: [
        { ts: start, line: 3.5, odds: 2 },
        { ts: start + 60_000, line: 3.5, odds: 1.8 },
      ],
    }, start + 4 * 60_000)).toBeNull();
  });

  it("uses adaptive precision instead of displaying a real tiny drop as 0.0%", () => {
    const message = formatUnifiedAlert({
      ...alertInput(),
      timeline: [
        { ts: start, line: 3.5, odds: 2 },
        { ts: start + 60_000, line: 3.5, odds: 1.999 },
      ],
    });
    expect(message).toContain("\\-0\\.05%");
    expect(message).not.toContain("\\-0\\.0%");
  });

  it("shows Live when a live caller has no minute label", () => {
    const message = formatUnifiedAlert({ ...alertInput(), minute: null });
    expect(message).toContain("0:0 \\(Live\\)");
    expect(message).not.toContain("0:0 \\(—\\)");
  });

  it("hard-bounds the inflow cache and evicts its oldest market", () => {
    for (let index = 0; index < 2_001; index++) {
      expect(
        recordUnifiedInflow({
          matchId: `match-${index}`,
          line: 2.5,
          side: "OVER",
          single: 500,
          total: 1_000 + index,
          observedAt: start + index,
        }),
      ).toBe(true);
    }
    expect(getRecentUnifiedInflow("match-0", 2.5, "OVER", start + 2_001)).toBeNull();
    expect(getRecentUnifiedInflow("match-2000", 2.5, "OVER", start + 2_001)).not.toBeNull();
  });
});