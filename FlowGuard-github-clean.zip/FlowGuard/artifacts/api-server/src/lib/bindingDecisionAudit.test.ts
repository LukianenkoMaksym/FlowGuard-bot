import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { BindingDecisionOutbox } from "./bindingDecisionOutbox";

const store = vi.hoisted(() => ({
  insert: vi.fn(),
  values: vi.fn(),
  conflict: vi.fn(async () => undefined),
  rows: [] as Array<Record<string, unknown>>,
}));
vi.mock("@workspace/db", () => ({
  bindingDecisionsTable: { id: "id", matchId: "match_id", occurredAt: "occurred_at" },
  db: {
    insert: store.insert,
    select: () => ({ from: () => ({ where: () => ({
      orderBy: async () => store.rows,
    }) }) }),
  },
}));
vi.mock("./logger", () => ({ logger: { error: vi.fn() } }));

import {
  createBindingDecision, flushBindingDecisions, getBindingDecisionHistory,
  persistBindingDecision, recordBindingDecision,
  __testOnlySetBindingDecisionOutbox,
} from "./bindingDecisionAudit";

const fixture = {
  id: "42", home: "Home", away: "Away", league: "League",
  score: { home: 1, away: 0 }, period: "second-half", minute: 61,
};
const decision = () => createBindingDecision({
  action: "bind", mode: "automatic", target: fixture,
  source: { ...fixture, id: "900" }, reason: "Verified live evidence",
});

describe("binding decision audit persistence", () => {
  let directory: string;
  let outboxPath: string;
  beforeEach(() => {
    directory = mkdtempSync(path.join(tmpdir(), "binding-audit-"));
    outboxPath = path.join(directory, "outbox.json");
    __testOnlySetBindingDecisionOutbox(outboxPath);
    store.insert.mockReturnValue({ values: store.values });
    store.values.mockReturnValue({ onConflictDoNothing: store.conflict });
    store.conflict.mockReset().mockResolvedValue(undefined);
    store.values.mockClear();
    store.rows = [];
  });
  afterEach(() => {
    __testOnlySetBindingDecisionOutbox(outboxPath);
    rmSync(directory, { recursive: true, force: true });
  });

  it("snapshots nullable whitelisted evidence without carrying source secrets", () => {
    const input = { ...fixture, cookie: "do-not-store", score: { home: 1, away: 0 } };
    const item = createBindingDecision({
      action: "bind", mode: "manual_override", target: input,
      source: { ...fixture, minute: null, score: null }, reason: "Explicit approval",
    });
    input.score.home = 9;
    expect(item.target.score?.home).toBe(1);
    expect(item.target).not.toHaveProperty("cookie");
    expect(item.source.minute).toBeNull();
    expect(item.source.score).toBeNull();
    expect(Number.isNaN(Date.parse(item.occurredAt))).toBe(false);
  });

  it("uses the event identity as a database conflict key for uncertain retries", async () => {
    const item = decision();
    await persistBindingDecision("manual-text:Home|Away", item);
    await persistBindingDecision("manual-text:Home|Away", item);
    expect(store.values.mock.calls[0]?.[0].id).toBe(store.values.mock.calls[1]?.[0].id);
    expect(store.conflict).toHaveBeenCalledWith({ target: "id" });
  });

  it("retains failed events with the same identity and exposes failure instead of empty history", async () => {
    const item = decision();
    store.conflict.mockRejectedValue(new Error("offline"));
    recordBindingDecision("42", item);
    await expect(flushBindingDecisions()).rejects.toThrow("offline");
    await expect(getBindingDecisionHistory("42")).rejects.toThrow("persistence is pending");
    store.conflict.mockResolvedValue(undefined);
    await flushBindingDecisions();
    expect(store.values.mock.calls.every(([value]) => value.id === item.id)).toBe(true);
  });

  it("returns persisted snapshots without runtime membership and no internal matchId", async () => {
    const item = decision();
    store.rows = [{ ...item, matchId: "removed-match", occurredAt: new Date(item.occurredAt) }];
    expect(await getBindingDecisionHistory("removed-match")).toEqual([item]);
    store.rows = [];
    expect(await getBindingDecisionHistory("unknown")).toEqual([]);
  });

  it("replays the same event after restart during a database outage and only then removes it", async () => {
    const item = decision();
    store.conflict.mockRejectedValue(new Error("offline"));
    recordBindingDecision("42", item);
    // Admission is synchronous, before the database promise can resolve.
    expect(JSON.parse(readFileSync(outboxPath, "utf8")).entries[0].decision.id).toBe(item.id);
    await expect(flushBindingDecisions()).rejects.toThrow("offline");
    __testOnlySetBindingDecisionOutbox(outboxPath); // new process-local state, same durable file
    expect(new BindingDecisionOutbox(outboxPath).entries()[0]?.decision.id).toBe(item.id);
    store.conflict.mockResolvedValue(undefined);
    await flushBindingDecisions();
    expect(store.values.mock.calls.every(([value]) => value.id === item.id)).toBe(true);
    expect(new BindingDecisionOutbox(outboxPath).entries()).toEqual([]);
  });

  it("fails admission synchronously if the local file cannot be written and never inserts", () => {
    const obstruction = path.join(directory, "not-a-directory");
    writeFileSync(obstruction, "blocked");
    __testOnlySetBindingDecisionOutbox(path.join(obstruction, "outbox.json"));
    expect(() => recordBindingDecision("42", decision())).toThrow("could not be saved locally");
    expect(store.values).not.toHaveBeenCalled();
  });

  it("deduplicates persisted local entries and replays an uncertain acknowledgement by ID", async () => {
    const item = decision();
    const firstProcess = new BindingDecisionOutbox(outboxPath);
    firstProcess.append([{ matchId: "42", decision: item }, { matchId: "42", decision: item }]);
    expect(firstProcess.entries()).toHaveLength(1);
    // Simulate a crash after PostgreSQL accepted the event but before local acknowledgement.
    await persistBindingDecision("42", item);
    __testOnlySetBindingDecisionOutbox(outboxPath);
    await flushBindingDecisions();
    expect(store.values).toHaveBeenCalledTimes(2);
    expect(store.conflict).toHaveBeenCalledWith({ target: "id" });
    expect(new BindingDecisionOutbox(outboxPath).entries()).toEqual([]);
  });

  it("retains the durable event when local acknowledgement fails after a confirmed database insert", async () => {
    const item = decision();
    new BindingDecisionOutbox(outboxPath).append([{ matchId: "42", decision: item }]);
    const acknowledge = vi.spyOn(BindingDecisionOutbox.prototype, "acknowledge")
      .mockImplementationOnce(() => { throw new Error("disk unavailable"); });
    try {
      await expect(flushBindingDecisions()).rejects.toThrow("disk unavailable");
      expect(new BindingDecisionOutbox(outboxPath).entries()[0]?.decision.id).toBe(item.id);
      __testOnlySetBindingDecisionOutbox(outboxPath);
      await flushBindingDecisions();
      expect(store.values.mock.calls.every(([value]) => value.id === item.id)).toBe(true);
      expect(new BindingDecisionOutbox(outboxPath).entries()).toEqual([]);
    } finally {
      acknowledge.mockRestore();
    }
  });

  it("fails closed on a corrupt outbox instead of silently dropping its contents", () => {
    writeFileSync(outboxPath, "invalid json");
    expect(() => recordBindingDecision("42", decision())).toThrow("could not be saved locally");
    expect(readFileSync(outboxPath, "utf8")).toBe("invalid json");
    expect(store.values).not.toHaveBeenCalled();
  });
});