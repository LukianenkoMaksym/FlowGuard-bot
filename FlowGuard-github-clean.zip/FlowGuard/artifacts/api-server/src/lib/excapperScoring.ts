import { matchTargetLeague } from "./targetLeagues";
import { parseExcapperBetTime } from "./prebetAnalysis";
import { canonicalExplicitTeamAlias } from "./teamIdentity";
import { manualLeagueAliasMatches } from "./manualLeagueAliases";

export interface BindingBase {
  id: string; team1: string; team2: string; league: string;
  kickoffMs: number | null;
  homeScore?: number | null; awayScore?: number | null;
  period?: string | null;
  liveMinute?: number | null;
}
export function normalizeBindingTeam(value: string): string {
  return canonicalExplicitTeamAlias(value).normalize("NFD").replace(/\p{M}/gu, "").toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ").split(/\s+/)
    .filter((token) => token && !new Set(["fc", "cf", "cd", "sc", "de", "del", "la", "el", "club"]).has(token))
    .sort().join(" ");
}
function similarity(a: string, b: string): number {
  a = normalizeBindingTeam(a); b = normalizeBindingTeam(b);
  if (!a || !b) return 0;
  const previous = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let diagonal = previous[0]!;
    previous[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const old = previous[j]!;
      previous[j] = Math.min(previous[j]! + 1, previous[j - 1]! + 1, diagonal + (a[i - 1] === b[j - 1] ? 0 : 1));
      diagonal = old;
    }
  }
  return 1 - previous[b.length]! / Math.max(a.length, b.length);
}
function setting(key: string, fallback: number, min: number, max: number): number {
  const n = Number(process.env[key]);
  return process.env[key] && Number.isFinite(n) && n >= min && n <= max ? n : fallback;
}
/** No invented year: yearless wall-clock times are anchored to transport observation.
 * The existing local-time interpretation is uncertain; the window absorbs it.
 */
export function parseBindingKickoff(text: string | null | undefined, observedAt: number): number | null {
  if (!text) return null;
  const full = /^(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2}):(\d{2})$/.exec(text.trim());
  if (full) {
    const [, day, month, year, hour, minute] = full.map(Number);
    if (year! < 1000 || month! < 1 || month! > 12 || day! < 1 || day! > 31 || hour! > 23 || minute! > 59) return null;
    // Same local wall-clock interpretation as the yearless source parser;
    // preserve the supplied year, never substitute the observation year.
    const date = new Date(year!, month! - 1, day!, hour!, minute!);
    return date.getFullYear() === year && date.getMonth() === month! - 1 &&
      date.getDate() === day && date.getHours() === hour && date.getMinutes() === minute
      ? date.getTime() : null;
  }
  const direct = parseExcapperBetTime(text, observedAt);
  if (direct !== null) return direct;
  const reverse = /^(\d{1,2})\.(\d{1,2})\.?\s+(\d{1,2}):(\d{2})$/.exec(text.trim());
  if (reverse) return parseExcapperBetTime(`${reverse[3]}:${reverse[4]} ${reverse[1]}.${reverse[2]}`, observedAt);
  return null;
}
export function chooseBaseBinding(source: BindingBase, candidates: readonly BindingBase[]) {
  const windowMs = setting("EXCAPPER_BIND_WINDOW_MS", 3 * 3600_000, 60_000, 12 * 3600_000);
  const threshold = setting("EXCAPPER_BIND_THRESHOLD", .86, .8, 1);
  const epsilon = setting("EXCAPPER_BIND_EPSILON", .03, 0, .2);
  const scored = candidates.map((candidate) => {
    const home = similarity(source.team1, candidate.team1);
    const away = similarity(source.team2, candidate.team2);
    const reverseHome = similarity(source.team1, candidate.team2);
    const reverseAway = similarity(source.team2, candidate.team1);
    const orientationAmbiguous = home >= .92 && away >= .92 && reverseHome >= .92 && reverseAway >= .92;
    const delta = source.kickoffMs != null && candidate.kickoffMs != null &&
      Number.isFinite(source.kickoffMs) && Number.isFinite(candidate.kickoffMs)
      ? Math.abs(source.kickoffMs - candidate.kickoffMs) : null;
    const canonical = matchTargetLeague(source.league);
    const league = (canonical !== null && canonical === matchTargetLeague(candidate.league)) ||
      manualLeagueAliasMatches(source.league, candidate.league);
    const conflict = (source.homeScore != null && candidate.homeScore != null && source.homeScore !== candidate.homeScore) ||
      (source.awayScore != null && candidate.awayScore != null && source.awayScore !== candidate.awayScore) ||
      (!!source.period && !!candidate.period && source.period !== candidate.period) ||
      (source.liveMinute != null && candidate.liveMinute != null &&
        Math.abs(source.liveMinute - candidate.liveMinute) > 3);
    const corroborated = source.homeScore != null && source.awayScore != null &&
      candidate.homeScore != null && candidate.awayScore != null &&
      !!source.period && !!candidate.period && !conflict;
    const missingKickoff = source.kickoffMs == null || candidate.kickoffMs == null;
    const fallback = missingKickoff && home >= .98 && away >= .98 && corroborated;
    const time = delta !== null && delta <= windowMs ? 1 - .2 * delta / windowMs : 0;
    const contributions = { teams: .7 * (home + away) / 2, time: .25 * time,
      league: league ? .05 : 0, corroboration: fallback ? .25 : 0, country: 0, minute: 0 };
    const score = Object.values(contributions).reduce((a, b) => a + b, 0);
    const kickoff = (delta !== null && delta <= windowMs) || fallback;
    const reason = conflict ? "explicit_disagreement" : orientationAmbiguous ? "orientation_ambiguous" : home < .92 || away < .92 ? "teams" :
      !kickoff ? "kickoff_missing_or_outside_window" : score < threshold ? "threshold" : "qualified";
    const safeCandidate: BindingBase = { id: candidate.id, team1: candidate.team1, team2: candidate.team2,
      league: candidate.league, kickoffMs: candidate.kickoffMs, homeScore: candidate.homeScore ?? null,
      awayScore: candidate.awayScore ?? null, period: candidate.period ?? null, liveMinute: candidate.liveMinute ?? null };
    return { candidate: safeCandidate, model: "base_weighted", home, away, reverseHome, reverseAway, orientationAmbiguous,
      sourceEvidence: { kickoffMs: source.kickoffMs, homeScore: source.homeScore ?? null,
        awayScore: source.awayScore ?? null, period: source.period ?? null, liveMinute: source.liveMinute ?? null },
      time: delta === null ? null : time, league: league ? 1 : 0, delta, score, reason, contributions,
      normalized: { sourceHome: normalizeBindingTeam(source.team1), sourceAway: normalizeBindingTeam(source.team2),
        candidateHome: normalizeBindingTeam(candidate.team1), candidateAway: normalizeBindingTeam(candidate.team2) },
      gates: { teams: home >= .92 && away >= .92, kickoff, scorePeriod: corroborated, conflict } };
  }).sort((a, b) => b.score - a.score);
  const passing = scored.filter((entry) => entry.reason === "qualified");
  const ambiguous = !!passing[1] && passing[0]!.score - passing[1].score <= epsilon;
  return { chosen: ambiguous ? null : passing[0]?.candidate ?? null, ambiguous, scored,
    thresholds: { threshold, epsilon, windowMs, teamMinimum: .92, missingKickoffTeamMinimum: .98 } };
}

export async function boundedEnrichment<T>(work: Promise<T>, fallback: () => T, timeoutMs = 30_000): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([work, new Promise<T>((resolve) => {
      timer = setTimeout(() => resolve(fallback()), Math.min(30_000, Math.max(1, timeoutMs)));
    })]);
  } catch {
    return fallback();
  } finally { if (timer) clearTimeout(timer); }
}