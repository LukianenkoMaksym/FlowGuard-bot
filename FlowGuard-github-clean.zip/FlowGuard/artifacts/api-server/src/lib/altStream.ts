/**
 * BRANCH B — Alt-mirror odds stream.
 *
 * Runs as a sequential adapter in the unified scan coordinator (different
 * host pick, separate try/catch boundary). Purpose: if the
 * primary X-scanner mirror freezes, lags, or drops a regional fixture, the
 * alt branch keeps refreshing odds and seeds missing rows so the watchlist
 * + dashboard stays alive.
 *
 * --- DESIGN CONSTRAINTS (Replit VM safety) ---
 *
 *   1. BOUNDED. The alt fetch uses the scanner's bounded fetch path. The
 *      coordinator awaits this adapter before starting the next one, so scan
 *      work never overlaps.
 *   2. SUPPLEMENT, NOT SHADOW. We never overwrite a fresh primary tick —
 *      mergeAltOddsSnapshot in scanner.ts only writes when the primary
 *      has been quiet for > altStaleAfterMs. So Telegram alerts continue
 *      to fire exclusively from the primary path (zero risk of duplicate
 *      alerts from the alt branch).
 *   3. NO RAM ACCUMULATION. Each tick parses one XML response, merges it,
 *      then drops the local maps. The only persistent state is in the
 *      shared matchStates Map (already capped by pruneHistory).
 *   4. DIFFERENT HOST. Always picks a mirror DIFFERENT from the primary's
 *      current base — that's the whole point. If only one mirror is alive
 *      we skip the tick (logged) rather than double-poll the same host.
 *   5. CONCURRENCY GUARD. A single in-flight flag prevents overlapping
 *      ticks when the alt mirror is slow.
 */

import { logger } from "./logger";
import { listCandidates, currentBaseUrl, endpointsFor, withCacheBuster } from "./upstream";
import {
  fetchRaw,
  parseOUXml,
  parseMatchMeta,
  mergeAltOddsSnapshot,
} from "./scanner";

const ALT_TICK_INTERVAL_MS = 12_000;
const ALT_STALE_AFTER_MS = 60_000;

let altTimer: ReturnType<typeof setTimeout> | null = null;
let altGeneration = 0;
let inFlight = false;

interface AltStats {
  ticks: number;
  tickFailures: number;
  matchesParsedLast: number;
  seededTotal: number;
  refreshedTotal: number;
  skippedFreshTotal: number;
  lastTickAt: number | null;
  lastHost: string | null;
  lastError: string | null;
}

const stats: AltStats = {
  ticks: 0,
  tickFailures: 0,
  matchesParsedLast: 0,
  seededTotal: 0,
  refreshedTotal: 0,
  skippedFreshTotal: 0,
  lastTickAt: null,
  lastHost: null,
  lastError: null,
};

export function getAltStreamStats(): Readonly<AltStats> {
  return stats;
}

/**
 * Pick a mirror different from whichever the primary is currently riding.
 * Round-robin via tick counter for fair coverage across all alternates.
 * Returns null when no alternates exist (only one mirror in the pool).
 */
function pickAltHost(): string | null {
  const primary = currentBaseUrl();
  const alternates = listCandidates().filter((h) => h !== primary);
  if (alternates.length === 0) return null;
  return alternates[stats.ticks % alternates.length];
}

async function altTick(myGen: number): Promise<void> {
  if (myGen !== altGeneration) return;
  if (inFlight) {
    logger.debug("[ALT-STREAM] previous tick still in flight, skipping");
    schedule(myGen);
    return;
  }
  inFlight = true;

  try {
    const altBase = pickAltHost();
    if (!altBase) {
      logger.debug("[ALT-STREAM] no alternate mirror available — pool size 1");
      return;
    }
    stats.lastHost = altBase;
    const ep = endpointsFor(altBase);

    const [ouRes, metaRes] = await Promise.allSettled([
      fetchRaw(withCacheBuster(ep.primaryOu)),
      fetchRaw(withCacheBuster(ep.meta)),
    ]);

    if (ouRes.status !== "fulfilled") {
      stats.tickFailures++;
      stats.lastError = ouRes.reason instanceof Error ? ouRes.reason.message : String(ouRes.reason);
      logger.warn(
        { host: altBase, err: stats.lastError },
        "[ALT-STREAM] OU fetch failed (non-fatal, primary continues)",
      );
      return;
    }

    const ouMap = parseOUXml(ouRes.value);
    const metaMap = metaRes.status === "fulfilled" ? parseMatchMeta(metaRes.value) : new Map();
    stats.matchesParsedLast = ouMap.size;

    const merged = mergeAltOddsSnapshot(ouMap, metaMap, {
      altStaleAfterMs: ALT_STALE_AFTER_MS,
      source: altBase,
    });

    stats.seededTotal += merged.seeded;
    stats.refreshedTotal += merged.refreshed;
    stats.skippedFreshTotal += merged.skippedFresh;
    stats.ticks++;
    stats.lastTickAt = Date.now();
    stats.lastError = null;

    if (merged.seeded > 0 || merged.refreshed > 0) {
      logger.info(
        {
          altHost: altBase,
          primaryHost: currentBaseUrl(),
          parsed: ouMap.size,
          seeded: merged.seeded,
          refreshed: merged.refreshed,
          skippedFresh: merged.skippedFresh,
        },
        "[ALT-STREAM] tick contributed",
      );
    } else {
      logger.debug(
        {
          altHost: altBase,
          parsed: ouMap.size,
          skippedFresh: merged.skippedFresh,
        },
        "[ALT-STREAM] tick (primary covered everything)",
      );
    }
  } catch (err) {
    stats.tickFailures++;
    stats.lastError = err instanceof Error ? err.message : String(err);
    logger.warn({ err }, "[ALT-STREAM] tick crashed (non-fatal)");
  } finally {
    inFlight = false;
  }
}

function schedule(myGen: number): void {
  if (myGen !== altGeneration) return;
  altTimer = setTimeout(() => altTick(myGen).catch(() => {}), ALT_TICK_INTERVAL_MS);
}

export function startAltStream(): void {
  // Compatibility control hook. Scheduling belongs exclusively to
  // scanCoordinator; toggles are read by runAltStreamCycle().
  altGeneration++;
  logger.info("[ALT-STREAM] enabled for coordinated cycles");
}

export async function runAltStreamCycle(): Promise<void> {
  const { getControls } = await import("./controls");
  if (!getControls().altStreamEnabled) return;
  await altTick(altGeneration);
}

export function stopAltStream(): void {
  altGeneration++;
  if (altTimer !== null) {
    clearTimeout(altTimer);
    altTimer = null;
  }
  logger.info("[ALT-STREAM] stopped");
}
