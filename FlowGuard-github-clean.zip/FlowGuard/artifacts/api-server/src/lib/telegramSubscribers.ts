/**
 * Telegram broadcast subscribers.
 *
 * Users register by sending /start to the bot (see telegramBot.ts). Their chat
 * IDs are persisted here so a scanner restart (which happens often — watchdog
 * recovery, manual force-restart, deploy) never loses the subscriber list.
 *
 * Persistence mirrors lib/watchlist.ts: atomic temp-file + rename write, guarded
 * by an in-process mutation lock so concurrent /start and /stop handling can't
 * clobber each other's writes. We also persist `lastUpdateId` (the Telegram
 * getUpdates offset) so a restart resumes exactly where it left off — no missed
 * commands, and no re-processing of old /start messages (which would re-spam
 * "already subscribed" replies).
 */
import { promises as fs } from "node:fs";
import path from "node:path";
import { logger } from "./logger";

const CONFIG_PATH = path.resolve(process.cwd(), "config/telegram-subscribers.json");

// Mutable so tests can inject a temp path via _resetForTests().
// In production this always equals CONFIG_PATH.
let _configPath: string = CONFIG_PATH;

interface SubscriberRecord {
  chatId: number;
  username?: string;
  subscribedAt: string;
}

interface SubscribersFile {
  subscribers: SubscriberRecord[];
  /** Telegram getUpdates offset of the last processed update. */
  lastUpdateId: number;
}

let subscribers = new Map<number, SubscriberRecord>();
let lastUpdateId = 0;
let loaded = false;

/** In-process mutex serializing mutations so concurrent writers don't clobber. */
let mutationChain: Promise<unknown> = Promise.resolve();
function withMutationLock<T>(fn: () => Promise<T>): Promise<T> {
  const next = mutationChain.then(fn, fn);
  mutationChain = next.catch(() => undefined);
  return next;
}

/** Atomic write: stage to a sibling temp file, fsync, rename over the target. */
async function atomicWriteJson(filePath: string, payload: string): Promise<void> {
  const dir = path.dirname(filePath);
  const tmp = path.join(dir, `.${path.basename(filePath)}.tmp-${process.pid}-${Date.now()}`);
  const fh = await fs.open(tmp, "w");
  try {
    await fh.writeFile(payload, "utf8");
    await fh.sync();
  } finally {
    await fh.close();
  }
  await fs.rename(tmp, filePath);
}

async function persist(): Promise<void> {
  const payload: SubscribersFile = {
    subscribers: [...subscribers.values()],
    lastUpdateId,
  };
  await atomicWriteJson(_configPath, JSON.stringify(payload, null, 2));
}

export async function loadSubscribers(): Promise<void> {
  try {
    const raw = await fs.readFile(_configPath, "utf8");
    const parsed = JSON.parse(raw) as Partial<SubscribersFile>;
    const next = new Map<number, SubscriberRecord>();
    for (const s of parsed.subscribers ?? []) {
      if (s && typeof s.chatId === "number") {
        next.set(s.chatId, {
          chatId: s.chatId,
          username: typeof s.username === "string" ? s.username : undefined,
          subscribedAt:
            typeof s.subscribedAt === "string" ? s.subscribedAt : new Date().toISOString(),
        });
      }
    }
    subscribers = next;
    lastUpdateId = typeof parsed.lastUpdateId === "number" ? parsed.lastUpdateId : 0;
    loaded = true;
    logger.info({ count: subscribers.size, lastUpdateId }, "[TG-SUBS] Loaded subscribers");
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") {
      subscribers = new Map();
      lastUpdateId = 0;
      loaded = true;
      logger.info("[TG-SUBS] No subscriber file yet — starting with an empty list");
      return;
    }
    logger.error({ err }, "[TG-SUBS] Failed to load subscribers — starting empty");
    subscribers = new Map();
    lastUpdateId = 0;
    loaded = true;
  }
}

export function subscribersLoaded(): boolean {
  return loaded;
}

/**
 * Idempotent, race-free load. Multiple concurrent callers (the bot listener AND
 * the first broadcast that fires before boot finishes) share a single in-flight
 * load, so an alert sent immediately after restart never reads an empty list
 * while the file is still being read from disk.
 */
let loadPromise: Promise<void> | null = null;
export function ensureSubscribersLoaded(): Promise<void> {
  if (loaded) return Promise.resolve();
  if (!loadPromise) {
    loadPromise = loadSubscribers().finally(() => {
      loadPromise = null;
    });
  }
  return loadPromise;
}

export function listSubscriberChatIds(): number[] {
  return [...subscribers.keys()];
}

export function subscriberCount(): number {
  return subscribers.size;
}

/** Returns true if this was a brand-new subscriber, false if already present. */
export function addSubscriber(chatId: number, username?: string): Promise<boolean> {
  return withMutationLock(async () => {
    const existing = subscribers.get(chatId);
    if (existing) {
      if (username && existing.username !== username) {
        existing.username = username;
        await persist();
      }
      return false;
    }
    subscribers.set(chatId, {
      chatId,
      username,
      subscribedAt: new Date().toISOString(),
    });
    await persist();
    return true;
  });
}

/** Returns true if a subscriber was actually removed. */
export function removeSubscriber(chatId: number): Promise<boolean> {
  return withMutationLock(async () => {
    if (!subscribers.has(chatId)) return false;
    subscribers.delete(chatId);
    await persist();
    return true;
  });
}

export function getLastUpdateId(): number {
  return lastUpdateId;
}

export function setLastUpdateId(id: number): Promise<void> {
  return withMutationLock(async () => {
    if (id > lastUpdateId) {
      lastUpdateId = id;
      await persist();
    }
  });
}

// ---------------------------------------------------------------------------
// Test helpers — exported only so unit tests can inject a temp config path
// and reset module-level state between test cases without reloading the module.
// Do NOT call these from production code.
// ---------------------------------------------------------------------------

/** @internal Reset all module-level state and optionally re-point the config file path. */
export function _resetForTests(newConfigPath?: string): void {
  subscribers = new Map();
  lastUpdateId = 0;
  loaded = false;
  mutationChain = Promise.resolve();
  loadPromise = null;
  if (newConfigPath !== undefined) {
    _configPath = newConfigPath;
  }
}
