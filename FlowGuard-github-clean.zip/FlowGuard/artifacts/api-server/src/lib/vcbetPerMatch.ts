/**
 * Per-match VSBet (Vcbet, NowGoal company id 14) odds fallback.
 *
 * Why this exists:
 *   The batch goal14.xml feed only contains matches Vcbet has actively quoted
 *   recently. For watchlist matches not present in that batch, NowGoal's own
 *   oddscomp page calls a per-match Ajax endpoint that DOES return Vcbet odds.
 *
 * Verified endpoint (replayed from a browser DevTools capture):
 *   GET https://<base>/ajax/soccerajax?type=14&t=11&id=<matchId>&h=0&flesh=<rand>
 *   Headers: User-Agent + Referer: <base>/oddscomp/<matchId>
 *   Returns: gzipped JSON { ErrCode:0, Data:{ roddsList:[ {cid, euro, ou, ah}, ... ] } }
 *
 * We extract only the cid:14 entry and shape it into OUEntry-compatible
 * { line, overDecimal, underDecimal } using `ou` (goal-line OU odds), which
 * is what scanner's primary pipeline tracks for the other 4 extra books.
 */

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { logger } from "./logger";
import { NOWGOAL_VCBET_HOST, USER_AGENT_VCBET } from "./config";

const execFileAsync = promisify(execFile);

const VCBET_COMPANY_ID = 14;
const PER_MATCH_TIMEOUT_MS = 4000;
// Hard ceiling for the entire batch per tick. The scanner polls every ~12s,
// so anything longer than this risks stalling the main loop. Workers that
// haven't returned by this deadline are abandoned (their results are dropped)
// and the next tick will re-request the still-missing matches.
const BATCH_DEADLINE_MS = 8000;
// UA + host pinned in `config.ts`; see comments there for fingerprint rationale.
const UA = USER_AGENT_VCBET;

// ---- Host-drift handling -------------------------------------------------
// NowGoal rotates the oddscomp mirror occasionally (live9 → live10 observed
// 2026-08). A stale mirror answers with an IIS-style HTML "Document Moved"
// page whose HREF names the CURRENT mirror. We do NOT use curl -L because the
// new host rejects requests carrying the OLD host's Referer — the retry must
// rebuild both URL and Referer against the new host. On detection we hot-swap
// the module-level host so all subsequent requests (fetch + probe) go straight
// to the live mirror.
let currentVcbetHost = NOWGOAL_VCBET_HOST;

/** Current effective oddscomp host (exported for health/diagnostics). */
export function getVcbetHost(): string {
  return currentVcbetHost;
}

/**
 * If `body` is a NowGoal redirect page, extract the target origin.
 * Returns null when the body is not a redirect (i.e. normal JSON) OR the
 * target fails validation. SSRF guard: the upstream body is untrusted, so a
 * redirect target is only accepted when it is HTTPS and is either a bare
 * nowgoalNN.com origin or the explicitly-shaped liveN/www subdomain. The
 * numeric suffix keeps future mirror rotations possible without accepting
 * arbitrary attacker-controlled subdomains.
 */
export function extractRedirectHost(body: string): string | null {
  if (body.length > 4096 || body.trimStart().startsWith("{")) return null;
  const m = /HREF="(https?:\/\/[a-z0-9.-]+)\//i.exec(body);
  if (!m) return null;
  try {
    const u = new URL(m[1]!);
    if (u.protocol !== "https:") return null;
    const isBareNowGoal = /^nowgoal\d+\.com$/i.test(u.hostname);
    const isNamedMirror = /^(?:live\d+|www)\.nowgoal\d+\.com$/i.test(u.hostname);
    if (!isBareNowGoal && !isNamedMirror) {
      logger.warn(
        { rejected: u.hostname },
        "[VCBET-PERMATCH] Redirect target outside NowGoal family — REJECTED (possible SSRF attempt)",
      );
      return null;
    }
    return `https://${u.hostname}`;
  } catch {
    return null;
  }
}

/** Detect redirect drift in `body`; if found, swap hosts and return true. */
function maybeSwapHost(body: string): boolean {
  const target = extractRedirectHost(body);
  if (!target || target === currentVcbetHost) return false;
  logger.warn(
    { from: currentVcbetHost, to: target },
    "[VCBET-PERMATCH] Host drift detected via redirect page — hot-swapping oddscomp host",
  );
  currentVcbetHost = target;
  return true;
}

interface CurlResponse {
  body: string;
  status: number | null;
  effectiveUrl: string | null;
  redirectedFrom?: string;
}

const CURL_META_MARKER = "__NOWGOAL_CURL_META__";

/** One raw curl GET against the oddscomp Ajax for `id` on the current host. */
async function curlSoccerAjax(id: string): Promise<CurlResponse> {
  const flesh = Math.random().toString();
  const url = `${currentVcbetHost}/ajax/soccerajax?type=14&t=11&id=${encodeURIComponent(id)}&h=0&flesh=${flesh}`;
  const referer = `${currentVcbetHost}/oddscomp/${encodeURIComponent(id)}`;
  const { stdout } = await execFileAsync(
    "curl",
    [
      "-sS",
      "--compressed",
      "--max-time",
      String(Math.ceil(PER_MATCH_TIMEOUT_MS / 1000)),
      "-A",
      UA,
      "-H",
      `Referer: ${referer}`,
      "-H",
      "X-Requested-With: XMLHttpRequest",
      "-H",
      "Accept: */*",
      "-w",
      `\n${CURL_META_MARKER}%{http_code}\t%{url_effective}`,
      url,
    ],
    { timeout: PER_MATCH_TIMEOUT_MS + 500, maxBuffer: 1 << 20 },
  );
  const raw = stdout ?? "";
  const markerAt = raw.lastIndexOf(CURL_META_MARKER);
  if (markerAt < 0) {
    return { body: raw, status: null, effectiveUrl: null };
  }
  const body = raw.slice(0, markerAt).replace(/\n$/, "");
  const metadata = raw.slice(markerAt + CURL_META_MARKER.length).trim();
  const [statusText, effectiveUrl] = metadata.split("\t");
  const parsedStatus = Number.parseInt(statusText ?? "", 10);
  return {
    body,
    status: Number.isFinite(parsedStatus) && parsedStatus > 0 ? parsedStatus : null,
    effectiveUrl: effectiveUrl || null,
  };
}

/**
 * curl the Ajax endpoint, transparently following ONE host drift: if the
 * response is a "Document Moved" page, swap hosts and retry once against the
 * new mirror (fresh URL + Referer). Never follows more than one hop per call.
 */
async function curlSoccerAjaxWithDrift(id: string): Promise<CurlResponse> {
  const first = await curlSoccerAjax(id);
  if (first.body && maybeSwapHost(first.body)) {
    const retry = await curlSoccerAjax(id);
    return {
      ...retry,
      redirectedFrom: first.effectiveUrl ?? currentVcbetHost,
    };
  }
  return first;
}

export interface VcbetSnapshot {
  line: number;
  overDecimal: number;
  underDecimal: number;
}

interface RoddsTriplet {
  u?: string;
  g?: string;
  d?: string;
}
interface RoddsRow {
  cid?: number;
  ou?: RoddsTriplet;
}

/**
 * Fetch the per-match oddscomp Ajax for `matchId` and return the Vcbet
 * (company 14) OU snapshot, or null if Vcbet did not quote this match
 * or the response was unusable. Never throws.
 */
export async function fetchVcbetForMatch(matchId: string): Promise<VcbetSnapshot | null> {
  // Defense-in-depth: only numeric ids are legitimate NowGoal match ids.
  // execFile already avoids shell interpretation, but rejecting non-numeric
  // ids fast also prevents wasted upstream requests for garbage input.
  if (!/^\d{1,12}$/.test(matchId)) return null;

  // Why curl instead of Node's fetch:
  //   The upstream filters by TLS/HTTP fingerprint, not by IP. From this
  //   same VM, curl gets the full roddsList (cid:14 included) while undici
  //   fetch with identical URL+headers gets `{"code":1001}`. Shelling out
  //   to curl side-steps the entire TLS-impersonation problem without
  //   adding third-party deps or rotating proxies. `--compressed` makes
  //   curl auto-decode gzip so we get plain JSON on stdout.
  try {
    const response = await curlSoccerAjaxWithDrift(matchId);
    if (!response.body) return null;
    let json: { ErrCode?: number; Data?: { roddsList?: RoddsRow[] } };
    try {
      json = JSON.parse(response.body);
    } catch {
      return null;
    }
    if (json.ErrCode !== 0) return null;
    const list = json.Data?.roddsList;
    if (!Array.isArray(list)) return null;
    const vcbet = list.find((r) => r?.cid === VCBET_COMPANY_ID);
    if (!vcbet?.ou) return null;
    const line = parseFloat(vcbet.ou.g ?? "");
    const overHk = parseFloat(vcbet.ou.u ?? "");
    const underHk = parseFloat(vcbet.ou.d ?? "");
    // IMPORTANT: this Ajax endpoint quotes Hong Kong odds (e.g. 0.95 / 0.85)
    // while the rest of the scanner's pipeline (goal14.xml batch, downstream
    // history math at scanner.ts:1140) stores European DECIMAL odds. We must
    // convert HK→decimal (add 1.0) before returning, otherwise downstream
    // computes nonsense like (0.95 - 1) = -0.05 HK.
    const overDecimal = overHk + 1;
    const underDecimal = underHk + 1;
    // Bounds match parseOUXml's sanity range for decimal odds: > 1 and <= 20.
    if (
      !Number.isFinite(line) ||
      !Number.isFinite(overHk) ||
      !Number.isFinite(underHk) ||
      overDecimal <= 1 ||
      overDecimal > 20 ||
      underDecimal <= 1 ||
      underDecimal > 20
    ) {
      return null;
    }
    return { line, overDecimal, underDecimal };
  } catch (err) {
    // curl exit non-zero / timeout / parse error — silently fall through.
    logger.debug(
      { matchId, err: err instanceof Error ? err.message : String(err) },
      "[VCBET-PERMATCH] fetch failed",
    );
    return null;
  }
}

/**
 * Lightweight reachability probe for the Vcbet per-match Ajax endpoint, used by
 * the scanner's pre-flight validation gate. This is NOT a token/cookie
 * handshake — the endpoint is a stateless GET with no session state — it simply
 * confirms the host + path + gzip transport are alive and returning a
 * well-formed `{ ErrCode, Data }` envelope (i.e. we're not being silently
 * blocked or hung).
 *
 * Pass a real, currently-live `sampleMatchId` (lifted from the validated META
 * feed) for the most meaningful probe; if none is available a placeholder id is
 * used and we still accept any intact JSON envelope as proof of reachability.
 *
 * Success criteria (deliberately lenient — we're checking ROUTING, not data):
 *   - curl returns within the timeout (no hang / no kill)
 *   - stdout is non-empty and parses as JSON
 *   - the JSON carries a numeric `ErrCode` field (the envelope is intact)
 * A populated `roddsList` is reported but not required (it's match-specific).
 * Never throws.
 */
export async function probeVcbet(
  sampleMatchId?: string | null,
): Promise<{
  ok: boolean;
  reason: string;
  matchId: string;
  hadRoddsList: boolean;
  status?: number;
  effectiveUrl?: string;
  redirected?: boolean;
  redirectedFrom?: string;
}> {
  const id =
    sampleMatchId && /^\d{1,12}$/.test(sampleMatchId) ? sampleMatchId : "2700000";
  try {
    const response = await curlSoccerAjaxWithDrift(id);
    const transport = {
      ...(response.status !== null && { status: response.status }),
      ...(response.effectiveUrl !== null && { effectiveUrl: response.effectiveUrl }),
      ...(response.redirectedFrom !== undefined && {
        redirected: true,
        redirectedFrom: response.redirectedFrom,
      }),
    };
    if (!response.body) {
      return { ok: false, reason: "empty_response", matchId: id, hadRoddsList: false, ...transport };
    }
    let json: { ErrCode?: number; Data?: { roddsList?: unknown } };
    try {
      json = JSON.parse(response.body);
    } catch {
      return { ok: false, reason: "unparseable_json", matchId: id, hadRoddsList: false, ...transport };
    }
    if (typeof json.ErrCode !== "number") {
      return { ok: false, reason: "missing_errcode_envelope", matchId: id, hadRoddsList: false, ...transport };
    }
    const hadRoddsList = Array.isArray(json.Data?.roddsList);
    return {
      ok: true,
      reason: hadRoddsList ? "ok_with_rodds" : `ok_envelope_errcode_${json.ErrCode}`,
      matchId: id,
      hadRoddsList,
      ...transport,
    };
  } catch (err) {
    return {
      ok: false,
      reason: err instanceof Error ? err.message : String(err),
      matchId: id,
      hadRoddsList: false,
    };
  }
}

/**
 * Fetch Vcbet for many matches in parallel with a fixed concurrency cap.
 * Returns a Map of matchId → snapshot (matches that returned null are omitted).
 * Never throws; bounded by `PER_MATCH_TIMEOUT_MS` per request.
 */
export async function fetchVcbetBatch(
  matchIds: readonly string[],
  concurrency = 5,
): Promise<Map<string, VcbetSnapshot>> {
  const out = new Map<string, VcbetSnapshot>();
  if (matchIds.length === 0) return out;
  // Workers write directly into `out` as snapshots arrive. If the global
  // deadline fires first, we resolve early with whatever has been collected
  // so far; in-flight workers will keep writing to `out` but the scanner
  // tick has already moved on (their writes become no-ops for this tick,
  // and the next tick will re-request anyway, so it's safe).
  let cursor = 0;
  const workers = Array.from({ length: Math.min(concurrency, matchIds.length) }, async () => {
    while (true) {
      const i = cursor++;
      if (i >= matchIds.length) return;
      const id = matchIds[i]!;
      const snap = await fetchVcbetForMatch(id);
      if (snap) out.set(id, snap);
    }
  });
  const allDone = Promise.all(workers).then(() => "done" as const);
  const deadline = new Promise<"deadline">((resolve) =>
    setTimeout(() => resolve("deadline"), BATCH_DEADLINE_MS).unref?.(),
  );
  const result = await Promise.race([allDone, deadline]);
  if (result === "deadline") {
    logger.warn(
      { requested: matchIds.length, collected: out.size, deadlineMs: BATCH_DEADLINE_MS },
      "[VCBET-PERMATCH] batch deadline hit; returning partial results",
    );
  }
  return out;
}
