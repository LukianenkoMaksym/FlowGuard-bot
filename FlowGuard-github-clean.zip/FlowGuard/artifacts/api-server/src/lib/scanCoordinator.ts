import { logger } from "./logger";

export const ACTIVE_SCAN_CADENCE_MS = 12_000;
export const DISCOVERY_SCAN_CADENCE_MS = 60_000;

export interface ScanCoordinatorTasks {
  active: () => Promise<void>;
  discovery: () => Promise<void>;
}

export interface ScanCoordinatorStatus {
  running: boolean;
  inFlight: boolean;
  generation: number;
  cyclesStarted: number;
  cyclesCompleted: number;
  overlapSkips: number;
  lastStartedAt: number | null;
  lastCompletedAt: number | null;
  lastDurationMs: number | null;
  lastDiscoveryAt: number | null;
  nextActiveAt: number | null;
  activeCadenceMs: number;
  discoveryCadenceMs: number;
  lastError: string | null;
}

/**
 * The sole timer owner for scanning work. A completion-anchored timeout and an
 * in-flight latch make overlap impossible, including when an upstream request
 * takes longer than the nominal cadence. Discovery is folded into the same
 * sequential cycle rather than being allowed to compete with active work.
 */
export class SequentialScanCoordinator {
  private timer: ReturnType<typeof setTimeout> | null = null;
  private generation = 0;
  private inFlight = false;
  private running = false;
  private lastDiscoveryAt: number | null = null;
  private readonly status: ScanCoordinatorStatus = {
    running: false,
    inFlight: false,
    generation: 0,
    cyclesStarted: 0,
    cyclesCompleted: 0,
    overlapSkips: 0,
    lastStartedAt: null,
    lastCompletedAt: null,
    lastDurationMs: null,
    lastDiscoveryAt: null,
    nextActiveAt: null,
    activeCadenceMs: ACTIVE_SCAN_CADENCE_MS,
    discoveryCadenceMs: DISCOVERY_SCAN_CADENCE_MS,
    lastError: null,
  };

  constructor(
    private readonly tasks: ScanCoordinatorTasks,
    private readonly activeCadenceMs = ACTIVE_SCAN_CADENCE_MS,
    private readonly discoveryCadenceMs = DISCOVERY_SCAN_CADENCE_MS,
  ) {
    this.status.activeCadenceMs = activeCadenceMs;
    this.status.discoveryCadenceMs = discoveryCadenceMs;
  }

  start(): boolean {
    if (this.running) return false;
    this.running = true;
    this.generation++;
    this.status.running = true;
    this.status.generation = this.generation;
    // A stopped generation may still be unwinding an awaited task. Never
    // overlap it; its finally block will hand ownership to this generation.
    if (!this.inFlight) this.arm(0, this.generation);
    return true;
  }

  stop(): boolean {
    if (!this.running && this.timer === null) return false;
    this.running = false;
    this.generation++;
    this.status.running = false;
    this.status.generation = this.generation;
    this.status.nextActiveAt = null;
    if (this.timer !== null) clearTimeout(this.timer);
    this.timer = null;
    return true;
  }

  /** Coalesced manual wake-up; it never starts a second cycle. */
  requestRun(): void {
    if (!this.running || this.inFlight) return;
    if (this.timer !== null) clearTimeout(this.timer);
    this.timer = null;
    this.arm(0, this.generation);
  }

  snapshot(): ScanCoordinatorStatus {
    return { ...this.status };
  }

  private arm(delay: number, generation: number): void {
    if (!this.running || generation !== this.generation) return;
    this.status.nextActiveAt = Date.now() + delay;
    this.timer = setTimeout(() => {
      this.timer = null;
      void this.run(generation);
    }, delay);
    this.timer.unref?.();
  }

  private async run(generation: number): Promise<void> {
    if (!this.running || generation !== this.generation) return;
    if (this.inFlight) {
      this.status.overlapSkips++;
      return;
    }
    this.inFlight = true;
    this.status.inFlight = true;
    const startedAt = Date.now();
    this.status.lastStartedAt = startedAt;
    this.status.cyclesStarted++;
    this.status.nextActiveAt = null;
    let cycleError: string | null = null;
    try {
      await this.tasks.active();
    } catch (err) {
      cycleError = err instanceof Error ? err.message : String(err);
      logger.error({ err: cycleError, stage: "active" }, "[SCAN-COORDINATOR] stage failed");
    }
    // A stop/restart while active work was awaited invalidates the remainder of
    // the old cycle. In particular it must not run stale discovery work.
    if (
      this.running &&
      generation === this.generation &&
      (this.lastDiscoveryAt === null || startedAt - this.lastDiscoveryAt >= this.discoveryCadenceMs)
    ) {
      // This is an attempt cadence, not a success cadence: an unavailable
      // directory must not be hammered every active (12s) cycle.
      this.lastDiscoveryAt = Date.now();
      this.status.lastDiscoveryAt = this.lastDiscoveryAt;
      try {
        await this.tasks.discovery();
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        cycleError = cycleError ? `${cycleError}; ${message}` : message;
        logger.error({ err: message, stage: "discovery" }, "[SCAN-COORDINATOR] stage failed");
      }
    }
    this.status.lastError = cycleError;
    {
      this.inFlight = false;
      this.status.inFlight = false;
      this.status.cyclesCompleted++;
      this.status.lastCompletedAt = Date.now();
      this.status.lastDurationMs = this.status.lastCompletedAt - startedAt;
      if (this.running) {
        this.arm(
          generation === this.generation ? this.activeCadenceMs : 0,
          this.generation,
        );
      }
    }
  }
}

let coordinator: SequentialScanCoordinator | null = null;
let coordinatorStartPromise: Promise<void> | null = null;
let lastPreMatchAt = 0;
const PREMATCH_CADENCE_MS = 180_000;

export async function runCoordinatorDiscoveryCycle(
  refreshDirectory: () => Promise<void>,
  refreshPreMatch: () => Promise<void>,
): Promise<void> {
  const errors: string[] = [];
  try {
    await refreshDirectory();
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    errors.push(`live-directory: ${message}`);
    logger.error({ stage: "live-directory", err }, "[SCAN-COORDINATOR] adapter failed; continuing");
  }
  if (lastPreMatchAt === 0 || Date.now() - lastPreMatchAt >= PREMATCH_CADENCE_MS) {
    try {
      await refreshPreMatch();
      lastPreMatchAt = Date.now();
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      errors.push(`prematch: ${message}`);
      logger.error({ stage: "prematch", err }, "[SCAN-COORDINATOR] adapter failed; continuing");
    }
  }
  if (errors.length) throw new Error(errors.join("; "));
}

export async function startScanCoordinator(): Promise<void> {
  if (coordinator?.snapshot().running) return;
  if (coordinatorStartPromise) return coordinatorStartPromise;
  coordinatorStartPromise = (async () => {
    const scanner = await import("./scanner");
    await scanner.startScanner({ externalScheduling: true });
    const [alt, score, excapper, preMatch] = await Promise.all([
      import("./altStream"),
      import("./sofascoreWatchdog"),
      import("./excapper"),
      import("./preMatchAlerts"),
    ]);
    excapper.startExcapperScraper();
    const runStage = async (name: string, fn: () => Promise<void>): Promise<string | null> => {
      try {
        await fn();
        return null;
      } catch (err) {
        logger.error({ stage: name, err }, "[SCAN-COORDINATOR] adapter failed; continuing");
        return `${name}: ${err instanceof Error ? err.message : String(err)}`;
      }
    };
    coordinator = new SequentialScanCoordinator({
      active: async () => {
        const errors: string[] = [];
        for (const [name, fn] of [
          ["primary", scanner.runScannerCycle],
          ["watchlist-score", scanner.runWatchlistScoreRefreshCycle],
          ["alt", alt.runAltStreamCycle],
          ["score-watchdog", score.runScoreWatchdogCycle],
          ["excapper-watchlist", excapper.runExcapperScraperCycle],
        ] as const) {
          const error = await runStage(name, fn);
          if (error) errors.push(error);
        }
        if (errors.length > 0) throw new Error(errors.join("; "));
      },
      discovery: async () => {
        // External scheduling disables scanner's internal directory timer.
        await runCoordinatorDiscoveryCycle(
          scanner.runLeagueDirectoryCycle,
          () => preMatch.runPreMatchAlertCycle(scanner.getLeagueNamesSnapshot()),
        );
      },
    });
    coordinator.start();
    logger.info(
      { activeCadenceMs: ACTIVE_SCAN_CADENCE_MS, discoveryCadenceMs: DISCOVERY_SCAN_CADENCE_MS },
      "[SCAN-COORDINATOR] sequential engine started",
    );
  })();
  try {
    await coordinatorStartPromise;
  } finally {
    coordinatorStartPromise = null;
  }
}

export async function stopScanCoordinator(): Promise<void> {
  if (coordinatorStartPromise) {
    try {
      await coordinatorStartPromise;
    } catch {
      // Startup failure has no live coordinator to stop.
    }
  }
  coordinator?.stop();
  coordinator = null;
  const [scanner, excapper] = await Promise.all([
    import("./scanner"),
    import("./excapper"),
  ]);
  excapper.stopExcapperScraper();
  await scanner.stopScanner();
}

export function requestCoordinatedScan(): void {
  coordinator?.requestRun();
}

export function getScanCoordinatorStatus(): ScanCoordinatorStatus | null {
  return coordinator?.snapshot() ?? null;
}