import { beforeEach, describe, expect, it, vi } from "vitest";

const storage = vi.hoisted(() => ({
  blocks: new Map<string, { diagnosticId: string; gameId: string }>(),
  decisions: new Map<string, Record<string, unknown>>(),
  active: new Map<string, Record<string, unknown>>(),
  failAudit: false,
  failBlock: "",
  blocksTable: { gameId: "game_id" },
  decisionsTable: { id: "id" },
  activeTable: { nowgoalId: "nowgoal_id" },
}));
vi.mock("@workspace/db", () => ({
  manualBindingBlocksTable: storage.blocksTable,
  manualActiveBindingsTable: storage.activeTable,
  bindingDecisionsTable: storage.decisionsTable,
  db: {
    execute: async () => undefined,
    select: () => ({ from: async () => [...storage.blocks.values()] }),
    transaction: async (run: (tx: unknown) => Promise<void>) => {
      // Model PostgreSQL transaction isolation/rollback: staged writes become
      // durable only on successful callback completion.
      const blocks = new Map(storage.blocks);
      const decisions = new Map(storage.decisions);
      const active = new Map(storage.active);
      await run({
        execute: async () => undefined,
        delete: () => ({ where: async () => { active.delete("42"); } }),
        insert: (table: unknown) => ({
          values: (value: Record<string, unknown>) => ({
            onConflictDoNothing: () => {
              if (table === storage.blocksTable) return {
                returning: async () => {
                  const gameId = value.gameId as string;
                  if (gameId === storage.failBlock) throw new Error("block insert failed");
                  const diagnosticId = value.diagnosticId as string;
                  const key = `${diagnosticId}:${gameId}`;
                  if (blocks.has(key)) return [];
                  blocks.set(key, { diagnosticId, gameId });
                  return [{ gameId }];
                },
              };
              if (storage.failAudit) return Promise.reject(new Error("audit insert failed"));
              decisions.set(value.id as string, value);
              return Promise.resolve();
            },
          }),
        }),
      });
      storage.blocks = blocks;
      storage.decisions = decisions;
      storage.active = active;
    },
  },
}));

import { initManualBindingBlocks, persistManualBindingReset } from "./manualBindingBlocks";
import type { PendingBindingDecision } from "./bindingDecisionOutbox";

function event(gameId: string): PendingBindingDecision {
  const evidence = {
    id: gameId, home: null, away: null, league: null,
    score: null, minute: null, period: null,
  };
  return {
    matchId: "42",
    decision: {
      id: `reset-${gameId}`, action: "reset", mode: "manual",
      occurredAt: "2026-09-22T00:00:00.000Z",
      target: { ...evidence, id: "42" }, source: evidence, reason: "Operator reset",
    },
  };
}

describe("atomic reset blocks and decision history", () => {
  beforeEach(() => {
    storage.blocks = new Map([["42:prior", { diagnosticId: "42", gameId: "prior" }]]);
    storage.decisions = new Map();
    storage.active = new Map([["42", { nowgoalId: "42" }]]);
    storage.failAudit = false;
    storage.failBlock = "";
  });

  it("reloads only prior blocks after audit admission fails: no unaudited reset survives restart", async () => {
    storage.failAudit = true;
    await expect(persistManualBindingReset([
      { diagnosticId: "42", gameId: "prior" },
      { diagnosticId: "42", gameId: "new" },
    ], [event("prior"), event("new")])).rejects.toThrow("audit insert failed");
    // Startup reload reads durable storage, not the previous runtime block set.
    expect(await initManualBindingBlocks()).toEqual([{ diagnosticId: "42", gameId: "prior" }]);
    expect(storage.decisions.size).toBe(0);
    expect(storage.active.has("42")).toBe(true);
  });

  it("rolls back earlier blocks and audits if a later candidate block fails", async () => {
    storage.failBlock = "second";
    await expect(persistManualBindingReset([
      { diagnosticId: "42", gameId: "first" },
      { diagnosticId: "42", gameId: "second" },
    ], [event("first"), event("second")])).rejects.toThrow("block insert failed");
    expect(await initManualBindingBlocks()).toEqual([{ diagnosticId: "42", gameId: "prior" }]);
    expect(storage.decisions.size).toBe(0);
    expect(storage.active.has("42")).toBe(true);
  });

  it("commits blocks and history together, preserving prior blocks and deduplicating repeated reset", async () => {
    const pairs = [{ diagnosticId: "42", gameId: "new" }];
    await persistManualBindingReset(pairs, [event("new")]);
    expect(storage.active.has("42")).toBe(false);
    await persistManualBindingReset(pairs, [{ ...event("new"), decision: { ...event("new").decision, id: "retry" } }]);
    expect(await initManualBindingBlocks()).toEqual([
      { diagnosticId: "42", gameId: "prior" }, { diagnosticId: "42", gameId: "new" },
    ]);
    expect([...storage.decisions.keys()]).toEqual(["reset-new"]);
  });

  it("persists an identity-only wildcard reset with null audit source, never a fabricated source ID", async () => {
    const pair = { diagnosticId: "42", gameId: "*" };
    const reset = event("*");
    reset.decision.source.id = null;
    await persistManualBindingReset([pair], [reset], "42");
    expect(storage.active.has("42")).toBe(false);
    expect(await initManualBindingBlocks()).toContainEqual(pair);
    expect(storage.decisions.get("reset-*")).toMatchObject({
      source: { id: null },
    });
  });

  it("rejects wildcard audit evidence claiming a source ID without committing a block", async () => {
    await expect(persistManualBindingReset(
      [{ diagnosticId: "42", gameId: "*" }], [event("*")], "42",
    )).rejects.toThrow("Reset audit evidence is missing");
    expect(storage.active.has("42")).toBe(true);
    expect(await initManualBindingBlocks()).not.toContainEqual({ diagnosticId: "42", gameId: "*" });
  });
});