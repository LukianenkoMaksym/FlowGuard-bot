/**
 * Development and production can share a Telegram token. A token, polling
 * override, or NODE_ENV alone must never authorize work-chat traffic.
 * Read the environment at request time so queued work cannot bypass the guard.
 */
export function resolveTelegramOutboundMode(
  env: Record<string, string | undefined> = process.env,
): { allowed: boolean; reason: string } {
  if (env["NODE_ENV"] !== "production") {
    return { allowed: false, reason: "NODE_ENV is not production" };
  }
  if (env["REPLIT_DEPLOYMENT"] !== "1") {
    return { allowed: false, reason: "REPLIT_DEPLOYMENT is not 1" };
  }
  return { allowed: true, reason: "production deployment" };
}