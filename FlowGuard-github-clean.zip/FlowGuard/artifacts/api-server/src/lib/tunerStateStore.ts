import { pool } from "@workspace/db";
import type { TunerMetadata } from "./autoTunerRules";

/** Only tuner clocks/state live here; scanner filters remain in their existing file. */
export async function loadTunerState(seed: TunerMetadata): Promise<unknown> {
  await pool.query(`CREATE TABLE IF NOT EXISTS scanner_tuner_state (
    id integer PRIMARY KEY CHECK (id = 1),
    metadata jsonb NOT NULL
  )`);
  await pool.query(
    "INSERT INTO scanner_tuner_state (id, metadata) VALUES (1, $1::jsonb) ON CONFLICT (id) DO NOTHING",
    [JSON.stringify(seed)],
  );
  const result = await pool.query("SELECT metadata FROM scanner_tuner_state WHERE id = 1");
  if (!result.rows[0]) throw new Error("Tuner state singleton missing");
  return result.rows[0].metadata;
}

/** Stage DB state, publish the file, then commit; caller compensates the file on failure. */
export async function saveTunerState(metadata: TunerMetadata, publishFile: () => Promise<void>): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query("UPDATE scanner_tuner_state SET metadata = $1::jsonb WHERE id = 1", [JSON.stringify(metadata)]);
    if (result.rowCount !== 1) throw new Error("Tuner state singleton missing");
    await publishFile();
    await client.query("COMMIT");
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}