import { afterEach, describe, expect, it, vi } from "vitest";
import { validateUpstream } from "./healthcheck";
import { getLeaguePolicy } from "./targetLeagues";

afterEach(() => vi.useRealTimers());

describe("upstream health count labels", () => {
  it("distinguishes scheduled kickoffs, upstream directory rows, and whitelist entries", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-08-01T12:00:00.000Z"));
    const schedule = Array.from({ length: 291 }, (_, i) =>
      `${i}^x^x^2026,7,1,20,0,0`,
    ).join("!");
    const directory = Array.from({ length: 148 }, (_, i) => `B[${i}]=[`).join("");
    const fetchFn = vi.fn(async (url: string) => {
      if (url.includes("goal8.xml") || url.includes("goal3.xml")) return "<m>1^2^3</m>".repeat(6);
      if (url.includes("type=12")) return JSON.stringify({ ErrCode: 0, Data: schedule });
      if (url.includes("type=6")) return JSON.stringify({ ErrCode: 0, Data: directory });
      throw new Error(`Unexpected upstream URL: ${url}`);
    });

    const validation = await validateUpstream(fetchFn);

    expect(validation.ok).toBe(true);
    expect(validation.freshness.matchesNearNow).toBe(291);
    expect(validation.summary).toContain("291 scheduled kickoffs in -6/+36h window");
    expect(validation.summary).toContain("upstream league directory: 148");
    expect(validation.summary).toContain(`whitelist leagues: ${getLeaguePolicy().total}`);
    expect(validation.summary).not.toMatch(/291 live|kickoffs near now/);
  });
});