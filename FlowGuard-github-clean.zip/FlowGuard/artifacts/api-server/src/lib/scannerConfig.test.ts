import { mkdtemp, readFile, readdir, rm, mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
vi.mock("./logger", () => ({ logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() } }));
const durable = vi.hoisted(() => ({ value: null as unknown, fail: false }));
vi.mock("./tunerStateStore", () => ({
  loadTunerState: async (seed: unknown) => {
    if (durable.fail) throw new Error("DB unavailable");
    return structuredClone(durable.value ??= seed);
  },
  saveTunerState: async (metadata: unknown, publish: () => Promise<void>) => {
    if (durable.fail) throw new Error("DB unavailable");
    await publish();
    durable.value = structuredClone(metadata);
  },
}));

vi.mock("./scanner", () => {
  const config = {
    dropThreshold: 0.4, maxSpread: 0.5, tightSpread: 0.15,
    benchmarkConfirmDrop: 0.05, minConfidence: 5, requireDensity: true,
    requireLiquidityConfirmation: false, priorityLeagueIds: ["21"],
    lowLiqMaxSpread: 1, bypassSpreadOnBigDrop: 0.8, absurdSpreadCap: 1.5,
  };
  return {
    config,
    getScannerConfig: () => ({ ...config, priorityLeagueIds: [...config.priorityLeagueIds] }),
    setScannerConfig: (next: typeof config) => Object.assign(config, next, { priorityLeagueIds: [...next.priorityLeagueIds] }),
  };
});

let dir: string;
let file: string;

beforeEach(async () => {
  durable.value = null;
  durable.fail = false;
  vi.stubEnv("DROP_THRESHOLD", undefined);
  vi.stubEnv("MAX_SPREAD", undefined);
  vi.stubEnv("BYPASS_SPREAD_ON_BIG_DROP", undefined);
  dir = await mkdtemp(path.join(tmpdir(), "scanner-config-"));
  file = path.join(dir, "config", "scanner-config.json");
  process.env["SCANNER_CONFIG_PATH"] = file;
  vi.resetModules();
  const scanner = await import("./scanner");
  scanner.setScannerConfig({
    dropThreshold: 0.4, maxSpread: 0.5, tightSpread: 0.15,
    benchmarkConfirmDrop: 0.05, minConfidence: 5, requireDensity: true,
    requireLiquidityConfirmation: false, priorityLeagueIds: ["21"],
    lowLiqMaxSpread: 1, bypassSpreadOnBigDrop: 0.8, absurdSpreadCap: 1.5,
  });
});

afterEach(async () => {
  vi.unstubAllEnvs();
  delete process.env["SCANNER_CONFIG_PATH"];
  vi.resetModules();
  await rm(dir, { recursive: true, force: true });
});

describe("scanner filter persistence", () => {
  it("resolves artifact-owned source and bundled config independently of cwd", async () => {
    const { resolveScannerConfigPath } = await import("./scannerConfig");
    const expected = "/workspace/artifacts/api-server/config/scanner-config.json";
    const urls = [
      "file:///workspace/artifacts/api-server/src/lib/scannerConfig.ts",
      "file:///workspace/artifacts/api-server/dist/index.mjs",
    ];
    vi.stubEnv("SCANNER_CONFIG_PATH", undefined);
    const cwd = vi.spyOn(process, "cwd");
    try {
      for (const workingDir of ["/workspace", "/workspace/artifacts/api-server"]) {
        cwd.mockReturnValue(workingDir);
        for (const url of urls) {
          expect(resolveScannerConfigPath(url, undefined, (file) => file === expected)).toBe(expected);
          expect(resolveScannerConfigPath(url, undefined, () => false)).toBe(expected);
          expect(resolveScannerConfigPath(url, "/operator/custom.json", () => false)).toBe("/operator/custom.json");
        }
      }
    } finally {
      cwd.mockRestore();
    }
  });
  it("keeps env effective while Apply saves file values and unrelated flags/metadata", async () => {
    vi.stubEnv("DROP_THRESHOLD", "0.25");
    vi.stubEnv("MAX_SPREAD", "0.6");
    vi.stubEnv("BYPASS_SPREAD_ON_BIG_DROP", "0.9");
    const scanner = await import("./scanner");
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, JSON.stringify({ ...scanner.getScannerConfig(), extraFlag: false }));
    const storage = await import("./scannerConfig");
    await storage.initScannerConfig();
    expect(storage.getScannerConfigSources()).toEqual({ dropThreshold: "env", maxSpread: "env", bypassSpreadOnBigDrop: "env" });
    await storage.updateScannerConfig({ dropThreshold: 0.7, requireDensity: false });
    expect(scanner.config.dropThreshold).toBe(0.25);
    expect(JSON.parse(await readFile(file, "utf8"))).toMatchObject({ dropThreshold: 0.7, maxSpread: 0.5, bypassSpreadOnBigDrop: 0.8, extraFlag: false, requireDensity: false });
    expect(await storage.transactAutoTuner((_c, metadata) => ({ dropThreshold: 0.3, metadata }))).toMatchObject({ persisted: false, error: expect.stringContaining("source: env") });
    vi.stubEnv("DROP_THRESHOLD", undefined);
    vi.stubEnv("MAX_SPREAD", undefined);
    vi.stubEnv("BYPASS_SPREAD_ON_BIG_DROP", undefined);
    vi.resetModules();
    const fresh = await import("./scannerConfig");
    await fresh.initScannerConfig();
    expect((await import("./scanner")).config.dropThreshold).toBe(0.7);
    expect(fresh.getScannerConfigSources().dropThreshold).toBe("file");
    const edited = JSON.parse(await readFile(file, "utf8"));
    await writeFile(file, JSON.stringify({ ...edited, dropThreshold: 0.55 }));
    vi.stubEnv("DROP_THRESHOLD", "0.3");
    vi.resetModules();
    const withEnv = await import("./scannerConfig");
    await withEnv.initScannerConfig();
    expect((await import("./scanner")).config.dropThreshold).toBe(0.3);
    vi.stubEnv("DROP_THRESHOLD", undefined);
    vi.resetModules();
    const editedFile = await import("./scannerConfig");
    await editedFile.initScannerConfig();
    expect((await import("./scanner")).config.dropThreshold).toBe(0.55);
  });

  it("rejects invalid env including zero consistently with API ranges", async () => {
    vi.stubEnv("DROP_THRESHOLD", "bad");
    vi.stubEnv("MAX_SPREAD", "0");
    vi.stubEnv("BYPASS_SPREAD_ON_BIG_DROP", "false");
    const storage = await import("./scannerConfig");
    await storage.initScannerConfig();
    expect(storage.getScannerConfigSources()).toEqual({ dropThreshold: "default", maxSpread: "default", bypassSpreadOnBigDrop: "default" });
    expect((await import("./logger")).logger.warn).toHaveBeenCalledWith(
      expect.objectContaining({ env: "DROP_THRESHOLD" }),
      expect.stringContaining("invalid environment"),
    );
    expect(await storage.updateScannerConfig({ maxSpread: 0 })).toMatchObject({ invalid: true });
  });

  it("retains DB tuner pause after replacement deletes the local file; outage blocks mutations", async () => {
    const storage = await import("./scannerConfig");
    await storage.initScannerConfig();
    const metadata = { enabled: true, pausedUntil: "2030-01-01T00:00:00.000Z", lastAdjustment: null };
    await storage.transactAutoTuner(() => ({ metadata }));
    await rm(file);
    vi.resetModules();
    const fresh = await import("./scannerConfig");
    await fresh.initScannerConfig();
    expect(fresh.getTunerMetadata()).toEqual(metadata);
    durable.fail = true;
    expect(await fresh.updateScannerConfig({ dropThreshold: 0.7 })).toMatchObject({ persisted: false });
    expect(fresh.getTunerMetadata()).toEqual(metadata);
    expect(await fresh.transactAutoTuner(() => ({ metadata: { ...metadata, enabled: false } }))).toMatchObject({ persisted: false, error: expect.stringContaining("unavailable") });
  });
  it("survives a simulated fresh-process boot and writes no orphaned temp files", async () => {
    const storage = await import("./scannerConfig");
    const scanner = await import("./scanner");
    await storage.initScannerConfig();
    const defaults = scanner.getScannerConfig();
    const saved = await storage.updateScannerConfig({
      dropThreshold: 0.7, requireLiquidityConfirmation: true, priorityLeagueIds: ["140"],
    });
    expect(saved.persisted).toBe(true);
    expect(scanner.config.dropThreshold).toBe(0.7);
    expect(JSON.parse(await readFile(file, "utf8"))).toMatchObject({
      dropThreshold: 0.7, requireLiquidityConfirmation: true, priorityLeagueIds: ["140"],
    });
    expect(await readdir(path.dirname(file))).toEqual(["scanner-config.json"]);

    scanner.setScannerConfig(defaults); // discard runtime state to simulate a process restart
    vi.resetModules(); // fresh persistence module, same on-disk config
    const freshScanner = await import("./scanner");
    const freshStorage = await import("./scannerConfig");
    expect(freshScanner.config.dropThreshold).toBe(0.4);
    await freshStorage.initScannerConfig();
    expect(freshScanner.config).toMatchObject({
      dropThreshold: 0.7, requireLiquidityConfirmation: true, priorityLeagueIds: ["140"],
    });
  });

  it("rejects invalid combined changes without modifying runtime or disk", async () => {
    const storage = await import("./scannerConfig");
    const scanner = await import("./scanner");
    const before = scanner.getScannerConfig();
    const result = await storage.updateScannerConfig({ maxSpread: 3, lowLiqMaxSpread: 1 });
    expect(result).toMatchObject({ persisted: false, invalid: true });
    expect(scanner.getScannerConfig()).toEqual(before);
    await expect(readFile(file, "utf8")).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("reports disk failures rather than applying filters only in memory", async () => {
    const storage = await import("./scannerConfig");
    const scanner = await import("./scanner");
    await mkdir(file, { recursive: true }); // rename to a directory must fail
    const result = await storage.updateScannerConfig({ dropThreshold: 0.7 });
    expect(result).toMatchObject({ persisted: false, invalid: false });
    expect(scanner.config.dropThreshold).toBe(0.4);
    expect(await readdir(path.dirname(file))).toEqual(["scanner-config.json"]);
  });

  it("serializes overlapping requests so the last completed write wins", async () => {
    const storage = await import("./scannerConfig");
    const scanner = await import("./scanner");
    const results = await Promise.all([
      storage.updateScannerConfig({ maxSpread: 0.6 }),
      storage.updateScannerConfig({ maxSpread: 0.8, lowLiqMaxSpread: 1.2 }),
    ]);
    expect(results.every((result) => result.persisted)).toBe(true);
    expect(scanner.config.maxSpread).toBe(0.8);
    expect(JSON.parse(await readFile(file, "utf8")).maxSpread).toBe(0.8);
  });
});