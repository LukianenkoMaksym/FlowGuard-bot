/**
 * Telegram command listener — the /start subscription front door.
 *
 * Long-polls Telegram's getUpdates (raw fetch, consistent with telegram.ts — we
 * deliberately do NOT add a bot framework like telegraf, which would spin up a
 * SECOND getUpdates consumer on the same token and trigger 409 Conflict against
 * our own poller). Handles two commands:
 *   /start — subscribe the chat to scanner broadcasts
 *   /stop  — unsubscribe
 *
 * Only one getUpdates consumer may run per bot token. This loop is the single
 * consumer; the rest of the app only ever calls sendMessage/getMe, so there is
 * no conflict. If a 409 (another consumer / leftover webhook) is seen, we back
 * off and retry rather than hammering the API.
 *
 * POLLING GUARD — only a production deployment can contact Telegram. An
 * optional TELEGRAM_POLLING override can disable polling, but cannot enable it
 * outside production.
 *
 * Outbound sends have their own mandatory production guard in telegram.ts.
 *
 * RESTART / OFFSET-RESUME BEHAVIOUR
 * ---------------------------------------------------------------------------
 * When the production server restarts (deploy, crash, OOM) the polling loop
 * is temporarily unavailable.  Any /start or /stop commands sent by users
 * during the downtime window are queued by Telegram (held for up to 24 h).
 *
 * On restart the following sequence guarantees those queued commands are not
 * lost:
 *
 *   1. `startTelegramBot` calls `ensureSubscribersLoaded`, which reads
 *      `lastUpdateId` from `config/telegram-subscribers.json` (persisted
 *      atomically by every `setLastUpdateId` call in the previous session).
 *
 *   2. `pollLoop` starts its first `getUpdates` call with
 *      `offset = getLastUpdateId() + 1`.  Telegram therefore delivers all
 *      updates with an id ≥ offset — including every /start and /stop that
 *      arrived during the downtime window.
 *
 *   3. Each update is processed exactly once: `setLastUpdateId` advances the
 *      offset monotonically (lower ids are ignored), so even a rapid restart
 *      cycle cannot replay already-processed updates.
 *
 * Acceptable gap: there is a brief period between the last successful
 * `setLastUpdateId` and the server going down during which a new update
 * might have been received by Telegram but not yet acknowledged.  Because
 * `lastUpdateId` was not yet written for that update, the offset on restart
 * re-requests it — i.e. the update is replayed, not dropped.  This is the
 * safe failure mode: `addSubscriber` and `removeSubscriber` are idempotent,
 * so a replayed /start simply returns "already subscribed" to the user.
 *
 * Not covered: if the server is down for more than ~24 h Telegram may
 * discard queued updates.  This is a platform-level constraint outside our
 * control; normal deploys and crashes recover well within that window.
 */
import { logger } from "./logger";
import { handleDiagnosticsCommand } from "./telegramDiagnostics";
import { telegramGetUpdatesUrl } from "./config";
import { sendTelegramTo } from "./telegram";
import { resolveTelegramOutboundMode } from "./telegramOutboundPolicy";
import {
  addSubscriber,
  removeSubscriber,
  getLastUpdateId,
  setLastUpdateId,
  ensureSubscribersLoaded,
  subscriberCount,
} from "./telegramSubscribers";

const TELEGRAM_TOKEN = process.env["TELEGRAM_TOKEN"];
const LONG_POLL_TIMEOUT_SEC = 50;

/**
 * Resolve whether this process instance should run the getUpdates polling loop.
 *
 * Accepts an optional `env` map so the function is a pure, testable unit.
 * Defaults to `process.env` in production.
 *
 * A polling override never grants permission to access Telegram outside a
 * production deployment.
 */
export function resolvePollingMode(
  env: Record<string, string | undefined> = process.env,
): { shouldPoll: boolean; reason: string } {
  const outbound = resolveTelegramOutboundMode(env);
  if (!outbound.allowed) {
    return { shouldPoll: false, reason: `dev workspace — ${outbound.reason}` };
  }
  const override = env["TELEGRAM_POLLING"]?.trim().toLowerCase();
  if (override === "enabled") {
    return { shouldPoll: true, reason: "TELEGRAM_POLLING=enabled (forced on)" };
  }
  if (override === "disabled") {
    return { shouldPoll: false, reason: "TELEGRAM_POLLING=disabled (forced off)" };
  }
  return { shouldPoll: true, reason: "REPLIT_DEPLOYMENT=1 (production instance)" };
}

const pollingMode = resolvePollingMode();

/** Returns the polling mode resolved at startup (for health endpoints). */
export function getTelegramPollingMode(): { shouldPoll: boolean; reason: string } {
  return pollingMode;
}

interface TelegramUpdate {
  update_id: number;
  message?: {
    chat: { id: number; type?: string };
    from?: { id?: number; username?: string; first_name?: string };
    text?: string;
  };
}

let started = false;
let running = false;
let generation = 0;
let activePollAbort: AbortController | null = null;

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function startTelegramBot(): Promise<void> {
  if (started) return;
  if (!TELEGRAM_TOKEN) {
    logger.warn("[TG-BOT] TELEGRAM_TOKEN missing — /start subscription listener disabled");
    return;
  }

  // Recheck at invocation, not just module import; a dev instance must not
  // poll even if a cached mode or an override would otherwise permit it.
  if (!pollingMode.shouldPoll || !resolveTelegramOutboundMode().allowed) {
    logger.info(
      { pollingDisabledReason: pollingMode.reason },
      "[TG-BOT] getUpdates polling DISABLED",
    );
    return;
  }

  started = true;
  const myGeneration = ++generation;
  try {
    await ensureSubscribersLoaded();
  } catch (err) {
    if (generation === myGeneration) {
      started = false;
      running = false;
    }
    throw err;
  }
  // stopTelegramBot may have been called while persisted state was loading.
  if (!started || generation !== myGeneration) return;
  running = true;
  logger.info(
    { subscribers: subscriberCount(), pollingReason: pollingMode.reason },
    "[TG-BOT] Long-poll listener started",
  );
  void pollLoop(myGeneration);
}

export function stopTelegramBot(): void {
  running = false;
  started = false;
  generation++;
  activePollAbort?.abort();
  activePollAbort = null;
}

async function pollLoop(myGeneration: number): Promise<void> {
  while (running && generation === myGeneration) {
    if (!resolveTelegramOutboundMode().allowed) {
      logger.warn("[TG-BOT] getUpdates suppressed — non-production instance");
      break;
    }
    let iterationAbort: AbortController | null = null;
    try {
      const offset = getLastUpdateId() + 1;
      const url =
        `${telegramGetUpdatesUrl(TELEGRAM_TOKEN!)}` +
        `?timeout=${LONG_POLL_TIMEOUT_SEC}&offset=${offset}` +
        `&allowed_updates=${encodeURIComponent('["message"]')}`;

      // Abort a bit after the server-side long-poll window so a dead socket
      // can't wedge the loop forever.
      const controller = new AbortController();
      iterationAbort = controller;
      activePollAbort = controller;
      const signal = AbortSignal.any([
        controller.signal,
        AbortSignal.timeout((LONG_POLL_TIMEOUT_SEC + 10) * 1000),
      ]);
      const res = await fetch(url, { method: "GET", signal });

      if (!res.ok) {
        const body = await res.text();
        logger.warn(
          { status: res.status, body: body.slice(0, 200) },
          "[TG-BOT] getUpdates non-OK — backing off",
        );
        await delay(res.status === 409 ? 10_000 : 5_000);
        continue;
      }

      const data = (await res.json()) as { ok: boolean; result?: TelegramUpdate[] };
      if (!data.ok || !Array.isArray(data.result)) {
        await delay(2_000);
        continue;
      }

      for (const update of data.result) {
        try {
          await handleUpdate(update);
        } catch (err) {
          logger.warn({ err, updateId: update.update_id }, "[TG-BOT] handler threw — skipping");
        }
        // Advance the offset even if the handler failed, so one bad update can't
        // wedge the loop replaying it forever.
        await setLastUpdateId(update.update_id);
      }
    } catch (err) {
      if (!running || generation !== myGeneration) break;
      logger.warn(
        { err: err instanceof Error ? err.message : String(err) },
        "[TG-BOT] poll error — retrying",
      );
      await delay(3_000);
    } finally {
      if (activePollAbort === iterationAbort) activePollAbort = null;
    }
  }
  logger.info("[TG-BOT] Long-poll listener stopped");
}

async function handleUpdate(update: TelegramUpdate): Promise<void> {
  const msg = update.message;
  if (!msg || typeof msg.text !== "string") return;

  const chatId = msg.chat.id;
  const username = msg.from?.username ?? msg.from?.first_name;
  // Commands can arrive as "/start@BotName" in groups — strip the @suffix.
  const command = msg.text.trim().split(/\s+/)[0]?.split("@")[0]?.toLowerCase();
  if (command && await handleDiagnosticsCommand(msg, command)) return;

  if (command === "/start") {
    const isNew = await addSubscriber(chatId, username);
    logger.info({ isNew }, "[TG-BOT] /start processed");
    await sendTelegramTo(
      chatId,
      isNew
        ? "✅ Subscribed to NowGoal26 scanner alerts. You'll get odds-movement notifications here. Send /stop to unsubscribe."
        : "You're already subscribed. Send /stop to unsubscribe.",
      { parseMode: "plain" },
    );
  } else if (command === "/stop") {
    const removed = await removeSubscriber(chatId);
    logger.info({ removed }, "[TG-BOT] /stop processed");
    await sendTelegramTo(
      chatId,
      removed
        ? "🛑 Unsubscribed. You won't receive further alerts. Send /start to re-subscribe."
        : "You weren't subscribed. Send /start to subscribe.",
      { parseMode: "plain" },
    );
  }
}
