import { EXCAPPER_BASE_URL } from "./config";
import { getControls } from "./controls";
import {
  getVerifiedExcapperBinding,
  bindAutomaticExcapperRows,
  loadLiveExcapperDirectory,
  loadParsedGameDetail,
  processTransactions,
  setNewExcapperTransactionListener,
  type DirectoryRow,
  type ExcapperTransaction,
  type ParsedGameDetail,
} from "./excapper";
import { isExcapperBreakerOpen } from "./excapperBackoff";
import { admitGlobalSpike, drainGlobalSpikeOutbox } from "./globalSpikeOutbox";
import { logger } from "./logger";
import { fixedBetTime, PrebetAnalysis } from "./prebetAnalysis";
import { getScannerAlertContext } from "./scanner";
import { matchTargetLeague } from "./targetLeagues";
import { isTelegramConfigured } from "./telegram";
import { formatUnifiedAlert, type UnifiedAlertInput } from "./unifiedAlert";
import { boundedEnrichment } from "./excapperScoring";
import { getCachedBookMovements } from "./radarBookMarkets";
import { recordExcapperPollStart, recordExcapperPollComplete, setExcapperDiagnosticsActive } from "./telegramDiagnostics";

const DEFAULT_INTERVAL_MS = 60_000;
const DEFAULT_CAP = 8;
function positiveInteger(raw: string | undefined, fallback: number): number {
  const n = Number(raw);
  return raw && Number.isSafeInteger(n) && n > 0 ? n : fallback;
}

let active = false;
let busy = false;
let controller: AbortController | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;
let cursor = 0;
let currentRows = new Map<string, DirectoryRow>();
let directoryFresh = false;
const evidence = new Map<string, { row: DirectoryRow; detail: ParsedGameDetail }>();
const prebet = new PrebetAnalysis();

function eligible(row: DirectoryRow): boolean {
  return row.isLive === true && row.activity === "live" &&
    matchTargetLeague(row.league) !== null;
}

async function directory(signal: AbortSignal): Promise<DirectoryRow[]> {
  const snapshot = await loadLiveExcapperDirectory(signal);
  if (snapshot.stale) {
    directoryFresh = false;
    currentRows.clear();
    logger.warn("[GLOBAL-SPIKE] Directory is stale; skipping cycle");
    return [];
  }
  const rows = snapshot.rows.filter(eligible);
  directoryFresh = true;
  currentRows = new Map(rows.map((row) => [row.gameId, row]));
  prebet.observeDirectory(rows.map((row) => row.gameId), Date.now());
  return rows;
}

function buildCard(gameId: string, tx: ExcapperTransaction, row: DirectoryRow, detail: ParsedGameDetail): string | "closed" | null {
  if (!isTelegramConfigured() || !active) return null;
  if (!eligible(row)) return "closed";
  const sample = detail.samples.find((item) => item.line === tx.line);
  const odds = tx.side === "Over" ? sample?.overOdds : sample?.underOdds;
  const quote = odds && odds > 1 && sample?.collectedAt != null
    ? { line: tx.line, odds, ts: sample.collectedAt }
    : null;
  const binding = getVerifiedExcapperBinding(gameId);
  const scanner = binding
    ? getScannerAlertContext(binding.matchId, tx.line, tx.side.toUpperCase() as "OVER" | "UNDER")
    : null;
  const betTime = fixedBetTime(tx, detail.observedAt);
  const scannerPrebet = scanner?.timeline.filter((point) => point.ts <= betTime) ?? [];
  const history = scannerPrebet.length
    ? scannerPrebet
    : prebet.timeline(gameId, tx.line, tx.side, betTime);
  const prebetPoints = PrebetAnalysis.window(history, betTime);
  const currentPrebet = prebetPoints[prebetPoints.length - 1] ?? null;
  // Only a verified NowGoal binding permits bookmaker attribution. Scanner
  // history is Bet365; Excapper's own sample has no bookmaker identifier.
  // Read the RADAR cache without I/O, and never use observations after the
  // actual transaction timestamp (including a delayed outbox retry).
  const firstScannerQuote = scannerPrebet.find((point) =>
    point.line === tx.line && point.ts >= betTime - 5 * 60_000);
  const lastScannerQuote = scannerPrebet.at(-1);
  const scannerMovement = firstScannerQuote && lastScannerQuote &&
    lastScannerQuote.ts > firstScannerQuote.ts &&
    lastScannerQuote.odds !== firstScannerQuote.odds
    ? [{
      cid: "8", bookmaker: "Bet365",
      type: lastScannerQuote.odds < firstScannerQuote.odds ? "drop" as const : "rise" as const,
      from: firstScannerQuote.odds, to: lastScannerQuote.odds,
      percent: (lastScannerQuote.odds - firstScannerQuote.odds) / firstScannerQuote.odds * 100,
      quoteAt: lastScannerQuote.ts,
      history: scannerPrebet.filter((point) => point.line === tx.line)
        .map((point) => ({ ts: point.ts, odds: point.odds })),
    }] : [];
  const cachedMovements = scanner
    ? getCachedBookMovements(binding!.matchId, tx.side.toUpperCase() as "OVER" | "UNDER",
      tx.line, betTime).filter((book) => book.cid !== "8")
    : [];
  const score = detail.live.liveScore ?? row.liveScore ?? null;
  const homeScore = score?.home ?? scanner?.homeScore ?? null;
  const awayScore = score?.away ?? scanner?.awayScore ?? null;
  // A line already settled by known goals is not a live OU opportunity.
  if ((homeScore !== null && awayScore !== null && tx.line <= homeScore + awayScore) ||
    (row.liveScore != null && tx.line <= row.liveScore.home + row.liveScore.away) ||
    (scanner?.homeScore != null && scanner.awayScore != null &&
      tx.line <= scanner.homeScore + scanner.awayScore)) {
    logger.info({ gameId, line: tx.line, score: `${homeScore}:${awayScore}` },
      "[GLOBAL-SPIKE] Settled total skipped");
    return "closed";
  }
  if (!quote && !scanner?.currentQuote && !scanner?.timeline.length &&
    homeScore === null && awayScore === null) {
    logger.warn({ gameId, line: tx.line, side: tx.side },
      "[GLOBAL-SPIKE] Skipped bet without odds or score evidence");
    return null;
  }
  // Transaction matchMinute is historical evidence for the inflow only;
  // never use it to fill a missing current event clock on the card.
  const minute = scanner?.minute ?? (detail.live.liveMinute != null
    ? String(detail.live.liveMinute)
    : row.liveMinute != null ? String(row.liveMinute) : null);
  // Excapper ids and NowGoal ids are unrelated. A binding is the ONLY reason
  // to use a scanner identity; otherwise use the real Excapper game URL.
  const input: UnifiedAlertInput = {
    source: "excapper-global",
    matchId: scanner ? binding!.matchId : `excapper:${gameId}`,
    bookmaker: scannerPrebet.length ? "Bet365" : undefined,
    quoteAt: currentPrebet?.ts ?? undefined,
    radarBooks: [...scannerMovement, ...cachedMovements],
    league: row.league,
    home: row.team1,
    away: row.team2,
    isLive: true,
    homeScore,
    awayScore,
    minute,
    side: tx.side === "Over" ? "OVER" : "UNDER",
    line: tx.line,
    timeline: prebetPoints,
    currentQuote: currentPrebet ?? (quote && quote.ts <= betTime ? quote : null),
    prebet: {
      betTime,
      ...prebet.money(gameId, tx, betTime),
      observationDepth: history.length,
      firstObservedAt: history[0]?.ts ?? null,
      dateTimeIsApproximate: true,
    },
    inflow: { matchId: scanner ? binding!.matchId : `excapper:${gameId}`, line: tx.line,
      side: tx.side === "Over" ? "OVER" : "UNDER", single: tx.change,
      total: tx.summ, minute: tx.matchMinute || minute, observedAt: detail.observedAt },
    link: scanner?.link ?? `${EXCAPPER_BASE_URL}/?action=game&id=${encodeURIComponent(gameId)}`,
  };
  return formatUnifiedAlert(input);
}

async function refreshCard(gameId: string, tx: ExcapperTransaction): Promise<string | "closed" | null> {
  const signal = controller?.signal;
  if (!active || !signal || signal.aborted || isExcapperBreakerOpen()) return null;
  try {
    // A previous cycle's row is never authority for a later send.
    const row = (await directory(signal)).find((candidate) => candidate.gameId === gameId);
    if (!row || signal.aborted) return signal.aborted || !directoryFresh ? null : "closed";
    const detail = await loadParsedGameDetail(gameId, signal, "live");
    if (!signal.aborted) prebet.observeDetail(gameId, detail);
    return signal.aborted ? null : buildCard(gameId, tx, row, detail);
  } catch (err) {
    directoryFresh = false;
    currentRows.clear();
    if (!signal.aborted) logger.warn({ err, gameId }, "[GLOBAL-SPIKE] Fresh bet context unavailable");
    throw err;
  }
}

async function buildFreshCard(gameId: string, tx: ExcapperTransaction): Promise<string | "closed" | null> {
  const fallback = () => {
    const original = (tx as ExcapperTransaction & { originalEvidence?: { row: DirectoryRow; detail: ParsedGameDetail } }).originalEvidence ?? evidence.get(gameId);
    if (!original || Date.now() - original.detail.observedAt > 15 * 60_000) return null;
    logger.warn({ gameId }, "[GLOBAL-SPIKE] Enrichment timed out; sending original evidence");
    return buildCard(gameId, tx, original.row, original.detail);
  };
  return boundedEnrichment(refreshCard(gameId, tx), fallback,
    positiveInteger(process.env["EXCAPPER_ENRICHMENT_TIMEOUT_MS"], 30_000));
}

async function handleNewBet(gameId: string, tx: ExcapperTransaction): Promise<boolean> {
  if (!active || controller?.signal.aborted || tx.sourceType === "prematch") return false;
  // Persist raw bet before the Excapper high-water may move. Failed context
  // builds and transport results remain retryable in the durable outbox.
  const admitted = await admitGlobalSpike(gameId, Object.assign({}, tx, { originalEvidence: evidence.get(gameId) }));
  if (admitted && !getControls().alertsMuted) {
    void drainGlobalSpikeOutbox(buildFreshCard).catch((err: unknown) =>
      logger.error({ err }, "[GLOBAL-SPIKE] Outbox drain failed"));
  }
  return admitted;
}

/** An entire cycle is sequential and bounded; manual hydration shares both caches. */
export async function runGlobalLiveSpikeCycle(): Promise<void> {
  if (!active || busy || !isTelegramConfigured()) return;
  busy = true;
  recordExcapperPollStart();
  try {
    const signal = controller!.signal;
    if (isExcapperBreakerOpen() || signal.aborted) return;
    await drainGlobalSpikeOutbox(buildFreshCard);
    const rows = await directory(signal);
    const cap = Math.min(positiveInteger(process.env["EXCAPPER_GLOBAL_SPIKE_CAP"], DEFAULT_CAP), 16);
    let inspected = 0;
    for (let i = 0; i < Math.min(cap, rows.length); i++) {
      if (signal.aborted || isExcapperBreakerOpen()) break;
      const row = rows[(cursor + i) % rows.length]!;
      try {
        const detail = await loadParsedGameDetail(row.gameId, signal, "live");
        if (signal.aborted) break;
        prebet.observeDetail(row.gameId, detail);
        evidence.set(row.gameId, { row, detail });
        while (evidence.size > 500) evidence.delete(evidence.keys().next().value!);
        // Binding is optional; a stalled persistence/enrichment path cannot block money.
        void boundedEnrichment(
          bindAutomaticExcapperRows(rows.map((item) => item.gameId === row.gameId ? { ...row, ...detail.live } : item), detail.observedAt).catch((err) =>
            logger.warn({ err, gameId: row.gameId }, "[GLOBAL-SPIKE] Binding unavailable")),
          () => undefined, positiveInteger(process.env["EXCAPPER_ENRICHMENT_TIMEOUT_MS"], 30_000));
        // The listener receives newly admitted bets synchronously, including
        // bets first observed by the manual binding path in between cycles.
        processTransactions(`excapper:${row.gameId}`, row.gameId, detail.transactions, row.league);
        inspected++;
      } catch (err) {
        if (!signal.aborted) logger.warn({ err, gameId: row.gameId }, "[GLOBAL-SPIKE] Detail unavailable");
        if (isExcapperBreakerOpen()) break;
      }
      if (i + 1 < Math.min(cap, rows.length) && !signal.aborted && !isExcapperBreakerOpen()) {
        await new Promise<void>((resolve) => {
          const onAbort = () => { clearTimeout(timeout); resolve(); };
          const timeout = setTimeout(() => {
            signal.removeEventListener("abort", onAbort);
            resolve();
          }, 250 + Math.floor(Math.random() * 500));
          signal.addEventListener("abort", onAbort, { once: true });
        });
      }
    }
    if (rows.length) cursor = (cursor + Math.min(cap, rows.length)) % rows.length;
    logger.info({ eligible: rows.length, inspected, cap }, "[GLOBAL-SPIKE] Cycle complete");
  } catch (err) {
    if (!controller?.signal.aborted) logger.warn({ err }, "[GLOBAL-SPIKE] Cycle failed");
  } finally {
    recordExcapperPollComplete();
    busy = false;
  }
}

function schedule(): void {
  if (!active) return;
  const interval = positiveInteger(process.env["EXCAPPER_GLOBAL_SPIKE_INTERVAL_MS"], DEFAULT_INTERVAL_MS);
  timer = setTimeout(() => { void runGlobalLiveSpikeCycle().finally(schedule); }, interval);
  timer.unref?.();
}

export function startGlobalLiveSpikeWatch(): void {
  if (active || !isTelegramConfigured()) return;
  active = true;
  setExcapperDiagnosticsActive(true);
  controller = new AbortController();
  setNewExcapperTransactionListener(({ gameId, tx }) => handleNewBet(gameId, tx));
  logger.info({
    intervalMs: positiveInteger(process.env["EXCAPPER_GLOBAL_SPIKE_INTERVAL_MS"], DEFAULT_INTERVAL_MS),
    cap: Math.min(positiveInteger(process.env["EXCAPPER_GLOBAL_SPIKE_CAP"], DEFAULT_CAP), 16),
  }, "[GLOBAL-SPIKE] Watch enabled");
  void runGlobalLiveSpikeCycle().finally(schedule);
}

export function stopGlobalLiveSpikeWatch(): void {
  active = false;
  setExcapperDiagnosticsActive(false);
  controller?.abort();
  controller = null;
  if (timer) clearTimeout(timer);
  timer = null;
  setNewExcapperTransactionListener(null);
  currentRows.clear();
  prebet.clear();
  evidence.clear();
  directoryFresh = false;
}