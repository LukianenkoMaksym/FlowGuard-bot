import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  approveManualLeagueAlias,
  __testOnlyInstallManualLeagueAlias,
  __testOnlyResetManualLeagueAliases,
  __testOnlySetManualLeagueAliasStorage,
  initManualLeagueAliases,
  manualLeagueAliasMatches,
} from "./manualLeagueAliases";

describe("manual league aliases", () => {
  beforeEach(() => __testOnlyResetManualLeagueAliases());
  afterEach(() => __testOnlySetManualLeagueAliasStorage());

  it("matches persisted canonical pairs reciprocally", () => {
    __testOnlyInstallManualLeagueAlias(
      "São Paulo Regional League",
      "Sao-Paulo Regional  League",
    );
    expect(manualLeagueAliasMatches(
      "SAO PAULO REGIONAL LEAGUE",
      "Sao-Paulo Regional League",
    )).toBe(false);

    __testOnlyInstallManualLeagueAlias("NowGoal Competition", "Excapper Division");
    expect(manualLeagueAliasMatches("NowGoal Competition", "Excapper Division")).toBe(true);
    expect(manualLeagueAliasMatches("Excapper Division", "NowGoal Competition")).toBe(true);
  });

  it("does not grant unrelated leagues", () => {
    __testOnlyInstallManualLeagueAlias("League A", "League B");
    expect(manualLeagueAliasMatches("League A", "League C")).toBe(false);
  });

  it("reloads persisted reciprocal aliases into a fresh matcher cache", async () => {
    const rows: Array<{ left: string; right: string }> = [];
    const insert = vi.fn(async (values: {
      canonicalLeft: string;
      canonicalRight: string;
    }) => {
      if (rows.some((row) =>
        row.left === values.canonicalLeft && row.right === values.canonicalRight
      )) return false;
      rows.push({ left: values.canonicalLeft, right: values.canonicalRight });
      return true;
    });
    __testOnlySetManualLeagueAliasStorage({
      ensure: async () => undefined,
      load: async () => [...rows],
      insert,
    });
    await initManualLeagueAliases();
    expect(manualLeagueAliasMatches("Brazil Campeonato Paraibano 2", "Brazilian Paraibano Matches")).toBe(true);
    expect(manualLeagueAliasMatches("Brazil Campeonato Paraibano", "Brazilian Paraibano Matches")).toBe(false);
    await expect(approveManualLeagueAlias("NowGoal Cup", "Excapper Trophy"))
      .resolves.toMatchObject({ created: true });
    await expect(approveManualLeagueAlias("Excapper Trophy", "NowGoal Cup"))
      .resolves.toMatchObject({ created: false });

    __testOnlyResetManualLeagueAliases();
    expect(manualLeagueAliasMatches("NowGoal Cup", "Excapper Trophy")).toBe(false);
    await initManualLeagueAliases();
    expect(rows.filter((row) => row.left === "brazil campeonato paraibano 2")).toHaveLength(1);
    expect(manualLeagueAliasMatches("NowGoal Cup", "Excapper Trophy")).toBe(true);
    expect(manualLeagueAliasMatches("Excapper Trophy", "NowGoal Cup")).toBe(true);
  });
});