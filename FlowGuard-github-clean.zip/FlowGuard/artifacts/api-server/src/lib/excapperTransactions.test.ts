import { beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
const audit = vi.hoisted(() => vi.fn());
const manualBindings = vi.hoisted(() => ({
  get: vi.fn(() => [] as Array<Record<string, unknown>>),
  save: vi.fn(async () => undefined),
  init: vi.fn(async () => [] as Array<Record<string, unknown>>),
}));
vi.mock("./bindingDecisionAudit", async (importOriginal) => ({
  ...await importOriginal<typeof import("./bindingDecisionAudit")>(),
  recordBindingDecision: audit,
}));
vi.mock("./manualBindingsStore", () => ({
  manualBindingsUseTestFile: () => true,
  forgetPersistedManualBinding: vi.fn(),
  getPersistedManualBindings: manualBindings.get,
  initManualBindingsStore: manualBindings.init,
  removePersistedManualBinding: vi.fn(async () => undefined),
  savePersistedManualBinding: manualBindings.save,
}));

const {
  fetchExcapperText,
  fetchSharedExcapperGamePage,
  getExcapperResponseObservedAt,
  queueManualWatchlistVolumeDigest,
} = vi.hoisted(() => ({
  fetchExcapperText: vi.fn(),
  fetchSharedExcapperGamePage: vi.fn(
    async (_gameId: string, loader: () => Promise<string>) => loader(),
  ),
  getExcapperResponseObservedAt: vi.fn(() => Date.now()),
  queueManualWatchlistVolumeDigest: vi.fn(async (_observations: unknown[]) => undefined),
}));

vi.mock("./scanner", () => ({
  refreshManualBindingEvidence: vi.fn(async (ids: string[]) => new Set(ids)),
  getAutomaticExcapperCandidates: vi.fn(() => []),
  getWatchlistMatchesForVolume: vi.fn(() => []),
  getManualWatchlistMatchesForExcapper: vi.fn(() => []),
  hydrateManualMatchVolume: vi.fn(() => false),
  canHydrateManualMatchVolume: vi.fn(() => true),
  clearManualMatchVolumeBinding: vi.fn(() => false),
  hasManualExcapperHydrationMembership: vi.fn(() => false),
  installManualHydrationDiagnosticFixture: vi.fn(),
  getManualVolumeAlertContext: vi.fn(() => null),
  setMatchVolume: vi.fn(),
  findMatchIdByTeams: vi.fn(),
  getExcapperPromotionOddsEvidence: vi.fn(),
  dispatchQualifiedExcapperPromotionAlert: vi.fn(),
  installExcapperDiagnosticFixture: vi.fn(),
}));

vi.mock("./excapperSharedFetch", () => ({
  fetchExcapperText,
  fetchSharedExcapperGamePage,
  getExcapperResponseObservedAt,
}));

vi.mock("./manualWatchlistVolumeAlerts", () => ({
  queueManualWatchlistVolumeDigest,
}));

import {
  parseDirectory,
  parseGamePage,
  parseLiveObservation,
  parseObservedLiveMinute,
  isRecognizedEmptyTransactionTab,
  resolveManualExcapperBindings,
  classifyManualExcapperBindings,
  getExcapperBindingDiagnostic,
  withExcapperBindingDiagnostics,
  __testOnlyRecordExcapperBindingDiagnostic,
  __testOnlyRecordManualCandidateDiagnostic,
  __testOnlyResetExcapperBindingDiagnostics,
  manualBindingConfidence,
  secondaryFuzzyIdentityScore,
  normalizedTeamName,
  requestManualExcapperHydration,
  releaseManualExcapperBinding,
  __testOnlyGetManualExcapperBindingCache,
  __testOnlyResetManualExcapperBindingCache,
  initManualExcapperBindingBlocks,
  __testOnlySetBindingBlockDependencies,
  processTransactions,
  __testOnlyTransactionWatermarks,
  setNewExcapperTransactionListener,
  parseGameTransactions,
  loadParsedGameDetail,
  bindAutomaticExcapperRows,
  getVerifiedExcapperBinding,
  forceManualExcapperBinding,
} from "./excapper";
import {
  __testOnlyInstallManualLeagueAlias,
  __testOnlyResetManualLeagueAliases,
} from "./manualLeagueAliases";
import {
  clearManualMatchVolumeBinding,
  getManualWatchlistMatchesForExcapper,
  hydrateManualMatchVolume,
  getAutomaticExcapperCandidates,
} from "./scanner";
import { formatUnifiedAlert } from "./unifiedAlert";
import { __testOnlyMigrateVolumeConfig } from "./volumeConfig";
import { __testOnlyResetExcapperBatchCache } from "./excapperBatch";
import { forceManualVerifiedIds } from "./excapperBindingRuntime";

describe("global automatic base binding runtime", () => {
  it("persists and exposes control 3071680 despite differing league/country evidence", async () => {
    const kickoffMs = new Date(2026, 8, 24, 23, 30).getTime();
    vi.mocked(getAutomaticExcapperCandidates).mockReturnValue([{
      matchId: "3071680", team1: "Independiente Juniors", team2: "Vinotinto Ecuador",
      league: "Ecuador Serie B", countryCode: "EC", kickoffMs,
      state: 3, homeScore: 1, awayScore: 0, nowGoalLine: null,
    } as ReturnType<typeof getAutomaticExcapperCandidates>[number]]);
    manualBindings.get.mockReturnValue([]);
    await bindAutomaticExcapperRows([{
      gameId: "runtime-control-3071680", team1: "CD Independiente Juniors",
      team2: "Vinotinto de Ecuador", league: "Different source league", countryCode: "GB",
      kickoffText: "24.09.2026 23:30", totalVolume: 1000, isLive: true, activity: "live",
      liveScore: { home: 1, away: 0 }, livePeriod: "second-half",
    }], kickoffMs + 3600_000);
    expect(manualBindings.save).toHaveBeenCalledWith(expect.objectContaining({
      nowgoalId: "3071680", excapperId: "runtime-control-3071680", autoBound: true,
    }), undefined);
    expect(audit).toHaveBeenCalledWith("3071680", expect.anything());
    expect(getVerifiedExcapperBinding("runtime-control-3071680")?.matchId).toBe("3071680");
    releaseManualExcapperBinding("3071680");
    vi.mocked(getAutomaticExcapperCandidates).mockReturnValue([]);
  });
});

describe("safe sequential full-detail fixture hydration", () => {
  const candidate = {
    matchId: "700001",
    team1: "Alpha FC",
    team2: "Beta FC",
    league: "Verified League",
    nowGoalLine: 2.5,
    state: 3,
    homeScore: 1,
    awayScore: 0,
  };
  const directoryHtml = `
    <div id="live"><table><tr class="a_link" game_id="9001">
      <td>20:00</td><td title="FI">FI</td><td>Verified League</td>
      <td>Alpha FC - Beta FC</td><td>1 500 €</td>
    </tr></table></div>`;
  const confirmedPage = (score = "1-0", minute = 60) => `
    <div class="matchinfo"><h1>Alpha FC - Beta FC</h1><font class="score live">${minute}'</font></div>
    <a href="#tab_content_1">Over/Under 2.5 Goals</a>
    <div id="tab_content_1" class="tab-content">
      <div class="charts-bk__item-title">Over</div>
      <div class="charts-bk__item-coef">1 000 € - 1.91</div>
      <div class="charts-bk__item-title">Under</div>
      <div class="charts-bk__item-coef">500 € - 2.02</div>
      <table><tr><td>live</td><td>20:30 20.09</td><td>Over</td>
        <td>1 000 €</td><td>10 €</td><td>${minute}</td><td>${score}</td></tr></table>
    </div></body>`;

  beforeEach(() => {
    __testOnlyResetExcapperBatchCache();
    __testOnlyResetManualExcapperBindingCache();
    audit.mockReset();
    manualBindings.get.mockReset();
    manualBindings.get.mockReturnValue([]);
    manualBindings.save.mockReset();
    manualBindings.save.mockResolvedValue(undefined);
    manualBindings.init.mockReset();
    manualBindings.init.mockResolvedValue([]);
    fetchExcapperText.mockReset();
    fetchSharedExcapperGamePage.mockClear();
    getExcapperResponseObservedAt.mockClear();
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([candidate]);
    (hydrateManualMatchVolume as ReturnType<typeof vi.fn>).mockReset();
    (hydrateManualMatchVolume as ReturnType<typeof vi.fn>).mockReturnValue(true);
    (clearManualMatchVolumeBinding as ReturnType<typeof vi.fn>).mockClear();
    queueManualWatchlistVolumeDigest.mockClear();
  });

  const batchEvent = (overrides: Record<string, unknown> = {}) => ({
    gameId: "9001",
    homeTeam: "Alpha FC",
    awayTeam: "Beta FC",
    league: "Verified League",
    status: "live",
    score: "1-0",
    period: "second-half",
    elapsed: 60,
    markets: [{ line: 2.5, over: 1000, under: 500 }],
    ...overrides,
  });
  const batchPayload = (...events: Array<Record<string, unknown>>) =>
    JSON.stringify({ events });

  it("hydrates a confirmed numeric operator pair without kickoff or period evidence", async () => {
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([{ ...candidate, kickoffMs: null, state: null,
        homeScore: 0, awayScore: 0 }]);
    await forceManualExcapperBinding({
      nowgoalId: "700001", excapperId: "9001", signature: "id:700001",
      source: { team1: "Alpha FC", team2: "Beta FC", league: "Verified League" },
    });
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage("1-0", 60) : directoryHtml);
    await requestManualExcapperHydration(["700001"]);
    expect(manualBindings.save).toHaveBeenCalledWith(expect.objectContaining({
      nowgoalId: "700001", excapperId: "9001", autoBound: false,
    }), undefined, "700001", false);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: "700001", gameId: "9001", bindingMode: "manual_override" }),
    ]);
    expect(hydrateManualMatchVolume).toHaveBeenCalledWith("700001",
      expect.arrayContaining([expect.objectContaining({ line: 2.5, over: 1000, under: 500 })]), "9001");
    expect(getExcapperBindingDiagnostic("700001")).toMatchObject({
      status: "hydrated", candidateExcapperId: "9001",
      bindingDecision: { status: "manual", chosenId: "9001" },
    });
  });

  it("uses one root directory and sequential full-detail requests for plausible bindings", async () => {
    const second = {
      ...candidate, matchId: "700002", team1: "Gamma FC", team2: "Delta FC",
    };
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([candidate, second]);
    const directory = directoryHtml.replace("</table>", `
      <tr class="a_link" game_id="9002"><td>20:00</td><td title="FI">FI</td>
      <td>Verified League</td><td>Gamma FC - Delta FC</td><td>900 €</td></tr></table>`);
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directory);

    await requestManualExcapperHydration(["700001", "700002"]);

    expect(fetchExcapperText).toHaveBeenCalledTimes(3);
    expect(fetchExcapperText.mock.calls.filter(([url]) =>
      String(url).includes("action=game"))).toHaveLength(2);
    expect(getExcapperResponseObservedAt).toHaveBeenCalledWith(
      "https://www.excapper.com/?action=game&id=9001",
    );
    expect(getExcapperResponseObservedAt).toHaveBeenCalledWith(
      "https://www.excapper.com/?action=game&id=9002",
    );
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(2);
    expect(hydrateManualMatchVolume).toHaveBeenCalledTimes(2);
    expect(queueManualWatchlistVolumeDigest).toHaveBeenCalledOnce();
    expect(queueManualWatchlistVolumeDigest.mock.calls[0]![0]).toHaveLength(4);
  });

  it.each([{ homeScore: null }, { awayScore: null }, { state: null }])(
    "does not let legacy missing-kickoff discovery bypass missing live evidence: %j",
    async (missing) => {
      (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
        .mockReturnValue([{ ...candidate, ...missing }]);
      fetchExcapperText.mockImplementation(async (url: string) =>
        url.includes("action=game") ? confirmedPage() : directoryHtml);
      await requestManualExcapperHydration(["700001"]);
      expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
      expect(manualBindings.save).not.toHaveBeenCalled();
      expect(getExcapperBindingDiagnostic("700001").bindingDecision).toMatchObject({
        status: "unbound", chosenId: null,
      });
    },
  );

  it("auto-binds and durably persists a verified automatic binding", async () => {
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directoryHtml);
    await requestManualExcapperHydration(["700001"]);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: "700001", gameId: "9001", confidence: 1 }),
    ]);
    expect(audit.mock.calls[0]?.[1]).toMatchObject({ action: "bind", mode: "automatic" });
    expect(getExcapperBindingDiagnostic("700001").bindingDecision).toMatchObject({
      status: "bound", chosenId: "9001", candidateCount: 1,
      scored: [expect.objectContaining({ home: 1, away: 1, delta: null,
        gates: { teams: true, kickoff: true, scorePeriod: true, conflict: false } })],
    });
    expect(manualBindings.save).toHaveBeenCalledWith(expect.objectContaining({
      nowgoalId: "700001",
      excapperId: "9001",
      status: "Verified",
      autoBound: true,
    }), undefined, "700001");
  });

  it("resolves an operator placeholder using a rendered detail clock instead of a commented one", async () => {
    const placeholder = {
      nowgoalId: "700001",
      excapperId: "FORCE_MANUAL",
      boundAt: "2026-09-22T12:00:00.000Z",
      status: "Verified",
      autoBound: false,
      signature: "id:700001",
      source: { team1: "Alpha FC", team2: "Beta FC", league: "Verified League" },
    };
    forceManualVerifiedIds.add("700001");
    manualBindings.get.mockReturnValue([placeholder]);
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game")
        ? `<div class="matchinfo" style="padding:10px;display:none"><h3>ValueBetsAI</h3></div>
           <div class="matchinfo"><h1>Alpha FC - Beta FC</h1><!-- time <font class="score live">57'</font>--></div>${confirmedPage("1-0", 60)}`
        : directoryHtml);

    await requestManualExcapperHydration(["700001"]);

    expect(fetchExcapperText.mock.calls.some(([url]) =>
      String(url).includes("FORCE_MANUAL"))).toBe(false);
    expect(manualBindings.save).toHaveBeenCalledWith(expect.objectContaining({
      nowgoalId: "700001",
      excapperId: "9001",
      autoBound: false,
      signature: "id:700001",
    }), undefined, "700001");
    expect(audit.mock.calls[0]?.[1]).toMatchObject({
      action: "bind",
      mode: "manual_override",
    });
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: "700001", gameId: "9001" }),
    ]);
    expect(forceManualVerifiedIds.has("700001")).toBe(false);
    expect(hydrateManualMatchVolume).toHaveBeenCalledOnce();
    expect(getExcapperBindingDiagnostic("700001").source?.minute).toBe(60);
  });

  it("keeps an ambiguous operator placeholder unresolved", async () => {
    forceManualVerifiedIds.add("700001");
    manualBindings.get.mockReturnValue([{
      nowgoalId: "700001",
      excapperId: "FORCE_MANUAL",
      boundAt: "2026-09-22T12:00:00.000Z",
      status: "Verified",
      autoBound: false,
      source: { team1: "Alpha FC", team2: "Beta FC", league: "Verified League" },
    }]);
    const ambiguousDirectory = directoryHtml.replace("</table>", `
      <tr class="a_link" game_id="9002"><td>20:00</td><td title="FI">FI</td>
        <td>Verified League</td><td>Alpha FC - Beta FC</td><td>900 €</td>
      </tr></table>`);
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : ambiguousDirectory);

    await requestManualExcapperHydration(["700001"]);

    expect(manualBindings.save).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(0);
    expect(forceManualVerifiedIds.has("700001")).toBe(true);
    expect(getExcapperBindingDiagnostic("700001")).toMatchObject({
      status: "identity_only", bindingDecision: { status: "manual", chosenId: null },
    });
    expect(hydrateManualMatchVolume).not.toHaveBeenCalled();
  });

  it("retains last-good score when a later full-detail request fails", async () => {
    fetchExcapperText
      .mockResolvedValueOnce(directoryHtml)
      .mockResolvedValueOnce(confirmedPage())
      .mockResolvedValueOnce(confirmedPage("2-0", 72));
    await requestManualExcapperHydration(["700001"]);
    vi.useFakeTimers();
    vi.setSystemTime(Date.now() + 13_000);
    const second = requestManualExcapperHydration(["700001"]);
    await vi.runAllTimersAsync();
    await second;
    const diagnosticBefore = getExcapperBindingDiagnostic("700001");
    expect(diagnosticBefore.source?.score).toEqual({ home: 2, away: 0 });
    const writesBefore = (hydrateManualMatchVolume as ReturnType<typeof vi.fn>).mock.calls.length;
    vi.setSystemTime(Date.now() + 13_000);
    fetchExcapperText.mockRejectedValueOnce(new Error("HTTP 503"));
    const refresh = requestManualExcapperHydration(["700001"]);
    await vi.runAllTimersAsync();
    await refresh;
    vi.useRealTimers();
    expect(hydrateManualMatchVolume).toHaveBeenCalledTimes(writesBefore);
    expect(getExcapperBindingDiagnostic("700001").source?.score)
      .toEqual(diagnosticBefore.source?.score);
    expect(getExcapperBindingDiagnostic("700001").lastSuccessfulUpdateAt)
      .toBe(diagnosticBefore.lastSuccessfulUpdateAt);
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(1);
  });

  it("does not bind identity-only or incomplete root evidence", async () => {
    fetchExcapperText.mockResolvedValue(directoryHtml);
    await requestManualExcapperHydration(["700001"]);
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(0);
    expect(hydrateManualMatchVolume).not.toHaveBeenCalled();
  });

  it("does not emit or hydrate twice from one cached parsed observation", async () => {
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directoryHtml);
    await requestManualExcapperHydration(["700001"]);
    const writes = (hydrateManualMatchVolume as ReturnType<typeof vi.fn>).mock.calls.length;
    const digests = queueManualWatchlistVolumeDigest.mock.calls.length;
    await requestManualExcapperHydration(["700001"]);
    expect(fetchExcapperText).toHaveBeenCalledTimes(2);
    expect(hydrateManualMatchVolume).toHaveBeenCalledTimes(writes);
    expect(queueManualWatchlistVolumeDigest).toHaveBeenCalledTimes(digests);
  });

  it("does not bind when the fixture is removed while the one root request is awaited", async () => {
    let resolveDeferred!: (payload: string) => void;
    const deferred = new Promise<string>((resolve) => {
      resolveDeferred = resolve;
    });
    fetchExcapperText.mockReturnValue(deferred);

    const hydration = requestManualExcapperHydration(["700001"]);
    await vi.waitFor(() => expect(fetchExcapperText).toHaveBeenCalledOnce());
    releaseManualExcapperBinding("700001");
    resolveDeferred(batchPayload(batchEvent()));
    await hydration;

    expect(fetchExcapperText.mock.calls[0]![0]).not.toContain("action=game");
    expect(hydrateManualMatchVolume).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(0);
  });

  it("coalesces concurrent callers and lets removal win while detail is awaited", async () => {
    let resolveDetail!: (payload: string) => void;
    const deferredDetail = new Promise<string>((resolve) => {
      resolveDetail = resolve;
    });
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? deferredDetail : directoryHtml);

    const first = requestManualExcapperHydration(["700001"]);
    const second = requestManualExcapperHydration(["700001"]);
    expect(second).toBe(first);
    await vi.waitFor(() => expect(fetchExcapperText).toHaveBeenCalledTimes(2));
    releaseManualExcapperBinding("700001");
    resolveDetail(confirmedPage());
    await Promise.all([first, second]);

    expect(fetchSharedExcapperGamePage).toHaveBeenCalledOnce();
    expect(hydrateManualMatchVolume).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(0);
  });

  it("uses the secondary BuxDU alias only when the item has zero primary rows", async () => {
    const buxoro = {
      ...candidate,
      team1: "Buxoro University",
      team2: "Turan FC",
    };
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([buxoro]);
    const directory = `
      <div id="live"><table><tr class="a_link" game_id="9101">
        <td>20:00</td><td title="UZ">UZ</td><td>Verified League</td>
        <td>BuxDU - Turan</td><td>1 500 €</td>
      </tr></table></div>`;
    expect(secondaryFuzzyIdentityScore(buxoro, {
      team1: "BuxDU", team2: "Turan", league: "Verified League",
    })).toBeGreaterThan(0.9);
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directory);

    await requestManualExcapperHydration(["700001"]);

    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: "700001", gameId: "9101" }),
    ]);
    expect(fetchExcapperText).toHaveBeenCalledTimes(2);
    expect(audit.mock.calls[0]?.[1]?.reason).toContain("weighted secondary");
  });

  it("supports Cyrillic transliteration and suffix stripping in secondary discovery", async () => {
    const transliterated = {
      ...candidate,
      team1: "Бухоро Университет U21",
      team2: "Туран U21",
    };
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([transliterated]);
    const directory = `
      <div id="live"><table><tr class="a_link" game_id="9102">
        <td>20:00</td><td title="UZ">UZ</td><td>Verified League</td>
        <td>Bukhoro University U21 - Turan U21 FC</td><td>1 500 €</td>
      </tr></table></div>`;
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directory);

    await requestManualExcapperHydration(["700001"]);

    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ gameId: "9102" }),
    ]);
  });

  it("supports the controlled Fergana and Fardu Ferghana family alias", () => {
    expect(secondaryFuzzyIdentityScore(
      { team1: "Fergana University", team2: "Turan FK", league: "UZ League" },
      { team1: "Fardu Ferghana", team2: "Turan", league: "UZ League" },
    )).toBeGreaterThanOrEqual(0.9);
  });

  it("accepts a three-minute clock tolerance but rejects a four-minute conflict", async () => {
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([{ ...candidate, team1: "Buxoro University", liveMinute: 60 }]);
    const directory = `
      <div id="live"><table><tr class="a_link" game_id="9150">
        <td>20:00</td><td title="UZ">UZ</td><td>Verified League</td>
        <td>BuxDU - Beta</td><td>1 500 €</td>
      </tr></table></div>`;
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage("1-0", 63) : directory);
    await requestManualExcapperHydration(["700001"]);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ gameId: "9150" }),
    ]);

    __testOnlyResetExcapperBatchCache();
    __testOnlyResetManualExcapperBindingCache();
    fetchExcapperText.mockClear();
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage("1-0", 64) : directory);
    await requestManualExcapperHydration(["700001"]);
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(0);
  });

  it("rejects an explicit GB versus UZ country conflict despite matching teams and live state", async () => {
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([{ ...candidate, countryCode: "GB", liveMinute: 60 }]);
    const directory = directoryHtml.replace(
      '<td title="FI">FI</td>',
      '<td><img alt="UZ"></td>',
    );
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directory);
    await requestManualExcapperHydration(["700001"]);
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(0);
  });

  it("treats ENG and GB as compatible explicit country abbreviations", async () => {
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([{ ...candidate, countryCode: "GB", liveMinute: 60 }]);
    const directory = directoryHtml.replace(
      '<td title="FI">FI</td>',
      '<td><img alt="ENG"></td>',
    );
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directory);
    await requestManualExcapperHydration(["700001"]);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ gameId: "9001" }),
    ]);
  });

  it("allows unknown country to contribute zero when other anchors exceed 0.50", async () => {
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([{ ...candidate, countryCode: null, liveMinute: 60 }]);
    const directory = directoryHtml.replace(
      '<td title="FI">FI</td>',
      "<td>Unknown</td>",
    );
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directory);
    await requestManualExcapperHydration(["700001"]);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ gameId: "9001" }),
    ]);
  });

  it("reloads a persisted numeric automatic binding as automatic", async () => {
    manualBindings.init.mockResolvedValue([{
      nowgoalId: "700001",
      excapperId: "9001",
      boundAt: "2026-09-22T12:00:00.000Z",
      status: "Verified",
      autoBound: true,
      source: { team1: "Alpha FC", team2: "Beta FC", league: "Verified League" },
    }]);
    __testOnlySetBindingBlockDependencies({ load: async () => [] });
    await initManualExcapperBindingBlocks();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({
        matchId: "700001",
        gameId: "9001",
        bindingMode: "automatic",
      }),
    ]);
    __testOnlySetBindingBlockDependencies();
  });

  it("keeps evaluating hybrid candidates when a primary row conflicts", async () => {
    const directory = `
      <div id="live"><table>
        <tr class="a_link" game_id="9201"><td>20:00</td><td title="FI">FI</td>
          <td>Verified League</td><td>Alpha FC - Beta FC</td><td>1 500 €</td></tr>
        <tr class="a_link" game_id="9202"><td>20:00</td><td title="FI">FI</td>
          <td>Verified League</td><td>Alphaa - Betaa</td><td>900 €</td></tr>
      </table></div>`;
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("id=9201") ? confirmedPage("0-0", 60) :
      url.includes("id=9202") ? confirmedPage() :
      directory);

    await requestManualExcapperHydration(["700001"]);

    expect(fetchExcapperText.mock.calls.some(([url]) =>
      String(url).includes("id=9202"))).toBe(true);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ gameId: "9202" }),
    ]);
  });

  it.each([
    {
      label: "score mismatch",
      candidate: { ...candidate, team1: "Buxoro University", team2: "Turan FC" },
      league: "Verified League",
      teams: "BuxDU - Turan",
      detail: confirmedPage("0-0", 60),
      expectedDetailRequests: 1,
    },
    {
      label: "different league label is absent evidence, not a conflict",
      candidate: { ...candidate, team1: "Buxoro University", team2: "Turan FC" },
      league: "Other League",
      teams: "BuxDU - Turan",
      detail: confirmedPage(),
      expectedDetailRequests: 1,
      expectedBindings: 1,
    },
    {
      label: "U21 suffix is normalized as directed",
      candidate: { ...candidate, team1: "Alpha U21", team2: "Beta U21" },
      league: "Verified League",
      teams: "Alpha FC - Beta FC",
      detail: confirmedPage(),
      expectedDetailRequests: 1,
      expectedBindings: 1,
    },
  ])("evaluates hybrid evidence: $label", async ({
    candidate: unsafeCandidate,
    league,
    teams,
    detail,
    expectedDetailRequests,
    expectedBindings = 0,
  }) => {
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([unsafeCandidate]);
    const directory = `
      <div id="live"><table><tr class="a_link" game_id="9301">
        <td>20:00</td><td title="FI">FI</td><td>${league}</td>
        <td>${teams}</td><td>1 500 €</td>
      </tr></table></div>`;
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? detail : directory);

    await requestManualExcapperHydration(["700001"]);

    expect(fetchExcapperText.mock.calls.filter(([url]) =>
      String(url).includes("action=game"))).toHaveLength(expectedDetailRequests);
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(expectedBindings);
  });

  it("rejects an ambiguous secondary pair instead of selecting by directory order", async () => {
    const buxoro = {
      ...candidate,
      team1: "Buxoro University",
      team2: "Turan FC",
    };
    (getManualWatchlistMatchesForExcapper as ReturnType<typeof vi.fn>)
      .mockReturnValue([buxoro]);
    const directory = `
      <div id="live"><table>
        <tr class="a_link" game_id="9401"><td>20:00</td><td title="UZ">UZ</td>
          <td>Verified League</td><td>BuxDU - Turan</td><td>1 500 €</td></tr>
        <tr class="a_link" game_id="9402"><td>20:00</td><td title="UZ">UZ</td>
          <td>Verified League</td><td>BukhDU - Turan FC</td><td>1 400 €</td></tr>
      </table></div>`;
    fetchExcapperText.mockImplementation(async (url: string) =>
      url.includes("action=game") ? confirmedPage() : directory);

    await requestManualExcapperHydration(["700001"]);

    expect(fetchExcapperText.mock.calls.filter(([url]) =>
      String(url).includes("action=game"))).toHaveLength(2);
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(0);
  });
});

describe("Excapper empty transaction tabs", () => {
  const row = (market: string, summ: string, change: string) => `
    <tr>
      <td>premach</td><td>17:18 20.09</td><td>${market}</td>
      <td>${summ}</td><td>${change}</td><td></td><td></td>
      <td></td><td></td><td>-</td><td>-</td>
    </tr>`;

  it("recognizes live Excapper blank zero rows as an empty market", () => {
    const liveEmptyShape = `
      <table><tbody>${row("", "0", "0€ / 0%")}</tbody>
      <tbody>${row("", "0", "0€ / 0%")}</tbody></table>`;
    expect(isRecognizedEmptyTransactionTab(liveEmptyShape)).toBe(true);
  });

  it("does not suppress drift for unknown labels or non-zero blank-market money", () => {
    expect(
      isRecognizedEmptyTransactionTab(`<table>${row("Above", "10€", "10€ / 100%")}</table>`),
    ).toBe(false);
    expect(
      isRecognizedEmptyTransactionTab(`<table>${row("", "10€", "0€ / 0%")}</table>`),
    ).toBe(false);
    expect(
      isRecognizedEmptyTransactionTab(`<table>${row("", "0", "not-a-change")}</table>`),
    ).toBe(false);
    expect(isRecognizedEmptyTransactionTab("<div>no transaction rows</div>")).toBe(false);
  });
});

describe("Excapper native EUR contract", () => {
  it("retains a failed admission below later bets and retries in cumulative order", async () => {
    const gameId = "retry-admission-2026";
    const mk = (summ: number) => ({
      line: 2.5, side: "Over" as const, summ, change: 500,
      rawChange: "500 €", date: "", matchMinute: "56",
    });
    const listener = vi.fn().mockResolvedValueOnce(false).mockResolvedValue(true);
    setNewExcapperTransactionListener(listener);
    try {
      processTransactions(gameId, gameId, [mk(1000)], "Finland Kakkonen");
      processTransactions(gameId, gameId, [mk(1500), mk(2000)], "Finland Kakkonen");
      await vi.waitFor(() => expect(__testOnlyTransactionWatermarks().pending).toBe(0));
      expect(listener).toHaveBeenCalledTimes(1);
      processTransactions(gameId, gameId, [mk(1500), mk(2000)], "Finland Kakkonen");
      await vi.waitFor(() => expect(listener).toHaveBeenCalledTimes(3));
      expect(listener.mock.calls.map(([event]) => event.tx.summ)).toEqual([1500, 1500, 2000]);
    } finally {
      setNewExcapperTransactionListener(null);
    }
  });

  it("bounds seeded and high-water keys together under rotation", () => {
    const mk = { line: 2.5, side: "Over" as const, summ: 1000,
      change: 500, rawChange: "500 €", date: "", matchMinute: "56" };
    for (let i = 0; i < 5100; i++) {
      processTransactions("rotation", `cap-${i}`, [mk], "Finland Kakkonen");
    }
    expect(__testOnlyTransactionWatermarks()).toMatchObject({ size: 5000, seeded: 5000 });
  });

  it("does not evict an uncommitted key while rotating older baselines", async () => {
    const mk = (summ: number) => ({ line: 2.5, side: "Over" as const,
      summ, change: 500, rawChange: "500 €", date: "", matchMinute: "56" });
    let rejectAdmission!: (accepted: boolean) => void;
    const admission = new Promise<boolean>((resolve) => { rejectAdmission = resolve; });
    const listener = vi.fn().mockReturnValueOnce(admission).mockReturnValue(true);
    setNewExcapperTransactionListener(listener);
    try {
      processTransactions("rotation", "cap-5099", [mk(1500)], "Finland Kakkonen");
      expect(__testOnlyTransactionWatermarks().pending).toBe(1);
      for (let i = 5100; i < 5200; i++) {
        processTransactions("rotation", `cap-${i}`, [mk(1000)], "Finland Kakkonen");
      }
      expect(__testOnlyTransactionWatermarks()).toMatchObject({ size: 5000, seeded: 5000, pending: 1 });
      rejectAdmission(false);
      await vi.waitFor(() => expect(__testOnlyTransactionWatermarks().pending).toBe(0));
      processTransactions("rotation", "cap-5099", [mk(1500)], "Finland Kakkonen");
      expect(listener).toHaveBeenCalledTimes(2);
    } finally {
      setNewExcapperTransactionListener(null);
    }
  });

  it("shares the Summ high-water across manual/global callers and emits every new bet, not history", () => {
    const listener = vi.fn();
    setNewExcapperTransactionListener(listener);
    const mk = (summ: number, change: number) => ({
      line: 2.5, side: "Over" as const, summ, change, rawChange: `${change} €`,
      date: "", matchMinute: "56",
    });
    try {
      processTransactions("manual-nowgoal", "99112233", [mk(1000, 900)], "Finland Kakkonen");
      expect(listener).not.toHaveBeenCalled(); // first sight is historical seed
      processTransactions("manual-nowgoal", "99112233", [
        mk(1000, 900), mk(1499, 499), mk(1999, 500), mk(2600, 601),
      ], "Finland Kakkonen");
      expect(listener.mock.calls.map(([event]) => event.tx.change)).toEqual([500, 601]);
      processTransactions("excapper:99112233", "99112233", [
        mk(1000, 900), mk(1499, 499), mk(1999, 500), mk(2600, 601),
      ], "Finland Kakkonen");
      expect(listener).toHaveBeenCalledTimes(2);
      processTransactions("manual-nowgoal", "99112233", [mk(3200, 600)], "Other League");
      expect(listener).toHaveBeenCalledTimes(2);
    } finally {
      setNewExcapperTransactionListener(null);
    }
  });

  it("keeps all transaction rows from an authentic detail page rather than only maximum Summ", async () => {
    const page = `
      <a href="#tab_content_1">Over/Under 2.5 Goals</a>
      <div id="tab_content_1" class="tab-content">
        <div class="charts-bk__item-title">Over</div>
        <div class="charts-bk__item-coef">2 600 € - 1.80</div>
        <div class="charts-bk__item-title">Under</div>
        <div class="charts-bk__item-coef">600 € - 2.10</div>
        <table>${[[1000, 100], [1500, 500], [2100, 600], [2600, 500]].map(
          ([summ, change]) => `<tr><td>live</td><td>20:30 20.09</td><td>Over</td>
          <td>${summ} €</td><td>${change} €</td><td>56</td><td>1-0</td></tr>`,
        ).join("")}</table></div></body>`;
    expect(parseGameTransactions(page)).toHaveLength(4);
    fetchExcapperText.mockResolvedValueOnce(page);
    const parsed = await loadParsedGameDetail("9988112233", new AbortController().signal, "live");
    expect(parsed.transactions.map((item) => item.summ)).toEqual([2600, 2100, 1500, 1000]);
  });

  it("hydrates all nine OU lines and full live state when the detail page supplies them", () => {
    const tabs = Array.from({ length: 9 }, (_, index) => {
      const line = index + 0.5;
      return `
        <a href="#tab_content_${index}">Over/Under ${line} Goals</a>
        <div id="tab_content_${index}" class="tab-content">
          <div class="charts-bk__item-title">Over</div>
          <div class="charts-bk__item-coef">${1_000 + index} € - 1.91</div>
          <div class="charts-bk__item-title">Under</div>
          <div class="charts-bk__item-coef">${500 + index} € - 2.02</div>
          <table><tr><td>live</td><td>20:30 20.09</td><td>Over</td>
            <td>${1_000 + index} €</td><td>10 €</td><td>67</td><td>2-1</td></tr></table>
        </div>`;
    }).join("");

    const page = `${tabs}</body>`;
    const parsed = parseGamePage(page, 123_456);
    expect(parsed).toHaveLength(9);
    expect(parsed?.map((sample) => sample.line)).toEqual([
      0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5,
    ]);
    expect(parsed?.every((sample) =>
      sample.over > 0 &&
      sample.under > 0 &&
      sample.collectedAt === 123_456
    )).toBe(true);
    expect(parseLiveObservation(page)).toEqual({
      liveScore: { home: 2, away: 1 },
      livePeriod: null,
    });
  });

  it("ignores a disabled event clock and does not turn a transaction minute into current time", () => {
    const page = `<div class="matchinfo" style="padding:10px;display:none"><h3>ValueBetsAI</h3>
      <font class="score live">90'</font></div>
      <div class="matchinfo"><h1>AD Picuiense - AD Guarabira</h1>
      <!-- time <font class="score live">57'</font>--></div>
      <a href="#tab_content_1">Over/Under 2.5 Goals</a>
      <div id="tab_content_1" class="tab-content">
        <table><tr><td>live</td><td>23:20 24.09</td><td>Over</td>
        <td>100 €</td><td>10 €</td><td>45</td><td>0-2</td></tr></table>
      </div><div class="footer"></div>`;
    expect(parseLiveObservation(page)).toEqual({
      liveScore: { home: 0, away: 2 }, livePeriod: null,
    });
    expect(parseLiveObservation(page.replace("<!-- time <font class=\"score live\">57'</font>-->", "time <font class=\"score live\">57'</font>"))).toEqual({
      liveScore: { home: 0, away: 2 }, livePeriod: "second-half",
    });
  });

  it("retains transaction score but never promotes transaction 0/1 to current minute", async () => {
    const txPage = (clock: string) => `<div class="matchinfo"><h1>Alpha - Beta</h1>${clock}</div>
      <a href="#tab_content_1">Over/Under 2.5 Goals</a>
      <div id="tab_content_1" class="tab-content">
        <div class="charts-bk__item-title">Over</div>
        <div class="charts-bk__item-coef">100 € - 1.91</div>
        <div class="charts-bk__item-title">Under</div>
        <div class="charts-bk__item-coef">90 € - 2.02</div><table>
        <tr><td>live</td><td>10:01 25.09</td><td>Over</td><td>100 €</td><td>10 €</td><td>1</td><td>0-1</td></tr>
        <tr><td>live</td><td>10:00 25.09</td><td>Over</td><td>90 €</td><td>10 €</td><td>0</td><td>0-0</td></tr>
      </table></div><div class="footer"></div>`;
    fetchExcapperText.mockResolvedValueOnce(txPage(`<!-- <font class="score live">57'</font> -->`));
    const disabled = await loadParsedGameDetail("9988112255", new AbortController().signal, "live");
    expect(disabled.live).toMatchObject({
      liveScore: { home: 0, away: 1 }, livePeriod: null, liveMinute: null,
    });
    fetchExcapperText.mockResolvedValueOnce(txPage(`<font class="score live">57'</font>`));
    const rendered = await loadParsedGameDetail("9988112256", new AbortController().signal, "live");
    expect(rendered.live).toMatchObject({
      liveScore: { home: 0, away: 1 }, livePeriod: "second-half", liveMinute: 57,
    });
  });

  it("does not turn missing detail volumes or live state into zero values", () => {
    const incomplete = `
      <a href="#tab_content_1">Over/Under 2.5 Goals</a>
      <div id="tab_content_1" class="tab-content">
        <div class="charts-bk__item-title">Over</div>
        <div class="charts-bk__item-coef">1 000 € - 1.91</div>
      </div>`;
    expect(parseGamePage(incomplete)).toBeNull();
    expect(parseLiveObservation(incomplete)).toEqual({
      liveScore: null,
      livePeriod: null,
    });
  });

  it("parses the sanitized live detail shape without changing raw EUR totals", () => {
    const html = readFileSync(
      new URL("./fixtures/excapper-live-detail-sanitized.html", import.meta.url),
      "utf8",
    );
    const parsed = parseGamePage(html);
    expect(parsed).toEqual([
      expect.objectContaining({
        line: 2.5,
        over: 42_135,
        under: 52_962,
        overOdds: 2.02,
        underOdds: 1.98,
      }),
      expect.objectContaining({
        line: 3.5,
        over: 6_653,
        under: 30_718,
        overOdds: 7.8,
        underOdds: 1.15,
      }),
    ]);
    expect(parsed?.every((sample) =>
      Number.isFinite(sample.collectedAt) && sample.collectedAt! > 0
    )).toBe(true);
  });

  it("keeps live directory/detail euro amounts unchanged through thresholds", () => {
    const huge = Number.MAX_SAFE_INTEGER;
    const directory = parseDirectory(`
      <tr class="a_link" game_id="36094595">
        <td></td><td></td><td>Finland Kakkonen</td>
        <td>Alpha FC - Beta FC</td><td>170€</td>
      </tr>
    `);
    expect(directory[0]?.totalVolume).toBe(170);

    const detail = parseGamePage(`
      <a href="#tab_content_25">Over/Under 2.5 Goals</a>
      <div id="tab_content_25" class="tab-content">
        <div class="charts-bk__item-title">Over</div>
        <div class="charts-bk__item-coef">9€</div>
        <div class="charts-bk__item-title">Under</div>
        <div class="charts-bk__item-coef">161€</div>
      </div>
      <a href="#tab_content_35">Over/Under 3.5 Goals</a>
      <div id="tab_content_35" class="tab-content">
        <div class="charts-bk__item-title">Over</div>
        <div class="charts-bk__item-coef">${huge.toLocaleString("en-US")}€</div>
        <div class="charts-bk__item-title">Under</div>
        <div class="charts-bk__item-coef">170€</div>
      </div>
      <div class="footer"></div>
    `);
    expect(detail).toEqual([
      { line: 2.5, over: 9, under: 161 },
      { line: 3.5, over: huge, under: 170 },
    ]);

    const message = formatUnifiedAlert({
      matchId: "live-1",
      league: "Finland Kakkonen",
      home: "Alpha FC",
      away: "Beta FC",
      isLive: true,
      homeScore: 0,
      awayScore: 0,
      minute: "12",
      side: "OVER",
      line: 3.5,
      timeline: [
        { ts: 1_000, line: 3.5, odds: 2 },
        { ts: 11_000, line: 3.5, odds: 1.7 },
      ],
      inflow: {
        matchId: "live-1",
        line: 3.5,
        side: "OVER",
        single: detail![1]!.over,
        total: detail![1]!.over,
        minute: "12",
        observedAt: 11_000,
      },
      link: "https://www.nowgoal26.com/match/live-1.html",
    });
    expect(message).toContain("€9,007,199,254,740,991");
  });

  it("migrates nondefault legacy names without changing their numeric values", () => {
    expect(__testOnlyMigrateVolumeConfig({
      minSingleSpikeUsd: 725.5,
      minCumulativeUsd: 54_321,
      linesToTrack: [2.5],
    })).toEqual({
      minSingleSpikeEur: 725.5,
      minCumulativeEur: 54_321,
      linesToTrack: [2.5],
    });
  });
});

describe("manual Excapper identity binding", () => {
  const candidate = {
    matchId: "700001",
    team1: "Álpha Football Club",
    team2: "Beta",
    league: "Finland Kakkonen",
    nowGoalLine: 2.5,
    state: 3,
    homeScore: 0,
    awayScore: 1,
  };
  const row = {
    gameId: "9001",
    team1: "Beta",
    team2: "Alpha FC",
    league: "Finland Kakkonen",
    totalVolume: 1_000,
    activity: "live" as const,
    isLive: true,
    liveScore: { home: 1, away: 0 },
    livePeriod: "second-half" as const,
  };

  const verifiedLive = {
    ...row,
    activity: "live" as const,
    isLive: true,
    liveScore: { home: 1, away: 0 },
    livePeriod: "second-half" as const,
  };
  const verifiedCandidate = {
    ...candidate,
    state: 3,
    homeScore: 0,
    awayScore: 1,
  };

  it("parses directory tab and country metadata instead of guessing live from text", () => {
    const parsed = parseDirectory(`
      <div id="premach" class="tab-content">
        <tr class="a_link" game_id="1"><td>22.09.2026 10:00</td><td><img alt="FI"></td><td>Finland Kakkonen</td><td>Alpha - Beta</td><td>10 €</td></tr>
      </div>
      <div id="live" class="tab-content">
        <tr class="a_link" game_id="2"><td>21.09.2026 22:00</td><td><img title="CO"></td><td>Colombian Primera B</td><td>Bogota - Barranquilla</td><td>20 €</td></tr>
      </div>
      <div id="fav"></div>
    `);
    expect(parsed.map(({ gameId, activity, isLive, countryCode, kickoffText }) => ({
      gameId, activity, isLive, countryCode, kickoffText,
    }))).toEqual([
      { gameId: "1", activity: "scheduled", isLive: false, countryCode: "FI", kickoffText: "22.09.2026 10:00" },
      { gameId: "2", activity: "live", isLive: true, countryCode: "CO", kickoffText: "21.09.2026 22:00" },
    ]);
  });

  it("accepts normalized noise but routes translated-league discrepancies to review", () => {
    expect(resolveManualExcapperBindings(
      [{ ...verifiedCandidate, team1: "Alpha Football Club" }],
      [verifiedLive],
    )).toHaveLength(1);
    expect(resolveManualExcapperBindings(
      [{ ...verifiedCandidate, league: "Singapore S-League" }],
      [verifiedLive],
    )).toEqual([]);
  });

  it("auto-binds exact normalized teams with an operator-approved league alias", () => {
    __testOnlyInstallManualLeagueAlias("Singapore S-League", verifiedLive.league);
    expect(resolveManualExcapperBindings(
      [{ ...verifiedCandidate, league: "Singapore S-League" }],
      [verifiedLive],
    )).toHaveLength(1);
    __testOnlyResetManualLeagueAliases();
  });

  it("rejects scheduled, finished, ambiguous, missing, and conflicting live corroboration", () => {
    expect(resolveManualExcapperBindings(
      [verifiedCandidate],
      [{ ...verifiedLive, activity: "scheduled", isLive: false }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [{ ...verifiedCandidate, state: 0 }],
      [verifiedLive],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [{ ...verifiedCandidate, state: -1 }],
      [verifiedLive],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [{ ...verifiedCandidate, state: 2 }],
      [{ ...verifiedLive, livePeriod: "first-half" }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [verifiedCandidate],
      [{ ...verifiedLive, liveScore: null }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [verifiedCandidate],
      [{ ...verifiedLive, liveScore: { home: 0, away: 0 } }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [verifiedCandidate],
      [{ ...verifiedLive, livePeriod: "first-half" }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [verifiedCandidate],
      [verifiedLive, { ...verifiedLive, gameId: "duplicate" }],
    )).toEqual([]);
    expect(classifyManualExcapperBindings(
      [{ ...verifiedCandidate, state: 0 }],
      [verifiedLive],
    ).get(verifiedCandidate.matchId)?.status).toBe("non_live_candidate");
    expect(classifyManualExcapperBindings(
      [{ ...verifiedCandidate, state: -1 }],
      [verifiedLive],
    ).get(verifiedCandidate.matchId)?.status).toBe("non_live_candidate");
  });

  it("uses newest timestamped live evidence and keeps 45+ in the first half", () => {
    expect(parseObservedLiveMinute("45+2")).toBe(47);
    expect(parseObservedLiveMinute("90 + 5'")).toBe(95);
    expect(parseObservedLiveMinute("HT")).toBeNull();
    const txRow = (date: string, minute: string, score: string) => `
      <tr><td>live</td><td>${date}</td><td>Over</td><td>10 €</td>
      <td>1 € / 10%</td><td>${minute}</td><td>${score}</td></tr>`;
    const html = `
      <a href="#tab_content_25">Over/Under 2.5 Goals</a>
      <div id="tab_content_25" class="tab-content">
        ${txRow("10:05 21.09", "45+2", "1-0")}
        ${txRow("10:00 21.09", "80", "0-0")}
      </div><div class="footer"></div>`;
    expect(parseLiveObservation(html)).toEqual({
      liveScore: { home: 1, away: 0 },
      livePeriod: null,
    });
  });

  it("hydrates nested scoreboard JSON and explicit half-time from the actual page parser", () => {
    expect(parseLiveObservation(`<script type="application/json">${JSON.stringify({
      data: { event: { currentScore: { h: 2, a: 1 }, status: "HT", elapsed: 45 } },
    })}</script>`)).toEqual({
      liveScore: { home: 2, away: 1 },
      livePeriod: "half-time",
    });
    expect(parseLiveObservation("<div>Excapper teams only</div>")).toEqual({
      liveScore: null, livePeriod: null,
    });
  });

  it("binds one complete pair in the same canonical league", () => {
    expect(resolveManualExcapperBindings([candidate], [row])).toEqual([
      {
        matchId: "700001",
        gameId: "9001",
        nowGoalLine: 2.5,
        league: "Finland Kakkonen D3",
        confidence: 1,
      },
    ]);
  });

  it("uses an inclusive 0.50 hybrid promotion threshold", () => {
    const hybridRow = {
      ...row,
      team1: "Localized Home",
      team2: "Localized Away",
    };
    expect(resolveManualExcapperBindings(
      [candidate],
      [hybridRow],
      new Map([["700001", { gameId: "9001", confidence: 0.50 }]]),
    )).toEqual([
      expect.objectContaining({ gameId: "9001", confidence: 0.50 }),
    ]);
    expect(resolveManualExcapperBindings(
      [candidate],
      [hybridRow],
      new Map([["700001", { gameId: "9001", confidence: 0.499 }]]),
    )).toEqual([]);
  });

  it("does not let a shared token masquerade as 0.70 full-pair confidence", () => {
    expect(manualBindingConfidence(candidate, {
      ...row,
      team1: "Alpha United",
      team2: "Completely Different",
    })).toBe(0);
    expect(resolveManualExcapperBindings([candidate], [{
      ...row,
      team1: "Alpha United",
      team2: "Completely Different",
    }])).toEqual([]);
  });

  it("rejects ambiguous repeated fixtures and one-core-word variations", () => {
    expect(
      resolveManualExcapperBindings([candidate], [
        row,
        { ...row, gameId: "9002" },
      ]),
    ).toEqual([]);
    expect(
      resolveManualExcapperBindings(
        [{ ...candidate, team1: "Alpha United", team2: "City" }],
        [{
          ...row,
          team1: "Alpha Reserves",
          team2: "City",
          liveScore: { home: 0, away: 1 },
        }],
      ),
    ).toEqual([]);
  });

  it("normalizes Unicode, punctuation, attached designators, and every identity noise token", () => {
    expect(normalizedTeamName("RÉAL—Soacha Cundinamarca FK")).toBe("real soacha");
    expect(normalizedTeamName("BogotaFC")).toBe("bogota");
    expect(normalizedTeamName("Bogota FC")).toBe("bogota");
    expect(normalizedTeamName(
      "Águilas-FK FC CF CD SC Club FutbolClub FootballClub Cundinamarca Sub-20 U20 U21",
    )).toBe("aguilas");
    expect(normalizedTeamName("FK-FC_CF/CD SC Club Football Futbol U20 U21 Sub-20"))
      .toBe("");
  });

  it("routes Real Soacha and Deportes Quindio minor variations to review", () => {
    const soachaCandidate = {
      ...candidate,
      matchId: "3012198",
      team1: "Real Soacha Cundinamarca FK",
      team2: "Deportes Quindío",
      league: "Colombia Primera B",
      state: 3,
      homeScore: 2,
      awayScore: 1,
    };
    const soachaRow = {
      ...row,
      gameId: "soacha-live",
      team1: "Soacha",
      team2: "Quindio Football Club U21",
      league: "Colombia Primera B",
      liveScore: { home: 2, away: 1 },
      livePeriod: "second-half" as const,
    };

    expect(resolveManualExcapperBindings([soachaCandidate], [soachaRow])).toEqual([]);
  });

  it("supports reversed live orientation and swaps the exact score orientation", () => {
    const liveCandidate = {
      ...candidate,
      team1: "Real Soacha Cundinamarca FK",
      team2: "Deportes Quindio",
      league: "Colombia Primera B",
      homeScore: 2,
      awayScore: 1,
    };
    const reversed = {
      ...row,
      team1: "Deportes Quindio",
      team2: "Real Soacha",
      league: "Colombia Primera B",
      liveScore: { home: 1, away: 2 },
    };
    expect(resolveManualExcapperBindings([liveCandidate], [reversed])).toHaveLength(1);
    expect(resolveManualExcapperBindings(
      [liveCandidate],
      [{ ...reversed, liveScore: { home: 2, away: 1 } }],
    )).toEqual([]);
  });

  it("rejects core-word edges outside exact score, period, live, or uniqueness context", () => {
    const liveCandidate = {
      ...candidate,
      team1: "Real Soacha Cundinamarca FK",
      team2: "Deportes Quindio",
      league: "Colombia Primera B",
      homeScore: 2,
      awayScore: 1,
    };
    const matching = {
      ...row,
      team1: "Soacha",
      team2: "Quindio",
      league: "Colombian Primera B",
      liveScore: { home: 2, away: 1 },
    };
    expect(resolveManualExcapperBindings(
      [liveCandidate],
      [{ ...matching, liveScore: { home: 0, away: 0 } }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [liveCandidate],
      [{ ...matching, league: "Unrelated Competition" }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [liveCandidate],
      [{ ...matching, livePeriod: "first-half" }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [liveCandidate],
      [{ ...matching, activity: "scheduled", isLive: false }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [liveCandidate],
      [matching, { ...matching, gameId: "soacha-collision" }],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [{ ...liveCandidate, team1: "FK Football Club" }],
      [matching],
    )).toEqual([]);
  });

  it("reports distinct conservative binding failures without weakening identity checks", () => {
    const ambiguous = classifyManualExcapperBindings(
      [candidate],
      [row, { ...row, gameId: "9002" }],
    );
    expect(ambiguous.get(candidate.matchId)).toEqual({
      status: "ambiguous_identity",
      source: null,
    });

    const wrongLeague = { ...row, league: "Unrelated Competition" };
    expect(classifyManualExcapperBindings([candidate], [wrongLeague]).get(candidate.matchId))
      .toEqual({
        status: "pending",
        source: {
          team1: wrongLeague.team1,
          team2: wrongLeague.team2,
          league: wrongLeague.league,
          score: wrongLeague.liveScore,
          period: wrongLeague.livePeriod,
          minute: null,
        },
      });

    expect(
      classifyManualExcapperBindings(
        [candidate],
        [{ ...row, team1: "Alpha Reserves", team2: "City" }],
      ).get(candidate.matchId),
    ).toEqual({ status: "ambiguous_identity", source: null });
  });

  it("routes a translated league to review while exact league auto-binds", () => {
    expect(
      resolveManualExcapperBindings(
        [candidate],
        [{ ...row, league: "Singapore S-League" }],
      ),
    ).toEqual([]);
    expect(resolveManualExcapperBindings([candidate], [row])).toHaveLength(1);
  });

  it("auto-binds a unique non-allowlisted exact league but reviews a translation", () => {
    const regionalCandidate = {
      ...candidate,
      league: "Verified Regional Competition",
    };
    const regionalRow = {
      ...row,
      league: "Verified Regional Competition",
    };
    expect(resolveManualExcapperBindings([regionalCandidate], [regionalRow])).toHaveLength(1);
    expect(
      resolveManualExcapperBindings(
        [regionalCandidate],
        [{ ...regionalRow, league: "Other Regional Competition" }],
      ),
    ).toEqual([]);
  });

  it("rejects ambiguous non-allowlisted upstream rows instead of guessing", () => {
    const regionalCandidate = {
      ...candidate,
      league: "Verified Regional Competition",
    };
    const regionalRow = {
      ...row,
      league: "Verified Regional Competition",
    };
    expect(
      resolveManualExcapperBindings(
        [regionalCandidate],
        [regionalRow, { ...regionalRow, gameId: "9002" }],
      ),
    ).toEqual([]);
  });

  it("does not bind text-only identity without NowGoal live corroboration", () => {
    const textCandidate = {
      matchId: "manual-text:txt:direct away|direct home",
      team1: "Direct Home",
      team2: "Direct Away",
      league: "",
      nowGoalLine: null,
    };
    const directRow = {
      gameId: "direct-1",
      team1: "Direct Away",
      team2: "Direct Home",
      league: "Unapproved Regional League",
      totalVolume: 1_500,
    };
    expect(resolveManualExcapperBindings([textCandidate], [directRow])).toEqual([]);
    expect(
      resolveManualExcapperBindings(
        [textCandidate],
        [directRow, { ...directRow, gameId: "direct-2", league: "Another League" }],
      ),
    ).toEqual([]);
  });

  it("does not use hardcoded team aliases", () => {
    expect(
      resolveManualExcapperBindings(
        [{
          matchId: "manta",
          team1: "Manta FC",
          team2: "Orense Sporting Club",
          league: "Liga Pro Ecuador Serie A",
          nowGoalLine: 2.5,
        }],
        [{
          gameId: "manta-game",
          team1: "Manta FC",
          team2: "Orense SC",
          league: "Ecuador Primera A",
          totalVolume: 2_000,
        }],
      ),
    ).toEqual([]);
    expect(
      resolveManualExcapperBindings(
        [{
          matchId: "engineers",
          team1: "Ingenieros CD",
          team2: "26 de Febrero",
          league: "Simon Bolivar Cup",
          nowGoalLine: null,
        }],
        [{
          gameId: "engineers-game",
          team1: "Club Ingenieros",
          team2: "Club 26 de Febrero Colquir",
          league: "Bolivian Copa Simon Bolivar",
          totalVolume: 1_500,
        }],
      ),
    ).toEqual([]);
  });

  it("rejects historical bindings that required team aliases", () => {
    expect(
      resolveManualExcapperBindings(
        [{
          matchId: "3091904",
          team1: "Manta FC",
          team2: "Orense SC",
          league: "Liga Pro Ecuador Serie A",
          nowGoalLine: 2.5,
        }],
        [{
          gameId: "36077261",
          team1: "Manta FC",
          team2: "Orense Sporting Club",
          league: "Ecuadorian Serie A",
          totalVolume: 282_745,
        }],
      ),
    ).toEqual([]);

    expect(
      resolveManualExcapperBindings(
        [{
          matchId: "3093722",
          team1: "Club Ingenieros",
          team2: "Club 26 de Febrero Colquir",
          league: "Simon Bolivar Cup",
          nowGoalLine: 1.5,
        }],
        [{
          gameId: "36098045",
          team1: "Ingenieros",
          team2: "CD 26 de Febrero",
          league: "Bolivian Copa Simon Bolivar",
          totalVolume: 30_108,
        }],
      ),
    ).toEqual([]);
  });

  it("binds a sanitized live fixture via generic club-suffix normalization", () => {
    const candidate = {
      matchId: "sanitized-nowgoal-id",
      team1: "Bogota FC",
      team2: "Barranquilla FC",
      league: "Colombia Primera B",
      nowGoalLine: 3.25,
      state: 3,
      homeScore: 1,
      awayScore: 0,
    };
    const authenticDirectoryFixture = {
      gameId: "sanitized-excapper-id",
      team1: "Bogota",
      team2: "Barranquilla",
      league: "Colombia Primera B",
      totalVolume: 376_098,
      activity: "live" as const,
      isLive: true,
      liveScore: { home: 1, away: 0 },
      livePeriod: "second-half" as const,
    };

    expect(
      resolveManualExcapperBindings([candidate], [authenticDirectoryFixture]),
    ).toEqual([{
      matchId: "sanitized-nowgoal-id",
      gameId: "sanitized-excapper-id",
      nowGoalLine: 3.25,
      league: "Colombian Primera B",
      confidence: 1,
    }]);
    expect(
      classifyManualExcapperBindings([candidate], [authenticDirectoryFixture])
        .get(candidate.matchId),
    ).toEqual({
      status: "pending",
      source: {
        team1: "Bogota",
        team2: "Barranquilla",
        league: "Colombia Primera B",
        score: { home: 1, away: 0 },
        period: "second-half",
        minute: null,
      },
    });

    // A repeated strict pair is ambiguous and must never be selected by order.
    expect(
      resolveManualExcapperBindings(
        [candidate],
        [
          authenticDirectoryFixture,
          { ...authenticDirectoryFixture, gameId: "sanitized-duplicate-id" },
        ],
      ),
    ).toEqual([]);
  });

  it("keeps current live team aliases league-scoped and ambiguity-safe", () => {
    const current = {
      matchId: "3093722",
      team1: "Club Ingenieros",
      team2: "Club 26 de Febrero Colquir",
      league: "Simon Bolivar Cup",
      nowGoalLine: 1.5,
    };
    const row = {
      gameId: "36098045",
      team1: "Ingenieros",
      team2: "CD 26 de Febrero",
      league: "Unrelated Competition",
      totalVolume: 30_108,
    };
    expect(resolveManualExcapperBindings([current], [row])).toEqual([]);
    expect(
      resolveManualExcapperBindings(
        [current],
        [
          { ...row, league: "Bolivian Copa Simon Bolivar" },
          {
            ...row,
            gameId: "duplicate-current-pair",
            league: "Bolivian Copa Simon Bolivar",
          },
        ],
      ),
    ).toEqual([]);
  });

});

describe("per-row Excapper binding diagnostics", () => {
  beforeEach(() => {
    __testOnlyResetExcapperBindingDiagnostics();
  });

  it("emits the safe contract for numeric, text-only, and untouched rows", () => {
    __testOnlyRecordExcapperBindingDiagnostic(
      "700001",
      "hydrated",
      { team1: "Home", team2: "Away", league: "Safe League" },
      1_750_000_000_123,
    );
    __testOnlyRecordExcapperBindingDiagnostic(
      "manual-text:txt:alpha|beta",
      "empty_market",
      { team1: "Alpha", team2: "Beta", league: "Regional League" },
    );
    const decorated = withExcapperBindingDiagnostics({
      entries: [
        { signature: "id:700001", matchId: "700001", label: "numeric" },
        { signature: "txt:alpha|beta", matchId: null, label: "text" },
        { signature: "id:700002", matchId: "700002", label: "pending auto/manual" },
      ],
    });

    expect(decorated.entries.map((entry) => entry.excapperBinding)).toMatchObject([
      {
        status: "hydrated",
        source: { team1: "Home", team2: "Away", league: "Safe League" },
        target: null,
        lastSuccessfulUpdateAt: 1_750_000_000_123,
      },
      {
        status: "empty_market",
        source: { team1: "Alpha", team2: "Beta", league: "Regional League" },
        target: null,
        lastSuccessfulUpdateAt: null,
      },
      {
        status: "pending",
        source: null,
        target: null,
        lastSuccessfulUpdateAt: null,
      },
    ]);
    expect(Object.keys(decorated.entries[0]!.excapperBinding).sort()).toEqual([
      "bindingDecision",
      "lastSuccessfulUpdateAt",
      "source",
      "status",
      "target",
    ]);
  });

  it("reports only the allowlisted manual target identity and returns safe copies", () => {
    const candidate = {
      matchId: "manual-target",
      team1: "NowGoal Home",
      team2: "NowGoal Away",
      league: "NowGoal League",
      nowGoalLine: 2.5,
      gameId: "raw-game-id",
      requestUrl: "https://internal.example/raw",
      rawMetadata: { secret: true },
    };
    __testOnlyRecordManualCandidateDiagnostic(candidate, "pending", null);

    candidate.team1 = "mutated after recording";
    const first = withExcapperBindingDiagnostics({
      entries: [{
        signature: `id:${candidate.matchId}`,
        matchId: candidate.matchId,
      }],
    }).entries[0]!.excapperBinding;
    expect(first.target).toEqual({
      team1: "NowGoal Home",
      team2: "NowGoal Away",
      league: "NowGoal League",
    });
    expect(Object.keys(first.target!).sort()).toEqual(["league", "team1", "team2"]);
    expect(first).not.toHaveProperty("gameId");
    expect(first).not.toHaveProperty("requestUrl");
    expect(first).not.toHaveProperty("rawMetadata");

    first.target!.team2 = "mutated public copy";
    expect(withExcapperBindingDiagnostics({
      entries: [{
        signature: `id:${candidate.matchId}`,
        matchId: candidate.matchId,
      }],
    }).entries[0]!.excapperBinding.target).toEqual({
      team1: "NowGoal Home",
      team2: "NowGoal Away",
      league: "NowGoal League",
    });
  });

  it("keeps the last successful epoch timestamp under feed and fetch failure overlays", () => {
    const source = { team1: "Home", team2: "Away", league: "Safe League" };
    __testOnlyRecordExcapperBindingDiagnostic("row", "hydrated", source, 1_750_000_000_456);
    __testOnlyRecordExcapperBindingDiagnostic("row", "source_unavailable");
    expect(getExcapperBindingDiagnostic("row")).toMatchObject({
      status: "source_unavailable",
      source,
      target: null,
      lastSuccessfulUpdateAt: 1_750_000_000_456,
    });

    __testOnlyRecordExcapperBindingDiagnostic("row", "fetch_failed");
    expect(getExcapperBindingDiagnostic("row").lastSuccessfulUpdateAt)
      .toBe(1_750_000_000_456);
  });

  it("keeps a resolved text-only row keyed by its stable signature across every outcome", () => {
    const diagnosticId = "manual-text:txt:alpha|beta";
    const resolvedTextCandidate = {
      matchId: "numeric-scanner-state-42",
      diagnosticId,
      team1: "Alpha",
      team2: "Beta",
      league: "Verified Regional Competition",
      nowGoalLine: 2.5,
    };
    const source = {
      gameId: "game-42",
      team1: "Beta",
      team2: "Alpha",
      league: "Verified Regional Competition",
      totalVolume: 1_000,
      activity: "live" as const,
      isLive: true,
      liveScore: { home: 0, away: 0 },
      livePeriod: "second-half" as const,
    };
    const rowSnapshot = () => withExcapperBindingDiagnostics({
      entries: [{ signature: "txt:alpha|beta", matchId: null, label: "Alpha vs Beta" }],
    }).entries[0]!.excapperBinding;

    const noMatch = classifyManualExcapperBindings(
      [resolvedTextCandidate],
      [],
    ).get(diagnosticId)!;
    expect(noMatch).toEqual({ status: "no_directory_match", source: null });
    __testOnlyRecordManualCandidateDiagnostic(
      resolvedTextCandidate,
      noMatch.status,
      noMatch.source,
    );
    expect(rowSnapshot().status).toBe("no_directory_match");

    const missingEvidence = classifyManualExcapperBindings(
      [resolvedTextCandidate],
      [{ ...source, league: "Other Regional Competition" }],
    ).get(diagnosticId)!;
    expect(missingEvidence).toEqual({
      status: "missing_live_corroboration",
      source: {
        team1: "Beta",
        team2: "Alpha",
        league: "Other Regional Competition",
        score: { home: 0, away: 0 },
        period: "second-half",
        minute: null,
      },
    });
    __testOnlyRecordManualCandidateDiagnostic(
      resolvedTextCandidate,
      missingEvidence.status,
      missingEvidence.source,
    );
    expect(rowSnapshot().status).toBe("missing_live_corroboration");

    const pending = classifyManualExcapperBindings(
      [resolvedTextCandidate],
      [source],
    ).get(diagnosticId)!;
    expect(pending).toEqual({
      status: "missing_live_corroboration",
      source: {
        team1: "Beta",
        team2: "Alpha",
        league: "Verified Regional Competition",
        score: { home: 0, away: 0 },
        period: "second-half",
        minute: null,
      },
    });
    __testOnlyRecordManualCandidateDiagnostic(
      resolvedTextCandidate,
      pending.status,
      pending.source,
    );
    expect(rowSnapshot().status).toBe("missing_live_corroboration");

    for (const status of ["empty_market", "fetch_failed"] as const) {
      __testOnlyRecordManualCandidateDiagnostic(
        resolvedTextCandidate,
        status,
        { team1: source.team1, team2: source.team2, league: source.league },
      );
      expect(rowSnapshot().status).toBe(status);
      // A resolved text row must never accidentally read the numeric scanner
      // state's independent diagnostic slot.
      expect(getExcapperBindingDiagnostic(resolvedTextCandidate.matchId).status)
        .toBe("pending");
    }

    __testOnlyRecordManualCandidateDiagnostic(
      resolvedTextCandidate,
      "hydrated",
      { team1: source.team1, team2: source.team2, league: source.league },
      1_750_000_000_789,
    );
    expect(rowSnapshot()).toMatchObject({
      status: "hydrated",
      source: {
        team1: "Beta",
        team2: "Alpha",
        league: "Verified Regional Competition",
      },
      target: {
        team1: "Alpha",
        team2: "Beta",
        league: "Verified Regional Competition",
      },
      lastSuccessfulUpdateAt: 1_750_000_000_789,
    });
  });

  it("surfaces multiple strict scanner states as ambiguous on the text row", () => {
    const diagnosticId = "manual-text:txt:alpha|beta";
    const classification = classifyManualExcapperBindings([{
      matchId: diagnosticId,
      diagnosticId,
      identityAmbiguous: true,
      team1: "alpha",
      team2: "beta",
      league: "",
      nowGoalLine: null,
    }], []);
    expect(classification.get(diagnosticId)).toEqual({
      status: "ambiguous_identity",
      source: null,
    });
    __testOnlyRecordExcapperBindingDiagnostic(
      diagnosticId,
      classification.get(diagnosticId)!.status,
      null,
    );
    expect(withExcapperBindingDiagnostics({
      entries: [{ signature: "txt:alpha|beta", matchId: null }],
    }).entries[0]!.excapperBinding.status).toBe("ambiguous_identity");
  });
});
