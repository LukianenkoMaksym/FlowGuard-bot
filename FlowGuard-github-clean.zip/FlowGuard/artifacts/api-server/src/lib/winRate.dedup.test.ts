import { beforeEach, describe, expect, it, vi } from "vitest";
import { PgDialect } from "drizzle-orm/pg-core";

// Deliberately no database connection: an isolated PostgreSQL integration run
// must be coordinated with the test DB guard before it can touch any DB.
const store = vi.hoisted(() => ({
  rows: [] as Array<Record<string, any>>,
  pending: [] as Promise<unknown>[],
  locks: new Map<string, Promise<void>>(),
  now: Date.now(),
  nextId: 1,
  sql: [] as string[],
}));
vi.mock("@workspace/db", () => ({
  signalHistoryEntriesTable: { createdAt: "created_at" },
  anomaliesTable: {
    anomalyType: "anomaly_type", targetSide: "target_side", status: "status",
    createdAt: "created_at",
  },
  db: {
    transaction: (work: (tx: { execute: (statement: unknown) => Promise<{ rows: unknown[] }> }) => Promise<unknown>) => {
      let release = () => {};
      const tx = {
        execute: async (statement: unknown) => {
          const compiled = new PgDialect().sqlToQuery(statement as Parameters<PgDialect["sqlToQuery"]>[0]);
          store.sql.push(compiled.sql);
          if (compiled.sql.includes("pg_advisory_xact_lock")) {
            const key = String(compiled.params[0]);
            const previous = store.locks.get(key) ?? Promise.resolve();
            const next = new Promise<void>((resolve) => { release = resolve; });
            store.locks.set(key, previous.then(() => next));
            await previous;
            return { rows: [] };
          }
          if (!compiled.sql.includes("INSERT INTO anomalies")) throw new Error("Unexpected SQL");
          const p = compiled.params;
          const existing = store.rows.some((row) =>
            row.matchId === p[13] && row.anomalyType === p[14] &&
            row.targetSide === p[15] && row.line === p[16] &&
            row.createdAt.getTime() > store.now - Number(p[17]));
          if (existing) return { rows: [] };
          const id = store.nextId++;
          store.rows.push({
            id, matchId: p[0], team1: p[1], team2: p[2], league: p[3],
            anomalyType: p[4], targetSide: p[5], line: p[6],
            minuteBucket: p[7], matchMinute: p[8],
            homeScoreAtFire: p[9], awayScoreAtFire: p[10], oddsAtFire: p[11],
            status: "PENDING", finalHomeScore: null, finalAwayScore: null,
            finalTotal: null, createdAt: new Date(store.now), resolvedAt: null,
          });
          return { rows: [{ id }] };
        },
      };
      const promise = work(tx).finally(() => release());
      store.pending.push(promise);
      return promise;
    },
    select: () => ({
      from: (table: unknown) => ({
        where: () => ({
          orderBy: async () => [...store.rows].sort(
            (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
          ),
        }),
        orderBy: async () => table === "delivered_signals" ? [] : [],
      }),
    }),
  },
}));
vi.mock("./targetLeagues", () => ({
  matchTargetLeague: (league: string) => league === "Finland Kakkonen D3" ? league : null,
}));
vi.mock("./scanner", () => ({ fetchFreshScoreNow: vi.fn() }));
vi.mock("./logger", () => ({
  logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn(), debug: vi.fn() },
}));

const input = {
  matchId: "rebooted:fixture",
  team1: "Alpha", team2: "Beta", league: "Finland Kakkonen D3",
  anomalyType: "MONEY_SPIKE" as const, targetSide: "OVER" as const,
  line: 2.5, matchMinute: 30, isLive: false,
  homeScore: 0, awayScore: 0, oddsAtFire: 0.9, kickoffAtMs: null,
};
const drain = async () => { await Promise.all(store.pending.splice(0)); };

describe("anomaly database dedup and history", () => {
  beforeEach(() => {
    store.rows = [];
    store.pending = [];
    store.locks.clear();
    store.sql = [];
    store.nextId = 1;
    store.now = Date.now();
    vi.resetModules();
  });

  it("persists only one of five repeats despite resetting the memory map on every call", async () => {
    for (let i = 0; i < 5; i++) {
      vi.resetModules(); // simulates process reboot, clearing lastRecordedAt
      const { recordAnomaly } = await import("./winRate");
      recordAnomaly(input);
      await drain();
    }
    expect(store.rows).toHaveLength(1);
    expect(store.sql.filter((s) => s.includes("INSERT INTO anomalies"))).toHaveLength(5);
    expect(store.sql.join("\n")).toContain("IS NOT DISTINCT FROM");
    expect(store.sql.join("\n")).toContain("NOT EXISTS");
  });

  it("serializes concurrent writers for the same key", async () => {
    const { recordAnomaly } = await import("./winRate");
    recordAnomaly(input);
    vi.resetModules();
    (await import("./winRate")).recordAnomaly(input);
    await drain();
    expect(store.rows).toHaveLength(1);
    expect(store.sql.filter((s) => s.includes("pg_advisory_xact_lock"))).toHaveLength(2);
  });

  it("compares lines null-safely while retaining the non-null scanner input contract", async () => {
    const { recordAnomaly } = await import("./winRate");
    recordAnomaly(input);
    await drain();
    expect(store.sql.find((s) => s.includes("INSERT INTO anomalies")))
      .toMatch(/line IS NOT DISTINCT FROM \$\d+/);
  });

  it("uses a rolling window rather than fixed quarter-hour uniqueness", async () => {
    const { recordAnomaly } = await import("./winRate");
    recordAnomaly(input);
    await drain();
    store.now += 14 * 60_000;
    vi.resetModules();
    (await import("./winRate")).recordAnomaly(input);
    await drain();
    expect(store.rows).toHaveLength(1);
    store.now += 60_000;
    vi.resetModules();
    (await import("./winRate")).recordAnomaly(input);
    await drain();
    expect(store.rows).toHaveLength(2);
  });

  it("collapses each key/15-minute bucket before page slicing and total counts", async () => {
    const { getAnomalyHistory } = await import("./winRate");
    const quarter = Math.floor(store.now / 900_000) * 900_000;
    const base = {
      id: 1, matchId: "a", team1: "Alpha", team2: "Beta",
      league: input.league, anomalyType: input.anomalyType,
      targetSide: input.targetSide, line: 2.5, minuteBucket: "prematch",
      matchMinute: null, homeScoreAtFire: 0, awayScoreAtFire: 0,
      oddsAtFire: null, status: "PENDING", finalHomeScore: null,
      finalAwayScore: null, finalTotal: null, resolvedAt: null,
    };
    store.rows = [
      { ...base, id: 1, createdAt: new Date(quarter + 1000) },
      { ...base, id: 2, createdAt: new Date(quarter + 2000) },
      { ...base, id: 3, createdAt: new Date(quarter + 900_000) },
      { ...base, id: 4, line: null, createdAt: new Date(quarter + 3000) },
      { ...base, id: 5, line: null, createdAt: new Date(quarter + 4000) },
      { ...base, id: 6, targetSide: "UNDER", createdAt: new Date(quarter + 5000) },
      { ...base, id: 7, league: "not allowed", createdAt: new Date(quarter + 6000) },
    ];
    const page1 = await getAnomalyHistory({ limit: 2 });
    const page2 = await getAnomalyHistory({ limit: 2, offset: 2 });
    expect(page1.total).toBe(4);
    expect(page2.total).toBe(4);
    expect([...page1.rows, ...page2.rows].map((row) => row.id)).toEqual([3, 6, 4, 1]);
  });
});