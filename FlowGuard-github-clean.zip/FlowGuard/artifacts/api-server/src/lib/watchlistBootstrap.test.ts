import { describe, expect, it } from "vitest";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { chooseWatchlistBootstrap, readLegacyWatchlistFromPaths } from "./watchlist";

describe("watchlist storage bootstrap", () => {
  const pin = { matchId: "3061656", label: "Operator pin", teams: [], origin: "manual" };

  it("restores DB pins after a production container loses its JSON file", () => {
    expect(chooseWatchlistBootstrap([pin], null).matches).toEqual([pin]);
  });

  it("does not resurrect removed pins from old JSON after intentional DB emptying", () => {
    expect(chooseWatchlistBootstrap([], { matches: [pin] }).matches).toEqual([]);
  });

  it("reads the artifact legacy file if the old root-cwd path is absent", async () => {
    const directory = await fs.mkdtemp(path.join(os.tmpdir(), "watchlist-bootstrap-"));
    try {
      const legacyPath = path.join(directory, "artifacts/api-server/config/watchlist.json");
      await fs.mkdir(path.dirname(legacyPath), { recursive: true });
      await fs.writeFile(legacyPath, JSON.stringify({ matches: [pin] }));
      const imported = await readLegacyWatchlistFromPaths([
        path.join(directory, "config/watchlist.json"), legacyPath,
      ]);
      expect(imported).toEqual({ parsed: { matches: [pin] }, file: legacyPath });
    } finally {
      await fs.rm(directory, { recursive: true, force: true });
    }
  });

  it("imports a legacy file once, without replacing it with an empty list", () => {
    expect(chooseWatchlistBootstrap(null, { matches: [pin] }).matches).toEqual([pin]);
  });

  it("initializes genuinely empty storage without fake seeded pins", () => {
    expect(chooseWatchlistBootstrap(null, null).matches).toEqual([]);
  });

  it("refuses malformed legacy data rather than erasing operator pins", () => {
    expect(() => chooseWatchlistBootstrap(null, {})).toThrow(/invalid/);
  });
});