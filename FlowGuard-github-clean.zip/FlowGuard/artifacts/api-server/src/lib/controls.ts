/**
 * Manual runtime controls (user directive 2026-08-17, revised):
 * individual on/off switches for subsystems, persisted to
 * config/controls.json so they survive restarts.
 *
 * Flags:
 *  - alertsMuted:          when true, broadcast alerts to Telegram are
 *                          suppressed (logged instead). Direct replies to
 *                          /start etc. are unaffected.
 *  - altStreamEnabled:     branch-B alternate-mirror OU stream on/off.
 *  - scoreWatchdogEnabled: Sofascore score watchdog on/off.
 *
 * NOTE: the global scanner pause flag and the global volume scan flag have
 * their own dedicated scanner state.
 */
import { promises as fs } from "node:fs";
import path from "node:path";
import { logger } from "./logger";

const CONFIG_PATH = path.resolve(process.cwd(), "config/controls.json");

export interface Controls {
  alertsMuted: boolean;
  altStreamEnabled: boolean;
  scoreWatchdogEnabled: boolean;
}

const DEFAULTS: Controls = {
  alertsMuted: false,
  altStreamEnabled: true,
  scoreWatchdogEnabled: true,
};

let current: Controls = { ...DEFAULTS };
// Serializes ENTIRE setControl transactions (state update + subsystem
// side effect + disk write), not just file writes: the last requested
// intent also determines the final timer state.
let opQueue: Promise<unknown> = Promise.resolve();

async function persist(snapshot: Controls): Promise<boolean> {
  try {
    const dir = path.dirname(CONFIG_PATH);
    const tmp = path.join(dir, `.controls.json.tmp-${process.pid}-${Date.now()}`);
    await fs.mkdir(dir, { recursive: true });
    await fs.writeFile(tmp, JSON.stringify(snapshot, null, 2) + "\n", "utf8");
    await fs.rename(tmp, CONFIG_PATH);
    return true;
  } catch (err) {
    logger.error({ err, path: CONFIG_PATH }, "[CONTROLS] persist failed");
    return false;
  }
}

export function getControls(): Readonly<Controls> {
  return current;
}

let initialized = false;

/**
 * Load persisted controls from disk. Called ONCE at boot in index.ts,
 * BEFORE the HTTP server starts listening and BEFORE the scanner starts —
 * so alert producers and the /scanner/controls routes always see the
 * persisted flags, and scanner.ts can consult getControls() when deciding
 * whether to start the alt-stream / score watchdog (no stop-after-start).
 */
export async function initControls(): Promise<void> {
  if (initialized) return; // a racing setControl() must not be clobbered
  try {
    const raw = await fs.readFile(CONFIG_PATH, "utf8");
    const parsed = JSON.parse(raw) as Partial<Controls>;
    if (initialized) return; // re-check after await
    current = {
      alertsMuted: typeof parsed.alertsMuted === "boolean" ? parsed.alertsMuted : DEFAULTS.alertsMuted,
      altStreamEnabled:
        typeof parsed.altStreamEnabled === "boolean" ? parsed.altStreamEnabled : DEFAULTS.altStreamEnabled,
      scoreWatchdogEnabled:
        typeof parsed.scoreWatchdogEnabled === "boolean"
          ? parsed.scoreWatchdogEnabled
          : DEFAULTS.scoreWatchdogEnabled,
    };
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== "ENOENT") {
      logger.error({ err, path: CONFIG_PATH }, "[CONTROLS] load failed — using defaults");
    }
    if (initialized) return;
    current = { ...DEFAULTS };
  }
  initialized = true;
  logger.info({ ...current }, "[CONTROLS] loaded");
}

/**
 * Flip one control, apply its side effect, persist. The whole transaction
 * runs on a serial queue so overlapping requests always leave timer state
 * and disk consistent with the LAST request.
 */
export async function setControl(
  key: keyof Controls,
  enabled: boolean,
): Promise<{ controls: Controls; persisted: boolean }> {
  const task = opQueue.then(async () => {
    initialized = true; // explicit set makes state authoritative over disk
    const prev = current[key];
    current = { ...current, [key]: enabled };
    if (prev !== enabled) {
      if (key === "altStreamEnabled") {
        // No subsystem timer is started here. The coordinator reads this flag
        // at the next cycle, so rapid toggles remain serialized and coalesced.
      } else if (key === "scoreWatchdogEnabled") {
        // Same as altStreamEnabled: control state, not timer ownership.
      }
      logger.warn({ key, enabled }, "[CONTROLS] manual control changed");
    }
    const persisted = await persist({ ...current });
    return { controls: { ...current }, persisted };
  });
  opQueue = task.catch(() => {});
  return task;
}
