/**
 * Dynamic Win-Rate Tracker & Live Probability Engine.
 *
 * Three responsibilities:
 *
 *   1. recordAnomaly() — called by the scanner the instant a user-facing
 *      anomaly alert fires (odds-drop Pro Alert or Excapper money-spike). It
 *      persists a PENDING snapshot to Postgres and updates the in-memory
 *      "active anomaly per match" map so the live snapshot can attach a
 *      win-rate immediately.
 *
 *   2. A background resolver loop — periodically takes PENDING rows whose
 *      match is old enough to be finished, fetches the final score, and flips
 *      them to WIN/LOSS, resolved STRICTLY by the targeted side:
 *        - OVER  wins when finalTotal >  line
 *        - UNDER wins when finalTotal <  line
 *        (an exact-line landing counts as a LOSS for the targeted side.)
 *
 *   3. computeWinRateForMatch() — reads two in-memory caches (the active
 *      anomaly per match + aggregated resolved stats) to produce the live
 *      win-rate shown in the Priority Watchlist. The WIN% reflects the OVER
 *      win-rate STRICTLY: the match's active money-flow pattern (anomaly type +
 *      phase) selects the bucket, but the side is always OVER regardless of
 *      which side the anomaly targeted — the user's strategy is Over-only. It
 *      uses a CONDITIONAL sub-bucket: if the most-specific pattern
 *      (type + OVER + minute bucket) has >= MIN_RESOLVED resolved cases it
 *      shows that rate; otherwise it falls back to the broad (type + OVER)
 *      rate. Below MIN_RESOLVED resolved cases we report `sufficient: false`
 *      so the UI can show a "building" state instead of a misleading number.
 *
 *      The aggregate caches are built from OVER rows only — UNDER buckets are
 *      deprecated (no Watchlist consumer reads them) which also trims memory.
 *      UNDER anomalies are still recorded and resolved in the DB so the
 *      underlying history stays intact.
 */
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db, anomaliesTable, signalHistoryEntriesTable } from "@workspace/db";
import { resolveDeliveredSignals } from "./deliveredSignals";
import { logger } from "./logger";
import { fetchFreshScoreNow } from "./scanner";
import { matchTargetLeague } from "./targetLeagues";

export type AnomalyType = "ODDS_DROP" | "MONEY_SPIKE";
export type TargetSide = "OVER" | "UNDER";
export type MinuteBucket = "prematch" | "early" | "mid" | "late" | "unknown";

/** Minimum resolved cases in a bucket before we surface a real percentage. */
const MIN_RESOLVED = 5;

/** How far back the active-anomaly map and stats cache look on (re)load. */
const ACTIVE_WINDOW_MS = 4 * 60 * 60 * 1000; // 4h

/**
 * A PENDING anomaly is eligible for resolution once it's this old (most
 * football matches are over ~2h after the alert window). The resolver fetches
 * the live score and only resolves when the match is no longer live.
 */
const RESOLVE_AFTER_MS = 130 * 60 * 1000; // 130 min
/** Hard cap: force-resolve with whatever score we can get past this age. */
const FORCE_RESOLVE_AFTER_MS = 5 * 60 * 60 * 1000; // 5h
/** Abandon (mark UNKNOWN) anomalies we still can't score past this age. */
const ABANDON_AFTER_MS = 12 * 60 * 60 * 1000; // 12h

const RESOLVE_INTERVAL_MS = 5 * 60 * 1000; // run resolver every 5 min
const STATS_REFRESH_MS = 60 * 1000; // refresh aggregate cache every 60s

/**
 * In-process dedup so a single logical alert event (which can momentarily
 * re-fire) doesn't write multiple rows. Keyed by matchId:type:side:line.
 */
const DEDUP_TTL_MS = 15 * 60 * 1000;
const lastRecordedAt = new Map<string, number>();

/** The most recent anomaly per match, used to pick the live win-rate pattern. */
interface ActiveAnomaly {
  anomalyType: AnomalyType;
  targetSide: TargetSide;
  minuteBucket: MinuteBucket;
  at: number;
}
const activeByMatch = new Map<string, ActiveAnomaly>();

/**
 * Aggregated resolved stats, refreshed from the DB on a timer. OVER-only:
 * UNDER rows are excluded so the Watchlist WIN% reflects Over performance and
 * the maps stay small (no dead UNDER buckets).
 */
interface Bucket {
  wins: number;
  total: number;
}
let specificStats = new Map<string, Bucket>(); // key: type|OVER|minuteBucket
let broadStats = new Map<string, Bucket>(); // key: type|OVER
let totalResolved = 0; // resolved OVER cases only

let resolveTimer: ReturnType<typeof setTimeout> | null = null;
let statsTimer: ReturnType<typeof setTimeout> | null = null;
let generation = 0;

export interface WinRate {
  pct: number | null;
  wins: number;
  total: number;
  anomalyType: AnomalyType;
  targetSide: TargetSide;
  /** true when the specific (minute-bucket) rate was used, false for broad. */
  adjusted: boolean;
  /** true once the chosen bucket has >= MIN_RESOLVED resolved cases. */
  sufficient: boolean;
}

/** Map a (possibly missing) live match minute to a coarse phase bucket. */
export function minuteToBucket(minute: number | null, isLive: boolean): MinuteBucket {
  if (!isLive) return "prematch";
  if (minute === null || !Number.isFinite(minute)) return "unknown";
  if (minute <= 30) return "early";
  if (minute <= 60) return "mid";
  return "late";
}

/** Parse a raw Excapper match-minute string ("75", "75'", "45+2") to int. */
export function parseMatchMinute(raw: string | null | undefined): number | null {
  if (!raw) return null;
  const m = raw.match(/\d+/);
  if (!m) return null;
  const n = parseInt(m[0], 10);
  return Number.isFinite(n) ? n : null;
}

/**
 * Upstream VALUE GUARDS — protect the Win-Rate Tracker from "low-risk,
 * low-yield heavy money parking" (scalping on micro-odds and dead-certain
 * unders). An anomaly that fails any guard must NOT be persisted or alerted:
 * it would skew the WIN% column with bets that were never actionable value.
 *
 * Thresholds are deliberately exported so the scanner's alert path and this
 * module's DB write share ONE source of truth.
 */
export const ANOMALY_ODDS_FLOOR = 1.15;
export const ANOMALY_BUFFER_GAP_GENERAL = 2.5;
export const ANOMALY_BUFFER_GAP_LATE = 1.5;
export const ANOMALY_LATE_GAME_MINUTE = 75;

export interface ValueGuardInput {
  /** Active DECIMAL odds on the target side at fire time (e.g. 1.85); null = unknown. */
  decimalOdds: number | null;
  targetSide: TargetSide;
  /** Target Over/Under line (e.g. 3.5). */
  line: number;
  /** Current combined goals (home + away), or null when no authoritative live score exists. */
  totalGoals: number | null;
  /** Closed-market filtering applies only after kickoff. */
  isLive: boolean;
  /** Live match minute, or null when unknown (the late-game rule is skipped then). */
  minute: number | null;
}

export type ValueGuardResult = { ok: true } | { ok: false; reason: string };

/**
 * Returns `{ ok:false, reason }` when an anomaly should be discarded before it
 * reaches PostgreSQL or Telegram. Pure — same inputs always yield same result.
 */
export function passesValueGuards(input: ValueGuardInput): ValueGuardResult {
  // A live total at or below the score is already settled/pushed and must never
  // enter alerting or persistence. Missing live score evidence fails closed.
  if (input.isLive) {
    if (input.totalGoals == null || !Number.isFinite(input.totalGoals)) {
      return { ok: false, reason: "live-score-unavailable" };
    }
    if (input.line <= input.totalGoals) {
      return { ok: false, reason: "total-already-settled" };
    }
  }

  // 1. ODDS FLOOR — ignore micro-odds (≈1.02–1.15) money parking. Only applied
  //    when we actually know the price; an unknown price cannot be floored.
  if (input.decimalOdds != null && input.decimalOdds < ANOMALY_ODDS_FLOOR) {
    return { ok: false, reason: "odds-floor" };
  }

  // 2. DYNAMIC SCORE-TO-LINE BUFFER — a "guaranteed clear" only applies to
  //    UNDER: a wide gap between the line and the goals already scored means
  //    the under is near-certain, so the anomaly carries no edge.
  if (input.targetSide === "UNDER" && input.totalGoals != null) {
    const gap = input.line - input.totalGoals;
    if (gap >= ANOMALY_BUFFER_GAP_GENERAL) {
      return { ok: false, reason: "score-buffer-general" };
    }
    // Late-game tightening: deep into the match even a 1.5-goal cushion is
    // effectively safe. Skipped when the minute is unknown (e.g. the odds-drop
    // path carries no live clock) — the general rule still applies there.
    if (
      input.minute != null &&
      input.minute > ANOMALY_LATE_GAME_MINUTE &&
      gap >= ANOMALY_BUFFER_GAP_LATE
    ) {
      return { ok: false, reason: "score-buffer-late" };
    }
  }

  return { ok: true };
}

export interface RecordAnomalyInput {
  matchId: string;
  team1: string;
  team2: string;
  league: string;
  anomalyType: AnomalyType;
  targetSide: TargetSide;
  line: number;
  matchMinute: number | null;
  isLive: boolean;
  homeScore: number;
  awayScore: number;
  oddsAtFire: number | null;
  /** Absolute kickoff epoch ms; null when unknown at fire time. */
  kickoffAtMs: number | null;
}

/**
 * Persist a PENDING anomaly snapshot. Fire-and-forget: never throws into the
 * caller (the scanner's alert path must not be coupled to DB availability).
 */
export function recordAnomaly(input: RecordAnomalyInput): void {
  const now = Date.now();

  // Anomaly persistence is itself a tracking boundary. Existing historical
  // rows remain in the database, but unknown/non-target league input must not
  // create a new active snapshot or notification.
  const canonicalLeague = matchTargetLeague(input.league);
  if (!canonicalLeague) {
    logger.warn(
      { matchId: input.matchId, league: input.league },
      "[WIN-RATE] anomaly rejected — league is not in target allowlist",
    );
    return;
  }

  // VALUE-GUARD SAFETY NET. Callers already gate alerts on passesValueGuards,
  // but enforce it here too so the WIN% table can NEVER be polluted by a
  // micro-odds or "guaranteed clear" anomaly from any present or future caller.
  // oddsAtFire is stored as (decimal - 1), so reconstruct the decimal price.
  const guard = passesValueGuards({
    decimalOdds: input.oddsAtFire == null ? null : input.oddsAtFire + 1,
    targetSide: input.targetSide,
    line: input.line,
    totalGoals: input.homeScore + input.awayScore,
    isLive: input.isLive,
    minute: input.matchMinute,
  });
  if (!guard.ok) {
    logger.debug(
      {
        matchId: input.matchId,
        type: input.anomalyType,
        side: input.targetSide,
        line: input.line,
        reason: guard.reason,
      },
      "[WIN-RATE] anomaly discarded by value guard",
    );
    return;
  }

  const dedupKey = `${input.matchId}:${input.anomalyType}:${input.targetSide}:${input.line}`;
  const last = lastRecordedAt.get(dedupKey);
  if (last !== undefined && now - last < DEDUP_TTL_MS) return;
  lastRecordedAt.set(dedupKey, now);
  if (lastRecordedAt.size > 5000) {
    for (const [k, t] of lastRecordedAt) {
      if (now - t > DEDUP_TTL_MS) lastRecordedAt.delete(k);
    }
  }

  const minuteBucket = minuteToBucket(input.matchMinute, input.isLive);
  // Update the live pattern map immediately so the next snapshot poll can
  // attach a win-rate without waiting for a DB round-trip.
  activeByMatch.set(input.matchId, {
    anomalyType: input.anomalyType,
    targetSide: input.targetSide,
    minuteBucket,
    at: now,
  });

  // Serialize every writer for this logical key across processes. A fixed
  // 15-minute UNIQUE bucket would incorrectly allow repeats at bucket edges;
  // the NOT EXISTS check below uses the actual rolling window instead.
  // JSON tuple encoding avoids collisions between components containing ":".
  const lockKey = JSON.stringify([input.matchId, input.anomalyType, input.targetSide, input.line]);
  void db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${lockKey}, 0))`);
    // Under the per-key transaction lock this check and insert are atomic for
    // all application writers. IS NOT DISTINCT FROM also treats legacy NULL
    // lines as the same key (new schema requires line NOT NULL).
    const inserted = await tx.execute(sql`
      INSERT INTO anomalies (
        match_id, team1, team2, league, anomaly_type, target_side, line,
        minute_bucket, match_minute, home_score_at_fire, away_score_at_fire,
        odds_at_fire, kickoff_at_ms, status
      )
      SELECT ${input.matchId}, ${input.team1}, ${input.team2}, ${canonicalLeague},
        ${input.anomalyType}, ${input.targetSide}, ${input.line},
        ${minuteBucket}, ${input.matchMinute}, ${input.homeScore}, ${input.awayScore},
        ${input.oddsAtFire}, ${input.kickoffAtMs}, 'PENDING'
      WHERE NOT EXISTS (
        SELECT 1 FROM anomalies
        WHERE match_id = ${input.matchId}
          AND anomaly_type = ${input.anomalyType}
          AND target_side = ${input.targetSide}
          AND line IS NOT DISTINCT FROM ${input.line}
          AND created_at > clock_timestamp() - (${DEDUP_TTL_MS} * interval '1 millisecond')
      )
      RETURNING id
    `);
    return inserted.rows.length > 0;
  })
    .then((inserted) => {
      if (inserted) {
        logger.info(
          {
            matchId: input.matchId,
            type: input.anomalyType,
            side: input.targetSide,
            line: input.line,
            minuteBucket,
          },
          "[WIN-RATE] anomaly snapshot recorded",
        );
      }
    })
    .catch((err) => {
      logger.error({ err, matchId: input.matchId }, "[WIN-RATE] failed to record anomaly");
    });
}

/**
 * Resolve WIN/LOSS strictly by the targeted side.
 *   OVER  → final total must beat the line.
 *   UNDER → final total must stay under the line.
 * Exact-line landings (only possible on whole-number lines) count as a LOSS.
 */
function decideOutcome(side: TargetSide, total: number, line: number): "WIN" | "LOSS" {
  if (side === "OVER") return total > line ? "WIN" : "LOSS";
  return total < line ? "WIN" : "LOSS";
}

/** Live win-rate for a match, or null when no recent anomaly fired on it. */
export function computeWinRateForMatch(matchId: string): WinRate | null {
  const active = activeByMatch.get(matchId);
  if (!active) return null;
  if (Date.now() - active.at > ACTIVE_WINDOW_MS) {
    activeByMatch.delete(matchId);
    return null;
  }

  // OVER-only WIN%: the active money-flow anomaly (type + phase) picks the
  // pattern bucket, but the side is pinned to OVER regardless of which side the
  // anomaly targeted — the Watchlist reports Over probability exclusively.
  const { anomalyType, minuteBucket } = active;
  const side: TargetSide = "OVER";
  const specKey = `${anomalyType}|${side}|${minuteBucket}`;
  const broadKey = `${anomalyType}|${side}`;
  const spec = specificStats.get(specKey);
  const broad = broadStats.get(broadKey) ?? { wins: 0, total: 0 };

  const useSpecific = !!spec && spec.total >= MIN_RESOLVED;
  const chosen = useSpecific ? spec! : broad;
  const sufficient = chosen.total >= MIN_RESOLVED;
  const pct = chosen.total > 0 ? Math.round((chosen.wins / chosen.total) * 100) : null;

  return {
    pct: sufficient ? pct : null,
    wins: chosen.wins,
    total: chosen.total,
    anomalyType,
    targetSide: side,
    adjusted: useSpecific,
    sufficient,
  };
}

/**
 * Rebuild the aggregate stats caches from resolved OVER rows. UNDER rows are
 * filtered out at the query so they never enter the Watchlist WIN% math and the
 * maps carry no dead UNDER buckets.
 */
async function refreshStatsCache(): Promise<void> {
  try {
    const resolved = await db
      .select({
        anomalyType: anomaliesTable.anomalyType,
        targetSide: anomaliesTable.targetSide,
        minuteBucket: anomaliesTable.minuteBucket,
        status: anomaliesTable.status,
        league: anomaliesTable.league,
      })
      .from(anomaliesTable)
      .where(eq(anomaliesTable.targetSide, "OVER"));

    const spec = new Map<string, Bucket>();
    const broad = new Map<string, Bucket>();
    let total = 0;
    for (const r of resolved) {
      if (!matchTargetLeague(r.league)) continue;
      if (r.status !== "WIN" && r.status !== "LOSS") continue;
      total++;
      const win = r.status === "WIN" ? 1 : 0;
      const specKey = `${r.anomalyType}|${r.targetSide}|${r.minuteBucket}`;
      const broadKey = `${r.anomalyType}|${r.targetSide}`;
      const s = spec.get(specKey) ?? { wins: 0, total: 0 };
      s.wins += win;
      s.total++;
      spec.set(specKey, s);
      const b = broad.get(broadKey) ?? { wins: 0, total: 0 };
      b.wins += win;
      b.total++;
      broad.set(broadKey, b);
    }
    specificStats = spec;
    broadStats = broad;
    totalResolved = total;
  } catch (err) {
    logger.error({ err }, "[WIN-RATE] failed to refresh stats cache");
  }
}

/** Load recent anomalies into the active-by-match map (post-restart warm-up). */
async function warmActiveMap(): Promise<void> {
  try {
    const since = new Date(Date.now() - ACTIVE_WINDOW_MS);
    const rows = await db
      .select({
        matchId: anomaliesTable.matchId,
        anomalyType: anomaliesTable.anomalyType,
        targetSide: anomaliesTable.targetSide,
        minuteBucket: anomaliesTable.minuteBucket,
        createdAt: anomaliesTable.createdAt,
        league: anomaliesTable.league,
      })
      .from(anomaliesTable)
      .where(gte(anomaliesTable.createdAt, since))
      .orderBy(desc(anomaliesTable.createdAt));
    // rows are newest-first; only set if we haven't already (keeps the newest).
    for (const r of rows) {
      if (!matchTargetLeague(r.league)) continue;
      if (activeByMatch.has(r.matchId)) continue;
      activeByMatch.set(r.matchId, {
        anomalyType: r.anomalyType as AnomalyType,
        targetSide: r.targetSide as TargetSide,
        minuteBucket: r.minuteBucket as MinuteBucket,
        at: r.createdAt.getTime(),
      });
    }
  } catch (err) {
    logger.error({ err }, "[WIN-RATE] failed to warm active-anomaly map");
  }
}

/** One pass of the resolver: settle eligible PENDING anomalies. */
async function resolvePending(): Promise<void> {
  let pending;
  try {
    pending = await db
      .select()
      .from(anomaliesTable)
      .where(eq(anomaliesTable.status, "PENDING"));
  } catch (err) {
    logger.error({ err }, "[WIN-RATE] failed to load pending anomalies");
    return;
  }

  const now = Date.now();
  let resolvedCount = 0;
  for (const a of pending) {
    if (!matchTargetLeague(a.league)) continue;
    // Anchor all timing windows on absolute kickoff when known, so alerts that
    // fire long before kickoff (pre-match odds drops) aren't mis-resolved off
    // their fire time. Fall back to createdAt when kickoff wasn't captured.
    const anchorMs = a.kickoffAtMs ?? a.createdAt.getTime();
    const age = now - anchorMs;
    if (age < RESOLVE_AFTER_MS) continue;

    const fresh = await fetchFreshScoreNow(a.matchId);
    const haveScore = fresh !== null;
    const force = age >= FORCE_RESOLVE_AFTER_MS;
    const abandon = age >= ABANDON_AFTER_MS;

    // Score feed unavailable: retry until the abandon horizon, then give up.
    if (!haveScore) {
      if (abandon) {
        try {
          await db
            .update(anomaliesTable)
            .set({ status: "VOID", resolvedAt: new Date() })
            .where(and(eq(anomaliesTable.id, a.id), eq(anomaliesTable.status, "PENDING")));
        } catch (err) {
          logger.error({ err, id: a.id }, "[WIN-RATE] failed to abandon anomaly");
        }
      }
      continue; // no score yet — try again next pass
    }

    // state codes: <0 finished, 0 scheduled/postponed, >=1 in-play. We only
    // settle a real WIN/LOSS once the match has truly finished. A not-started
    // match (state 0) past the resolve window is almost certainly postponed —
    // never score it 0:0; abandon it as VOID at the horizon instead.
    const finished = fresh.state !== null && fresh.state < 0;
    const notStarted = fresh.state === 0;

    if (notStarted) {
      if (abandon) {
        try {
          await db
            .update(anomaliesTable)
            .set({ status: "VOID", resolvedAt: new Date() })
            .where(and(eq(anomaliesTable.id, a.id), eq(anomaliesTable.status, "PENDING")));
        } catch (err) {
          logger.error({ err, id: a.id }, "[WIN-RATE] failed to abandon anomaly");
        }
      }
      continue;
    }

    // Not finished and still in-play (or unknown state): wait, unless we've
    // blown past the hard force-resolve cap (feed stuck mid-match), in which
    // case we settle with the latest score we have.
    if (!finished && !force) continue;

    const total = fresh.homeScore + fresh.awayScore;
    const outcome = decideOutcome(a.targetSide as TargetSide, total, a.line);
    try {
      const updated = await db
        .update(anomaliesTable)
        .set({
          status: outcome,
          finalHomeScore: fresh.homeScore,
          finalAwayScore: fresh.awayScore,
          finalTotal: total,
          resolvedAt: new Date(),
        })
        .where(and(eq(anomaliesTable.id, a.id), eq(anomaliesTable.status, "PENDING")))
        .returning({ id: anomaliesTable.id });
      if (updated.length === 0) continue; // already settled by another pass/worker
      resolvedCount++;
      logger.info(
        {
          id: a.id,
          matchId: a.matchId,
          side: a.targetSide,
          line: a.line,
          finalTotal: total,
          outcome,
        },
        "[WIN-RATE] anomaly resolved",
      );
    } catch (err) {
      logger.error({ err, id: a.id }, "[WIN-RATE] failed to resolve anomaly");
    }
  }

  if (resolvedCount > 0) await refreshStatsCache();
}

export function startWinRateTracker(): void {
  generation++;
  const myGen = generation;

  void warmActiveMap();
  void refreshStatsCache();

  const statsLoop = () => {
    statsTimer = setTimeout(async () => {
      if (myGen !== generation) return;
      await refreshStatsCache();
      if (myGen === generation) statsLoop();
    }, STATS_REFRESH_MS);
  };
  statsLoop();

  const resolveLoop = () => {
    resolveTimer = setTimeout(async () => {
      if (myGen !== generation) return;
      try {
        await resolvePending();
      } catch (err) {
        logger.error({ err }, "[WIN-RATE] legacy resolver pass failed");
      }
      try { await resolveDeliveredSignals(); }
      catch (err) { logger.error({ err }, "[SIGNAL-HISTORY] resolver pass failed"); }
      if (myGen === generation) resolveLoop();
    }, RESOLVE_INTERVAL_MS);
  };
  resolveLoop();

  logger.info(
    { resolveIntervalSec: RESOLVE_INTERVAL_MS / 1000, minResolved: MIN_RESOLVED },
    "[WIN-RATE] tracker started",
  );
}

export function stopWinRateTracker(): void {
  generation++;
  if (resolveTimer) {
    clearTimeout(resolveTimer);
    resolveTimer = null;
  }
  if (statsTimer) {
    clearTimeout(statsTimer);
    statsTimer = null;
  }
}

/** Diagnostics accessor (used by tests / future status endpoint). */
export function getWinRateDebug() {
  return { totalResolved, activeMatches: activeByMatch.size };
}

export interface OverallStats {
  /**
   * The side this report covers. Always "OVER": the historical performance
   * report tracks the user's Over strategy exclusively — UNDER anomalies are
   * deliberately excluded so they can't dilute the win-rate.
   */
  side: "OVER";
  /** Counts of OVER anomaly rows by lifecycle status. */
  byStatus: { pending: number; win: number; loss: number; void: number };
  /** Resolved OVER-only totals and the Over-Bet win-rate percentage. */
  resolved: { wins: number; losses: number; total: number; winRatePct: number | null };
  /** Per anomaly-type resolved breakdown (OVER only), largest sample first. */
  byPattern: Array<{
    anomalyType: string;
    targetSide: string;
    wins: number;
    losses: number;
    total: number;
    winRatePct: number | null;
  }>;
}

/**
 * Historical Over-Bet win-rate stats across all recorded anomalies. Read-only
 * aggregate for the dashboard report.
 *
 * Strategy filter: UNDER anomalies are excluded entirely — the report reflects
 * the user's Over strategy only, so speculative under bets never enter the math.
 * Of the remaining OVER rows, only WIN/LOSS count toward the win-rate; PENDING
 * and VOID are reported for visibility but excluded from the percentage.
 */
export interface AnomalyHistoryRow {
  id: number;
  matchId: string;
  team1: string;
  team2: string;
  league: string;
  anomalyType: string;
  source?: "RADAR" | "TELEGRAM" | "LEGACY";
  targetSide: TargetSide | "HOME" | "AWAY" | "";
  line: number | null;
  minuteBucket: MinuteBucket;
  matchMinute: number | null;
  homeScoreAtFire: number | null;
  awayScoreAtFire: number | null;
  oddsAtFire: number | null;
  status: string;
  finalHomeScore: number | null;
  finalAwayScore: number | null;
  finalTotal: number | null;
  createdAt: string;
  resolvedAt: string | null;
}

export interface AnomalyHistoryResult {
  rows: AnomalyHistoryRow[];
  total: number;
  limit: number;
  offset: number;
}

export interface AnomalyHistoryFilter {
  anomalyType?: AnomalyType;
  targetSide?: TargetSide | "HOME" | "AWAY";
  status?: string;
  /** Only return rows created within the last N days. Default: no limit. */
  days?: number;
  limit?: number;
  offset?: number;
}

/**
 * Paginated list of anomaly snapshots for the history view, ordered newest
 * first. Includes all statuses so the operator can audit pending, resolved,
 * and voided signals in one place.
 */
export async function getAnomalyHistory(
  filter: AnomalyHistoryFilter = {},
): Promise<AnomalyHistoryResult> {
  const { anomalyType, targetSide, status, days, limit = 50, offset = 0 } = filter;

  // Build conditions array
  const conditions = [];
  if (anomalyType) conditions.push(eq(anomaliesTable.anomalyType, anomalyType));
  if (targetSide) conditions.push(eq(anomaliesTable.targetSide, targetSide));
  if (status) conditions.push(eq(anomaliesTable.status, status));
  if (days && days > 0) {
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    conditions.push(gte(anomaliesTable.createdAt, since));
  }

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  // League eligibility is a TypeScript matcher (including aliases and
  // qualifier exclusions), so apply it before pagination. This keeps an old
  // non-target row from consuming a visible page slot or inflating `total`.
  const allRows = await db
    .select()
    .from(anomaliesTable)
    .where(where)
    .orderBy(desc(anomaliesTable.createdAt));
  const delivered = (await db.select().from(signalHistoryEntriesTable)
    .orderBy(desc(signalHistoryEntriesTable.createdAt)))
    .filter((r) => r.status !== "AWAITING_ACK");
  // Collapse legacy duplicates before counting or paginating. These are
  // display buckets only, NOT the rolling-window persistence rule above.
  // Keep the earliest row in each bucket, matching the PENDING cleanup plan.
  const buckets = new Map<string, (typeof allRows)[number]>();
  for (const row of allRows) {
    if (!matchTargetLeague(row.league)) continue;
    const key = JSON.stringify([
      row.matchId, row.anomalyType, row.targetSide, row.line,
      Math.floor(row.createdAt.getTime() / DEDUP_TTL_MS),
    ]);
    const earlier = buckets.get(key);
    if (!earlier || row.createdAt < earlier.createdAt ||
        (row.createdAt.getTime() === earlier.createdAt.getTime() && row.id < earlier.id)) {
      buckets.set(key, row);
    }
  }
  const legacy = [...buckets.values()];
  // Ledger rows win over legacy tracker snapshots for the same delivered event.
  // Preserve other historical tracker rows; none of this feeds win-rate math.
  const ledgerRows = delivered.filter((r) =>
    (!anomalyType || r.anomalyType === anomalyType) &&
    (!targetSide || r.targetSide === targetSide) &&
    (!status || r.status === status) &&
    (!days || r.createdAt >= new Date(Date.now() - days * 86_400_000)));
  const visibleLegacy = legacy.filter((row) => !ledgerRows.some((signal) =>
    signal.anomalyType === "SMART_MONEY" && row.anomalyType === "ODDS_DROP" &&
    signal.matchId === row.matchId && signal.targetSide === row.targetSide &&
    signal.line === row.line && Math.abs(signal.createdAt.getTime() - row.createdAt.getTime()) < DEDUP_TTL_MS
  ));
  const collapsed = [...visibleLegacy, ...ledgerRows].sort(
    (a, b) => b.createdAt.getTime() - a.createdAt.getTime() || b.id - a.id,
  );
  const rows = collapsed.slice(offset, offset + limit);
  const total = collapsed.length;

  return {
    rows: rows.map((r) => ({
      id: ledgerRows.some((entry) => entry === r) ? -r.id : r.id,
      matchId: r.matchId ?? "",
      team1: r.team1,
      team2: r.team2,
      league: r.league,
      anomalyType: r.anomalyType,
      source: ledgerRows.some((entry) => entry === r)
        ? r.anomalyType.startsWith("RADAR_") ? "RADAR" : "TELEGRAM"
        : "LEGACY",
      targetSide: (r.targetSide ?? "") as AnomalyHistoryRow["targetSide"],
      line: r.line,
      minuteBucket: r.minuteBucket as MinuteBucket,
      matchMinute: r.matchMinute,
      homeScoreAtFire: r.homeScoreAtFire,
      awayScoreAtFire: r.awayScoreAtFire,
      oddsAtFire: r.oddsAtFire,
      status: r.status,
      finalHomeScore: r.finalHomeScore,
      finalAwayScore: r.finalAwayScore,
      finalTotal: r.finalTotal,
      createdAt: r.createdAt.toISOString(),
      resolvedAt: r.resolvedAt?.toISOString() ?? null,
    })),
    total,
    limit,
    offset,
  };
}

export async function getOverallStats(): Promise<OverallStats> {
  const rows = await db
    .select({
      anomalyType: anomaliesTable.anomalyType,
      targetSide: anomaliesTable.targetSide,
      status: anomaliesTable.status,
      league: anomaliesTable.league,
      count: sql<number>`count(*)::int`,
    })
    .from(anomaliesTable)
    .where(eq(anomaliesTable.targetSide, "OVER"))
    .groupBy(
      anomaliesTable.anomalyType,
      anomaliesTable.targetSide,
      anomaliesTable.status,
      anomaliesTable.league,
    );

  const byStatus = { pending: 0, win: 0, loss: 0, void: 0 };
  const patternMap = new Map<string, { anomalyType: string; targetSide: string; wins: number; losses: number }>();

  for (const r of rows) {
    if (!matchTargetLeague(r.league)) continue;
    const n = r.count;
    switch (r.status) {
      case "PENDING":
        byStatus.pending += n;
        break;
      case "WIN":
        byStatus.win += n;
        break;
      case "LOSS":
        byStatus.loss += n;
        break;
      case "VOID":
        byStatus.void += n;
        break;
    }
    if (r.status !== "WIN" && r.status !== "LOSS") continue;
    const key = `${r.anomalyType}|${r.targetSide}`;
    const p =
      patternMap.get(key) ?? { anomalyType: r.anomalyType, targetSide: r.targetSide, wins: 0, losses: 0 };
    if (r.status === "WIN") p.wins += n;
    else p.losses += n;
    patternMap.set(key, p);
  }

  const wins = byStatus.win;
  const losses = byStatus.loss;
  const total = wins + losses;
  const byPattern = [...patternMap.values()]
    .map((p) => {
      const t = p.wins + p.losses;
      return {
        anomalyType: p.anomalyType,
        targetSide: p.targetSide,
        wins: p.wins,
        losses: p.losses,
        total: t,
        winRatePct: t > 0 ? Math.round((p.wins / t) * 100) : null,
      };
    })
    .sort((a, b) => b.total - a.total);

  return {
    side: "OVER",
    byStatus,
    resolved: {
      wins,
      losses,
      total,
      winRatePct: total > 0 ? Math.round((wins / total) * 100) : null,
    },
    byPattern,
  };
}
