/** Parse data-only NowGoal array literals; never execute upstream JavaScript. */
function fields(text: string): Array<string | number> | null {
  const result: Array<string | number> = [];
  const token = /\s*(?:'((?:[^'\\]|\\.)*)'|(-?\d+(?:\.\d+)?))\s*(,|$)/gy;
  let offset = 0;
  while (offset < text.length) {
    token.lastIndex = offset;
    const match = token.exec(text);
    if (!match) return null;
    result.push(match[1] !== undefined
      ? match[1].replace(/\\(['\\])/g, "$1")
      : Number(match[2]));
    offset = token.lastIndex;
  }
  return result;
}

export interface DiscoveryCandidate {
  team1: string;
  team2: string;
  leagueId: string;
  leagueName: string;
  homeScore: number;
  awayScore: number;
  kickoffMs: number | null;
  // A[] is discovery evidence ONLY. type=11 must supply state and scoreboard.
  isLive: false;
}

export function parseLiveDirectory(text: string) {
  const leagues = new Map<string, string>();
  const candidates = new Map<string, DiscoveryCandidate>();
  const json = JSON.parse(text);
  if (json.ErrCode !== 0 || typeof json.Data !== "string") throw new Error("Invalid live directory envelope");
  const directory = new Map<number, { id: string; name: string }>();
  for (const match of json.Data.matchAll(/B\[(\d+)\]\s*=\s*\[((?:[^\]'\\]|'(?:[^'\\]|\\.)*')*)\]/g)) {
    const row = fields(match[2]);
    if (!row || typeof row[0] !== "number" || typeof row[2] !== "string") continue;
    const entry = { id: String(row[0]), name: row[2].trim() };
    directory.set(Number(match[1]), entry);
    leagues.set(entry.id, entry.name);
  }
  for (const match of json.Data.matchAll(/A\[\d+\]\s*=\s*\[((?:[^\]'\\]|'(?:[^'\\]|\\.)*')*)\]/g)) {
    const row = fields(match[1]);
    if (!row || typeof row[0] !== "number" || typeof row[1] !== "number" ||
        typeof row[7] !== "number" || row[7] < 1 ||
        typeof row[4] !== "string" || !row[4] || typeof row[5] !== "string" || !row[5]) continue;
    const league = directory.get(row[1]);
    if (!league) continue;
    const time = typeof row[6] === "string" && /^\d{4},\d{1,2},\d{1,2},\d{1,2},\d{1,2},\d{1,2}$/.test(row[6])
      ? row[6].split(",").map(Number) : null;
    candidates.set(String(row[0]), {
      team1: row[4], team2: row[5], leagueId: league.id, leagueName: league.name,
      homeScore: 0, awayScore: 0,
      kickoffMs: time ? Date.UTC(time[0], time[1], time[2], time[3], time[4], time[5]) - 8 * 3600_000 : null,
      isLive: false,
    });
  }
  return { leagues, candidates };
}