import { afterEach, describe, expect, it, vi } from "vitest";
import { diagnosticsOwner, formatDiagnostics, getExcapperDiagnostics, recordExcapperCardDelivered,
  ExcapperObservationCounter, STALL_MS, REPEAT_MS, TelegramDiagnostics, type DiagnosticsSnapshot } from "./telegramDiagnostics";

function snapshot(): DiagnosticsSnapshot {
  return {
    scanner: { expectedActive: true, lastCompletedAt: null, matchesTracked: 12, liveNow: 3, lastAlertAt: null },
    radar: { expectedActive: false, lastCompletedAt: null, cooldownSignals: 2 },
    excapper: { expectedActive: false, lastCompletedAt: null, lastStartedAt: null, transactionsOver500: 4, lastCardAt: null },
    dropThreshold: 0.15, tunerState: "collecting",
  };
}
const ownerMessage = { from: { id: 123 }, chat: { id: 123, type: "private" } };
afterEach(() => vi.useRealTimers());

describe("owner diagnostics", () => {
  it("fails closed without an explicit trusted owner user id", () => {
    expect(diagnosticsOwner({ TELEGRAM_CHAT_ID: "123" })).toBeNull();
    for (const value of ["-123", "0", "invalid", "1.5"]) expect(diagnosticsOwner({ TELEGRAM_OWNER_USER_ID: value })).toBeNull();
    expect(diagnosticsOwner({ TELEGRAM_OWNER_USER_ID: "123" })).toBe("123");
  });
  it("rejects unauthorized senders, alternate chats, groups and missing sender", async () => {
    const read = vi.fn(snapshot), send = vi.fn();
    const service = new TelegramDiagnostics("123", read, send, "boot", 0);
    for (const message of [
      { from: { id: 456 }, chat: { id: 123, type: "private" } },
      { from: { id: 123 }, chat: { id: 456, type: "private" } },
      { from: { id: 123 }, chat: { id: 123, type: "group" } },
      { from: { id: 123 }, chat: { id: -123, type: "supergroup" } },
      { chat: { id: 123, type: "private" } },
    ]) for (const command of ["/status", "/diagnostics_off", "/diagnostics_on"]) await service.command(message, command);
    expect(send).not.toHaveBeenCalled();
    expect(read).not.toHaveBeenCalled();
  });
  it("renders every requested field from local state", async () => {
    vi.useFakeTimers(); vi.setSystemTime(60_000);
    const send = vi.fn();
    const service = new TelegramDiagnostics("123", snapshot, send, "boot-test", 0);
    await service.command(ownerMessage, "/status");
    expect(send).toHaveBeenCalledWith("123", formatDiagnostics(snapshot(), "boot-test", 0, 60_000, true));
    const card = send.mock.calls[0][1];
    for (const text of ["Odds scanner: alive", "last scan never", "matches tracked 12", "live now 3", "last alert never",
      "ODDS RADAR: paused", "last check never", "signals in cooldown 2", "Excapper monitor: paused",
      "last poll never", "observed >=€500 tx in last hour 4 (per-game baseline since boot)", "last SMART EXCAPPER card never",
      "boot-test", "uptime 60s", "dropThreshold: 0.15", "tuner state: collecting"]) expect(card).toContain(text);
  });
  it("uses five minute boot grace, one warning, bounded repeats and one recovery for a paused test loop expected active", async () => {
    vi.useFakeTimers(); vi.setSystemTime(0);
    const state = snapshot(), send = vi.fn(async (_owner: string, _text: string) => "ok");
    const service = new TelegramDiagnostics("123", () => state, send, "boot", 0);
    service.start();
    await vi.advanceTimersByTimeAsync(STALL_MS);
    expect(send).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(30_000);
    expect(send).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(REPEAT_MS - 30_000);
    expect(send).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(30_000);
    expect(send).toHaveBeenCalledTimes(2);
    state.scanner.lastCompletedAt = Date.now() + 1;
    await vi.advanceTimersByTimeAsync(60_000);
    expect(send).toHaveBeenCalledTimes(3);
    expect(send.mock.calls[2][1]).toContain("recovered");
    service.stop();
  });
  it("mutes indefinitely until on, retaining a pending recovery", async () => {
    vi.useFakeTimers(); vi.setSystemTime(0);
    const state = snapshot(), send = vi.fn(async (_owner: string, _text: string) => "ok");
    const service = new TelegramDiagnostics("123", () => state, send, "boot", 0);
    await service.check(STALL_MS + 1);
    await service.command(ownerMessage, "/diagnostics_off");
    send.mockClear();
    await service.check(REPEAT_MS * 10);
    expect(send).not.toHaveBeenCalled();
    vi.setSystemTime(REPEAT_MS * 10);
    state.scanner.lastCompletedAt = Date.now();
    await service.command(ownerMessage, "/diagnostics_on");
    send.mockClear();
    await service.check();
    await service.check();
    expect(send).toHaveBeenCalledTimes(1);
    expect(send.mock.calls[0][1]).toContain("recovered");
  });
  it("baselines each game and counts new observed rows without resurrecting expired repeats", () => {
    const now = 10_000_000;
    const counter = new ExcapperObservationCounter();
    const baseline = [{ id: "historical", change: 1000 }];
    counter.record("game", baseline, now);
    expect(counter.count(now)).toBe(0);
    const rows = [...baseline, { id: "new", change: 500 }, { id: "small", change: 499 }];
    counter.record("game", rows, now + 1);
    counter.record("game", rows, now + 2);
    expect(counter.count(now + 2)).toBe(1);
    counter.record("another-game", rows, now + 3);
    expect(counter.count(now + 3)).toBe(1);
    expect(counter.count(now + 3_600_001)).toBe(0);
    counter.record("game", rows, now + 3_600_002);
    expect(counter.count(now + 3_600_002)).toBe(0);
    expect(getExcapperDiagnostics(now).lastCardAt).toBeNull();
    recordExcapperCardDelivered(now);
    expect(getExcapperDiagnostics(now).lastCardAt).toBe(now);
  });
  it("does not reject observations because the opaque source clock appears in the future", () => {
    const counter = new ExcapperObservationCounter();
    const now = Date.parse("2026-09-24T22:28:00Z");
    counter.record("game", [], now - 1);
    counter.record("game", [{ id: "game:over:1000:01:28 25.09", change: 1000 }], now);
    expect(counter.count(now)).toBe(1);
    counter.record("game", [{ id: "out-of-order", change: 1000 }], now - 1);
    expect(counter.count(now)).toBe(1);
  });
  it("re-baselines games absent beyond retention instead of recounting old history", () => {
    const counter = new ExcapperObservationCounter();
    counter.record("game", [], 0);
    const rows = [{ id: "new", change: 700 }];
    counter.record("game", rows, 1);
    expect(counter.count(1)).toBe(1);
    counter.record("game", rows, 25 * 3_600_000);
    expect(counter.count(25 * 3_600_000)).toBe(0);
  });
});