/**
 * Excapper.com manual watchlist hydrator.
 *
 * Pulls real Betfair-exchange traded volume for our watchlist matches and
 * feeds it back into scanner state so the dashboard can render per-side
 * money flow (VOL O / VOL U) alongside the Bet365 odds.
 *
 * --- ARCHITECTURE ---
 *
 *  Coordinated cycle (target ~12s for priority/live work; capacity permitting):
 *    1. Existing bindings fetch their saved full-detail event pages sequentially.
 *    2. Unresolved manual rows share the root identity directory, then inspect
 *       only plausible live candidates (never the complete directory).
 *    3. Parsed detail observations are cached for 12s; raw HTML is not retained.
 *
 * --- POLITENESS ---
 *
 *  Manual and coordinator callers share root/detail single-flight caches. The
 *  central transport owns serialization, jitter and upstream backoff.
 *
 *  Anti-leak guards:
 *    - Generation counter (mirrors scanner.ts pattern) prevents in-flight
 *      cycles from resurrecting the timer after stop().
 *    - AbortController cancels every in-flight HTTP on stop().
 *
 * --- ASSUMPTIONS DOCUMENTED ---
 *
 *  - Directory <tr class="a_link" game_id="NNN">...</tr> row layout is the
 *    contract. If Excapper changes column order, fix parseDirectory().
 *  - Per-game tabs are named "Over/Under X.5 Goals" and contain exactly two
 *    `.charts-bk__item` blocks labeled "Over"/"Under" with a coef of the
 *    form "NNN[currency marker] - O.OO". If they move to JS-rendered or change the label,
 *    parseGamePage() returns null and we log a debug line.
 */
import { logger } from "./logger";
import { chooseBaseBinding, parseBindingKickoff } from "./excapperScoring";
import { parseExcapperBetTime } from "./prebetAnalysis";
import { recordExcapperSnapshot } from "./telegramDiagnostics";
import { getAutomaticExcapperCandidates } from "./scanner";
import { parseExcapperLiveState, stripExcapperHtmlComments, type ExcapperLivePeriod } from "./excapperLiveState";
import {
  isExcapperBreakerOpen,
  excapperBreakerRemainingMs,
  getExcapperHealth,
  onExcapperRecovery,
} from "./excapperBackoff";
import {
  getManualWatchlistMatchesForExcapper,
  refreshManualBindingEvidence,
  hydrateManualMatchVolume,
  canHydrateManualMatchVolume,
  clearManualMatchVolumeBinding,
  hasManualExcapperHydrationMembership,
  getManualVolumeAlertContext,
  type ManualExcapperHydrationCandidate,
} from "./scanner";
import { EXCAPPER_BASE_URL } from "./config";
import { matchTargetLeague } from "./targetLeagues";
import {
  fetchExcapperText,
  fetchSharedExcapperGamePage,
  getExcapperResponseObservedAt,
} from "./excapperSharedFetch";
import {
  loadExcapperBatchSnapshot,
  getExcapperBatchStatus,
  parseExcapperStructuredRows,
  type ExcapperBatchSnapshot,
} from "./excapperBatch";
import {
  queueManualWatchlistVolumeDigest,
  type ManualVolumeObservation,
} from "./manualWatchlistVolumeAlerts";
import { normalizedTeamName } from "./teamIdentity";
import {
  initManualBindingBlocks,
  persistManualBindingBlock,
  persistManualBindingReset,
  removeManualBindingBlock,
} from "./manualBindingBlocks";
import { createHash } from "node:crypto";
import {
  createBindingDecision,
  recordBindingDecision,
  type BindingDecision,
  type BindingFixtureEvidence,
} from "./bindingDecisionAudit";
import {
  forgetPersistedManualBinding,
  getPersistedManualBindings,
  initManualBindingsStore,
  manualBindingsUseTestFile,
  removePersistedManualBinding,
  savePersistedManualBinding,
  type PersistedManualBinding,
} from "./manualBindingsStore";
import {
  approveManualLeagueAlias as persistManualLeagueAlias,
  manualLeagueAliasMatches,
} from "./manualLeagueAliases";
import {
  forceManualVerifiedIds,
  lastBatchHydratedAt,
  manualBindingCache,
  manualBindingEpoch,
} from "./excapperBindingRuntime";
export { normalizedTeamName } from "./teamIdentity";

// Target cadence only: the shared max-one queue intentionally allows actual
// completion cadence to stretch under load.
const FETCH_TIMEOUT_MS = 20_000;
const BASE_URL = EXCAPPER_BASE_URL;
// NOTE: per-request UA selection is delegated to `pickUserAgent()` from
// excapperBackoff.ts (rotating pool defined in config.ts). The old per-file
// single-UA constant was removed during the config.ts extraction — every
// outbound Excapper fetch now uses `pickUserAgent()` directly.

let scraperRunning = false;
let scraperGeneration = 0;
let abortController: AbortController | null = null;

/**
 * One parsed row from the Excapper live-directory page. `totalVolume` is
 * the running native-feed money total across all OU lines for the match (Excapper shows
 * it in the right-most column). Used by the GLOBAL volume scanner to
 * filter out dead matches BEFORE the expensive per-game page fetch.
 */
export interface DirectoryRow {
  gameId: string;
  team1: string;
  team2: string;
  league: string;
  totalVolume: number;
  /** Narrow upstream classification only; absent/unknown is treated prematch. */
  isLive?: boolean;
  activity?: "live" | "scheduled" | "unknown";
  countryCode?: string | null;
  kickoffText?: string | null;
  liveScore?: { home: number; away: number } | null;
  livePeriod?: ExcapperLivePeriod | null;
  liveMinute?: number | null;
  observedTime?: string | null;
}

export interface ManualExcapperBinding {
  matchId: string;
  gameId: string;
  nowGoalLine: number | null;
  league: string;
  /** Numeric evidence score from the initial, full identity validation. */
  confidence: number;
  bindingMode?: "automatic" | "manual_override";
}

interface QualifiedSecondaryBinding {
  gameId: string;
  confidence: number;
}

export interface CachedManualExcapperBinding extends ManualExcapperBinding {
  canonicalUrl: string;
  diagnosticId: string;
  source: NonNullable<ExcapperBindingDiagnostic["source"]>;
  auditEvidence?: { target: BindingFixtureEvidence; source: BindingFixtureEvidence };
}

const MANUAL_BINDING_MIN_CONFIDENCE = 0.50;
/** Fixture-lifetime cache. Entries are replaced only after explicit release. */
/** Verified identity-only overrides intentionally have no fetchable source id. */

export type ExcapperBindingStatus =
  | "source_unavailable"
  | "no_directory_match"
  | "ambiguous_identity"
  | "missing_league_alias"
  | "non_live_candidate"
  | "missing_live_corroboration"
  | "score_period_conflict"
  | "empty_market"
  | "bound_pending"
  | "bound_verified"
  | "identity_only"
  | "hydrated"
  | "pending"
  | "fetch_failed";

export interface ExcapperBindingDiagnostic {
  bindingDecision?: LatestBindingDecision;
  status: ExcapperBindingStatus;
  source: {
    team1: string; team2: string; league: string;
    score?: { home: number; away: number } | null;
    period?: ExcapperLivePeriod | null;
    minute?: number | null;
  } | null;
  target: {
    team1: string;
    team2: string;
    league: string;
    score?: { home: number; away: number } | null;
    period?: DirectoryRow["livePeriod"];
    minute?: number | null;
  } | null;
  /** Epoch milliseconds for the last volume sample actually accepted. */
  lastSuccessfulUpdateAt: number | null;
  /** Opaque handle for the exact server-resolved candidate; never a URL/id. */
  resolvedCandidate?: string | null;
  /** Explicit source identifier shown to and approved by the operator. */
  candidateExcapperId?: string | null;
  candidates?: ExcapperReviewCandidate[];
  bindingMode?: "automatic" | "manual_override";
}

export interface ExcapperReviewCandidate {
  ref: string;
  gameId: string;
  source: { team1: string; team2: string; league: string };
  score: { home: number; away: number } | null;
  period: DirectoryRow["livePeriod"];
  minute: number | null;
  observedTime: string | null;
  capturedAt: number;
  conflict: "none" | "score" | "timing" | "missing";
}

const excapperBindingDiagnostics = new Map<string, ExcapperBindingDiagnostic>();
type BaseDecision = ReturnType<typeof chooseBaseBinding>;
export interface LatestBindingDecision {
  status: "bound" | "unbound" | "ambiguous" | "manual";
  reason: string;
  candidateCount: number;
  chosenId: string | null;
  thresholds: BaseDecision["thresholds"];
  scored: BaseDecision["scored"];
  evaluatedAt: string;
  candidateAttempt?: { status: LatestBindingDecision["status"]; reason: string; chosenId: string | null };
  manualEvidence?: {
    source: ExcapperBindingDiagnostic["source"];
    target: ExcapperBindingDiagnostic["target"];
    normalizedSourceHome: string | null;
    normalizedSourceAway: string | null;
    normalizedTargetHome: string | null;
    normalizedTargetAway: string | null;
    contributions: null;
    gates: null;
  };
}
const latestBindingDecisions = new Map<string, LatestBindingDecision>();
function manualDecisionEvidence(id: string): LatestBindingDecision["manualEvidence"] {
  const diagnostic = excapperBindingDiagnostics.get(id);
  const source = diagnostic?.source ?? null;
  const target = diagnostic?.target ?? null;
  return { source, target,
    normalizedSourceHome: source?.team1 ? normalizedTeamName(source.team1) : null,
    normalizedSourceAway: source?.team2 ? normalizedTeamName(source.team2) : null,
    normalizedTargetHome: target?.team1 ? normalizedTeamName(target.team1) : null,
    normalizedTargetAway: target?.team2 ? normalizedTeamName(target.team2) : null,
    contributions: null, gates: null };
}
function publishBindingDecision(id: string, decision: BaseDecision, status: LatestBindingDecision["status"], reason: string): void {
  const next: LatestBindingDecision = { status, reason, candidateCount: decision.scored.length,
    chosenId: status === "bound" ? decision.chosen?.id ?? null : null,
    thresholds: decision.thresholds, scored: decision.scored.slice(0, 10), evaluatedAt: new Date().toISOString() };
  if (status === "manual") {
    next.manualEvidence = manualDecisionEvidence(id);
    next.chosenId = manualBindingCache.get(id)?.gameId ?? null;
  }
  const previous = latestBindingDecisions.get(id);
  // Keep one bounded snapshot per fixture; log changes only, not every poll.
  if (previous && JSON.stringify({ ...previous, evaluatedAt: null }) === JSON.stringify({ ...next, evaluatedAt: null })) return;
  latestBindingDecisions.delete(id);
  latestBindingDecisions.set(id, next);
  while (latestBindingDecisions.size > 1000) latestBindingDecisions.delete(latestBindingDecisions.keys().next().value!);
  logger.info({ matchId: id, bindingDecision: next }, "[EXCAPPER] Binding decision");
}
const leagueMismatchCandidates = new Map<string, {
  ref: string;
  gameId: string;
  source: NonNullable<ExcapperBindingDiagnostic["source"]>;
  target: NonNullable<ExcapperBindingDiagnostic["target"]>;
}>();
const reviewCandidates = new Map<string, Array<{
  ref: string;
  gameId: string;
  source: NonNullable<ExcapperBindingDiagnostic["source"]>;
  target: NonNullable<ExcapperBindingDiagnostic["target"]>;
  row: DirectoryRow;
  capturedAt: number;
}>>();
/** A reset is fixture-specific: other candidates remain eligible, this one requires explicit review. */
const blockedAutoPairs = new Set<string>();
let bindingBlockDependencies = {
  load: initManualBindingBlocks,
  persist: persistManualBindingBlock,
  reset: persistManualBindingReset,
  remove: removeManualBindingBlock,
};

export function __testOnlySetBindingBlockDependencies(
  overrides?: Partial<typeof bindingBlockDependencies>,
): void {
  bindingBlockDependencies = overrides
    ? { ...bindingBlockDependencies, ...overrides }
    : {
        load: initManualBindingBlocks,
        persist: persistManualBindingBlock,
        reset: persistManualBindingReset,
        remove: removeManualBindingBlock,
      };
}

export async function initManualExcapperBindingBlocks(): Promise<void> {
  const [rows, persistedBindings] = await Promise.all([
    bindingBlockDependencies.load(),
    initManualBindingsStore(),
  ]);
  blockedAutoPairs.clear();
  for (const row of rows) {
    blockedAutoPairs.add(`${row.diagnosticId}\u0000${row.gameId}`);
  }
  for (const binding of persistedBindings) {
    // A durable reset block wins over a stale positive JSON record left behind
    // by an interrupted/failed delete.
    if (rows.some((row) =>
      row.diagnosticId === binding.nowgoalId &&
      (row.gameId === binding.excapperId || row.gameId === "*")
    )) {
      removeCachedManualBinding(binding.nowgoalId);
      excapperBindingDiagnostics.delete(binding.nowgoalId);
      latestBindingDecisions.delete(binding.nowgoalId);
      continue;
    }
    installPersistedManualBinding(binding);
  }
}

function installPersistedManualBinding(binding: PersistedManualBinding): void {
  const source = binding.source ?? { team1: "", team2: "", league: "" };
  const current = manualBindingCache.get(binding.nowgoalId);
  if (current && (
    current.gameId !== binding.excapperId ||
    current.source.team1 !== source.team1 ||
    current.source.team2 !== source.team2 ||
    current.source.league !== source.league
  )) {
    clearManualMatchVolumeBinding(binding.nowgoalId);
  }
  // Invalidate any discovery/hydration operation that captured the previous
  // generation before this operator override was persisted.
  removeCachedManualBinding(binding.nowgoalId);
  const automatic = binding.autoBound === true;
  if (binding.excapperId !== "FORCE_MANUAL") {
    forceManualVerifiedIds.delete(binding.nowgoalId);
    manualBindingCache.set(binding.nowgoalId, {
      matchId: binding.nowgoalId,
      gameId: binding.excapperId,
      diagnosticId: binding.diagnosticId ?? binding.nowgoalId,
      nowGoalLine: null,
      league: source.league,
      confidence: automatic ? MANUAL_BINDING_MIN_CONFIDENCE : 0,
      bindingMode: automatic ? "automatic" : "manual_override",
      canonicalUrl: canonicalGameUrl(binding.excapperId),
      source,
    });
  } else forceManualVerifiedIds.add(binding.nowgoalId);
  excapperBindingDiagnostics.set(binding.nowgoalId, {
    status: binding.excapperId === "FORCE_MANUAL" ? "identity_only" : "bound_pending",
    source,
    target: null,
    lastSuccessfulUpdateAt: null,
    candidateExcapperId: binding.excapperId === "FORCE_MANUAL" ? null : binding.excapperId,
    bindingMode: automatic ? "automatic" : "manual_override",
  });
  if (!automatic) publishBindingDecision(binding.nowgoalId,
    chooseBaseBinding({ id: binding.nowgoalId, team1: "", team2: "", league: "", kickoffMs: null }, []),
    "manual", "Operator verification restored from durable binding");
}

function diagnosticIdentity(candidate: ManualExcapperHydrationCandidate): string {
  return candidate.diagnosticId ?? candidate.matchId;
}

function bindingEvidence(candidate: ManualExcapperHydrationCandidate, row: DirectoryRow) {
  return {
    target: {
      id: candidate.matchId, home: candidate.team1, away: candidate.team2,
      league: candidate.league || null,
      score: candidate.homeScore != null && candidate.awayScore != null
        ? { home: candidate.homeScore, away: candidate.awayScore } : null,
      period: candidate.state === 1 ? "first-half" : candidate.state === 3
        ? "second-half" : candidate.state === 2 ? "half-time" : null,
      minute: candidate.liveMinute ?? null,
    },
    source: {
      id: row.gameId, home: row.team1, away: row.team2, league: row.league || null,
      score: row.liveScore ?? null, period: row.livePeriod ?? null,
      minute: row.liveMinute ?? null,
    },
  };
}
function safeSource(row: DirectoryRow): ExcapperBindingDiagnostic["source"] {
  return {
    team1: row.team1, team2: row.team2, league: row.league,
    score: row.liveScore ?? null,
    period: row.livePeriod ?? null,
    minute: row.liveMinute ?? null,
  };
}

function candidateRef(diagnosticId: string, row: DirectoryRow): string {
  return createHash("sha256")
    .update(`${diagnosticId}\u0000${row.gameId}\u0000${row.league}\u0000${row.team1}\u0000${row.team2}`)
    .digest("base64url");
}

function safeTarget(
  candidate: ManualExcapperHydrationCandidate,
): ExcapperBindingDiagnostic["target"] {
  return {
    team1: candidate.team1,
    team2: candidate.team2,
    league: candidate.league,
    ...(candidate.homeScore == null || candidate.awayScore == null
      ? {}
      : { score: { home: candidate.homeScore, away: candidate.awayScore } }),
    ...(nowGoalPeriod(candidate.state ?? null)
      ? { period: nowGoalPeriod(candidate.state ?? null) }
      : {}),
    ...("liveMinute" in candidate ? { minute: candidate.liveMinute ?? null } : {}),
  };
}

function recordExcapperBindingDiagnostic(
  matchId: string,
  status: ExcapperBindingStatus,
  source?: ExcapperBindingDiagnostic["source"],
  successfulAt?: number,
  target?: ExcapperBindingDiagnostic["target"],
): void {
  const previous = excapperBindingDiagnostics.get(matchId);
  if (!latestBindingDecisions.has(matchId)) {
    const empty = chooseBaseBinding({ id: matchId, team1: target?.team1 ?? "",
      team2: target?.team2 ?? "", league: target?.league ?? "", kickoffMs: null }, []);
    publishBindingDecision(matchId, empty, status === "ambiguous_identity" ? "ambiguous" :
      status === "bound_verified" || status === "hydrated" ? "bound" : "unbound", status);
  }
  const reviews = (
    status === "ambiguous_identity" ||
    status === "missing_league_alias" ||
    status === "missing_live_corroboration" ||
    status === "score_period_conflict"
  ) ? (reviewCandidates.get(matchId) ?? []) : [];
  const resolvedCandidate = reviews.length === 1
    ? reviews[0]!.ref
    : status === "missing_league_alias"
      ? leagueMismatchCandidates.get(matchId)?.ref ?? null
      : null;
  excapperBindingDiagnostics.set(matchId, {
    status,
    source: source === undefined ? (previous?.source ?? null) : source,
    target: target === undefined ? (previous?.target ?? null) : target,
    // Failures and feed-health changes must never erase evidence of the most
    // recent accepted hydration.
    lastSuccessfulUpdateAt:
      successfulAt ?? previous?.lastSuccessfulUpdateAt ?? null,
    ...(resolvedCandidate ? { resolvedCandidate } : {}),
    ...((reviews[0]?.gameId ?? leagueMismatchCandidates.get(matchId)?.gameId)
      ? { candidateExcapperId: reviews[0]?.gameId ?? leagueMismatchCandidates.get(matchId)!.gameId }
      : {}),
    ...(reviews.length ? {
      candidates: reviews.map(({ ref, gameId, source, row, capturedAt }) => ({
        ref,
        gameId,
        source: { ...source },
        score: row.liveScore ? { ...row.liveScore } : null,
        period: row.livePeriod ?? null,
        minute: row.liveMinute ?? null,
        observedTime: row.observedTime ?? null,
        capturedAt,
        conflict: status === "score_period_conflict"
          ? "score"
          : status === "missing_live_corroboration"
            ? "missing"
            : status === "ambiguous_identity"
              ? "timing"
              : "none",
      })),
    } : {}),
  });
}

function recordManualCandidateDiagnostic(
  candidate: ManualExcapperHydrationCandidate,
  status: ExcapperBindingStatus,
  source?: ExcapperBindingDiagnostic["source"],
  successfulAt?: number,
): void {
  recordExcapperBindingDiagnostic(
    diagnosticIdentity(candidate),
    status,
    source,
    successfulAt,
    safeTarget(candidate),
  );
}

export function getExcapperBindingDiagnostic(
  matchId: string,
): ExcapperBindingDiagnostic {
  const value = excapperBindingDiagnostics.get(matchId);
  const cachedBinding = [...manualBindingCache.values()].find(
    (binding) => binding.diagnosticId === matchId,
  );
  const persisted = getPersistedManualBindings().find((row) =>
    row.nowgoalId === matchId || (row.signature && `manual-text:${row.signature}` === matchId));
  const persistedAllowed = persisted &&
    !blockedAutoPairs.has(`${persisted.nowgoalId}\u0000*`) &&
    !blockedAutoPairs.has(`${persisted.nowgoalId}\u0000${persisted.excapperId}`);
  const manual = !!(persistedAllowed && persisted.autoBound !== true) ||
    forceManualVerifiedIds.has(matchId) || cachedBinding?.bindingMode === "manual_override";
  // Hydration/retirement can remove runtime caches independently of the
  // durable operator approval. Read identity from that record, never from a
  // review candidate or a generic "hydrated" diagnostic.
  const manualGameId = persistedAllowed && persisted.autoBound !== true
    ? (/^\d+$/.test(persisted.excapperId) ? persisted.excapperId : null)
    : cachedBinding && /^\d+$/.test(cachedBinding.gameId) ? cachedBinding.gameId : null;
  const latest = latestBindingDecisions.get(matchId);
  const bindingDecision: LatestBindingDecision | undefined = manual ? {
    status: "manual", reason: "Operator verified identity; source quotes remain independently observed.",
    candidateCount: latest?.candidateCount ?? 0, chosenId: manualGameId,
    thresholds: latest?.thresholds ?? chooseBaseBinding({ id: matchId, team1: "", team2: "", league: "", kickoffMs: null }, []).thresholds,
    scored: latest?.scored ?? [], evaluatedAt: latest?.evaluatedAt ??
      getPersistedManualBindings().find((row) => row.nowgoalId === matchId)?.boundAt ?? new Date().toISOString(),
    manualEvidence: manualDecisionEvidence(matchId),
    ...(latest ? { candidateAttempt: {
      status: latest.status === "bound" && latest.chosenId === null ? "unbound" as const : latest.status,
      reason: latest.reason, chosenId: latest.chosenId,
    } } : {}),
  } : latest;
  return value
    ? {
        ...value,
        ...(bindingDecision ? { bindingDecision: structuredClone(bindingDecision) } : {}),
        source: value.source ? { ...value.source } : null,
        target: value.target ? { ...value.target } : null,
        ...(cachedBinding?.bindingMode ? { bindingMode: cachedBinding.bindingMode } : {}),
        ...(cachedBinding ? { candidateExcapperId: cachedBinding.gameId } : {}),
        ...(manual ? { status: manualGameId ? value.lastSuccessfulUpdateAt != null &&
            (value.status === "hydrated" || value.status === "bound_verified")
            ? value.status : "bound_pending" as const : "identity_only" as const,
          bindingMode: "manual_override" as const, candidateExcapperId: manualGameId } : {}),
      }
    : {
        status: "pending",
        source: manual && persistedAllowed ? persisted.source ?? null : null,
        target: null,
        lastSuccessfulUpdateAt: null,
        ...(bindingDecision ? { bindingDecision: structuredClone(bindingDecision) } : {}),
        ...(manual ? { status: manualGameId ? "bound_pending" as const : "identity_only" as const, bindingMode: "manual_override" as const,
          candidateExcapperId: manualGameId } : {}),
      };
}

/**
 * Add the public, allowlisted diagnostic contract without exposing request
 * URLs, exception strings, or any other upstream/internal metadata.
 */
export function withExcapperBindingDiagnostics<
  T extends { entries: Array<{ matchId?: string | null; signature: string }> },
>(snapshot: T): Omit<T, "entries"> & {
  entries: Array<T["entries"][number] & { excapperBinding: ExcapperBindingDiagnostic }>;
  excapperBatch: ReturnType<typeof getExcapperBatchStatus> & { mode: "sequential" };
} {
  return {
    ...snapshot,
    excapperBatch: { ...getExcapperBatchStatus(), mode: "sequential" },
    entries: snapshot.entries.map((entry) => ({
      ...entry,
      excapperBinding: getExcapperBindingDiagnostic(
        entry.matchId ?? `manual-text:${entry.signature}`,
      ),
    })),
  };
}

/** Test seam for the in-memory diagnostic overlay only. */
export function __testOnlyResetExcapperBindingDiagnostics(): void {
  latestBindingDecisions.clear();
  excapperBindingDiagnostics.clear();
  leagueMismatchCandidates.clear();
  reviewCandidates.clear();
}

/** Test seam used to prove failure overlays preserve successful timestamps. */
export function __testOnlyRecordExcapperBindingDiagnostic(
  matchId: string,
  status: ExcapperBindingStatus,
  source?: ExcapperBindingDiagnostic["source"],
  successfulAt?: number,
): void {
  recordExcapperBindingDiagnostic(matchId, status, source, successfulAt);
}

/** Test seam proving resolved text candidates retain their row identity. */
export function __testOnlyRecordManualCandidateDiagnostic(
  candidate: ManualExcapperHydrationCandidate,
  status: ExcapperBindingStatus,
  source?: ExcapperBindingDiagnostic["source"],
  successfulAt?: number,
): void {
  recordManualCandidateDiagnostic(candidate, status, source, successfulAt);
}

function normalizedLeagueIdentity(value: string): string {
  return value
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

const MANUAL_LEAGUE_ALIAS_GROUPS: ReadonlyArray<readonly string[]> = [
  [
    "Ecuador Primera A",
    "Ecuadorian Serie A",
    "Ecuador Serie A",
    "Ecuador Liga Pro Serie A",
    "Liga Pro Ecuador Serie A",
  ],
  [
    "Bolivia Nacional B",
    "Bolivian Copa Simon Bolivar",
    "Bolivia Copa Simon Bolivar",
    "Bolivia Simon Bolivar Cup",
    "Simon Bolivar Cup",
  ],
];

/**
 * Manual enrichment is not restricted to the automated league allowlist, but
 * it still requires strict league equivalence. Approved leagues retain their
 * existing canonical aliases; every other league must have an exact normalized
 * label. This intentionally does not use token overlap or substring matching.
 */
function leaguesAreSafelyEquivalent(a: string, b: string): boolean {
  const A = normalizedLeagueIdentity(a);
  const B = normalizedLeagueIdentity(b);
  if (!A || !B) return false;
  if (A === B) return true;
  if (manualLeagueAliasMatches(a, b)) return true;
  if (MANUAL_LEAGUE_ALIAS_GROUPS.some((group) => {
    const aliases = group.map(normalizedLeagueIdentity);
    return aliases.includes(A) && aliases.includes(B);
  })) return true;
  const targetA = matchTargetLeague(a);
  const targetB = matchTargetLeague(b);
  return targetA !== null && targetA === targetB;
}

function teamCoreWords(value: string): Set<string> {
  return new Set(normalizedTeamName(value).split(" ").filter(Boolean));
}

function sharesCoreTeamWord(a: string, b: string): boolean {
  const A = teamCoreWords(a);
  const B = teamCoreWords(b);
  if (A.size === 0 || B.size === 0) return false;
  for (const word of A) if (B.has(word)) return true;
  return false;
}

function pairOrientations(
  a1: string,
  a2: string,
  b1: string,
  b2: string,
): { direct: boolean; reversed: boolean } {
  return {
    direct: sharesCoreTeamWord(a1, b1) && sharesCoreTeamWord(a2, b2),
    reversed: sharesCoreTeamWord(a1, b2) && sharesCoreTeamWord(a2, b1),
  };
}

function completePairMatches(
  a1: string,
  a2: string,
  b1: string,
  b2: string,
  aLeague: string,
  bLeague: string,
): boolean {
  void aLeague;
  void bLeague;
  const orientation = pairOrientations(a1, a2, b1, b2);
  return orientation.direct || orientation.reversed;
}

function exactNormalizedPairMatches(
  a1: string,
  a2: string,
  b1: string,
  b2: string,
): boolean {
  const A1 = normalizedTeamName(a1);
  const A2 = normalizedTeamName(a2);
  const B1 = normalizedTeamName(b1);
  const B2 = normalizedTeamName(b2);
  return !!A1 && !!A2 && (
    (A1 === B1 && A2 === B2) ||
    (A1 === B2 && A2 === B1)
  );
}

function leagueApprovedForAutomaticBinding(a: string, b: string): boolean {
  const A = normalizedLeagueIdentity(a);
  const B = normalizedLeagueIdentity(b);
  return !!A && !!B && (A === B || manualLeagueAliasMatches(a, b));
}

type CandidateWithCountry = ManualExcapperHydrationCandidate & {
  countryCode?: string | null;
  country?: string | null;
};

const COUNTRY_CODE_ALIASES: Readonly<Record<string, string>> = {
  UK: "GB",
  ENG: "GB",
  GBR: "GB",
  UZB: "UZ",
};

function normalizedCountryCode(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const code = value.trim().toUpperCase();
  if (!/^[A-Z]{2,3}$/.test(code)) return null;
  return COUNTRY_CODE_ALIASES[code] ?? code;
}

function candidateCountryCode(candidate: ManualExcapperHydrationCandidate): string | null {
  const withCountry = candidate as CandidateWithCountry;
  return normalizedCountryCode(withCountry.countryCode ?? withCountry.country);
}

function countryEvidence(
  candidate: ManualExcapperHydrationCandidate,
  row: Pick<DirectoryRow, "countryCode">,
): "match" | "conflict" | "unknown" {
  const target = candidateCountryCode(candidate);
  const source = normalizedCountryCode(row.countryCode);
  if (!target || !source) return "unknown";
  return target === source ? "match" : "conflict";
}

/** Exact primary evidence remains a perfect-confidence fast path. */
export function manualBindingConfidence(
  candidate: ManualExcapperHydrationCandidate,
  row: DirectoryRow,
): number {
  if (countryEvidence(candidate, row) === "conflict") return 0;
  if (!exactNormalizedPairMatches(
    candidate.team1,
    candidate.team2,
    row.team1,
    row.team2,
  ) ||
    !pairFixtureClassesCompatible(candidate, row) ||
    !leagueApprovedForAutomaticBinding(candidate.league, row.league)) return 0;
  return liveCorroborationMatches(candidate, row) ? 1 : 0;
}

function nowGoalPeriod(state: number | null): DirectoryRow["livePeriod"] {
  if (state === 1) return "first-half";
  if (state === 2) return "half-time";
  if (state === 3) return "second-half";
  if (state !== null && state >= 4) return "extra-time";
  return null;
}

function liveCorroborationMatches(
  candidate: ManualExcapperHydrationCandidate,
  row: DirectoryRow,
): boolean {
  if (row.activity !== "live" || row.isLive !== true) return false;
  if (
    candidate.state == null ||
    candidate.state < 1 ||
    candidate.homeScore == null ||
    candidate.awayScore == null ||
    !row.liveScore ||
    !row.livePeriod
  ) return false;
  if (nowGoalPeriod(candidate.state ?? null) !== row.livePeriod) return false;
  // Literal clocks add precision when both feeds provide them. A missing clock
  // does not defeat otherwise exact score+phase evidence.
  if (candidate.liveMinute != null && row.liveMinute != null) {
    if (Math.abs(candidate.liveMinute - row.liveMinute) > 2) return false;
  }
  const orientation = pairOrientations(
    candidate.team1,
    candidate.team2,
    row.team1,
    row.team2,
  );
  const directScore =
    candidate.homeScore === row.liveScore.home &&
    candidate.awayScore === row.liveScore.away;
  const reversedScore =
    candidate.awayScore === row.liveScore.home &&
    candidate.homeScore === row.liveScore.away;
  return (orientation.direct && directScore) ||
    (orientation.reversed && reversedScore);
}

function liveScoreTimingPlausible(
  candidate: ManualExcapperHydrationCandidate,
  row: DirectoryRow,
): boolean {
  if (row.activity !== "live" || row.isLive !== true || !row.liveScore || !row.livePeriod) {
    return false;
  }
  if (candidate.homeScore == null || candidate.awayScore == null) return false;
  if (nowGoalPeriod(candidate.state ?? null) !== row.livePeriod) return false;
  if (candidate.liveMinute != null && row.liveMinute != null) {
    if (Math.abs(candidate.liveMinute - row.liveMinute) > 2) return false;
  }
  return (
    candidate.homeScore === row.liveScore.home &&
    candidate.awayScore === row.liveScore.away
  ) || (
    candidate.homeScore === row.liveScore.away &&
    candidate.awayScore === row.liveScore.home
  );
}

/**
 * Resolve exact-primary or qualified weighted-hybrid edges. Both ends must
 * still have degree one, so ambiguity never becomes an insertion-order choice.
 */
export function resolveManualExcapperBindings(
  candidates: readonly ManualExcapperHydrationCandidate[],
  directory: readonly DirectoryRow[],
  qualifiedSecondary: ReadonlyMap<string, QualifiedSecondaryBinding> = new Map(),
): ManualExcapperBinding[] {
  const edges: Array<{
    candidate: ManualExcapperHydrationCandidate;
    row: DirectoryRow;
  }> = [];
  for (const candidate of candidates) {
    if (candidate.identityAmbiguous) continue;
    for (const row of directory) {
      const secondary = qualifiedSecondary.get(diagnosticIdentity(candidate));
      const strict =
        exactNormalizedPairMatches(
          candidate.team1,
          candidate.team2,
          row.team1,
          row.team2,
        ) &&
        pairFixtureClassesCompatible(candidate, row) &&
        leagueApprovedForAutomaticBinding(candidate.league, row.league) &&
        liveCorroborationMatches(candidate, row) &&
        manualBindingConfidence(candidate, row) >= MANUAL_BINDING_MIN_CONFIDENCE;
      if (
        (strict || secondary?.gameId === row.gameId) &&
        !blockedAutoPairs.has(`${diagnosticIdentity(candidate)}\u0000${row.gameId}`) &&
        (strict || (secondary?.confidence ?? 0) >= MANUAL_BINDING_MIN_CONFIDENCE)
      ) {
        edges.push({ candidate, row });
      }
    }
  }
  const candidateDegree = new Map<string, number>();
  const gameDegree = new Map<string, number>();
  for (const edge of edges) {
    candidateDegree.set(
      diagnosticIdentity(edge.candidate),
      (candidateDegree.get(diagnosticIdentity(edge.candidate)) ?? 0) + 1,
    );
    gameDegree.set(edge.row.gameId, (gameDegree.get(edge.row.gameId) ?? 0) + 1);
  }
  return edges
    .filter(
      (edge) =>
        candidateDegree.get(diagnosticIdentity(edge.candidate)) === 1 &&
        gameDegree.get(edge.row.gameId) === 1,
    )
    .map((edge) => ({
      matchId: edge.candidate.matchId,
      gameId: edge.row.gameId,
      nowGoalLine: edge.candidate.nowGoalLine,
      league: matchTargetLeague(edge.row.league) ?? edge.row.league,
      confidence: manualBindingConfidence(edge.candidate, edge.row) ||
        (qualifiedSecondary.get(diagnosticIdentity(edge.candidate))?.gameId ===
          edge.row.gameId
          ? qualifiedSecondary.get(diagnosticIdentity(edge.candidate))!.confidence
          : 0),
    }));
}

/**
 * Explain manual binding outcomes using the exact same complete
 * pair, league-alias, and one-to-one identity rules as the binder above.
 */
export function classifyManualExcapperBindings(
  candidates: readonly ManualExcapperHydrationCandidate[],
  directory: readonly DirectoryRow[],
  qualifiedSecondary: ReadonlyMap<string, QualifiedSecondaryBinding> = new Map(),
): Map<string, {
  status: "pending" | "no_directory_match" | "ambiguous_identity" | "missing_league_alias" | "non_live_candidate" | "missing_live_corroboration" | "score_period_conflict";
  source: ExcapperBindingDiagnostic["source"];
}> {
  const result = new Map<string, {
    status: "pending" | "no_directory_match" | "ambiguous_identity" | "missing_league_alias" | "non_live_candidate" | "missing_live_corroboration" | "score_period_conflict";
    source: ExcapperBindingDiagnostic["source"];
  }>();
  const safeEdges: Array<{ candidate: ManualExcapperHydrationCandidate; row: DirectoryRow }> = [];
  const teamPairRows = new Map<string, DirectoryRow[]>();

  for (const candidate of candidates) {
    const diagnosticId = diagnosticIdentity(candidate);
    if (candidate.identityAmbiguous) {
      result.set(diagnosticId, { status: "ambiguous_identity", source: null });
      continue;
    }
    const pairRows = directory.filter((row) =>
      qualifiedSecondary.get(diagnosticId)?.gameId === row.gameId ||
        completePairMatches(
          candidate.team1,
          candidate.team2,
          row.team1,
          row.team2,
          // Evaluate pair identity in the directory row's scope so an audited
          // team alias can still be recognized as a pair when the candidate's
          // league label itself is the missing/incorrect piece.
          row.league,
          row.league,
        ),
    );
    teamPairRows.set(diagnosticId, pairRows);
    for (const row of pairRows) {
      if ((liveCorroborationMatches(candidate, row) ||
          qualifiedSecondary.get(diagnosticId)?.gameId === row.gameId) &&
          !blockedAutoPairs.has(`${diagnosticId}\u0000${row.gameId}`)) {
        safeEdges.push({ candidate, row });
      }
    }
  }

  const candidateDegree = new Map<string, number>();
  const gameDegree = new Map<string, number>();
  for (const edge of safeEdges) {
    const diagnosticId = diagnosticIdentity(edge.candidate);
    candidateDegree.set(diagnosticId, (candidateDegree.get(diagnosticId) ?? 0) + 1);
    gameDegree.set(edge.row.gameId, (gameDegree.get(edge.row.gameId) ?? 0) + 1);
  }

  for (const candidate of candidates) {
    const diagnosticId = diagnosticIdentity(candidate);
    if (candidate.identityAmbiguous) continue;
    const edges = safeEdges.filter(
      (edge) => diagnosticIdentity(edge.candidate) === diagnosticId,
    );
    if (edges.length === 0) {
      const pairRows = teamPairRows.get(diagnosticId) ?? [];
      const lowCoreRows = pairRows.length === 0
        ? directory.filter((row) =>
            leaguesAreSafelyEquivalent(candidate.league, row.league) &&
            liveScoreTimingPlausible(candidate, row))
        : [];
      const leagueRows = pairRows;
      const liveRows = leagueRows.filter(
        (row) => row.activity === "live" && row.isLive === true,
      );
      const hasNowGoalCorroboration =
        candidate.state != null &&
        candidate.state >= 1 &&
        candidate.homeScore != null &&
        candidate.awayScore != null;
      const nowGoalExplicitlyNonLive =
        candidate.state != null && candidate.state < 1;
      const status =
        lowCoreRows.length > 0
          ? "ambiguous_identity"
          : pairRows.length === 0
          ? "no_directory_match"
            : nowGoalExplicitlyNonLive
              ? "non_live_candidate"
            : liveRows.length === 0
              ? "non_live_candidate"
              : !hasNowGoalCorroboration ||
                  liveRows.some((row) => !row.liveScore || !row.livePeriod)
                ? "missing_live_corroboration"
                : "score_period_conflict";
      result.set(diagnosticId, {
        status,
        source: pairRows.length === 1 ? safeSource(pairRows[0]!) : null,
      });
      const uncertainRows = (pairRows.length ? pairRows : lowCoreRows)
        .filter((row) => row.activity === "live" && row.isLive === true);
      if (uncertainRows.length) {
        reviewCandidates.set(diagnosticId, uncertainRows.map((row) => ({
          ref: candidateRef(diagnosticId, row),
          gameId: row.gameId,
          source: safeSource(row)!,
          target: safeTarget(candidate)!,
          row: { ...row },
          capturedAt: Date.now(),
        })));
      } else {
        reviewCandidates.delete(diagnosticId);
      }
      leagueMismatchCandidates.delete(diagnosticId);
      continue;
    }
    const unique = edges.length === 1 && gameDegree.get(edges[0]!.row.gameId) === 1;
    result.set(diagnosticId, unique
      ? { status: "pending", source: safeSource(edges[0]!.row) }
      : { status: "ambiguous_identity", source: null });
    if (unique) {
      reviewCandidates.delete(diagnosticId);
    } else {
      reviewCandidates.set(diagnosticId, edges.map(({ row }) => ({
        ref: candidateRef(diagnosticId, row),
        gameId: row.gameId,
        source: safeSource(row)!,
        target: safeTarget(candidate)!,
        row: { ...row },
        capturedAt: Date.now(),
      })));
    }
  }
  return result;
}

// ----- HTTP -----

/**
 * Fetch with a hard timeout. We combine the cycle's stop-signal with a
 * per-request timeout AbortController so a stalled connection can't freeze
 * the loop (architect found the previous "_excapperTimeout flag" approach
 * never actually aborted — a hung fetch would block re-arm indefinitely).
 */
async function fetchText(
  url: string,
  signal: AbortSignal,
  tier: "manual" | "live" | "directory" | "prematch" | "background" = "background",
  maxAgeMs?: number,
  bypassCache = false,
): Promise<string> {
  const kind = /[?&]action=game\b/.test(url) ? "game" : "directory";
  return fetchExcapperText(url, signal, kind, FETCH_TIMEOUT_MS, {
    tier,
    maxAgeMs,
    bypassCache,
  });
}

/** Narrow an unknown caught value to a usable error message + kind. */
function isAbortError(err: unknown): boolean {
  return (
    err instanceof Error && (err.name === "AbortError" || err.name === "DOMException")
  );
}
function errMsg(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

// ----- Parsing -----

function stripTags(s: string): string {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&[a-z]+;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function parseObservedLiveMinute(value: string): number | null {
  const match = /^\s*(\d{1,3})(?:\s*\+\s*(\d{1,2}))?/.exec(value);
  if (!match) return null;
  const minute = Number(match[1]) + Number(match[2] ?? 0);
  return Number.isFinite(minute) ? minute : null;
}

export function parseDirectory(html: string): DirectoryRow[] {
  const rows: DirectoryRow[] = [];
  const liveStart = html.search(/<div\s+id=["']live["'][^>]*>/i);
  const liveEnd =
    liveStart >= 0
      ? html.slice(liveStart + 1).search(/<div\s+id=["'](?:fav|notification_log)["'][^>]*>/i)
      : -1;
  const absoluteLiveEnd =
    liveStart >= 0 && liveEnd >= 0 ? liveStart + 1 + liveEnd : html.length;
  const prematchStart = html.search(/<div\s+id=["']premach["'][^>]*>/i);
  const rowRe = /<tr\s+class="a_link"\s+game_id="(\d+)"[^>]*>([\s\S]*?)<\/tr>/g;
  let m: RegExpExecArray | null;
  while ((m = rowRe.exec(html))) {
    const gameId = m[1]!;
    const inner = m[2]!;
    const tdMatches = [...inner.matchAll(/<td([^>]*)>([\s\S]*?)<\/td>/g)];
    const tds = tdMatches.map((x) => x[2]!);
    if (tds.length < 5) continue;
    const league = stripTags(tds[2]!);
    const teamsRaw = stripTags(tds[3]!);
    // Teams formatted as "Home - Away". Slice rather than split-2 in case a
    // team name itself contains " - ".
    const sepIdx = teamsRaw.indexOf(" - ");
    if (sepIdx < 0) continue;
    const team1 = teamsRaw.slice(0, sepIdx).trim();
    const team2 = teamsRaw.slice(sepIdx + 3).trim();
    if (!team1 || !team2) continue;
    // Total volume: scan all tds for a currency-marked cell. The numeric
    // native-feed amount is retained unchanged; no FX conversion is applied.
    // If multiple cells match, pick the largest match-level aggregate.
    let totalVolume = 0;
    for (const td of tds) {
      const txt = stripTags(td);
      const moneyMatch = /^([\d.,\s\u00a0]+)\s*€/.exec(txt);
      if (!moneyMatch) continue;
      const digits = moneyMatch[1]!.replace(/[\s\u00a0.,]/g, "");
      const n = parseInt(digits, 10);
      if (isFinite(n) && n > totalVolume) totalVolume = n;
    }
    const rowOffset = m.index;
    const activity: DirectoryRow["activity"] =
      liveStart >= 0 && rowOffset >= liveStart && rowOffset < absoluteLiveEnd
        ? "live"
        : prematchStart >= 0 && rowOffset >= prematchStart && rowOffset < liveStart
          ? "scheduled"
          : "unknown";
    const countryCell = `${tdMatches[1]?.[1] ?? ""} ${tds[1] ?? ""}`;
    const countryCode =
      /\b(?:alt|title)=["']([A-Z]{2,3})["']/i.exec(countryCell)?.[1]?.toUpperCase() ??
      null;
    rows.push({
      gameId,
      team1,
      team2,
      league,
      totalVolume,
      isLive: activity === "live",
      activity,
      countryCode,
      kickoffText: stripTags(tds[0] ?? "") || null,
      liveScore: null,
      livePeriod: null,
    });
  }
  return rows;
}

async function loadBatchSnapshot(
  signal: AbortSignal,
): Promise<ExcapperBatchSnapshot<DirectoryRow>> {
  const boundIds = new Set([...manualBindingCache.values()].map((binding) => binding.gameId));
  const manualCandidates = getManualWatchlistMatchesForExcapper();
  const snapshot = await loadExcapperBatchSnapshot(
    () => fetchText(`${BASE_URL}/`, signal, "directory", 12_000, false),
    (raw) => {
      const htmlRows = parseDirectory(raw);
      const rows = htmlRows.length > 0 ? htmlRows : parseExcapperStructuredRows(raw);
      return rows.filter((row) =>
        row.activity === "live" && (
          boundIds.has(row.gameId) ||
          matchTargetLeague(row.league) !== null ||
          manualCandidates.some((candidate) =>
            !candidate.identityAmbiguous &&
             (
               completePairMatches(
                 candidate.team1, candidate.team2, row.team1, row.team2,
                 candidate.league, row.league,
               ) ||
               secondaryPairSimilarity(candidate, row) !== null
             )
          )
        )
      ).slice(0, 1_000);
    },
  );
  const whitelistedRows = snapshot.rows;
  const allowedIds = new Set(whitelistedRows.map((row) => row.gameId));
  const details = new Map(
    [...snapshot.details].filter(([gameId]) => allowedIds.has(gameId)),
  );
  return {
    ...snapshot,
    details,
    detailCapable: details.size > 0,
    rows: whitelistedRows.map((row) => {
      const detail = details.get(row.gameId);
      return detail ? {
        ...row,
        liveScore: detail.score,
        livePeriod: detail.period,
        liveMinute: detail.minute,
        observedTime: new Date(snapshot.observedAt).toISOString(),
      } : row;
    }),
  };
}

/**
 * Normalize a team name for fuzzy comparison.
 *  - lowercase
 *  - strip parenthetical suffixes "(W)", "(Res)", "(U21)"
 *  - drop common club prefixes/suffixes (FC, SC, CF, AC, FK, SK, NK, KS, etc.)
 *  - drop non-alphanumeric, collapse whitespace
 */
function normalizeName(s: string): string {
  return normalizedTeamName(s);
}

/**
 * Token-overlap fuzzy match. Returns true if both teams from side A have at
 * least one ≥3-char token in common with their counterpart on side B (in
 * either home/away orientation).
 */
export function fuzzyMatch(a1: string, a2: string, b1: string, b2: string): boolean {
  const tok = (s: string) =>
    new Set(normalizeName(s).split(" ").filter((t) => t.length >= 3));
  const A1 = tok(a1);
  const A2 = tok(a2);
  const B1 = tok(b1);
  const B2 = tok(b2);
  const overlap = (x: Set<string>, y: Set<string>) => {
    for (const t of x) if (y.has(t)) return true;
    return false;
  };
  return (
    (overlap(A1, B1) && overlap(A2, B2)) ||
    (overlap(A1, B2) && overlap(A2, B1))
  );
}

/**
 * Loose fallback for when strict fuzzyMatch fails — e.g. when the NowGoal
 * team string is "Foshan Nanshi" but Excapper carries "Foshan Nanshi GD",
 * or when one side has a transliteration variant. We score each directory
 * row by how many ≥4-char tokens it shares with EITHER watchlist team,
 * across either orientation, and return the highest-scoring row (if any).
 *
 * Why ≥4 chars: keeps generic words like "fc", "club", "real", "city",
 * "town" from creating false matches. Why score-pick-best: a watchlist
 * fragment "Beijing" would otherwise loosely-match every Beijing team in
 * the directory; scoring picks the one with the most overlap, which in
 * practice is the right fixture.
 */
export function looseFuzzyBest<T extends { team1: string; team2: string }>(
  ourTeam1: string,
  ourTeam2: string,
  rows: T[],
): T | null {
  const tok = (s: string) =>
    new Set(normalizeName(s).split(" ").filter((t) => t.length >= 4));
  const ourBag = new Set<string>([...tok(ourTeam1), ...tok(ourTeam2)]);
  if (ourBag.size === 0) return null;
  let best: T | null = null;
  let bestScore = 0;
  for (const r of rows) {
    const theirBag = new Set<string>([...tok(r.team1), ...tok(r.team2)]);
    let score = 0;
    for (const t of ourBag) if (theirBag.has(t)) score++;
    if (score > bestScore) {
      bestScore = score;
      best = r;
    }
  }
  return bestScore >= 1 ? best : null;
}

const CYRILLIC_LATIN: Readonly<Record<string, string>> = {
  а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh",
  з: "z", и: "i", й: "i", к: "k", л: "l", м: "m", н: "n", о: "o",
  п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "kh", ц: "ts",
  ч: "ch", ш: "sh", щ: "shch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu",
  я: "ya", і: "i", ї: "yi", є: "ye", ґ: "g", ў: "u",
};

const SECONDARY_NAME_NOISE = new Set([
  "fc", "fk", "cf", "sc", "club", "football", "futbol", "university",
  "universitet", "universiteti", "uni", "u21", "u20",
]);

const CONTROLLED_SECONDARY_ALIASES: Readonly<Record<string, readonly string[]>> = {
  buxdu: ["buxoro"],
  bukhdu: ["buxoro"],
  fardu: ["fergana"],
  farduferghana: ["fergana"],
  fardufergana: ["fergana"],
};

type FixtureClass = "u21" | "u20" | "youth" | "women" | "reserve" | "senior";

function transliterateForSecondary(value: string): string {
  return [...value.toLowerCase()].map((character) =>
    CYRILLIC_LATIN[character] ?? character).join("");
}

function fixtureClasses(value: string): Set<FixtureClass> {
  const lexical = transliterateForSecondary(value)
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
  const classes = new Set<FixtureClass>();
  if (/\b(?:u|under)\s*21\b/.test(lexical)) classes.add("u21");
  if (/\b(?:u|under)\s*20\b|\bsub\s*20\b/.test(lexical)) classes.add("u20");
  if (/\b(?:youth|junior|juniors)\b/.test(lexical)) classes.add("youth");
  if (/\b(?:women|woman|ladies|female|w)\b/.test(lexical)) classes.add("women");
  if (/\b(?:reserve|reserves|res|ii|b)\b/.test(lexical)) classes.add("reserve");
  if (classes.size === 0) classes.add("senior");
  return classes;
}

function compatibleFixtureClass(a: string, b: string): boolean {
  const A = fixtureClasses(a);
  const B = fixtureClasses(b);
  if (A.has("senior") || B.has("senior")) return A.has("senior") && B.has("senior");
  for (const classification of A) if (B.has(classification)) return true;
  return false;
}

function secondaryTeamTokens(value: string): string[] {
  const transliterated = transliterateForSecondary(value)
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
  const raw = transliterated.split(/\s+/).filter(Boolean);
  const compact = raw.join("");
  const alias = CONTROLLED_SECONDARY_ALIASES[compact];
  if (alias) return [...alias];
  return raw.filter((token) => !SECONDARY_NAME_NOISE.has(token));
}

function tokenSimilarity(a: string, b: string): number {
  if (a === b) return 1;
  if (a.length >= 4 && b.length >= 4 && (a.startsWith(b) || b.startsWith(a))) {
    return Math.min(a.length, b.length) / Math.max(a.length, b.length);
  }
  return 0;
}

function secondaryTeamSimilarity(a: string, b: string): number {
  const A = secondaryTeamTokens(a);
  const B = secondaryTeamTokens(b);
  if (A.length === 0 || B.length === 0) return 0;
  const directional = (left: string[], right: string[]) =>
    left.reduce((sum, token) =>
      sum + Math.max(0, ...right.map((other) => tokenSimilarity(token, other))), 0) /
      left.length;
  const tokenScore = Math.min(directional(A, B), directional(B, A));
  const compactA = A.join("");
  const compactB = B.join("");
  const acronymA = A.length >= 3 ? A.map((token) => token[0]).join("") : "";
  const acronymB = B.length >= 3 ? B.map((token) => token[0]).join("") : "";
  const controlledAcronym =
    (compactA.length >= 3 && compactA === acronymB) ||
    (compactB.length >= 3 && compactB === acronymA);
  return controlledAcronym ? Math.max(tokenScore, 0.9) : tokenScore;
}

function secondaryPairSimilarity(
  candidate: Pick<ManualExcapperHydrationCandidate, "team1" | "team2" | "league">,
  row: Pick<DirectoryRow, "team1" | "team2" | "league">,
): { score: number; reversed: boolean } | null {
  const directHome = secondaryTeamSimilarity(candidate.team1, row.team1);
  const directAway = secondaryTeamSimilarity(candidate.team2, row.team2);
  const reverseHome = secondaryTeamSimilarity(candidate.team1, row.team2);
  const reverseAway = secondaryTeamSimilarity(candidate.team2, row.team1);
  const direct = 0.5 * directHome + 0.5 * directAway;
  const reversed = 0.5 * reverseHome + 0.5 * reverseAway;
  const useReversed = reversed > direct;
  const teamScore = useReversed ? reversed : direct;
  const weakestTeam = useReversed
    ? Math.min(reverseHome, reverseAway)
    : Math.min(directHome, directAway);
  if (teamScore < 0.50 || weakestTeam <= 0) return null;
  return { score: teamScore, reversed: useReversed };
}

export function secondaryFuzzyIdentityScore(
  candidate: Pick<ManualExcapperHydrationCandidate, "team1" | "team2" | "league">,
  row: Pick<DirectoryRow, "team1" | "team2" | "league">,
): number {
  return secondaryPairSimilarity(candidate, row)?.score ?? 0;
}

function pairFixtureClassesCompatible(
  candidate: ManualExcapperHydrationCandidate,
  row: DirectoryRow,
): boolean {
  const directNames =
    normalizedTeamName(candidate.team1) === normalizedTeamName(row.team1) &&
    normalizedTeamName(candidate.team2) === normalizedTeamName(row.team2);
  const reversedNames =
    normalizedTeamName(candidate.team1) === normalizedTeamName(row.team2) &&
    normalizedTeamName(candidate.team2) === normalizedTeamName(row.team1);
  const direct = directNames &&
    compatibleFixtureClass(candidate.team1, row.team1) &&
    compatibleFixtureClass(candidate.team2, row.team2);
  const reversed = reversedNames &&
    compatibleFixtureClass(candidate.team1, row.team2) &&
    compatibleFixtureClass(candidate.team2, row.team1);
  return direct || reversed;
}

function secondaryLiveConfidence(
  candidate: ManualExcapperHydrationCandidate,
  row: DirectoryRow,
): number {
  const identity = secondaryPairSimilarity(candidate, row);
  if (!identity || row.activity !== "live" || row.isLive !== true) return 0;
  const country = countryEvidence(candidate, row);
  if (country === "conflict") return 0;

  const candidatePeriod = nowGoalPeriod(candidate.state ?? null);
  if (candidatePeriod && row.livePeriod && candidatePeriod !== row.livePeriod) return 0;
  if (candidate.liveMinute != null && row.liveMinute != null &&
      Math.abs(candidate.liveMinute - row.liveMinute) > 3) return 0;

  let scoreContribution = 0;
  if (candidate.homeScore != null && candidate.awayScore != null && row.liveScore) {
    const scoreMatches = identity.reversed
      ? candidate.homeScore === row.liveScore.away &&
        candidate.awayScore === row.liveScore.home
      : candidate.homeScore === row.liveScore.home &&
        candidate.awayScore === row.liveScore.away;
    if (!scoreMatches) return 0;
    scoreContribution = 0.15;
  }

  // Weights: teams 65%, explicit country 10%, league context 5%, score 15%,
  // and a within-3-minute clock 5%. Unknown evidence contributes zero.
  const countryContribution = country === "match" ? 0.10 : 0;
  const leagueContribution = leaguesAreSafelyEquivalent(candidate.league, row.league)
    ? 0.05
    : 0;
  const minuteContribution =
    candidate.liveMinute != null && row.liveMinute != null ? 0.05 : 0;
  // Team identity is indispensable: zero overlap can never reach the 50% gate.
  return 0.65 * identity.score + countryContribution + leagueContribution +
    scoreContribution + minuteContribution;
}

function secondaryRootShortlist(
  candidate: ManualExcapperHydrationCandidate,
  rows: readonly DirectoryRow[],
): DirectoryRow[] {
  const scored = rows
    .map((row) => ({ row, identity: secondaryPairSimilarity(candidate, row) }))
    .filter((entry): entry is { row: DirectoryRow; identity: { score: number; reversed: boolean } } =>
      entry.identity !== null)
    .sort((a, b) => b.identity.score - a.identity.score);
  if (scored.length === 0) return [];
  // Inspect at most three plausible contenders. A strong directory-name match
  // may later conflict on score/time, so it must not hide the next hybrid row.
  return scored
    .slice(0, 3)
    .map((entry) => entry.row);
}

/**
 * Token-overlap STRENGTH between two team pairs (best of either orientation).
 * Unlike `fuzzyMatch` (boolean), this returns how many ≥3-char tokens align,
 * so when several watchlist matches strictly match the SAME Excapper row — or
 * one watchlist match strictly matches several rows — we can pick the strongest
 * pairing and keep each Excapper gameId assigned to exactly one match. Without
 * this, two similarly-named fixtures (e.g. two "Leones" teams) collapse onto a
 * single Excapper game and show identical volume columns.
 */
export function pairScore(a1: string, a2: string, b1: string, b2: string): number {
  const tok = (s: string) =>
    new Set(normalizeName(s).split(" ").filter((t) => t.length >= 3));
  const A1 = tok(a1);
  const A2 = tok(a2);
  const B1 = tok(b1);
  const B2 = tok(b2);
  const ov = (x: Set<string>, y: Set<string>) => {
    let n = 0;
    for (const t of x) if (y.has(t)) n++;
    return n;
  };
  return Math.max(ov(A1, B1) + ov(A2, B2), ov(A1, B2) + ov(A2, B1));
}

/**
 * One parsed OU line from a per-game page.
 *  line     - Excapper integer-.5 line (0.5, 1.5, 2.5, ...).
 *  over     - running native-feed EUR total traded on Over for this line.
 *  under    - running native-feed EUR total traded on Under for this line.
 */
export interface ExcapperLineSample {
  line: number;
  over: number;
  under: number;
  /** Current decimal quote displayed beside the cumulative amount. */
  overOdds?: number;
  underOdds?: number;
  /** Actual local observation time when upstream provides no quote timestamp. */
  collectedAt?: number;
}

const COEF_ITEM_RE =
  /<div\s+class="[^"]*\bcharts-bk__item-title\b[^"]*">\s*(Over|Under)\s*<\/div>[\s\S]*?<div\s+class="[^"]*\bcharts-bk__item-coef\b[^"]*">\s*([\d.,\s\u00a0]+?)\s*€(?:\s*-\s*(\d+(?:[.,]\d+)?))?/gi;

const TAB_LINK_RE =
  /href="#(tab_content_\d+)"[^>]*>\s*Over\/Under\s+(\d+(?:\.\d+)?)\s+Goals/gi;

const TAB_BLOCK_RE_TMPL = (id: string) =>
  new RegExp(
    `<div\\s+id="${id}"\\s+class="tab-content[^"]*">([\\s\\S]*?)(?=<div\\s+id="tab_content_\\d+"\\s+class="tab-content|<div\\s+class="footer|</body>)`,
    "i",
  );

/**
 * Parse a per-game page and return per-side totals for EVERY OU line tab
 * present (0.5, 1.5, 2.5, ...). A live page may contain nine tabs in
 * one HTML payload, so this is no extra bandwidth vs. parsing one tab.
 *
 * Lines whose Over+Under both equal 0 are filtered out — they're noise
 * tabs with no Betfair liquidity (typically the extreme ends like 0.5/6.5
 * on low-volume matches). Returns null only if NO tab parsed successfully
 * (the markup contract is broken or the page is an error stub).
 */
export function parseGamePage(
  html: string,
  collectedAt = Date.now(),
): ExcapperLineSample[] | null {
  // 1. Find every OU tab link → (tab_id, line).
  const tabLinks: Array<{ tabId: string; line: number }> = [];
  let tm: RegExpExecArray | null;
  TAB_LINK_RE.lastIndex = 0;
  while ((tm = TAB_LINK_RE.exec(html))) {
    const line = parseFloat(tm[2]!);
    if (!isFinite(line)) continue;
    tabLinks.push({ tabId: tm[1]!, line });
  }
  if (tabLinks.length === 0) return null;

  // 2. For each tab, slice its content block and pull the two coef cards.
  const out: ExcapperLineSample[] = [];
  for (const { tabId, line } of tabLinks) {
    const blockMatch = TAB_BLOCK_RE_TMPL(tabId).exec(html);
    if (!blockMatch) continue;
    const content = blockMatch[1]!;

    let over: number | null = null;
    let under: number | null = null;
    let overOdds: number | undefined;
    let underOdds: number | undefined;
    COEF_ITEM_RE.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = COEF_ITEM_RE.exec(content))) {
      const label = m[1]!.toLowerCase();
      // Strip separators (',', '.', whitespace, non-breaking space) before parsing.
      const digits = m[2]!.replace(/[\s\u00a0.,]/g, "");
      const eur = parseInt(digits, 10);
      if (!isFinite(eur)) continue;
      const quote = m[3] ? Number(m[3].replace(",", ".")) : undefined;
      const validQuote = quote !== undefined && Number.isFinite(quote) && quote > 1
        ? quote
        : undefined;
      if (label === "over") {
        over = eur;
        overOdds = validQuote;
      } else if (label === "under") {
        under = eur;
        underOdds = validQuote;
      }
    }
    if (over === null || under === null) continue;
    // Drop completely dead lines (zero on both sides) — they pollute the UI.
    if (over === 0 && under === 0) continue;
    out.push({
      line,
      over,
      under,
      ...(overOdds !== undefined ? { overOdds } : {}),
      ...(underOdds !== undefined ? { underOdds } : {}),
      ...(
        (overOdds !== undefined || underOdds !== undefined) &&
        Number.isFinite(collectedAt)
          ? { collectedAt }
          : {}
      ),
    });
  }
  if (out.length === 0) return null;
  // Sort ascending so dashboard rendering order is deterministic.
  out.sort((a, b) => a.line - b.line);
  return out;
}

// ----- Per-bet transaction parsing (the real "Change" column) -----

/**
 * One row of Excapper's per-game transaction table. Each row is a single
 * bet placement event on Betfair Exchange, NOT a cycle aggregate.
 *
 * Column layout (12 <td> per row, observed live 2026-05-23):
 *   [0] Type        e.g. "live" / "prematch"
 *   [1] Date        wallclock "HH:MM DD.MM"
 *   [2] Market      "Over" | "Under"  (line is determined by parent tab)
 *   [3] Summ        running cumulative native-feed EUR total after this bet
 *   [4] Change      single-bet native-feed EUR size with an upstream marker
 *   [5] Time        match minute, e.g. "85"
 *   [6] Score       e.g. "1-1"
 *   [7] Odds        e.g. "3.00"
 *   [8] (empty)
 *   [9] All         total handle on this market
 *  [10] Percent     market share %
 *  [11] HTML comment trailer
 */
export interface ExcapperTransaction {
  line: number;
  side: "Over" | "Under";
  summ: number;
  change: number;
  rawChange: string;
  date: string;
  /** Fixed at durable global-alert admission, never recomputed on a retry. */
  betTime?: number;
  matchMinute: string;
  sourceType?: "live" | "prematch" | "unknown";
  score?: { home: number; away: number } | null;
}

/**
 * Threshold for the per-bet [MONEY SPIKE] Telegram alert. Mirrors the
 * SPIKE_ALERT_THRESHOLD in scanner.ts; kept duplicated rather than
 * imported to keep this parser self-contained.
 */
const TX_SPIKE_THRESHOLD = 500;

/**
 * Per-(gameId, line, side) HIGH-WATER MARK on the Summ column. New rows
 * are rows whose Summ exceeds what we've ever seen for that key — works
 * because Summ is monotonically increasing per (line, side) on Excapper
 * (it's the running cumulative total).
 */
const txHighWater = new Map<string, number>();
const TX_KEY_CAP = 5_000;
const txPending = new Set<string>();

/**
 * Set of keys that have been seen at least once. The first time we see a
 * (gameId, line, side), we SEED the high-water to the current max and
 * fire NOTHING — otherwise we'd dump every historical bet on startup.
 */
const txSeeded = new Set<string>();
type NewTransactionListener = (event: {
  gameId: string;
  tx: ExcapperTransaction;
  league: string;
}) => boolean | Promise<boolean> | void;
let newTransactionListener: NewTransactionListener | null = null;

/** Seed and watermark are one coordinated LRU entry. Never evict an admission in flight. */
function touchTxKey(key: string, summ: number): boolean {
  if (!txHighWater.has(key) && txHighWater.size >= TX_KEY_CAP) {
    const oldest = [...txHighWater.keys()].find((candidate) => !txPending.has(candidate));
    // Pending admissions cannot be evicted or re-seeded as historical rows.
    if (!oldest) return false;
    txHighWater.delete(oldest);
    txSeeded.delete(oldest);
  }
  txHighWater.delete(key);
  txHighWater.set(key, summ);
  txSeeded.add(key);
  return true;
}

export function __testOnlyTransactionWatermarks(): { size: number; seeded: number; pending: number } {
  return { size: txHighWater.size, seeded: txSeeded.size, pending: txPending.size };
}

/** One process-wide observer: manual and global hydration share the same high-water. */
export function setNewExcapperTransactionListener(listener: NewTransactionListener | null): void {
  newTransactionListener = listener;
}

function cleanTxCell(s: string): string {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;|&emsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Excapper renders two synthetic zero rows for OU markets that have no offers:
 * blank Market, zero Summ/Change, and otherwise empty cells. Those blocks are
 * often several KB because they still include charts/menus, so block size alone
 * is not markup-drift evidence.
 *
 * Fail closed: a blank market with non-zero money, or any non-empty unknown
 * market label, is not recognized as empty and therefore still warns.
 */
export function isRecognizedEmptyTransactionTab(block: string): boolean {
  const rows = [...block.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)];
  let dataRows = 0;
  let emptyRows = 0;
  for (const row of rows) {
    const tds = [...row[1]!.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map(
      (cell) => cleanTxCell(cell[1]!),
    );
    if (tds.length < 6) continue;
    dataRows++;
    const market = tds[2] ?? "";
    const summ = tds[3] ?? "";
    const change = tds[4] ?? "";
    if (
      market === "" &&
      /^0(?:\s*€)?$/.test(summ) &&
      /^0(?:[.,]0+)?\s*€\s*\/\s*0(?:[.,]0+)?%$/.test(change)
    ) {
      emptyRows++;
    }
  }
  return dataRows > 0 && emptyRows === dataRows;
}

/**
 * Parse a currency-marked upstream amount without applying FX conversion.
 * Returns null on parse failure (so the caller can skip the row).
 */
function parseMoneyCell(s: string): number | null {
  const m = /^([\d.,\s\u00a0]+)\s*€/.exec(s.trim());
  if (!m) return null;
  const digits = m[1]!.replace(/[\s\u00a0.,]/g, "");
  if (!digits) return null;
  const n = parseInt(digits, 10);
  return isFinite(n) ? n : null;
}

/**
 * Parse the "Change" cell. Live Excapper values carry an upstream € marker.
 * ANY parse failure or non-numeric content
 * returns 0 (per user audit point #2 — sanitize cleanly, treat
 * empty/dash strictly as 0, never NaN).
 */
function parseChangeCell(s: string): number {
  const trimmed = s.trim();
  if (!trimmed || trimmed === "—" || trimmed === "-") return 0;
  const m = /^([\d.,\s\u00a0]+)\s*€/.exec(trimmed);
  if (!m) return 0;
  const digits = m[1]!.replace(/[\s\u00a0.,]/g, "");
  if (!digits) return 0;
  const n = parseInt(digits, 10);
  return isFinite(n) ? n : 0;
}

export function parseGameTransactions(html: string): ExcapperTransaction[] {
  const out: ExcapperTransaction[] = [];
  const tabLinks: Array<{ tabId: string; line: number }> = [];
  TAB_LINK_RE.lastIndex = 0;
  let tm: RegExpExecArray | null;
  while ((tm = TAB_LINK_RE.exec(html))) {
    const line = parseFloat(tm[2]!);
    if (!isFinite(line)) continue;
    tabLinks.push({ tabId: tm[1]!, line });
  }
  for (const { tabId, line } of tabLinks) {
    const blockMatch = TAB_BLOCK_RE_TMPL(tabId).exec(html);
    if (!blockMatch) continue;
    const block = blockMatch[1]!;
    // Tolerate attributes on <tr> (`<tr class="...">`, `<tr data-id="...">`).
    // Without this, any future markup change adding attrs would silently
    // drop transactions to zero with no parse error — architect flagged.
    const rowRe = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
    let rm: RegExpExecArray | null;
    let parsedInThisTab = 0;
    while ((rm = rowRe.exec(block))) {
      const tds = [...rm[1]!.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map(
        (x) => cleanTxCell(x[1]!),
      );
      if (tds.length < 6) continue; // header row or malformed
      const marketRaw = tds[2]!;
      const side: "Over" | "Under" | null =
        marketRaw === "Over"
          ? "Over"
          : marketRaw === "Under"
            ? "Under"
            : null;
      if (!side) continue; // skip non-OU rows defensively
      const summ = parseMoneyCell(tds[3]!);
      if (summ === null) continue;
      const change = parseChangeCell(tds[4]!);
      const sourceType: ExcapperTransaction["sourceType"] =
        /^live$/i.test(tds[0] ?? "")
          ? "live"
          : /^prematch$/i.test(tds[0] ?? "")
            ? "prematch"
            : "unknown";
      const scoreMatch = /^(\d+)\s*[-:]\s*(\d+)$/.exec(tds[6] ?? "");
      out.push({
        line,
        side,
        summ,
        change,
        rawChange: tds[4]!,
        date: tds[1] ?? "",
        matchMinute: tds[5] ?? "",
        sourceType,
        score: scoreMatch
          ? { home: Number(scoreMatch[1]), away: Number(scoreMatch[2]) }
          : null,
      });
      parsedInThisTab++;
    }
    // Drift detector: if the tab block was non-trivially large but we
    // got zero rows out, the row/td markup contract has likely changed
    // upstream — emit a loud warn so we notice fast (instead of silent
    // alert loss). 2KB threshold avoids noise from empty-tab pages.
    if (
      parsedInThisTab === 0 &&
      block.length > 2000 &&
      !isRecognizedEmptyTransactionTab(block)
    ) {
      logger.warn(
        { line, tabId, blockBytes: block.length },
        "[EXCAPPER-TX] Tab block present but parsed 0 rows — possible markup drift",
      );
    }
  }
  return out;
}

function parseLiveObservationDetailed(
  html: string,
): Pick<DirectoryRow, "liveScore" | "livePeriod" | "liveMinute" | "observedTime"> {
  const visibleHtml = stripExcapperHtmlComments(html);
  const explicit = parseExcapperLiveState(visibleHtml);
  const transactionClock = (date: string): number | null => {
    // Excapper currently renders "HH:MM DD.MM" without year or timezone.
    // This is sufficient to order transactions from one current game page,
    // but not sufficient for an honest absolute-age/freshness calculation.
    const match = /^(\d{1,2}):(\d{2})\s+(\d{1,2})\.(\d{1,2})$/.exec(date.trim());
    if (!match) return null;
    const [, hourRaw, minuteRaw, dayRaw, monthRaw] = match;
    const hour = Number(hourRaw);
    const minute = Number(minuteRaw);
    const day = Number(dayRaw);
    const month = Number(monthRaw);
    if (
      hour > 23 ||
      minute > 59 ||
      day < 1 ||
      day > 31 ||
      month < 1 ||
      month > 12
    ) return null;
    return (((month * 32 + day) * 24 + hour) * 60) + minute;
  };
  const observations = parseGameTransactions(visibleHtml)
    .map((tx, index) => {
      const minute = parseObservedLiveMinute(tx.matchMinute);
      return { tx, minute, clock: transactionClock(tx.date), index };
    })
    .filter(
      (value) =>
        value.tx.sourceType === "live" &&
        value.tx.score &&
        value.minute !== null &&
        value.clock !== null,
    )
    // Use the newest explicit transaction timestamp, not the greatest
    // historical match minute. For equal timestamps, Excapper's first rendered
    // row is its newest row; preserving document order avoids inventing a tie
    // breaker from score or minute.
    .sort((a, b) => b.clock! - a.clock! || a.index - b.index);
  const latest = observations[0];
  // Only a rendered event clock describes the current minute. Transactions
  // are historical, and a disabled template clock inside a comment is inert.
  // Never scan arbitrary market text for a clock and never extrapolate it.
  // The first matchinfo block can be a hidden advertisement. Require an
  // event heading and clock in the same block, rather than taking the first
  // class match or combining unrelated blocks.
  let headerClock: string | undefined;
  for (const block of visibleHtml.matchAll(
    /<div\b[^>]*class=["']matchinfo["'][^>]*>([\s\S]*?)<\/div>/gi,
  )) {
    const content = block[1]!;
    if (!/<h1\b[^>]*>\s*\S[\s\S]*?<\/h1>/i.test(content)) continue;
    const clock = /<font\b[^>]*class=["']score live["'][^>]*>\s*(\d{1,3}(?:\+\d{1,2})?)['’]\s*<\/font>/i.exec(content)?.[1];
    if (clock) {
      headerClock = clock;
      break;
    }
  }
  const headerMinute = headerClock ? parseObservedLiveMinute(headerClock) : null;
  // Explicit event data takes precedence over a header clock. An old market
  // row cannot veto a visible header or establish the current period.
  const periodMinute = headerClock ? Number.parseInt(headerClock, 10) : null;
  const headerPeriod: DirectoryRow["livePeriod"] = periodMinute === null || headerMinute === null
    ? null
    : periodMinute <= 45 ? "first-half"
      : periodMinute <= 90 ? "second-half" : "extra-time";
  return {
    liveScore: explicit.score ?? latest?.tx.score ?? null,
    livePeriod: explicit.period ?? headerPeriod,
    liveMinute: explicit.minute ?? headerMinute,
    observedTime: latest?.tx.date ?? null,
  };
}

/** Backwards-compatible public parser contract used by existing consumers. */
export function parseLiveObservation(
  html: string,
): Pick<DirectoryRow, "liveScore" | "livePeriod"> {
  const { liveScore, livePeriod } = parseLiveObservationDetailed(html);
  return { liveScore, livePeriod };
}

/**
 * Identify NEW transactions since the last cycle and admit threshold-passing
 * rows to the global durable outbox listener when installed. Manual and global
 * hydrations share this watermark; admission failure leaves the row retryable.
 *
 * Critically: on FIRST observation for a (gameId, line, side) we only
 * seed the high-water and fire nothing — otherwise the entire history
 * of the match would spam the channel on first contact.
 */
export function processTransactions(
  matchId: string,
  gameId: string,
  txs: ReadonlyArray<ExcapperTransaction>,
  leagueName?: unknown,
): void {
  // The Excapper directory's own league label is authoritative for this
  // pipeline.  Do not seed transaction high-water state or emit alerts when
  // the caller cannot prove that label belongs to the canonical target set.
  if (!matchTargetLeague(leagueName)) return;
  if (txs.length === 0) return;
  const byKey = new Map<string, ExcapperTransaction[]>();
  for (const t of txs) {
    const k = `${gameId}:${t.line}:${t.side}`;
    let arr = byKey.get(k);
    if (!arr) {
      arr = [];
      byKey.set(k, arr);
    }
    arr.push(t);
  }
  for (const [key, arr] of byKey) {
    arr.sort((a, b) => a.summ - b.summ); // oldest bet → newest by cumulative total
    const maxSummNow = arr[arr.length - 1]!.summ;
    if (!txSeeded.has(key)) {
      if (!touchTxKey(key, maxSummNow)) continue;
      logger.info(
        {
          matchId,
          gameId,
          key,
          seededAtSumm: maxSummNow,
          historicalRowCount: arr.length,
        },
        "[EXCAPPER-TX] Seeded baseline (historical rows ignored, no alerts fired)",
      );
      continue;
    }
    const lastSeen = txHighWater.get(key) ?? 0;
    touchTxKey(key, lastSeen);
    const newRows = arr.filter((t) => t.summ > lastSeen);
    if (newRows.length === 0) continue;
    // A failed admission leaves the watermark unchanged. Retrying this key
    // replays every row in order; never skip a smaller failed bet for a newer one.
    if (txPending.has(key)) continue;
    const admit = (index: number): void => {
      if (index === newRows.length) {
        txPending.delete(key);
        return;
      }
      const tx = newRows[index]!;
      // The log below records every row when its admission is actually attempted.
      logger.info(
        {
          matchId, gameId, line: tx.line, side: tx.side, rawChangeCell: tx.rawChange,
          parsedChange: tx.change, summ: tx.summ, matchMinute: tx.matchMinute,
          date: tx.date, threshold: TX_SPIKE_THRESHOLD,
          thresholdPassed: tx.change >= TX_SPIKE_THRESHOLD,
          standaloneAlertSuppressed: newTransactionListener === null,
        },
        "[ALERT-CHECK] Per-transaction evaluation (Excapper Change cell)",
      );
      if (tx.change < TX_SPIKE_THRESHOLD || !newTransactionListener) {
        touchTxKey(key, tx.summ);
        admit(index + 1);
        return;
      }
      try {
        const outcome = newTransactionListener({ gameId, tx, league: String(leagueName) });
        if (outcome instanceof Promise) {
          txPending.add(key);
          void outcome.then((accepted) => {
            if (accepted === false) { txPending.delete(key); return; }
            touchTxKey(key, tx.summ);
            admit(index + 1);
          }, (error: unknown) => {
            txPending.delete(key);
            logger.error({ error, gameId }, "[GLOBAL-SPIKE] Transaction admission failed");
          });
        } else if (outcome === false) {
          // Explicit refusal: retain the high-water for the next observation.
        } else {
          touchTxKey(key, tx.summ);
          admit(index + 1);
        }
      } catch (error) {
        logger.error({ error, gameId }, "[GLOBAL-SPIKE] Transaction listener failed");
      }
    };
    admit(0);
  }
}

// ----- Cycle / Loop -----

function canonicalGameUrl(gameId: string): string {
  const url = new URL("/", BASE_URL);
  url.searchParams.set("action", "game");
  url.searchParams.set("id", gameId);
  return url.toString();
}

export interface ParsedGameDetail {
  gameId: string;
  observedAt: number;
  live: Pick<DirectoryRow, "liveScore" | "livePeriod" | "liveMinute" | "observedTime">;
  samples: ExcapperLineSample[];
  transactions: ExcapperTransaction[];
}

const GAME_DETAIL_MAX_AGE_MS = 12_000;
const MAX_PARSED_GAME_DETAILS = 100;
const parsedGameDetailCache = new Map<string, ParsedGameDetail>();
const parsedGameDetailInFlight = new Map<string, Promise<ParsedGameDetail>>();

/**
 * Fetch and parse one whitelisted fixture. Only normalized state is retained:
 * the multi-megabyte source HTML is released as soon as parsing completes.
 * Transport single-flight and the parsed single-flight make coordinator,
 * explicit refresh and approval consumers share one observation.
 */
export async function loadParsedGameDetail(
  gameId: string,
  signal: AbortSignal,
  tier: "manual" | "live" = "live",
): Promise<ParsedGameDetail> {
  if (gameId === "FORCE_MANUAL" || !/^\d+$/.test(gameId)) {
    throw new Error("Refusing to fetch a non-source Excapper fixture id");
  }
  const cached = parsedGameDetailCache.get(gameId);
  if (cached && Date.now() - cached.observedAt < GAME_DETAIL_MAX_AGE_MS) return cached;
  const existing = parsedGameDetailInFlight.get(gameId);
  if (existing) return existing;
  const request = (async () => {
    const gameUrl = canonicalGameUrl(gameId);
    const html = await fetchSharedExcapperGamePage(
      gameId,
      () => fetchText(gameUrl, signal, tier, GAME_DETAIL_MAX_AGE_MS),
    );
    const observedAt = getExcapperResponseObservedAt(gameUrl);
    if (observedAt === null) {
      throw new Error(`Excapper detail ${gameId} has no transport observation timestamp`);
    }
    const samples = parseGamePage(html, observedAt);
    if (!samples) throw new Error(`Excapper detail ${gameId} contained no parseable OU markets`);
    const detail: ParsedGameDetail = {
      gameId,
      observedAt,
      live: parseLiveObservationDetailed(html),
      samples,
      transactions: compactGameTransactions(parseGameTransactions(html)),
    };
    recordExcapperSnapshot(gameId, parseGameTransactions(html).map((tx) => ({
        id: `${gameId}:${tx.line}:${tx.side}:${tx.summ}:${tx.date}`,
        change: tx.change,
    })), observedAt);
    parsedGameDetailCache.set(gameId, detail);
    while (parsedGameDetailCache.size > MAX_PARSED_GAME_DETAILS) {
      const oldest = [...parsedGameDetailCache.entries()]
        .sort((a, b) => a[1].observedAt - b[1].observedAt)[0]?.[0];
      if (!oldest) break;
      parsedGameDetailCache.delete(oldest);
    }
    return detail;
  })().finally(() => {
    if (parsedGameDetailInFlight.get(gameId) === request) {
      parsedGameDetailInFlight.delete(gameId);
    }
  });
  parsedGameDetailInFlight.set(gameId, request);
  return request;
}

/** Keep every distinct parsed row (bounded), not only the max Summ: each new bet matters. */
function compactGameTransactions(
  transactions: readonly ExcapperTransaction[],
): ExcapperTransaction[] {
  const latest = new Map<string, ExcapperTransaction>();
  for (const transaction of transactions) {
    const key = `${transaction.line}:${transaction.side}:${transaction.summ}`;
    latest.set(key, transaction);
  }
  // Retain the highest cumulative rows for each market; older rows are only
  // historical baselines and must not crowd out newly arrived transactions.
  const bySide = new Map<string, ExcapperTransaction[]>();
  for (const transaction of latest.values()) {
    const key = `${transaction.line}:${transaction.side}`;
    const rows = bySide.get(key) ?? [];
    rows.push(transaction);
    bySide.set(key, rows);
  }
  return [...bySide.values()].flatMap((rows) =>
    rows.sort((a, b) => b.summ - a.summ).slice(0, 1_000));
}

/** Shared, target-filtered directory snapshot for the standalone watcher. */
export function loadLiveExcapperDirectory(signal: AbortSignal): Promise<ExcapperBatchSnapshot<DirectoryRow>> {
  return loadBatchSnapshot(signal);
}

const automaticBaseBindings = new Map<string, CachedManualExcapperBinding>();
let automaticBindingInFlight: Promise<void> | null = null;
/** Only verified bindings can supply a NowGoal identity to global alerts. */
export async function bindAutomaticExcapperRows(rows: readonly DirectoryRow[], observedAt: number): Promise<void> {
  if (automaticBindingInFlight) return automaticBindingInFlight;
  automaticBindingInFlight = performAutomaticBaseBinding(rows, observedAt).finally(() => { automaticBindingInFlight = null; });
  return automaticBindingInFlight;
}
async function performAutomaticBaseBinding(rows: readonly DirectoryRow[], observedAt: number): Promise<void> {
  const candidates = getAutomaticExcapperCandidates();
  const pending = new Map<string, { decision: BaseDecision; status: LatestBindingDecision["status"]; reason: string }>();
  const decisions = rows.map((row) => {
    const decision = chooseBaseBinding({
      id: row.gameId, ...row, kickoffMs: parseBindingKickoff(row.kickoffText, observedAt),
      homeScore: row.liveScore?.home, awayScore: row.liveScore?.away, period: row.livePeriod,
    }, candidates.filter((candidate) =>
      compatibleFixtureClass(candidate.team1, row.team1) &&
      compatibleFixtureClass(candidate.team2, row.team2)).map((candidate) => ({
      ...candidate, id: candidate.matchId,
      kickoffMs: candidate.kickoffMs ?? null,
      period: nowGoalPeriod(candidate.state ?? null),
    })));
    return { row, decision };
  });
  for (const candidate of candidates) {
    if (forceManualVerifiedIds.has(candidate.matchId)) continue;
    const decision = chooseBaseBinding({ ...candidate, id: candidate.matchId,
      kickoffMs: candidate.kickoffMs ?? null, period: nowGoalPeriod(candidate.state ?? null) },
    rows.filter((row) => compatibleFixtureClass(candidate.team1, row.team1) &&
      compatibleFixtureClass(candidate.team2, row.team2)).map((row) => ({
      ...row, id: row.gameId, kickoffMs: parseBindingKickoff(row.kickoffText, observedAt),
      homeScore: row.liveScore?.home, awayScore: row.liveScore?.away, period: row.livePeriod,
    })));
    const reverse = decisions.filter((item) => item.decision.chosen?.id === candidate.matchId);
    const blocked = blockedAutoPairs.has(`${candidate.matchId}\u0000*`) ||
      !!decision.chosen && blockedAutoPairs.has(`${candidate.matchId}\u0000${decision.chosen.id}`);
    const ambiguous = decision.ambiguous || (!!decision.chosen && (reverse.length !== 1 || reverse[0]?.row.gameId !== decision.chosen.id));
    pending.set(candidate.matchId, { decision,
      status: ambiguous ? "ambiguous" : decision.chosen && !blocked ? "bound" : "unbound",
      reason: blocked ? "operator_reset_block" : ambiguous ? "bidirectional_ambiguity" : decision.chosen ? "qualified" : decision.scored[0]?.reason ?? "no_candidates" });
  }
  for (const [id, binding] of automaticBaseBindings) {
    const current = decisions.find((entry) => entry.row.gameId === binding.gameId);
    if (!candidates.some((candidate) => candidate.matchId === id) ||
      (current && current.decision.chosen?.id !== id)) automaticBaseBindings.delete(id);
  }
  try {
  for (const { row, decision } of decisions) {
    const id = decision.chosen?.id;
    if (!id || decisions.filter((item) => item.decision.chosen?.id === id).length !== 1 ||
      manualBindingCache.has(id) || automaticBaseBindings.has(id) || getVerifiedExcapperBinding(row.gameId) ||
      forceManualVerifiedIds.has(id) || blockedAutoPairs.has(`${id}\u0000*`) ||
      pending.get(id)?.status !== "bound" ||
      blockedAutoPairs.has(`${id}\u0000${row.gameId}`)) continue;
    const candidate = candidates.find((item) => item.matchId === id)!;
    const epoch = manualBindingEpoch.get(id) ?? 0;
    const existing = getPersistedManualBindings().find((item) => item.nowgoalId === id || item.excapperId === row.gameId);
    if (existing && (existing.nowgoalId !== id || existing.excapperId !== row.gameId || !existing.autoBound)) continue;
    const evidence = bindingEvidence(candidate, row);
    const automaticDecision = createBindingDecision({
      ...evidence, action: "bind", mode: "automatic",
      reason: "Unique base team and kickoff agreement; canonical league is a soft bonus.",
    });
    const previous = await savePersistedManualBinding({
      nowgoalId: id, excapperId: row.gameId, boundAt: new Date(observedAt).toISOString(),
      status: "Verified", autoBound: true, source: safeSource(row) ?? undefined,
    }, manualBindingsUseTestFile() ? undefined : automaticDecision);
    try {
      if ((manualBindingEpoch.get(id) ?? 0) !== epoch || blockedAutoPairs.has(`${id}\u0000${row.gameId}`)) {
        throw new Error("Automatic binding invalidated by operator while persistence was pending");
      }
      if (manualBindingsUseTestFile()) recordBindingDecision(id, automaticDecision);
    } catch (error) {
      if (previous) await savePersistedManualBinding(previous);
      else await removePersistedManualBinding(id);
      throw error;
    }
    automaticBaseBindings.set(id, { matchId: id, diagnosticId: id, gameId: row.gameId,
      nowGoalLine: candidate.nowGoalLine, league: row.league, confidence: decision.scored.find((s) => s.candidate.id === id)!.score,
      bindingMode: "automatic", canonicalUrl: canonicalGameUrl(row.gameId),
      source: safeSource(row)!, auditEvidence: evidence });
  }
  } finally {
    for (const [id, item] of pending) {
      const manual = manualBindingCache.get(id)?.bindingMode === "manual_override";
      const bound = automaticBaseBindings.has(id) || manualBindingCache.has(id);
      publishBindingDecision(id, item.decision, manual ? "manual" :
        item.status === "bound" && !bound ? "unbound" : item.status,
      item.status === "bound" && !bound ? "binding_not_admitted" : item.reason);
    }
  }
}

export function getVerifiedExcapperBinding(gameId: string): {
  matchId: string; league: string; team1: string; team2: string;
} | null {
  const binding = [...manualBindingCache.values(), ...automaticBaseBindings.values()].find((item) =>
    item.gameId === gameId && (item.bindingMode === "automatic" || item.bindingMode === "manual_override"));
  return binding ? {
    matchId: binding.matchId,
    league: binding.source.league,
    team1: binding.source.team1,
    team2: binding.source.team2,
  } : null;
}

function removeCachedManualBinding(matchId: string): void {
  automaticBaseBindings.delete(matchId);
  manualBindingCache.delete(matchId);
  lastBatchHydratedAt.delete(matchId);
  forceManualVerifiedIds.delete(matchId);
  manualBindingEpoch.set(matchId, (manualBindingEpoch.get(matchId) ?? 0) + 1);
}

function isAuthoritativelyFinished(
  candidate: ManualExcapperHydrationCandidate,
): boolean {
  return (
    candidate.state !== null &&
    candidate.state !== undefined &&
    candidate.state < 0
  );
}

/**
 * Explicit fixture-lifetime release. The watchlist delete route calls this
 * both before and after persistence, invalidating any concurrent discovery
 * winner so an in-flight request cannot recreate the removed association.
 */
export function releaseManualExcapperBinding(matchId: string): void {
  removeCachedManualBinding(matchId);
  latestBindingDecisions.delete(matchId);
  void removePersistedManualBinding(matchId).catch((error) => {
    logger.error({ err: errMsg(error), matchId }, "[EXCAPPER] Failed to remove persistent binding on release");
  });
  excapperBindingDiagnostics.delete(matchId);
  leagueMismatchCandidates.delete(matchId);
}

export function __testOnlyResetManualExcapperBindingCache(): void {
  latestBindingDecisions.clear();
  manualBindingCache.clear();
  forceManualVerifiedIds.clear();
  manualBindingEpoch.clear();
  lastBatchHydratedAt.clear();
  parsedGameDetailCache.clear();
  parsedGameDetailInFlight.clear();
}

export function __testOnlyGetManualBindingEpoch(matchId: string): number {
  return manualBindingEpoch.get(matchId) ?? 0;
}

export function __testOnlyGetManualExcapperBindingCache(): Array<{
  matchId: string;
  gameId: string;
  canonicalUrl: string;
  confidence: number;
  bindingMode?: "automatic" | "manual_override";
}> {
  return [...manualBindingCache.values()].map(
    ({ matchId, gameId, canonicalUrl, confidence, bindingMode }) => ({
      matchId,
      gameId,
      canonicalUrl,
      confidence,
      bindingMode,
    }),
  );
}

/** Normalized identity only; lets the coordinator avoid a second game fetch. */
export function __testOnlyInstallManualExcapperBindingCache(input: {
  matchId: string;
  gameId: string;
  diagnosticId?: string;
}): void {
  manualBindingCache.set(input.matchId, {
    matchId: input.matchId,
    gameId: input.gameId,
    diagnosticId: input.diagnosticId ?? input.matchId,
    nowGoalLine: null,
    league: "Test League",
    confidence: 1,
    bindingMode: "automatic",
    canonicalUrl: canonicalGameUrl(input.gameId),
    source: {
      team1: "Test Home",
      team2: "Test Away",
      league: "Test League",
    },
  });
}

async function hydrateCachedManualBindings(
  candidates: readonly ManualExcapperHydrationCandidate[],
  signal: AbortSignal,
  digestObservations: ManualVolumeObservation[],
  onlyIds?: ReadonlySet<string>,
): Promise<{ attempted: number; hydrated: number }> {
  const candidatesById = new Map(candidates.map((candidate) => [candidate.matchId, candidate]));
  let attempted = 0;
  let hydrated = 0;
  for (const cached of [...manualBindingCache.values()]) {
    if (
      onlyIds &&
      !onlyIds.has(cached.matchId) &&
      !onlyIds.has(cached.diagnosticId)
    ) continue;
    const candidate = candidatesById.get(cached.matchId) ?? (
      hasManualExcapperHydrationMembership(cached.matchId)
        ? {
            matchId: cached.matchId,
            diagnosticId: cached.diagnosticId,
            team1: cached.source.team1,
            team2: cached.source.team2,
            league: cached.source.league,
            nowGoalLine: cached.nowGoalLine,
            state: null,
            homeScore: null,
            awayScore: null,
          }
        : undefined
    );
    // Membership disappeared (manual removal) or NowGoal explicitly reported a
    // negative terminal state. State 0 and half-time state 2 are deliberately
    // retained; temporary missing metadata is not interpreted as completion.
    if (!candidate) {
      removeCachedManualBinding(cached.matchId);
      clearManualMatchVolumeBinding(cached.matchId);
      continue;
    }
    if (isAuthoritativelyFinished(candidate)) {
      removeCachedManualBinding(cached.matchId);
      clearManualMatchVolumeBinding(cached.matchId);
      continue;
    }
    attempted++;
    let detail: ParsedGameDetail;
    try {
      detail = await loadParsedGameDetail(cached.gameId, signal, "live");
    } catch (error) {
      recordManualCandidateDiagnostic(candidate, "bound_pending", cached.source);
      logger.warn(
        { err: errMsg(error), matchId: cached.matchId, gameId: cached.gameId },
        "[EXCAPPER] Bound fixture detail unavailable; retaining last-good state",
      );
      // A shared 429/503/challenge opens the breaker. Stop this sequential pass
      // immediately instead of piling more per-game requests behind cooldown.
      if (isExcapperBreakerOpen()) break;
      continue;
    }
    if ((lastBatchHydratedAt.get(cached.matchId) ?? 0) >= detail.observedAt) continue;
    // Manual removal/re-add increments the epoch and replaces (or deletes)
    // this exact object. Never let an older response write into a new lifetime.
    if (manualBindingCache.get(cached.matchId) !== cached) continue;
      const observedSource = {
        ...cached.source,
        score: detail.live.liveScore,
        period: detail.live.livePeriod,
        minute: detail.live.liveMinute,
      };
      // Keep the latest successfully parsed source evidence on the immutable
      // binding object. A later stale/error tick must not revert diagnostics
      // to the score that happened to exist when the binding was created.
      cached.source = observedSource;
      const samples = detail.samples;
      if (hydrateManualMatchVolume(cached.matchId, samples, cached.gameId)) {
        lastBatchHydratedAt.set(cached.matchId, detail.observedAt);
        processTransactions(cached.matchId, cached.gameId, detail.transactions, cached.source.league);
        hydrated++;
        logger.info({
          matchId: cached.matchId,
          gameId: cached.gameId,
          score: detail.live.liveScore,
          period: detail.live.livePeriod,
          minute: detail.live.liveMinute,
          sampleCount: samples.length,
          observedAt: detail.observedAt,
        }, "[EXCAPPER] Full detail hydrated");
        for (const sample of samples) {
          digestObservations.push(
            {
              gameId: cached.gameId,
              matchLabel: `${cached.source.team1} vs ${cached.source.team2}`,
              league: cached.source.league,
              line: sample.line,
              side: "OVER",
              total: sample.over,
              observedAt: detail.observedAt,
              alertContext: getManualVolumeAlertContext(
                cached.matchId,
                sample.line,
                "OVER",
                sample.overOdds && sample.collectedAt
                  ? { odds: sample.overOdds, collectedAt: sample.collectedAt }
                  : null,
              ),
            },
            {
              gameId: cached.gameId,
              matchLabel: `${cached.source.team1} vs ${cached.source.team2}`,
              league: cached.source.league,
              line: sample.line,
              side: "UNDER",
              total: sample.under,
              observedAt: detail.observedAt,
              alertContext: getManualVolumeAlertContext(
                cached.matchId,
                sample.line,
                "UNDER",
                sample.underOdds && sample.collectedAt
                  ? { odds: sample.underOdds, collectedAt: sample.collectedAt }
                  : null,
              ),
            },
          );
        }
        recordManualCandidateDiagnostic(
          candidate,
          "hydrated",
          observedSource,
          detail.observedAt,
        );
      }
  }
  return { attempted, hydrated };
}

async function discoverManualBindings(
  directory: readonly DirectoryRow[],
  snapshot: ExcapperBatchSnapshot<DirectoryRow>,
  signal: AbortSignal,
  digestObservations: ManualVolumeObservation[],
  onlyIds?: ReadonlySet<string>,
): Promise<{ candidates: number; bound: number; hydrated: number }> {
  const placeholderIds = [...forceManualVerifiedIds].filter(
    (id) => !onlyIds || onlyIds.has(id),
  );
  const refreshedPlaceholders = placeholderIds.length
    ? await refreshManualBindingEvidence(placeholderIds)
    : new Set<string>();
  const candidates = getManualWatchlistMatchesForExcapper(onlyIds).filter(
    (candidate) =>
      !manualBindingCache.has(candidate.matchId) &&
      (!forceManualVerifiedIds.has(candidate.matchId) || refreshedPlaceholders.has(candidate.matchId)),
  );
  const candidateEpochs = new Map(
    candidates.map((candidate) => [
      candidate.matchId,
      manualBindingEpoch.get(candidate.matchId) ?? 0,
    ]),
  );
  if (snapshot.stale) {
    for (const candidate of candidates) {
      recordManualCandidateDiagnostic(candidate, "source_unavailable");
    }
    return { candidates: candidates.length, bound: 0, hydrated: 0 };
  }
  // Primary identity remains evidence, but every unmatched/review item is also
  // evaluated by the weighted hybrid matcher on each coordinator cycle.
  const liveRows = directory.filter((row) =>
    row.activity === "live" && row.isLive === true);
  const plausibleById = new Map<string, DirectoryRow>();
  const secondaryRowsByCandidate = new Map<string, Set<string>>();
  for (const candidate of candidates) {
    if (candidate.identityAmbiguous) continue;
    const countryCompatibleRows = liveRows.filter(
      (row) => countryEvidence(candidate, row) !== "conflict",
    );
    const primary = countryCompatibleRows.filter((row) =>
      completePairMatches(
        candidate.team1,
        candidate.team2,
        row.team1,
        row.team2,
        row.league,
        row.league,
      ));
    for (const row of primary) plausibleById.set(row.gameId, row);
    const fallback = secondaryRootShortlist(candidate, countryCompatibleRows);
    if (fallback.length === 0) continue;
    secondaryRowsByCandidate.set(
      diagnosticIdentity(candidate),
      new Set(fallback.map((row) => row.gameId)),
    );
    for (const row of fallback) plausibleById.set(row.gameId, row);
  }
  const plausibleRows = [...plausibleById.values()];
  const inspectedDirectory: DirectoryRow[] = [];
  const inspectedDetails = new Map<string, ParsedGameDetail>();
  for (const row of plausibleRows) {
    try {
      const detail = await loadParsedGameDetail(row.gameId, signal, "live");
      inspectedDetails.set(row.gameId, detail);
      inspectedDirectory.push({
        ...row, ...detail.live,
        liveScore: detail.live.liveScore ?? row.liveScore,
        livePeriod: detail.live.livePeriod ?? row.livePeriod,
        liveMinute: detail.live.liveMinute ?? row.liveMinute,
      });
    } catch (error) {
      logger.warn(
        { err: errMsg(error), gameId: row.gameId },
        "[EXCAPPER] Candidate detail inspection failed",
      );
      if (isExcapperBreakerOpen()) break;
    }
  }
  const qualifiedSecondary = new Map<string, QualifiedSecondaryBinding>();
  for (const candidate of candidates) {
    const diagnosticId = diagnosticIdentity(candidate);
    const fallbackIds = secondaryRowsByCandidate.get(diagnosticId);
    if (!fallbackIds) continue;
    const scored = inspectedDirectory
      .filter((row) => fallbackIds.has(row.gameId))
      .map((row) => ({ row, confidence: secondaryLiveConfidence(candidate, row) }))
      .filter((entry) => entry.confidence >= MANUAL_BINDING_MIN_CONFIDENCE)
      .sort((a, b) => b.confidence - a.confidence);
    const best = scored[0];
    if (!best) continue;
    // Similar candidates remain unresolved rather than being selected by
    // directory order, even when both clear the 50% promotion threshold.
    if (scored[1] && best.confidence - scored[1].confidence < 0.08) continue;
    qualifiedSecondary.set(diagnosticId, {
      gameId: best.row.gameId,
      confidence: best.confidence,
    });
  }
  // Runtime automatic binding uses base values. The legacy strict resolver is
  // retained for explicit manual preview/approval paths only.
  const pendingDecisions = new Map<string, { decision: BaseDecision; status: LatestBindingDecision["status"]; reason: string }>();
  const baseBindings = candidates.flatMap((candidate) => {
    const decision = chooseBaseBinding({
      ...candidate, id: candidate.matchId, kickoffMs: candidate.kickoffMs ?? null,
      period: nowGoalPeriod(candidate.state ?? null),
    }, inspectedDirectory.map((row) => ({
      ...row, id: row.gameId, kickoffMs: parseBindingKickoff(row.kickoffText, snapshot.observedAt),
      homeScore: row.liveScore?.home, awayScore: row.liveScore?.away, period: row.livePeriod,
    })));
    const blocked = blockedAutoPairs.has(`${diagnosticIdentity(candidate)}\u0000*`) ||
      !!decision.chosen && blockedAutoPairs.has(`${diagnosticIdentity(candidate)}\u0000${decision.chosen.id}`);
    pendingDecisions.set(diagnosticIdentity(candidate), { decision,
      status: candidate.identityAmbiguous || decision.ambiguous ? "ambiguous" : decision.chosen && !blocked ? "bound" : "unbound",
      reason: blocked ? "operator_reset_block" : candidate.identityAmbiguous ? "target_identity_ambiguous" : decision.ambiguous ? "candidate_margin" : decision.chosen ? "qualified" : decision.scored[0]?.reason ?? "no_candidates" });
    if (!decision.chosen || blocked || candidate.identityAmbiguous) return [];
    return [{ matchId: candidate.matchId, gameId: decision.chosen.id,
      nowGoalLine: candidate.nowGoalLine, league: decision.chosen.league,
      confidence: decision.scored.find((entry) => entry.candidate.id === decision.chosen!.id)!.score }];
  });
  // Retain the established manual-watchlist identity path, but missing-time
  // promotion now requires BOTH independent team identities and complete live
  // corroboration. Never let the legacy path bypass an observed kickoff.
  const legacyBindings = resolveManualExcapperBindings(candidates, inspectedDirectory, qualifiedSecondary)
    .filter((binding) => {
      const candidate = candidates.find((item) => item.matchId === binding.matchId)!;
      const row = inspectedDirectory.find((item) => item.gameId === binding.gameId)!;
      const direct = secondaryTeamSimilarity(candidate.team1, row.team1) >= .8 &&
        secondaryTeamSimilarity(candidate.team2, row.team2) >= .8;
      const reversed = secondaryTeamSimilarity(candidate.team1, row.team2) >= .8 &&
        secondaryTeamSimilarity(candidate.team2, row.team1) >= .8;
      return candidate.kickoffMs == null && !candidate.identityAmbiguous && direct && !reversed &&
        candidate.homeScore != null && candidate.awayScore != null &&
        row.liveScore?.home === candidate.homeScore && row.liveScore?.away === candidate.awayScore &&
        !!row.livePeriod && row.livePeriod === nowGoalPeriod(candidate.state ?? null) &&
        !blockedAutoPairs.has(`${diagnosticIdentity(candidate)}\u0000*`) &&
        !blockedAutoPairs.has(`${diagnosticIdentity(candidate)}\u0000${row.gameId}`);
    });
  const mergedBindings = [...legacyBindings, ...baseBindings.filter((binding) =>
    !legacyBindings.some((other) => other.matchId === binding.matchId && other.gameId === binding.gameId))];
  const bindings = mergedBindings.filter((binding) =>
    mergedBindings.filter((other) => other.gameId === binding.gameId).length === 1 &&
    mergedBindings.filter((other) => other.matchId === binding.matchId).length === 1);
  for (const binding of legacyBindings.filter((item) => bindings.includes(item))) {
    const candidate = candidates.find((item) => item.matchId === binding.matchId)!;
    const row = inspectedDirectory.find((item) => item.gameId === binding.gameId)!;
    const decision = chooseBaseBinding({ ...candidate, id: candidate.matchId, kickoffMs: null,
      period: nowGoalPeriod(candidate.state ?? null) },
      [{ ...row, id: row.gameId, kickoffMs: parseBindingKickoff(row.kickoffText, snapshot.observedAt),
        homeScore: row.liveScore?.home, awayScore: row.liveScore?.away, period: row.livePeriod }]);
    const scored = decision.scored[0]!;
    scored.home = secondaryTeamSimilarity(candidate.team1, row.team1);
    scored.away = secondaryTeamSimilarity(candidate.team2, row.team2);
    scored.score = binding.confidence;
    scored.reason = "qualified_manual_watchlist_identity";
    scored.gates = { teams: true, kickoff: true, scorePeriod: true, conflict: false };
    scored.normalized = { sourceHome: secondaryTeamTokens(candidate.team1).join(" "),
      sourceAway: secondaryTeamTokens(candidate.team2).join(" "),
      candidateHome: secondaryTeamTokens(row.team1).join(" "),
      candidateAway: secondaryTeamTokens(row.team2).join(" ") };
    const exact = manualBindingConfidence(candidate, row) === 1;
    scored.model = exact ? "manual_exact_gate" : "manual_secondary_weighted";
    scored.contributions = exact ? { teams: 1, time: 0, league: 0, corroboration: 0, country: 0, minute: 0 } :
      { teams: .65 * (scored.home + scored.away) / 2, time: 0,
        league: leaguesAreSafelyEquivalent(candidate.league, row.league) ? .05 : 0,
        corroboration: .15, country: countryEvidence(candidate, row) === "match" ? .1 : 0,
        minute: candidate.liveMinute != null && row.liveMinute != null ? .05 : 0 };
    decision.chosen = scored.candidate;
    decision.thresholds.threshold = MANUAL_BINDING_MIN_CONFIDENCE;
    decision.thresholds.epsilon = .08;
    decision.thresholds.teamMinimum = .8;
    decision.thresholds.missingKickoffTeamMinimum = .8;
    // Keep runners-up from the same discovery, rather than discarding them.
    const previous = pendingDecisions.get(diagnosticIdentity(candidate));
    decision.scored.push(...(previous?.decision.scored.filter((item) => item.candidate.id !== row.gameId) ?? []));
    pendingDecisions.set(diagnosticIdentity(candidate), { decision, status: "bound", reason: scored.reason });
  }
  for (const binding of mergedBindings) {
    if (!bindings.includes(binding)) {
      const candidate = candidates.find((item) => item.matchId === binding.matchId)!;
      const latest = pendingDecisions.get(diagnosticIdentity(candidate));
      if (latest) {
        latest.status = "ambiguous"; latest.reason = "reverse_identity_ambiguity";
      }
    }
  }
  const classifications = classifyManualExcapperBindings(
    candidates,
    inspectedDirectory,
    qualifiedSecondary,
  );
  for (const candidate of candidates) {
    const diagnosticId = diagnosticIdentity(candidate);
    const classification = classifications.get(diagnosticId);
    if (classification) {
      recordManualCandidateDiagnostic(
        candidate,
        classification.status,
        classification.source,
      );
    }
  }
  let hydrated = 0;
  for (const binding of bindings) {
    let promotedPlaceholder: PersistedManualBinding | undefined;
    let previousAutomaticBinding: PersistedManualBinding | undefined;
    let automaticBindingPersisted = false;
    const bindingEpoch = candidateEpochs.get(binding.matchId) ??
      (manualBindingEpoch.get(binding.matchId) ?? 0);
    try {
      const boundCandidate = candidates.find(
        (candidate) =>
          candidate.matchId === binding.matchId && !candidate.identityAmbiguous,
      );
      const bindingDiagnosticId = boundCandidate
        ? diagnosticIdentity(boundCandidate)
        : binding.matchId;
      const detail = inspectedDetails.get(binding.gameId);
      const samples = detail?.samples ?? [];
      const row = inspectedDirectory.find((candidate) => candidate.gameId === binding.gameId);
      const sourceConfirmed =
        samples.length > 0 &&
        !!row &&
        row.activity === "live" &&
        row.isLive === true &&
        binding.confidence >= MANUAL_BINDING_MIN_CONFIDENCE;
      if (
        sourceConfirmed &&
        !manualBindingCache.has(binding.matchId) &&
        (manualBindingEpoch.get(binding.matchId) ?? 0) === bindingEpoch &&
        ![...manualBindingCache.values()].some(
          (cached) =>
            cached.gameId === binding.gameId && cached.matchId !== binding.matchId,
        ) &&
        canHydrateManualMatchVolume(binding.matchId)
      ) {
        const canonicalUrl = canonicalGameUrl(binding.gameId);
        const evidence = boundCandidate && row ? bindingEvidence(boundCandidate, row) : undefined;
        if (!evidence) continue;
        const resolvesManualPlaceholder = forceManualVerifiedIds.has(binding.matchId);
        const usedSecondary =
          qualifiedSecondary.get(bindingDiagnosticId)?.gameId === binding.gameId;
        const hydrationDecision = createBindingDecision({
          ...evidence, action: "bind",
          mode: resolvesManualPlaceholder ? "manual_override" : "automatic",
          reason: resolvesManualPlaceholder
            ? "Operator-approved identity placeholder resolved to a unique live source fixture with complete team, league, score, period and market evidence."
            : usedSecondary
              ? "Primary identity discovery returned no rows; unique weighted secondary team and league match passed active score and period corroboration; initial market hydration accepted."
              : "Unique normalized teams and kickoff match; canonical league soft bonus; initial market hydration accepted.",
        });
        if (resolvesManualPlaceholder) {
          // FORCE_MANUAL is an operator-approved identity placeholder, never a
          // source URL. It may be promoted only while that exact placeholder is
          // still the durable record; a real verified source id is immutable
          // here and can only be changed through the explicit operator flow.
          const existing = getPersistedManualBindings()
            .find((item) => item.nowgoalId === binding.matchId);
          if (!existing || existing.excapperId !== "FORCE_MANUAL") continue;
          promotedPlaceholder = existing;
          await savePersistedManualBinding({
            ...existing,
            diagnosticId: bindingDiagnosticId,
            excapperId: binding.gameId,
            source: existing.source ?? safeSource(row) ?? undefined,
          }, manualBindingsUseTestFile() ? undefined : hydrationDecision, bindingDiagnosticId);
        } else {
          previousAutomaticBinding = await savePersistedManualBinding({
            nowgoalId: binding.matchId,
            diagnosticId: bindingDiagnosticId,
            excapperId: binding.gameId,
            boundAt: new Date(detail!.observedAt).toISOString(),
            status: "Verified",
            autoBound: true,
            source: safeSource(row) ?? undefined,
          }, manualBindingsUseTestFile() ? undefined : hydrationDecision, bindingDiagnosticId);
          automaticBindingPersisted = true;
        }
        try {
          if (manualBindingsUseTestFile()) {
            recordBindingDecision(bindingDiagnosticId, hydrationDecision);
          }
        } catch (error) {
          if (promotedPlaceholder) {
            await savePersistedManualBinding(promotedPlaceholder);
            promotedPlaceholder = undefined;
          } else if (automaticBindingPersisted) {
            if (previousAutomaticBinding) {
              await savePersistedManualBinding(previousAutomaticBinding);
            } else {
              await removePersistedManualBinding(binding.matchId);
            }
            automaticBindingPersisted = false;
          }
          throw error;
        }
        // No await between preflight, durable admission and hydration.
        hydrateManualMatchVolume(binding.matchId, samples, binding.gameId);
        lastBatchHydratedAt.set(binding.matchId, detail!.observedAt);
        processTransactions(binding.matchId, binding.gameId, detail!.transactions, row.league);
        manualBindingCache.set(binding.matchId, {
          ...binding,
          bindingMode: resolvesManualPlaceholder ? "manual_override" : "automatic",
          canonicalUrl,
          diagnosticId: boundCandidate
            ? diagnosticIdentity(boundCandidate)
            : binding.matchId,
          source: safeSource(row)!,
          auditEvidence: evidence,
        });
        if (resolvesManualPlaceholder) forceManualVerifiedIds.delete(binding.matchId);
        hydrated++;
        if (row?.isLive === true && row.activity === "live" && row.livePeriod) {
          for (const sample of samples) {
            digestObservations.push(
              {
                gameId: binding.gameId,
                matchLabel: `${row.team1} vs ${row.team2}`,
                league: row.league,
                line: sample.line,
                side: "OVER",
                total: sample.over,
                observedAt: detail!.observedAt,
                alertContext: getManualVolumeAlertContext(
                  binding.matchId,
                  sample.line,
                  "OVER",
                  sample.overOdds && sample.collectedAt
                    ? { odds: sample.overOdds, collectedAt: sample.collectedAt }
                    : null,
                ),
              },
              {
                gameId: binding.gameId,
                matchLabel: `${row.team1} vs ${row.team2}`,
                league: row.league,
                line: sample.line,
                side: "UNDER",
                total: sample.under,
                observedAt: detail!.observedAt,
                alertContext: getManualVolumeAlertContext(
                  binding.matchId,
                  sample.line,
                  "UNDER",
                  sample.underOdds && sample.collectedAt
                    ? { odds: sample.underOdds, collectedAt: sample.collectedAt }
                    : null,
                ),
              },
            );
          }
        }
        if (boundCandidate) {
          recordManualCandidateDiagnostic(
            boundCandidate,
            "hydrated",
            row ? safeSource(row) : undefined,
            detail!.observedAt,
          );
        } else {
          recordExcapperBindingDiagnostic(
            bindingDiagnosticId,
            "hydrated",
            row ? safeSource(row) : undefined,
            detail!.observedAt,
          );
        }
        logger.info(
          {
            matchId: binding.matchId,
            gameId: binding.gameId,
            nowGoalOddsLine: binding.nowGoalLine,
            excapperVolumeLines: samples.map((sample) => sample.line),
          },
          "[EXCAPPER] Manual row bound and volume hydrated",
        );
        logger.info({
          matchId: binding.matchId,
          gameId: binding.gameId,
          score: detail!.live.liveScore,
          period: detail!.live.livePeriod,
          minute: detail!.live.liveMinute,
          sampleCount: samples.length,
          observedAt: detail!.observedAt,
        }, "[EXCAPPER] Full detail hydrated");
      } else if (samples.length === 0) {
        // Initial empty/authentication/error-shaped pages are not source
        // confirmation and therefore never create a verified cache entry.
        if (boundCandidate) {
          recordManualCandidateDiagnostic(boundCandidate, "empty_market");
        } else {
          recordExcapperBindingDiagnostic(bindingDiagnosticId, "empty_market");
        }
      } else {
        // The fetch and market parse succeeded, but scanner membership changed
        // while they were in flight. Do not mislabel that identity race as an
        // upstream fetch failure.
        if (boundCandidate) {
          recordManualCandidateDiagnostic(boundCandidate, "pending");
        } else {
          recordExcapperBindingDiagnostic(bindingDiagnosticId, "pending");
        }
      }
    } catch (err) {
      if (promotedPlaceholder) {
        try {
          await savePersistedManualBinding(promotedPlaceholder);
          manualBindingCache.delete(binding.matchId);
          lastBatchHydratedAt.delete(binding.matchId);
          forceManualVerifiedIds.add(binding.matchId);
          clearManualMatchVolumeBinding(binding.matchId);
        } catch (rollbackError) {
          logger.error(
            { err: errMsg(rollbackError), matchId: binding.matchId },
            "[EXCAPPER] Failed to restore unresolved operator placeholder",
          );
        }
      }
      if (automaticBindingPersisted) {
        try {
          if (previousAutomaticBinding) {
            await savePersistedManualBinding(previousAutomaticBinding);
          } else {
            await removePersistedManualBinding(binding.matchId);
          }
        } catch (rollbackError) {
          logger.error(
            { err: errMsg(rollbackError), matchId: binding.matchId },
            "[EXCAPPER] Failed to roll back automatic binding persistence",
          );
        }
      }
      const boundCandidate = candidates.find(
        (candidate) =>
          candidate.matchId === binding.matchId && !candidate.identityAmbiguous,
      );
      if (boundCandidate) {
        recordManualCandidateDiagnostic(boundCandidate, "fetch_failed");
      } else {
        recordExcapperBindingDiagnostic(binding.matchId, "fetch_failed");
      }
      const message = errMsg(err);
      logger.warn(
        { err: message, matchId: binding.matchId, gameId: binding.gameId },
        "[EXCAPPER] Manual volume hydration failed",
      );
    }
  }
  for (const [id, item] of pendingDecisions) {
    const candidate = candidates.find((entry) => diagnosticIdentity(entry) === id)!;
    const cached = manualBindingCache.get(candidate.matchId);
    const manual = forceManualVerifiedIds.has(candidate.matchId) || cached?.bindingMode === "manual_override";
    const status = manual ? "manual" : item.status === "bound" && !cached ? "unbound" : item.status;
    publishBindingDecision(id, item.decision, status,
      status === "unbound" && item.status === "bound"
        ? excapperBindingDiagnostics.get(id)?.status ?? "binding_not_admitted" : item.reason);
  }
  return { candidates: candidates.length, bound: hydrated, hydrated };
}

/**
 * Immediate one-shot hydration used after a manual URL pin has completed its
 * NowGoal metadata refresh. This does not start a loop and never processes
 * Excapper transactions or promotion dispatch.
 */
const manualHydrationInFlight = new Map<
  string,
  Promise<{ candidates: number; bound: number; hydrated: number }>
>();

/** Public typed error used by the explicit refresh API to preserve upstream
 * cooldown semantics instead of disguising a rate limit as a successful retry. */
export class ExcapperExplicitRefreshRateLimitError extends Error {
  constructor(
    readonly retryAfterMs: number,
    readonly status: 429 | 503 = 429,
  ) {
    super(status === 429
      ? "Excapper is rate limited. Retry after the shared cooldown."
      : "Excapper is temporarily unavailable. Retry after the shared cooldown.");
    this.name = "ExcapperExplicitRefreshRateLimitError";
  }
}

export function requestManualExcapperHydration(
  matchIds?: readonly string[],
  options: { fresh?: boolean } = {},
): Promise<{ candidates: number; bound: number; hydrated: number }> {
  const normalizedIds = matchIds
    ? [...new Set(matchIds.filter(
        (id) => /^\d+$/.test(id) || /^manual-text:txt:.+/.test(id),
      ))].sort()
    : null;
  const fresh = options.fresh === true;
  const key = `batch:${normalizedIds ? normalizedIds.join(",") : "*"}`;
  const existing = manualHydrationInFlight.get(key);
  if (existing) return existing;
  const request = (async () => {
    const controller = new AbortController();
    const digestObservations: ManualVolumeObservation[] = [];
    try {
      const onlyIds = normalizedIds ? new Set(normalizedIds) : undefined;
      const candidates = getManualWatchlistMatchesForExcapper(onlyIds);
      const candidateEpochs = new Map(
        candidates.map((candidate) => [
          candidate.matchId,
          manualBindingEpoch.get(candidate.matchId) ?? 0,
        ]),
      );
      const cached = await hydrateCachedManualBindings(
        candidates,
        controller.signal,
        digestObservations,
        onlyIds,
      );
      const undiscovered = candidates.filter(
        (candidate) =>
          !manualBindingCache.has(candidate.matchId) &&
          !isAuthoritativelyFinished(candidate) &&
          (manualBindingEpoch.get(candidate.matchId) ?? 0) ===
            candidateEpochs.get(candidate.matchId),
      );
      if (undiscovered.length === 0) {
        return {
          candidates: candidates.length,
          bound: cached.attempted,
          hydrated: cached.hydrated,
        };
      }
      if (isExcapperBreakerOpen()) {
        for (const candidate of undiscovered) {
          recordManualCandidateDiagnostic(candidate, "source_unavailable");
        }
        if (fresh) {
          const health = getExcapperHealth();
          throw new ExcapperExplicitRefreshRateLimitError(
            Math.max(0, (health.retryAt ?? Date.now()) - Date.now()),
            health.lastErrorStatus === 429 ? 429 : 503,
          );
        }
        return {
          candidates: candidates.length,
          bound: cached.attempted,
          hydrated: cached.hydrated,
        };
      }
      // Only unresolved rows need the shared identity directory. Existing
      // bindings go directly through their parsed detail cache above.
      const snapshot = await loadBatchSnapshot(controller.signal);
      const discovered = await discoverManualBindings(
        snapshot.rows,
        snapshot,
        controller.signal,
        digestObservations,
        onlyIds,
      );
      return {
        candidates: candidates.length,
        bound: cached.attempted + discovered.bound,
        hydrated: cached.hydrated + discovered.hydrated,
      };
    } catch (err) {
      const onlyIds = normalizedIds ? new Set(normalizedIds) : undefined;
      for (const candidate of getManualWatchlistMatchesForExcapper(onlyIds).filter(
        (value) =>
          !manualBindingCache.has(value.matchId) &&
          !isAuthoritativelyFinished(value),
      )) {
        recordManualCandidateDiagnostic(candidate, "source_unavailable");
      }
      throw err;
    } finally {
      try {
        if (digestObservations.length > 0) {
          await queueManualWatchlistVolumeDigest(digestObservations);
        }
      } finally {
        if (!controller.signal.aborted) controller.abort();
      }
    }
  })().finally(() => {
    if (manualHydrationInFlight.get(key) === request) {
      manualHydrationInFlight.delete(key);
    }
  });
  manualHydrationInFlight.set(key, request);
  return request;
}

export class LeagueAliasApprovalConflict extends Error {}

const leagueAliasApprovalInFlight = new Map<string, Promise<{
  created: boolean;
  matchId: string;
  gameId: string;
  status: "bound_verified" | "bound_pending";
}>>();

interface LeagueAliasApprovalDependencies {
  loadDirectory(signal: AbortSignal): Promise<DirectoryRow[]>;
  loadGame(gameId: string, signal: AbortSignal): Promise<string | ParsedGameDetail>;
  persist(a: string, b: string): Promise<{ created: boolean }>;
  candidates(): ManualExcapperHydrationCandidate[];
  hasMembership(matchId: string): boolean;
  hydrate(
    matchId: string,
    samples: ReadonlyArray<{ line: number; over: number; under: number }>,
    gameId: string,
  ): boolean;
}

const defaultLeagueAliasApprovalDependencies: LeagueAliasApprovalDependencies = {
  async loadDirectory(signal) {
    return (await loadBatchSnapshot(signal)).rows;
  },
  async loadGame(gameId, signal) {
    return loadParsedGameDetail(gameId, signal, "manual");
  },
  persist: persistManualLeagueAlias,
  candidates: () => getManualWatchlistMatchesForExcapper(),
  hasMembership: hasManualExcapperHydrationMembership,
  hydrate: hydrateManualMatchVolume,
};
let leagueAliasApprovalDependencies = defaultLeagueAliasApprovalDependencies;

export function __testOnlySetLeagueAliasApprovalDependencies(
  overrides?: Partial<LeagueAliasApprovalDependencies>,
): void {
  leagueAliasApprovalDependencies = overrides
    ? { ...leagueAliasApprovalDependencies, ...overrides }
    : defaultLeagueAliasApprovalDependencies;
}

/**
 * Approve only the exact candidate previously resolved by the diagnostic.
 * Identity, membership, live state, score and period are revalidated from
 * server-owned state immediately before the durable alias write.
 */
export function approveResolvedManualLeagueAlias(
  matchId: string,
  resolvedCandidate: string,
  confirmScoresMatch = false,
): Promise<{
  created: boolean;
  matchId: string;
  gameId: string;
  status: "bound_verified" | "bound_pending";
}> {
  const key = `${matchId}\u0000${resolvedCandidate}\u0000${confirmScoresMatch}`;
  const current = leagueAliasApprovalInFlight.get(key);
  if (current) return current;
  const operation = (async () => {
    const resolved = reviewCandidates.get(matchId)?.find(
      (item) => item.ref === resolvedCandidate,
    ) ?? leagueMismatchCandidates.get(matchId);
    if (!resolved || resolved.ref !== resolvedCandidate) {
      throw new LeagueAliasApprovalConflict(
        "The resolved fixture candidate changed. Refresh the row and review it again; no alias was saved.",
      );
    }
    const alreadyBound = [...manualBindingCache.values()].find(
      (binding) => binding.diagnosticId === matchId,
    );
    if (alreadyBound?.gameId === resolved.gameId) {
      return {
        created: false,
        matchId,
        gameId: resolved.gameId,
        status: getExcapperBindingDiagnostic(matchId).status === "bound_verified" ||
          getExcapperBindingDiagnostic(matchId).status === "hydrated"
          ? "bound_verified" as const
          : "bound_pending" as const,
      };
    }
    const currentDiagnostic = getExcapperBindingDiagnostic(matchId);
    if (
      !currentDiagnostic.candidates?.some((item) => item.ref === resolvedCandidate) &&
      !(
        currentDiagnostic.status === "missing_league_alias" &&
        currentDiagnostic.resolvedCandidate === resolvedCandidate
      )
    ) {
      throw new LeagueAliasApprovalConflict(
        "This league mismatch is no longer the row's current diagnostic. Refresh and review it again; no alias was saved.",
      );
    }
    const candidate = leagueAliasApprovalDependencies.candidates()
      .find((item) => diagnosticIdentity(item) === matchId);
    if (!candidate || !leagueAliasApprovalDependencies.hasMembership(candidate.matchId)) {
      throw new LeagueAliasApprovalConflict(
        "This fixture is no longer a manual watchlist member. No alias was saved.",
      );
    }
    if (candidate.identityAmbiguous || isAuthoritativelyFinished(candidate)) {
      throw new LeagueAliasApprovalConflict(
        "The fixture is now ambiguous or finished. No alias was saved.",
      );
    }
    const approvalEpoch = manualBindingEpoch.get(candidate.matchId) ?? 0;

    const controller = new AbortController();
    let directory: DirectoryRow[];
    try {
      directory = await leagueAliasApprovalDependencies.loadDirectory(controller.signal);
    } catch {
      throw new LeagueAliasApprovalConflict(
        "The source could not be revalidated. No alias was saved; retry when the feed recovers.",
      );
    }
    const row = directory.find((item) => item.gameId === resolved.gameId);
    if (
      !row ||
      row.gameId !== resolved.gameId ||
      normalizedTeamName(row.team1) !== normalizedTeamName(resolved.source.team1) ||
      normalizedTeamName(row.team2) !== normalizedTeamName(resolved.source.team2) ||
      normalizedLeagueIdentity(row.league) !== normalizedLeagueIdentity(resolved.source.league) ||
      row.activity !== "live" ||
      row.isLive !== true
    ) {
      throw new LeagueAliasApprovalConflict(
        "The source fixture changed, disappeared, or is no longer uniquely live. No alias was saved.",
      );
    }
    let loadedDetail: string | ParsedGameDetail;
    try {
      loadedDetail = await leagueAliasApprovalDependencies.loadGame(
        row.gameId,
        controller.signal,
      );
    } catch {
      throw new LeagueAliasApprovalConflict(
        "The exact fixture could not be revalidated. No alias was saved; retry when the feed recovers.",
      );
    }
    const detail = typeof loadedDetail === "string"
      ? {
          gameId: row.gameId,
          observedAt: Date.now(),
          live: parseLiveObservationDetailed(loadedDetail),
          samples: parseGamePage(loadedDetail, Date.now()) ?? [],
          transactions: parseGameTransactions(loadedDetail),
        }
      : loadedDetail;
    const observed = { ...row, ...detail.live };
    const corroborated = liveCorroborationMatches(candidate, observed);
    const explicitlyConfirmed = confirmScoresMatch === true;
    if (!corroborated && !explicitlyConfirmed) {
      throw new LeagueAliasApprovalConflict(
        "Explicit confirmation that the scores identify the same fixture is required. Nothing was bound.",
      );
    }
    if (
      !corroborated &&
      ((candidate.state != null && candidate.state < 1) ||
        observed.activity !== "live" || observed.isLive !== true)
    ) {
      throw new LeagueAliasApprovalConflict(
        "Prematch, finished, or unconfirmed-live fixtures cannot be overridden. Nothing was bound.",
      );
    }
    if ([...manualBindingCache.values()].some(
      (binding) => binding.gameId === row.gameId && binding.matchId !== candidate.matchId,
    )) {
      throw new LeagueAliasApprovalConflict(
        "The source fixture is already bound to another row. No alias was saved.",
      );
    }
    if (
      !leagueAliasApprovalDependencies.hasMembership(candidate.matchId) ||
      (manualBindingEpoch.get(candidate.matchId) ?? 0) !== approvalEpoch
    ) {
      throw new LeagueAliasApprovalConflict(
        "This fixture was removed or replaced during approval. No alias was saved.",
      );
    }

    // Durable approval must commit before it can affect either matcher/cache.
    const needsNewAlias = normalizedLeagueIdentity(candidate.league) !==
      normalizedLeagueIdentity(row.league) &&
      !leaguesAreSafelyEquivalent(candidate.league, row.league);
    const approval = needsNewAlias
      ? await leagueAliasApprovalDependencies.persist(candidate.league, row.league)
      : { created: false };
    if (
      !leagueAliasApprovalDependencies.hasMembership(candidate.matchId) ||
      (manualBindingEpoch.get(candidate.matchId) ?? 0) !== approvalEpoch
    ) {
      throw new LeagueAliasApprovalConflict(
        "The alias was saved, but the fixture was removed before binding and was not restored.",
      );
    }
    const candidateBindingAfterPersist = manualBindingCache.get(candidate.matchId);
    if (
      candidateBindingAfterPersist &&
      candidateBindingAfterPersist.gameId !== row.gameId
    ) {
      throw new LeagueAliasApprovalConflict(
        "The alias was saved, but this row was already bound to a different fixture while approval completed. The existing binding was not overwritten.",
      );
    }
    const gameOwnerAfterPersist = [...manualBindingCache.values()].find(
      (binding) =>
        binding.gameId === row.gameId &&
        binding.matchId !== candidate.matchId,
    );
    if (gameOwnerAfterPersist) {
      throw new LeagueAliasApprovalConflict(
        "The alias was saved, but this source fixture was already bound to another row while approval completed. No second binding was created.",
      );
    }
    if (candidateBindingAfterPersist?.gameId === row.gameId) {
      const currentStatus = getExcapperBindingDiagnostic(matchId).status;
      return {
        created: approval.created,
        matchId: candidate.matchId,
        gameId: row.gameId,
        status: currentStatus === "hydrated" || currentStatus === "bound_verified"
          ? "bound_verified" as const
          : "bound_pending" as const,
      };
    }
    const binding: CachedManualExcapperBinding = {
      matchId: candidate.matchId,
      gameId: row.gameId,
      nowGoalLine: candidate.nowGoalLine,
      league: row.league,
      confidence: corroborated
        ? 1
        : completePairMatches(
            candidate.team1,
            candidate.team2,
            row.team1,
            row.team2,
            row.league,
            row.league,
          )
          ? 0.5
          : 0.25,
      bindingMode: corroborated ? "automatic" : "manual_override",
      canonicalUrl: canonicalGameUrl(row.gameId),
      diagnosticId: matchId,
      source: safeSource(observed)!,
      auditEvidence: bindingEvidence(candidate, observed),
    };
    await bindingBlockDependencies.remove(matchId, row.gameId);
    if (
      !leagueAliasApprovalDependencies.hasMembership(candidate.matchId) ||
      (manualBindingEpoch.get(candidate.matchId) ?? 0) !== approvalEpoch
    ) {
      // Reset wins this race. Re-establish its durable block in case this
      // approval's awaited delete completed after reset's insert.
      await bindingBlockDependencies.persist(matchId, row.gameId);
      blockedAutoPairs.add(`${matchId}\u0000${row.gameId}`);
      throw new LeagueAliasApprovalConflict(
        "This fixture was removed or reset while approval completed and was not restored.",
      );
    }
    const ownerAfterBlockRemoval = [...manualBindingCache.values()].find(
      (item) => item.gameId === row.gameId && item.matchId !== candidate.matchId,
    );
    const rowAfterBlockRemoval = manualBindingCache.get(candidate.matchId);
    if (ownerAfterBlockRemoval || (rowAfterBlockRemoval &&
      rowAfterBlockRemoval.gameId !== row.gameId)) {
      throw new LeagueAliasApprovalConflict(
        "Binding ownership changed while approval completed. No binding was overwritten.",
      );
    }
    const isNewBinding = !manualBindingCache.has(candidate.matchId);
    try {
      if (isNewBinding) auditBinding(matchId, binding.auditEvidence!, "bind",
        corroborated ? "manual" : "manual_override",
        corroborated
          ? "Operator approved the reviewed fixture after live identity, score and period revalidation."
          : "Operator explicitly confirmed the reviewed live fixture despite score or timing corroboration differences.");
    } catch (err) {
      // The awaited block delete above must not defeat an earlier reset if
      // local audit admission now fails. Runtime cache/membership stay intact.
      if (blockedAutoPairs.has(`${matchId}\u0000${row.gameId}`)) {
        await bindingBlockDependencies.persist(matchId, row.gameId);
      }
      throw err;
    }
    manualBindingCache.set(candidate.matchId, binding);
    blockedAutoPairs.delete(`${matchId}\u0000${row.gameId}`);
    const hydrated = detail.samples.length > 0 &&
      leagueAliasApprovalDependencies.hydrate(candidate.matchId, detail.samples, row.gameId);
    recordManualCandidateDiagnostic(
      candidate,
      hydrated ? "bound_verified" : "bound_pending",
      binding.source,
      hydrated ? detail.observedAt : undefined,
    );
    return {
      created: approval.created,
      matchId: candidate.matchId,
      gameId: row.gameId,
      status: hydrated ? "bound_verified" as const : "bound_pending" as const,
    };
  })().finally(() => leagueAliasApprovalInFlight.delete(key));
  leagueAliasApprovalInFlight.set(key, operation);
  return operation;
}

export interface ForceManualBindingInput {
  nowgoalId: string | number;
  excapperId?: string | number;
  candidateId?: string | number;
  suggestedId?: string | number;
  candidateExcapperId?: string | number;
  signature?: string;
  source?: Partial<{ team1: string; team2: string; league: string }>;
}

function cleanId(value: unknown): string | undefined {
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value) || value < 0) return undefined;
    return String(value);
  }
  if (typeof value !== "string") return undefined;
  const id = value.trim();
  return id && id.length <= 1000 && !/[\u0000-\u001f]/.test(id) ? id : undefined;
}

/**
 * Operator-owned escape hatch. It deliberately does not depend on the current
 * discovery cache. Opaque review handles are resolved to their server-owned
 * game id when still available and are never persisted as source ids.
 */
let forceBindingOperation: Promise<unknown> = Promise.resolve();

async function performForceManualExcapperBinding(
  input: ForceManualBindingInput,
): Promise<PersistedManualBinding> {
  const nowgoalId = cleanId(input.nowgoalId);
  if (!nowgoalId) throw new Error("NowGoal ID is required");
  const diagnosticId = nowgoalId;
  const opaqueRef = cleanId(input.candidateId);
  const resolvedReview = opaqueRef
    ? reviewCandidates.get(diagnosticId)?.find((item) => item.ref === opaqueRef) ??
      (leagueMismatchCandidates.get(diagnosticId)?.ref === opaqueRef
        ? leagueMismatchCandidates.get(diagnosticId)
        : undefined)
    : undefined;
  const explicitId = cleanId(input.excapperId) ??
    cleanId(input.candidateExcapperId) ??
    cleanId(input.suggestedId);
  // candidateId is accepted directly only when it is visibly a source id.
  const candidateAsId = opaqueRef && /^\d+$/.test(opaqueRef) ? opaqueRef : undefined;
  const excapperId = explicitId ?? resolvedReview?.gameId ?? candidateAsId ?? "FORCE_MANUAL";
  if (excapperId !== "FORCE_MANUAL" && !/^[1-9]\d*$/.test(excapperId))
    throw new Error("A real numeric Excapper game ID is required for source binding");
  if (excapperId !== "FORCE_MANUAL" && getPersistedManualBindings().some(
    (row) => row.nowgoalId !== nowgoalId && row.excapperId === excapperId,
  )) throw new Error("This Excapper game is already bound to another NowGoal fixture");
  const candidate = getManualWatchlistMatchesForExcapper()
    .find((item) => item.matchId === nowgoalId);
  const displayedSource = resolvedReview?.source ?? {
    team1: cleanId(input.source?.team1) ?? "",
    team2: cleanId(input.source?.team2) ?? "",
    league: cleanId(input.source?.league) ?? "",
  };
  const target = candidate ? bindingEvidence(candidate, {
    gameId: excapperId, team1: displayedSource.team1, team2: displayedSource.team2,
    league: displayedSource.league, totalVolume: 0,
  }).target : {
    id: nowgoalId, home: null, away: null, league: null,
    score: null, period: null, minute: null,
  };
  const decision = createBindingDecision({
    action: "bind",
    mode: "manual_override",
    target,
    source: {
      id: excapperId === "FORCE_MANUAL" ? null : excapperId,
      home: displayedSource.team1 || null,
      away: displayedSource.team2 || null,
      league: displayedSource.league || null,
      score: null, period: null, minute: null,
    },
    reason: excapperId === "FORCE_MANUAL"
      ? "Operator verified the displayed fixture without an available source id; no source hydration is attempted."
      : "Operator force-approved the displayed source fixture after its discovery candidate became stale or unavailable.",
  });
  const binding: PersistedManualBinding = {
    nowgoalId,
    excapperId,
    boundAt: new Date().toISOString(),
    status: "Verified",
    autoBound: false,
    ...(cleanId(input.signature) ? { signature: cleanId(input.signature) } : {}),
    source: displayedSource,
  };
  // Production approval, its evidence and block removal commit together.
  // The historical file-only test adapter retains its previous rollback path.
  const fileBackend = manualBindingsUseTestFile();
  const previous = await savePersistedManualBinding(binding, fileBackend ? undefined : decision, nowgoalId, !fileBackend);
  const wildcardKey = `${diagnosticId}\u0000*`;
  const hadWildcard = blockedAutoPairs.has(wildcardKey);
  const pairKey = `${diagnosticId}\u0000${excapperId}`;
  const wasBlocked = excapperId !== "FORCE_MANUAL" && blockedAutoPairs.has(pairKey);
  if (fileBackend) try {
    // A successful explicit rebind supersedes an earlier reset of this exact
    // pair. Remove its durable block before activation; restore it together
    // with the previous JSON state if subsequent audit admission fails.
    if (wasBlocked) await bindingBlockDependencies.remove(diagnosticId, excapperId);
    if (hadWildcard) await bindingBlockDependencies.remove(diagnosticId, "*");
    recordBindingDecision(diagnosticId, decision);
  } catch (error) {
    if (previous) await savePersistedManualBinding(previous);
    else await removePersistedManualBinding(nowgoalId);
    if (wasBlocked) {
      await bindingBlockDependencies.persist(diagnosticId, excapperId);
      blockedAutoPairs.add(pairKey);
    }
    if (hadWildcard) await bindingBlockDependencies.persist(diagnosticId, "*");
    throw error;
  }
  if (wasBlocked) blockedAutoPairs.delete(pairKey);
  if (hadWildcard) blockedAutoPairs.delete(wildcardKey);
  installPersistedManualBinding(binding);
  return binding;
}

export function forceManualExcapperBinding(
  input: ForceManualBindingInput,
): Promise<PersistedManualBinding> {
  // Keep save → audit admission → runtime activation/rollback indivisible from
  // every other force submit. Otherwise one failed duplicate could roll back a
  // later successful record.
  const run = forceBindingOperation.then(() => performForceManualExcapperBinding(input));
  forceBindingOperation = run.catch(() => undefined);
  return run;
}

/**
 * Operator reset: immediately invalidate the fixture lifetime and prevent the
 * same candidate being silently reattached. The candidate remains reviewable
 * and can be explicitly approved again.
 */
async function performResetManualExcapperBinding(matchId: string): Promise<void> {
  const current = manualBindingCache.get(matchId);
  const pairs = forceManualVerifiedIds.has(matchId)
    ? [{ diagnosticId: matchId, gameId: "*" }]
    : current
    ? [{ diagnosticId: current.diagnosticId, gameId: current.gameId }]
    : (reviewCandidates.get(matchId) ?? []).map((item) => ({
        diagnosticId: matchId,
        gameId: item.gameId,
      }));
  const resetCandidate = getManualWatchlistMatchesForExcapper()
    .find((candidate) => candidate.matchId === matchId);
  const auditEntries: Array<{ matchId: string; decision: BindingDecision }> = [];
  for (const pair of pairs) {
    const review = reviewCandidates.get(pair.diagnosticId)?.find((item) => item.gameId === pair.gameId);
    const source = current?.source ?? review?.source;
    const evidence = current?.auditEvidence ?? {
      target: {
        id: matchId, home: resetCandidate?.team1 ?? null, away: resetCandidate?.team2 ?? null,
        league: resetCandidate?.league ?? null, score: null, period: null, minute: null,
      },
      source: {
        id: pair.gameId === "*" ? null : pair.gameId,
        home: source?.team1 ?? null, away: source?.team2 ?? null,
        league: source?.league ?? null, score: null, period: null, minute: null,
      },
    };
    auditEntries.push({ matchId: pair.diagnosticId, decision: createBindingDecision({
      ...evidence, action: "reset", mode: "manual",
      reason: current
        ? "Operator reset the binding; the previous source fixture is blocked from automatic reattachment. Evidence is the original binding snapshot."
        : "Operator reset pending review; this source fixture is blocked from automatic reattachment.",
    }) });
  }
  // Reset blocks already require PostgreSQL. One transaction persists both
  // blocks and audit, eliminating local-outbox/DB partial reset outcomes.
  // A rejected transaction leaves prior blocks and the runtime binding intact.
  await bindingBlockDependencies.reset(pairs, auditEntries, matchId);
  let diskError: unknown;
  if (manualBindingsUseTestFile()) {
    try {
      await removePersistedManualBinding(matchId);
    } catch (error) {
      diskError = error;
    }
  } else forgetPersistedManualBinding(matchId);
  for (const pair of pairs) {
    blockedAutoPairs.add(`${pair.diagnosticId}\u0000${pair.gameId}`);
  }
  removeCachedManualBinding(matchId);
  latestBindingDecisions.delete(matchId);
  clearManualMatchVolumeBinding(matchId);
  reviewCandidates.delete(matchId);
  leagueMismatchCandidates.delete(matchId);
  recordExcapperBindingDiagnostic(matchId, "missing_live_corroboration", current?.source);
  // The durable DB block already makes a leftover positive JSON record inert
  // on restart. Runtime must likewise honor that reset even if JSON cleanup
  // failed, while the route still reports the storage failure.
  if (diskError) throw diskError;
}

export function resetManualExcapperBinding(matchId: string): Promise<void> {
  const run = forceBindingOperation.then(() => performResetManualExcapperBinding(matchId));
  forceBindingOperation = run.catch(() => undefined);
  return run;
}

// Whichever worker wins the one shared recovery probe (including GLOBAL)
// immediately rehydrates manual Priority Watchlist rows. The directory request
// itself is single-flight, so this callback reuses the successful response
// rather than issuing a concurrent recovery herd.
onExcapperRecovery(() => {
  void requestManualExcapperHydration().catch((err) => {
    logger.warn(
      { err: errMsg(err) },
      "[EXCAPPER] Immediate post-recovery manual hydration failed",
    );
  });
});

async function cycle(): Promise<void> {
  const myGen = scraperGeneration;
  abortController = new AbortController();
  const signal = abortController.signal;
  const digestObservations: ManualVolumeObservation[] = [];

  try {
    const manualMatches = getManualWatchlistMatchesForExcapper();
    const manualCandidateEpochs = new Map(
      manualMatches.map((candidate) => [
        candidate.matchId,
        manualBindingEpoch.get(candidate.matchId) ?? 0,
      ]),
    );
    if (
      manualMatches.length === 0 &&
      manualBindingCache.size === 0
    ) {
      logger.debug("[EXCAPPER] No manual matches eligible for hydration; skipping cycle");
      return;
    }

    const cachedManual = await hydrateCachedManualBindings(
      manualMatches,
      signal,
      digestObservations,
    );
    if (myGen !== scraperGeneration) return;
    const undiscoveredManual = manualMatches.filter(
      (candidate) =>
        !manualBindingCache.has(candidate.matchId) &&
        !isAuthoritativelyFinished(candidate) &&
        (manualBindingEpoch.get(candidate.matchId) ?? 0) ===
          manualCandidateEpochs.get(candidate.matchId),
    );
    // Shared circuit breaker also applies to on-demand manual discovery.
    if (isExcapperBreakerOpen()) {
      for (const match of undiscoveredManual) {
        recordManualCandidateDiagnostic(match, "source_unavailable");
      }
      logger.info(
        { cooldownRemainingMs: excapperBreakerRemainingMs() },
        "[EXCAPPER] Skipping cycle — breaker open (Excapper recently 503'd)",
      );
      return;
    }

    if (myGen !== scraperGeneration) return;
    let snapshot: ExcapperBatchSnapshot<DirectoryRow>;
    try {
      snapshot = await loadBatchSnapshot(signal);
    } catch (error) {
      for (const match of undiscoveredManual) {
        recordManualCandidateDiagnostic(match, "source_unavailable");
      }
      logger.warn({ err: errMsg(error) }, "[EXCAPPER] Root directory unavailable; retaining cache");
      return;
    }
    logger.debug(
      { rows: snapshot.rows.length, stale: snapshot.stale, detailCapable: snapshot.detailCapable },
      "[EXCAPPER] Root batch parsed",
    );

    // Only unresolved manual pins can trigger directory identity matching.
    if (undiscoveredManual.length > 0) {
      const result = await discoverManualBindings(
        snapshot.rows,
        snapshot,
        signal,
        digestObservations,
      );
      logger.info(
        { ...result, cachedDirect: cachedManual.attempted, cachedHydrated: cachedManual.hydrated },
        "[EXCAPPER] Manual binding/hydration pass",
      );
    }

  } finally {
    try {
      if (digestObservations.length > 0) {
        await queueManualWatchlistVolumeDigest(digestObservations);
      }
    } finally {
      abortController = null;
    }
  }
}

export function startExcapperScraper(): void {
  if (scraperRunning) {
    logger.warn("[EXCAPPER] Scraper already running");
    return;
  }
  scraperRunning = true;
  scraperGeneration++;
  logger.info("[EXCAPPER] Manual watchlist hydration enabled");
}

export async function runExcapperScraperCycle(): Promise<void> {
  if (!scraperRunning) return;
  await cycle();
}

export function stopExcapperScraper(): void {
  if (!scraperRunning) return;
  scraperRunning = false;
  scraperGeneration++;
  if (abortController) {
    try {
      abortController.abort();
    } catch {
      /* ignore */
    }
  }
  logger.info("[EXCAPPER] Manual watchlist hydration stopped");
}

function auditBinding(
  matchId: string,
  evidence: { target: BindingFixtureEvidence; source: BindingFixtureEvidence },
  action: BindingDecision["action"],
  mode: BindingDecision["mode"],
  reason: string,
): void {
  recordBindingDecision(matchId, createBindingDecision({ ...evidence, action, mode, reason }));
}
