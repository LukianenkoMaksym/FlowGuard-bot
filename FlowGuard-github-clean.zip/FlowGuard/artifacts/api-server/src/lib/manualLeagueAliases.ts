import { db, manualLeagueAliasesTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const approvedPairs = new Set<string>();
let ready = false;

interface ManualLeagueAliasStorage {
  ensure(): Promise<void>;
  load(): Promise<Array<{ left: string; right: string }>>;
  insert(values: {
    canonicalLeft: string;
    canonicalRight: string;
    leftLabel: string;
    rightLabel: string;
  }): Promise<boolean>;
}

const defaultStorage: ManualLeagueAliasStorage = {
  async ensure() {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS manual_league_aliases (
        canonical_left text NOT NULL,
        canonical_right text NOT NULL,
        left_label text NOT NULL,
        right_label text NOT NULL,
        approved_at timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT manual_league_aliases_pair_unique
          UNIQUE (canonical_left, canonical_right)
      )
    `);
  },
  load() {
    return db.select({
      left: manualLeagueAliasesTable.canonicalLeft,
      right: manualLeagueAliasesTable.canonicalRight,
    }).from(manualLeagueAliasesTable);
  },
  async insert(values) {
    const inserted = await db.insert(manualLeagueAliasesTable).values(values)
      .onConflictDoNothing().returning({
        left: manualLeagueAliasesTable.canonicalLeft,
      });
    return inserted.length > 0;
  },
};
let storage = defaultStorage;

export function canonicalLeagueIdentity(value: string): string {
  return value
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function canonicalPair(a: string, b: string): [string, string] | null {
  const left = canonicalLeagueIdentity(a);
  const right = canonicalLeagueIdentity(b);
  if (!left || !right || left === right) return null;
  return left < right ? [left, right] : [right, left];
}

function pairKey(left: string, right: string): string {
  return `${left}\u0000${right}`;
}

export async function initManualLeagueAliases(): Promise<void> {
  await storage.ensure();
  // Explicit operator-approved pair. Insert-only: never replace registry rows
  // or expand target-league/whitelist coverage.
  const leftLabel = "Brazil Campeonato Paraibano 2";
  const rightLabel = "Brazilian Paraibano Matches";
  const [canonicalLeft, canonicalRight] = canonicalPair(leftLabel, rightLabel)!;
  await storage.insert({ canonicalLeft, canonicalRight, leftLabel, rightLabel });
  const rows = await storage.load();
  approvedPairs.clear();
  for (const row of rows) approvedPairs.add(pairKey(row.left, row.right));
  ready = true;
}

export function manualLeagueAliasMatches(a: string, b: string): boolean {
  if (!ready) return false;
  const pair = canonicalPair(a, b);
  return pair ? approvedPairs.has(pairKey(...pair)) : false;
}

/**
 * Persist first, then publish to the process cache. A failed database write can
 * therefore never grant a runtime binding.
 */
export async function approveManualLeagueAlias(
  a: string,
  b: string,
): Promise<{ created: boolean; canonicalLeft: string; canonicalRight: string }> {
  if (!ready) throw new Error("League alias storage is not ready");
  const pair = canonicalPair(a, b);
  if (!pair) throw new Error("League labels do not form a valid alias pair");
  const [canonicalLeft, canonicalRight] = pair;
  const inserted = await storage.insert({
    canonicalLeft,
    canonicalRight,
    leftLabel: a,
    rightLabel: b,
  });
  approvedPairs.add(pairKey(canonicalLeft, canonicalRight));
  return { created: inserted, canonicalLeft, canonicalRight };
}

export function __testOnlyResetManualLeagueAliases(): void {
  approvedPairs.clear();
  ready = true;
}

export function __testOnlyInstallManualLeagueAlias(a: string, b: string): void {
  const pair = canonicalPair(a, b);
  if (pair) approvedPairs.add(pairKey(...pair));
  ready = true;
}

export function __testOnlySetManualLeagueAliasStorage(
  override?: ManualLeagueAliasStorage,
): void {
  storage = override ?? defaultStorage;
}