import type { CachedManualExcapperBinding } from "./excapper";

/**
 * Circular-safe runtime containers. scanner.ts can retire a fixture while the
 * Excapper module graph is still settling during startup/test isolation.
 */
export const manualBindingCache = new Map<string, CachedManualExcapperBinding>();
export const forceManualVerifiedIds = new Set<string>();
export const manualBindingEpoch = new Map<string, number>();
export const lastBatchHydratedAt = new Map<string, number>();