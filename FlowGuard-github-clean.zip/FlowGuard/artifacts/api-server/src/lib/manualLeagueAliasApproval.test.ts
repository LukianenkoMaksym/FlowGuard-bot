import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
vi.mock("./bindingDecisionAudit", async (importOriginal) => ({
  ...await importOriginal<typeof import("./bindingDecisionAudit")>(),
  recordBindingDecision: vi.fn(),
}));
import {
  __testOnlySetBindingBlockDependencies,
  __testOnlyGetManualExcapperBindingCache,
  __testOnlyInstallManualExcapperBindingCache,
  __testOnlyRecordManualCandidateDiagnostic,
  __testOnlyResetExcapperBindingDiagnostics,
  __testOnlyResetManualExcapperBindingCache,
  __testOnlySetLeagueAliasApprovalDependencies,
  approveResolvedManualLeagueAlias,
  classifyManualExcapperBindings,
  getExcapperBindingDiagnostic,
  LeagueAliasApprovalConflict,
  releaseManualExcapperBinding,
  type DirectoryRow,
} from "./excapper";

const candidate = {
  matchId: "700001",
  team1: "Alpha FC",
  team2: "Beta FC",
  league: "NowGoal Regional",
  nowGoalLine: 2.5,
  state: 3,
  homeScore: 1,
  awayScore: 0,
};
const row: DirectoryRow = {
  gameId: "9001",
  team1: "Alpha FC",
  team2: "Beta FC",
  league: "Excapper Regional",
  totalVolume: 1_500,
  isLive: true,
  activity: "live",
  liveScore: { home: 2, away: 0 },
  livePeriod: "second-half",
  liveMinute: 60,
  observedTime: "20:30 20.09",
};
const page = (score = "2-0", minute = "60") => `
  <a href="#tab_content_1">Over/Under 2.5 Goals</a>
  <div id="tab_content_1" class="tab-content">
    <div class="charts-bk__item-title">Over</div>
    <div class="charts-bk__item-coef">1 000 €</div>
    <div class="charts-bk__item-title">Under</div>
    <div class="charts-bk__item-coef">500 €</div>
    <table><tr><td>live</td><td>20:30 20.09</td><td>Over</td>
      <td>1 000 €</td><td>10 €</td><td>${minute}</td><td>${score}</td></tr></table>
  </div></body>`;

function installCurrentMismatch(): string {
  const classification = classifyManualExcapperBindings([candidate], [row])
    .get(candidate.matchId);
  expect(classification?.status).toBe("score_period_conflict");
  __testOnlyRecordManualCandidateDiagnostic(
    candidate,
    "missing_league_alias",
    classification?.source,
  );
  const ref = getExcapperBindingDiagnostic(candidate.matchId).resolvedCandidate;
  expect(ref).toBeTypeOf("string");
  return ref!;
}

describe("manual league alias approval", () => {
  const blockedPairs = new Set<string>();
  let membership: boolean;
  let persist = vi.fn(async (_a: string, _b: string) => ({ created: true }));
  let hydrate = vi.fn((
    _matchId: string,
    _samples: ReadonlyArray<{ line: number; over: number; under: number }>,
    _gameId: string,
  ) => true);

  beforeEach(() => {
    blockedPairs.clear();
    // Approval removes/reinstates durable auto-binding blocks. Keep that
    // persistence local to this suite; the default test DB denies all access.
    __testOnlySetBindingBlockDependencies({
      load: async () => [...blockedPairs].map((key) => {
        const [diagnosticId, gameId] = JSON.parse(key) as [string, string];
        return { diagnosticId, gameId };
      }),
      persist: async (diagnosticId, gameId) => {
        blockedPairs.add(JSON.stringify([diagnosticId, gameId]));
      },
      remove: async (diagnosticId, gameId) => {
        blockedPairs.delete(JSON.stringify([diagnosticId, gameId]));
      },
      reset: async () => {
        throw new Error("Unexpected binding reset in league alias approval test");
      },
    });
    __testOnlyResetExcapperBindingDiagnostics();
    __testOnlyResetManualExcapperBindingCache();
    membership = true;
    persist = vi.fn(async (_a: string, _b: string) => ({ created: true }));
    hydrate = vi.fn((
      _matchId: string,
      _samples: ReadonlyArray<{ line: number; over: number; under: number }>,
      _gameId: string,
    ) => true);
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [candidate],
      hasMembership: () => membership,
      loadDirectory: async () => [row],
      loadGame: async () => page(),
      persist: (a, b) => persist(a, b),
      hydrate: (matchId, samples, gameId) => hydrate(matchId, samples, gameId),
    });
  });
  afterEach(() => {
    __testOnlySetLeagueAliasApprovalDependencies();
    __testOnlySetBindingBlockDependencies();
  });

  it("persists the current mismatch, then immutably binds and directly hydrates it", async () => {
    const ref = installCurrentMismatch();
    const result = await approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    expect(result.status).toBe("bound_verified");
    expect(persist).toHaveBeenCalledWith(candidate.league, row.league);
    expect(hydrate).toHaveBeenCalledWith(
      candidate.matchId,
      expect.any(Array),
      row.gameId,
    );
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: candidate.matchId, gameId: row.gameId }),
    ]);
  });

  it("does not runtime-bind when durable persistence fails", async () => {
    const ref = installCurrentMismatch();
    persist.mockRejectedValueOnce(new Error("database unavailable"));
    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .rejects.toThrow("database unavailable");
    expect(hydrate).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });

  it("rejects stale opaque candidates but accepts explicitly confirmed stale score evidence", async () => {
    installCurrentMismatch();
    await expect(approveResolvedManualLeagueAlias(
      candidate.matchId,
      "stale_opaque_candidate_1234567890",
      true,
    )).rejects.toBeInstanceOf(LeagueAliasApprovalConflict);
    expect(persist).not.toHaveBeenCalled();

    const ref = getExcapperBindingDiagnostic(candidate.matchId).resolvedCandidate!;
    __testOnlySetLeagueAliasApprovalDependencies({ loadGame: async () => page("3-0") });
    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .resolves.toMatchObject({ gameId: row.gameId });
    expect(persist).toHaveBeenCalledOnce();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ gameId: row.gameId }),
    ]);
  });

  it("still rejects a changed selected game identity despite explicit confirmation", async () => {
    const ref = installCurrentMismatch();
    __testOnlySetLeagueAliasApprovalDependencies({
      loadDirectory: async () => [{
        ...row,
        team1: "Different Home",
      }],
    });
    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .rejects.toThrow("changed, disappeared, or is no longer uniquely live");
    expect(persist).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });

  it("coalesces simultaneous approvals and makes a completed retry idempotent", async () => {
    const ref = installCurrentMismatch();
    let release!: (html: string) => void;
    const delayedPage = new Promise<string>((resolve) => { release = resolve; });
    __testOnlySetLeagueAliasApprovalDependencies({
      loadGame: () => delayedPage,
    });
    const first = approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    const second = approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    release(page());
    await expect(Promise.all([first, second])).resolves.toHaveLength(2);
    expect(persist).toHaveBeenCalledTimes(1);
    expect(hydrate).toHaveBeenCalledTimes(1);

    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .resolves.toMatchObject({ created: false, status: "bound_verified" });
    expect(persist).toHaveBeenCalledTimes(1);
  });

  it("does not resurrect a fixture removed while revalidation is awaiting data", async () => {
    const ref = installCurrentMismatch();
    let release!: (html: string) => void;
    const delayedPage = new Promise<string>((resolve) => { release = resolve; });
    __testOnlySetLeagueAliasApprovalDependencies({
      loadGame: () => delayedPage,
    });
    const approval = approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    membership = false;
    releaseManualExcapperBinding(candidate.matchId);
    release(page());
    await expect(approval).rejects.toThrow("removed or replaced");
    expect(persist).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });

  it.each([
    {
      name: "the source game gains another owner",
      competing: { matchId: "other-row", gameId: row.gameId },
      message: "already bound to another row",
    },
    {
      name: "the target row gains a different game",
      competing: { matchId: candidate.matchId, gameId: "different-game" },
      message: "already bound to a different fixture",
    },
  ])("preserves the competing binding when $name during persistence", async ({
    competing,
    message,
  }) => {
    const ref = installCurrentMismatch();
    let persistenceStarted!: () => void;
    let finishPersistence!: (value: { created: boolean }) => void;
    const started = new Promise<void>((resolve) => { persistenceStarted = resolve; });
    const delayedPersistence = new Promise<{ created: boolean }>((resolve) => {
      finishPersistence = resolve;
    });
    persist.mockImplementationOnce(async () => {
      persistenceStarted();
      return delayedPersistence;
    });

    const approval = approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    await started;
    __testOnlyInstallManualExcapperBindingCache(competing);
    finishPersistence({ created: true });

    await expect(approval).rejects.toThrow(message);
    expect(hydrate).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining(competing),
    ]);
  });

  it("does not overwrite a same-fixture hydration that wins the persistence race", async () => {
    const ref = installCurrentMismatch();
    let persistenceStarted!: () => void;
    let finishPersistence!: (value: { created: boolean }) => void;
    const started = new Promise<void>((resolve) => { persistenceStarted = resolve; });
    const delayedPersistence = new Promise<{ created: boolean }>((resolve) => {
      finishPersistence = resolve;
    });
    persist.mockImplementationOnce(async () => {
      persistenceStarted();
      return delayedPersistence;
    });

    const approval = approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    await started;
    __testOnlyInstallManualExcapperBindingCache({
      matchId: candidate.matchId,
      gameId: row.gameId,
    });
    finishPersistence({ created: true });

    await expect(approval).resolves.toMatchObject({
      gameId: row.gameId,
      status: "bound_pending",
    });
    expect(hydrate).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toHaveLength(1);
  });
});
