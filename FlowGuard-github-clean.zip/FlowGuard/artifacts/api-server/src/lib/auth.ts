import { createHmac, timingSafeEqual, randomBytes } from "node:crypto";
import type { Request, Response, NextFunction } from "express";
import { logger } from "./logger";

const SESSION_SECRET = process.env["SESSION_SECRET"]?.trim();
const DASHBOARD_PASSWORD = process.env["DASHBOARD_PASSWORD"]?.trim();
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const COOKIE_NAME = "scnr_sess";

if (!SESSION_SECRET) {
  // Fail loud at boot — never silently fall back to an insecure mode.
  throw new Error("SESSION_SECRET is required for auth — set it in Replit Secrets.");
}
if (!DASHBOARD_PASSWORD) {
  // Don't crash (so /api/healthz still works) but lock everything else.
  logger.error("DASHBOARD_PASSWORD is not set — dashboard & API will reject all requests.");
}

function b64url(buf: Buffer): string {
  return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function sign(payload: string): string {
  // SESSION_SECRET is asserted non-null at module load above.
  return b64url(createHmac("sha256", SESSION_SECRET as string).update(payload).digest());
}

/** Build an opaque session token: <base64url payload>.<sig>  payload = `${expiresAt}` */
export function issueSessionToken(): string {
  const expiresAt = Date.now() + SESSION_TTL_MS;
  // Include random nonce so two simultaneous logins don't produce identical cookies.
  const nonce = b64url(randomBytes(12));
  const payload = b64url(Buffer.from(`${expiresAt}.${nonce}`));
  return `${payload}.${sign(payload)}`;
}

export function verifySessionToken(token: string | undefined): boolean {
  if (!token || typeof token !== "string") return false;
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  const [payload, providedSig] = parts;
  const expectedSig = sign(payload);
  // Constant-time compare to avoid timing attacks.
  const a = Buffer.from(providedSig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length) return false;
  if (!timingSafeEqual(a, b)) return false;
  // Decode and check expiry.
  try {
    const decoded = Buffer.from(payload.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString();
    const expiresAt = Number(decoded.split(".")[0]);
    if (!Number.isFinite(expiresAt)) return false;
    return Date.now() < expiresAt;
  } catch {
    return false;
  }
}

/** Constant-time string equality */
export function safeEqualStr(a: string, b: string): boolean {
  const aBuf = Buffer.from(a);
  const bBuf = Buffer.from(b);
  if (aBuf.length !== bBuf.length) return false;
  return timingSafeEqual(aBuf, bBuf);
}

export function checkPassword(submitted: string): boolean {
  if (!DASHBOARD_PASSWORD) return false;
  // Length-independent constant-time compare: HMAC both sides with the session
  // secret to produce fixed-size digests, then timing-safe compare. This avoids
  // leaking the password length via early-return on mismatch.
  const key = SESSION_SECRET as string;
  const a = createHmac("sha256", key).update(submitted).digest();
  const b = createHmac("sha256", key).update(DASHBOARD_PASSWORD).digest();
  return timingSafeEqual(a, b);
}

export function buildSessionCookie(token: string): string {
  const maxAge = Math.floor(SESSION_TTL_MS / 1000);
  // Secure: served over HTTPS in production via Replit proxy.
  // SameSite=Lax: allows top-level navigation (dashboard load) to send cookie.
  return `${COOKIE_NAME}=${token}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Lax`;
}

export function buildLogoutCookie(): string {
  return `${COOKIE_NAME}=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Lax`;
}

/** Extract session token from cookies (cookie-parser populated req.cookies). */
function extractToken(req: Request): string | undefined {
  const cookies = (req as Request & { cookies?: Record<string, string> }).cookies;
  return cookies?.[COOKIE_NAME];
}

/** Middleware: require a valid session for protected routes. */
export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const token = extractToken(req);
  if (verifySessionToken(token)) {
    next();
    return;
  }
  res.status(401).json({ ok: false, error: "auth_required" });
}

export function isAuthenticated(req: Request): boolean {
  return verifySessionToken(extractToken(req));
}

export const COOKIE_NAME_EXPORT = COOKIE_NAME;
