/**
 * LIVE-SCORE WATCHDOG — Sofascore cross-reference.
 *
 * Problem the user reported: the primary NowGoal feed occasionally serves
 * a frozen score (e.g. stuck at 2-0 when the real score is 3-1). Because
 * the % Success Rate signal blends odds with the assumption that the score
 * is current, a frozen score silently poisons every downstream decision
 * until the feed catches up.
 *
 * Fix: poll Sofascore (free, public, no API key) for every watchlist match.
 * Cross-reference home/away score. Trigger a forced override when:
 *
 *   (a) the Sofascore score differs from the cached primary score, AND
 *   (b) the primary score hasn't budged for FREEZE_THRESHOLD_MS while
 *       odds DID move recently (lastOddsChangeAt within ODDS_MOVE_MS).
 *
 * Both conditions matter. Pure score divergence isn't enough on its own
 * (a Sofascore parse glitch shouldn't be able to rewrite a healthy feed).
 * Pure freeze without odds activity isn't enough either (matches at HT
 * legitimately sit still for 15 min). The conjunction is the smell.
 *
 * --- DESIGN CONSTRAINTS ---
 *
 *   - WATCHLIST-ONLY scope. We never poll Sofascore for the full feed —
 *     CPU + Cloudflare risk would be unacceptable. Watchlist is bounded
 *     (typically < 20 matches), so even per-match calls every 25s are
 *     well under their tolerated request rate from a single IP.
 *   - SCALAR-ONLY MEMORY. The eventId resolution cache is a bounded Map
 *     (size cap RESOLVER_CACHE_MAX). No history arrays. Each tick reads
 *     current state and writes scalars.
 *   - NEVER THROWS into the timer loop. Every fetch is wrapped; failures
 *     are logged and ignored (Sofascore returning 403 / Cloudflare must
 *     never crash the bot).
 *   - INDEPENDENT TIMER. Same non-blocking pattern as altStream.ts.
 */

import { logger } from "./logger";
import {
  getWatchlistMatchesForVolume,
  setExternalScore,
  _internalGetMatchStates,
} from "./scanner";
import {
  nextSofascore403BackoffMs,
  SOFASCORE_RESOLVER_NEGATIVE_TTL_MS,
  SOFASCORE_UPSTREAM_ENABLED,
  sofascoreEventSuggesterUrl,
  sofascoreEventUrl,
  USER_AGENT_SOFASCORE,
} from "./config";

const TICK_INTERVAL_MS = 12_000;
const FETCH_TIMEOUT_MS = 4_500;
/** Odds moved within this window count as "recent activity". */
const ODDS_MOVE_MS = 3 * 60 * 1000;
/** Primary score hasn't changed for this long while odds moved = suspicious. */
const FREEZE_THRESHOLD_MS = 5 * 60 * 1000;
/** Hard cap on event-id resolution cache (matchId → sofascore eventId). */
const RESOLVER_CACHE_MAX = 500;

const UA = USER_AGENT_SOFASCORE;

interface ResolverEntry {
  eventId: number | null;
  resolvedAt: number;
  retryAt: number;
}

const resolverCache = new Map<string, ResolverEntry>();
/** Per-match seen score (used to detect freezes without keeping arrays).
 *  Bounded — pruned in lockstep with resolverCache so it cannot grow without
 *  limit across long-running uptimes with watchlist churn. */
const lastPrimaryScoreSeen = new Map<string, { home: number; away: number; at: number }>();
const SEEN_CACHE_MAX = RESOLVER_CACHE_MAX;

interface WatchdogStats {
  upstreamEnabled: boolean;
  disabledReason: string | null;
  ticks: number;
  resolved: number;
  unresolved: number;
  inSync: number;
  overrides: number;
  fetchFailures: number;
  lastTickAt: number | null;
  lastError: string | null;
  blocked: boolean;
  blockedUntil: number | null;
  blockedStatus: number | null;
}
const stats: WatchdogStats = {
  upstreamEnabled: SOFASCORE_UPSTREAM_ENABLED,
  disabledReason: SOFASCORE_UPSTREAM_ENABLED
    ? null
    : "Disabled by config after repeated HTTP 403 responses",
  ticks: 0,
  resolved: 0,
  unresolved: 0,
  inSync: 0,
  overrides: 0,
  fetchFailures: 0,
  lastTickAt: null,
  lastError: null,
  blocked: false,
  blockedUntil: null,
  blockedStatus: null,
};

let sofascore403BackoffMs = 0;

export function getScoreWatchdogStats(): Readonly<WatchdogStats> {
  refreshBlockedState();
  return stats;
}

let timer: ReturnType<typeof setTimeout> | null = null;
let generation = 0;
let inFlight = false;

class SofascoreHttpError extends Error {
  readonly status: number;

  constructor(status: number) {
    super(`HTTP ${status} from Sofascore`);
    this.name = "SofascoreHttpError";
    this.status = status;
  }
}

class SofascoreBlockedError extends Error {
  constructor(until: number | null) {
    super(
      until
        ? `Sofascore is blocked by HTTP 403; retry after ${new Date(until).toISOString()}`
        : "Sofascore is blocked by HTTP 403",
    );
    this.name = "SofascoreBlockedError";
  }
}

function refreshBlockedState(): void {
  if (!stats.blocked || stats.blockedUntil === null || Date.now() < stats.blockedUntil) return;
  stats.blocked = false;
  stats.blockedUntil = null;
  stats.blockedStatus = null;
}

function isBlocked(): boolean {
  refreshBlockedState();
  return stats.blocked;
}

function markBlocked(status: number): void {
  const nextBackoff = nextSofascore403BackoffMs(sofascore403BackoffMs);
  sofascore403BackoffMs = nextBackoff;
  stats.blocked = true;
  stats.blockedStatus = status;
  stats.blockedUntil = Date.now() + nextBackoff;
  stats.lastError = `HTTP ${status} from Sofascore (backoff ${Math.round(nextBackoff / 1000)}s)`;
}

function markReachable(): void {
  stats.blocked = false;
  stats.blockedUntil = null;
  stats.blockedStatus = null;
  sofascore403BackoffMs = 0;
}

function errorText(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

async function sofaFetch(url: string): Promise<unknown> {
  if (isBlocked()) throw new SofascoreBlockedError(stats.blockedUntil);
  const ctl = new AbortController();
  const timeoutId = setTimeout(() => ctl.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: ctl.signal,
      headers: {
        "User-Agent": UA,
        Accept: "application/json",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });
    if (!res.ok) {
      if (res.status === 403) markBlocked(res.status);
      throw new SofascoreHttpError(res.status);
    }
    markReachable();
    return await res.json();
  } finally {
    clearTimeout(timeoutId);
  }
}

interface ResolutionResult {
  eventId: number | null;
  retryAt: number;
}

/** Best-effort: turn a NowGoal team-pair into a Sofascore eventId via search. */
async function resolveEventId(team1: string, team2: string): Promise<ResolutionResult> {
  const now = Date.now();
  const q = encodeURIComponent(`${team1} ${team2}`).slice(0, 120);
  const url = sofascoreEventSuggesterUrl(q);
  let json: any;
  try {
    json = await sofaFetch(url);
  } catch (err) {
    stats.lastError = errorText(err);
    if (!(err instanceof SofascoreBlockedError)) {
      logger.debug({ err: errorText(err), team1, team2 }, "[SCORE-WATCHDOG] resolve failed");
    }
    return {
      eventId: null,
      retryAt: err instanceof SofascoreBlockedError
        ? (stats.blockedUntil ?? now + SOFASCORE_RESOLVER_NEGATIVE_TTL_MS)
        : now + SOFASCORE_RESOLVER_NEGATIVE_TTL_MS,
    };
  }
  const events = Array.isArray(json?.results)
    ? json.results
        .map((r: any) => r?.entity)
        .filter((e: any) => e && typeof e.id === "number" && e?.tournament?.category?.sport?.slug === "football")
    : [];
  if (events.length === 0) {
    return { eventId: null, retryAt: now + SOFASCORE_RESOLVER_NEGATIVE_TTL_MS };
  }
  // Prefer the most-recent / in-progress event in case the team pair has played
  // multiple times. Sofascore returns chronologically; first hit is usually it.
  return { eventId: events[0].id as number, retryAt: 0 };
}

async function fetchScoreById(eventId: number): Promise<{ home: number; away: number } | null> {
  const url = sofascoreEventUrl(eventId);
  let json: any;
  try {
    json = await sofaFetch(url);
  } catch (err) {
    if (!(err instanceof SofascoreBlockedError)) stats.fetchFailures++;
    stats.lastError = errorText(err);
    return null;
  }
  const home = Number(json?.event?.homeScore?.current);
  const away = Number(json?.event?.awayScore?.current);
  if (!Number.isFinite(home) || !Number.isFinite(away)) return null;
  return { home, away };
}

function pruneResolverCache(): void {
  if (resolverCache.size <= RESOLVER_CACHE_MAX) return;
  // Drop oldest entries by resolvedAt. We rebuild a sorted array only when
  // cap is exceeded — cost is amortized and rare.
  const sorted = [...resolverCache.entries()].sort((a, b) => a[1].resolvedAt - b[1].resolvedAt);
  const dropCount = sorted.length - RESOLVER_CACHE_MAX;
  for (let i = 0; i < dropCount; i++) {
    const key = sorted[i][0];
    resolverCache.delete(key);
    // Drop from the parallel seen-cache too; the two are keyed identically
    // by matchId so they should evict together.
    lastPrimaryScoreSeen.delete(key);
  }
}

function pruneSeenCache(): void {
  if (lastPrimaryScoreSeen.size <= SEEN_CACHE_MAX) return;
  const sorted = [...lastPrimaryScoreSeen.entries()].sort((a, b) => a[1].at - b[1].at);
  const dropCount = sorted.length - SEEN_CACHE_MAX;
  for (let i = 0; i < dropCount; i++) lastPrimaryScoreSeen.delete(sorted[i][0]);
}

async function checkOneMatch(matchId: string): Promise<void> {
  const states = _internalGetMatchStates();
  const st = states.get(matchId);
  if (!st || !st.lastMeta) return;
  const meta = st.lastMeta;
  if (!meta.isLive) return; // only worth checking live matches

  const now = Date.now();

  // Track first/last-changed time of the primary score so we can detect freezes
  // WITHOUT keeping a history array.
  const seen = lastPrimaryScoreSeen.get(matchId);
  if (!seen || seen.home !== meta.homeScore || seen.away !== meta.awayScore) {
    lastPrimaryScoreSeen.set(matchId, { home: meta.homeScore, away: meta.awayScore, at: now });
    pruneSeenCache();
  }
  const scoreUnchangedFor = now - (lastPrimaryScoreSeen.get(matchId)?.at ?? now);
  const oddsRecentlyMoved = now - st.lastOddsChangeAt < ODDS_MOVE_MS;
  const suspicious = scoreUnchangedFor > FREEZE_THRESHOLD_MS && oddsRecentlyMoved;

  // Resolve event id (cached). Empty searches get a bounded negative TTL;
  // upstream 403 backoff gets a shorter retry time so a policy block is
  // visible and recoverable without hammering the search endpoint.
  let entry = resolverCache.get(matchId);
  if (!entry || (entry.eventId === null && now >= entry.retryAt)) {
    const resolution = await resolveEventId(meta.team1, meta.team2);
    entry = {
      eventId: resolution.eventId,
      resolvedAt: now,
      retryAt: resolution.retryAt,
    };
    resolverCache.set(matchId, entry);
    pruneResolverCache();
    if (resolution.eventId === null) {
      stats.unresolved++;
      return;
    }
    stats.resolved++;
  }
  if (entry.eventId === null) return; // negative-cached

  const sofaScore = await fetchScoreById(entry.eventId);
  if (!sofaScore) return;

  if (sofaScore.home === meta.homeScore && sofaScore.away === meta.awayScore) {
    stats.inSync++;
    // Reset the freeze tracker — scores agree, no need to flag.
    lastPrimaryScoreSeen.set(matchId, { home: sofaScore.home, away: sofaScore.away, at: now });
    return;
  }

  // Divergence detected. Override only when the suspicious heuristic agrees.
  // Pure-divergence-without-freeze logs WARN but doesn't overwrite, so a
  // transient Sofascore glitch can't corrupt a healthy primary feed.
  if (!suspicious) {
    logger.info(
      {
        matchId,
        primary: { home: meta.homeScore, away: meta.awayScore },
        sofascore: sofaScore,
        scoreUnchangedForSec: Math.round(scoreUnchangedFor / 1000),
        oddsRecentlyMoved,
      },
      "[SCORE-WATCHDOG] divergence noted but not corrected (no freeze signal)",
    );
    return;
  }

  const res = setExternalScore(matchId, sofaScore.home, sofaScore.away, "sofascore");
  if (res.changed) {
    stats.overrides++;
    lastPrimaryScoreSeen.set(matchId, { home: sofaScore.home, away: sofaScore.away, at: now });
  }
}

async function tick(myGen: number): Promise<void> {
  if (myGen !== generation) return;
  if (inFlight) {
    schedule(myGen);
    return;
  }
  inFlight = true;
  try {
    if (!SOFASCORE_UPSTREAM_ENABLED) {
      // Keep the watchdog state alive so this source-level switch does
      // not disable NowGoal score updates or the broader score-watchdog
      // subsystem. It only prevents optional Sofascore network calls.
      stats.ticks++;
      stats.lastTickAt = Date.now();
      logger.debug(
        { reason: stats.disabledReason },
        "[SCORE-WATCHDOG] Sofascore upstream disabled; skipping optional HTTP calls",
      );
      return;
    }
    const watchlistMatches = getWatchlistMatchesForVolume();
    // Sequential per-match with a tiny inter-call gap so we don't burst all
    // requests at once (Cloudflare-friendly). For 10 matches at ~150ms each
    // that's ~1.5s — well inside our 25s budget.
    for (const m of watchlistMatches) {
      try {
        await checkOneMatch(m.matchId);
      } catch (err) {
        logger.debug({ matchId: m.matchId, err: err instanceof Error ? err.message : err }, "[SCORE-WATCHDOG] per-match error (continuing)");
      }
      await new Promise((r) => setTimeout(r, 150));
    }
    stats.ticks++;
    stats.lastTickAt = Date.now();
    logger.info(
      {
        watchlistChecked: watchlistMatches.length,
        resolvedTotal: stats.resolved,
        unresolvedTotal: stats.unresolved,
        inSyncTotal: stats.inSync,
        overridesTotal: stats.overrides,
        fetchFailuresTotal: stats.fetchFailures,
      },
      "[SCORE-WATCHDOG] tick complete (in sync / reconciled counts are running totals)",
    );
  } catch (err) {
    stats.lastError = err instanceof Error ? err.message : String(err);
    logger.warn({ err: stats.lastError }, "[SCORE-WATCHDOG] tick crashed (non-fatal)");
  } finally {
    inFlight = false;
  }
}

function schedule(myGen: number): void {
  if (myGen !== generation) return;
  timer = setTimeout(() => tick(myGen).catch(() => {}), TICK_INTERVAL_MS);
}

export function startScoreWatchdog(): void {
  // Compatibility control hook; scanCoordinator owns the only scan timer.
  generation++;
  logger.info(
    {
      intervalMs: TICK_INTERVAL_MS,
      freezeMs: FREEZE_THRESHOLD_MS,
      sofascoreUpstreamEnabled: SOFASCORE_UPSTREAM_ENABLED,
      disabledReason: stats.disabledReason,
    },
    "[SCORE-WATCHDOG] starting",
  );
}

export async function runScoreWatchdogCycle(): Promise<void> {
  const { getControls } = await import("./controls");
  if (!getControls().scoreWatchdogEnabled) return;
  await tick(generation);
}

export function stopScoreWatchdog(): void {
  generation++;
  if (timer !== null) {
    clearTimeout(timer);
    timer = null;
  }
  logger.info("[SCORE-WATCHDOG] stopped");
}
