import { getExcapperBindingDiagnostic } from "./excapper";
import {
  getRuntimeAuditScannerRows,
  getRuntimeArchiveRows,
  getRuntimeAuditTextExcapperBinding,
} from "./scanner";
import { getNormalizedEntries } from "./watchlist";
import type { NormalizedEntry } from "./watchlist";

export interface RuntimeAuditMatch {
  bindingDecision?: ReturnType<typeof getExcapperBindingDiagnostic>["bindingDecision"];
  key: string;
  nowGoalMatchId: string | null;
  matchName: string;
  leagueName: string;
  status: "Verified" | "Review Request" | "Pending";
  excapperMatchId: string | null;
  score: string | null;
  elapsedTime: string | null;
  matchPhase: string;
  sources: string[];
}

export interface RuntimeAudit {
  generatedAt: string;
  total: number;
  watchlistTotal: number;
  configuredWatchlistTotal?: number;
  archiveCount?: number;
  matches: RuntimeAuditMatch[];
}

export interface RuntimeAuditScannerRow {
  userWatchlist?: boolean;
  nowGoalMatchId: string;
  hasMeta: boolean;
  matchName: string | null;
  leagueName: string | null;
  score: string | null;
  elapsedTime: string | null;
  matchPhase: string;
  excapperMatchId: string | null;
}

interface RuntimeAuditDependencies {
  watchlist?: readonly NormalizedEntry[];
  scanner?: readonly RuntimeAuditScannerRow[];
  textBinding?: (signature: string) => string | null;
  diagnosticStatus?: (diagnosticId: string) => string;
  generatedAt?: string;
}

function statusFor(
  diagnosticId: string,
  excapperMatchId: string | null,
  diagnosticStatus: (diagnosticId: string) => string,
  forcePending = false,
): RuntimeAuditMatch["status"] {
  if (forcePending) return "Pending";
  if (excapperMatchId) return "Verified";
  const status = diagnosticStatus(diagnosticId);
  return status === "bound_verified" || status === "hydrated" ||
    status === "identity_only" || status === "bound_pending"
    ? "Verified" : status === "pending" ? "Pending" : "Review Request";
}

function addSource(row: RuntimeAuditMatch, source: string): void {
  if (!row.sources.includes(source)) row.sources.push(source);
}

/**
 * Builds an unfiltered union without fuzzy-name association. Numeric NowGoal
 * ids and accepted Excapper ids are the only cross-source identities.
 */
export function getRuntimeAudit(dependencies: RuntimeAuditDependencies = {}): RuntimeAudit {
  const watchlist = [...(dependencies.watchlist ?? getNormalizedEntries())];
  const scanner = [...(dependencies.scanner ?? getRuntimeAuditScannerRows())]
    .filter((row) => row.hasMeta && row.matchPhase === "Live");
  const textBinding = dependencies.textBinding ?? getRuntimeAuditTextExcapperBinding;
  const diagnosticStatus = dependencies.diagnosticStatus ??
    ((diagnosticId: string) => getExcapperBindingDiagnostic(diagnosticId).status);
  const rows = new Map<string, RuntimeAuditMatch>();
  const aliases = new Map<string, string>();

  const resolveKey = (nowGoalId: string | null, excapperId: string | null, fallback: string) => {
    const ng = nowGoalId ? aliases.get(`nowgoal:${nowGoalId}`) : undefined;
    if (ng) return ng;
    const ex = excapperId ? aliases.get(`excapper:${excapperId}`) : undefined;
    if (!ex) return fallback;
    const aliased = rows.get(ex);
    // A NowGoal id is the stronger fixture identity. A shared/erroneous
    // Excapper binding may join an id-less row to an id-bearing row, but must
    // never collapse two distinct NowGoal fixtures.
    if (
      nowGoalId &&
      aliased?.nowGoalMatchId &&
      aliased.nowGoalMatchId !== nowGoalId
    ) return fallback;
    return ex;
  };
  const remember = (key: string, nowGoalId: string | null, excapperId: string | null) => {
    if (nowGoalId) aliases.set(`nowgoal:${nowGoalId}`, key);
    if (excapperId) aliases.set(`excapper:${excapperId}`, key);
  };

  for (const entry of watchlist) {
    const excapperId = entry.matchId
      ? scanner.find((candidate) => candidate.nowGoalMatchId === entry.matchId)?.excapperMatchId ?? null
      : textBinding(entry.signature);
    const key = resolveKey(entry.matchId ?? null, excapperId, `watchlist:${entry.signature}`);
    const diagnosticId = entry.matchId ?? `manual-text:${entry.signature}`;
    rows.set(key, {
      key,
      nowGoalMatchId: entry.matchId ?? null,
      matchName: entry.label || "Unknown match",
      leagueName: entry.league ?? "Unknown league",
      status: statusFor(diagnosticId, excapperId, diagnosticStatus),
      excapperMatchId: excapperId,
      score: null,
      elapsedTime: null,
      matchPhase: "Unknown",
      sources: ["Watchlist"],
    });
    remember(key, entry.matchId ?? null, excapperId);
  }

  for (const tracked of scanner) {
    const key = resolveKey(
      tracked.nowGoalMatchId,
      tracked.excapperMatchId,
      `nowgoal:${tracked.nowGoalMatchId}`,
    );
    const existing = rows.get(key);
    if (existing) {
      existing.nowGoalMatchId = tracked.nowGoalMatchId;
      existing.matchName = tracked.matchName ?? existing.matchName;
      existing.leagueName = tracked.leagueName ?? existing.leagueName;
      existing.score = tracked.score;
      existing.elapsedTime = tracked.elapsedTime;
      existing.matchPhase = tracked.matchPhase;
      existing.excapperMatchId = tracked.excapperMatchId ?? existing.excapperMatchId;
      existing.status = statusFor(
        tracked.nowGoalMatchId,
        existing.excapperMatchId,
        diagnosticStatus,
        !tracked.hasMeta,
      );
      addSource(existing, "Scanner");
      if (existing.excapperMatchId) addSource(existing, "Excapper");
    } else {
      rows.set(key, {
        key,
        nowGoalMatchId: tracked.nowGoalMatchId,
        matchName: tracked.matchName ?? "Unknown match",
        leagueName: tracked.leagueName ?? "Unknown league",
        status: statusFor(
          tracked.nowGoalMatchId,
          tracked.excapperMatchId,
          diagnosticStatus,
          !tracked.hasMeta,
        ),
        excapperMatchId: tracked.excapperMatchId,
        score: tracked.score,
        elapsedTime: tracked.elapsedTime,
        matchPhase: tracked.matchPhase,
        sources: tracked.excapperMatchId ? ["Scanner", "Excapper"] : ["Scanner"],
      });
    }
    remember(key, tracked.nowGoalMatchId, tracked.excapperMatchId);
    if (tracked.userWatchlist) addSource(rows.get(key)!, "Watchlist");
  }

  const matches = [...rows.values()].filter((row) => row.matchPhase === "Live");
  for (const row of matches) {
    const id = row.nowGoalMatchId ?? row.key.replace(/^watchlist:/, "manual-text:");
    row.bindingDecision = getExcapperBindingDiagnostic(id).bindingDecision;
  }
  return {
    generatedAt: dependencies.generatedAt ?? new Date().toISOString(),
    total: matches.length,
    watchlistTotal: matches.filter((row) => row.sources.includes("Watchlist")).length,
    configuredWatchlistTotal: watchlist.length,
    archiveCount: getRuntimeArchiveRows().length,
    matches,
  };
}