import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const ORIGINAL_NAMES = ["Singapore S-League", "Malaysia"];
let directory = "";
let configPath = "";

async function loadPolicyModule() {
  vi.resetModules();
  return import("./targetLeagues");
}

beforeEach(async () => {
  directory = await mkdtemp(path.join(tmpdir(), "league-policy-"));
  configPath = path.join(directory, "target-leagues.json");
  await writeFile(configPath, JSON.stringify(ORIGINAL_NAMES), "utf8");
  process.env["TARGET_LEAGUES_CONFIG_PATH"] = configPath;
});

afterEach(async () => {
  delete process.env["TARGET_LEAGUES_CONFIG_PATH"];
  vi.resetModules();
  await rm(directory, { recursive: true, force: true });
});

describe("persistent league policy", () => {
  it("resolves real cross-source aliases and preserves them on legacy saves", async () => {
    const policy = await loadPolicyModule();
    const saved = await policy.updateLeaguePolicy([
      { name: "Ecuadorian Serie B", aliases: [" Liga Pro Ecuador Serie B "] },
    ], policy.getLeaguePolicy().revision, true);
    expect(policy.matchTargetLeague("Liga Pro Ecuador Serie B")).toBe("Ecuadorian Serie B");
    expect(policy.matchTargetLeague("ecuadorian serie b")).toBe("Ecuadorian Serie B");
    expect(policy.matchTargetLeague("Premier League")).toBeNull();
    expect(policy.matchTargetLeague("Liga Pro Ecuador Serie B Women")).toBeNull();
    await policy.updateLeaguePolicy(["Ecuadorian Serie B"], saved.revision);
    policy.reloadLeaguePolicyFromDisk();
    expect(policy.matchTargetLeague("Liga Pro Ecuador Serie B")).toBe("Ecuadorian Serie B");
    const revision = policy.getLeaguePolicy().revision;
    await policy.updateLeaguePolicy([{ name: "Ecuadorian Serie B", aliases: [] }], revision, true);
    expect(policy.getLeaguePolicy().revision).not.toBe(revision);
    expect(policy.matchTargetLeague("Liga Pro Ecuador Serie B")).toBeNull();
  });

  it("rejects ambiguous ownership, canonical collisions, invalid strings and caps", async () => {
    const policy = await loadPolicyModule();
    for (const entries of [
      [{ name: "A", aliases: ["same"] }, { name: "B", aliases: ["SAME"] }],
      [{ name: "A", aliases: ["B"] }, { name: "B", aliases: [] }],
      [{ name: "A", aliases: ["Singapore Premier League"] }],
      [{ name: "A", aliases: [3] }],
      [{ name: "A", aliases: [" "] }],
      [{ name: "A", aliases: ["x".repeat(201)] }],
      [{ name: "A", aliases: Array.from({ length: 65 }, (_, i) => `alias ${i}`) }],
    ]) {
      await expect(policy.updateLeaguePolicy(entries, policy.getLeaguePolicy().revision, true))
        .rejects.toMatchObject({ code: "validation" });
    }
  });
  it("enables the Ecuador alias only while its canonical competition is whitelisted", async () => {
    const policy = await loadPolicyModule();
    expect(policy.matchTargetLeague("Liga Pro Ecuador Serie B")).toBeNull();
    await policy.updateLeaguePolicy([{ name: "Ecuadorian Serie B", aliases: ["Liga Pro Ecuador Serie B"] }], policy.getLeaguePolicy().revision, true);
    expect(policy.matchTargetLeague("Liga Pro Ecuador Serie B")).toBe("Ecuadorian Serie B");
    expect(policy.getLeaguePolicy().total).toBe(1);
    await policy.updateLeaguePolicy([], policy.getLeaguePolicy().revision);
    expect(policy.matchTargetLeague("Liga Pro Ecuador Serie B")).toBeNull();
  });
  it("persists atomically, reloads, and retains known matcher semantics", async () => {
    const policy = await loadPolicyModule();
    const revision = policy.getLeaguePolicy().revision;

    const saved = await policy.updateLeaguePolicy(
      ["Singapore S-League", "Malaysia", "My Exact (U21) League"],
      revision,
    );
    expect(saved.total).toBe(3);
    expect(JSON.parse(await readFile(configPath, "utf8")).map((entry: { name: string }) => entry.name)).toEqual([
      "Singapore S-League",
      "Malaysia",
      "My Exact (U21) League",
    ]);
    expect(policy.matchTargetLeague("Singapore Premier League")).toBe("Singapore S-League");
    expect(policy.matchTargetLeague("my exact (u21) league")).toBe("My Exact (U21) League");
    expect(policy.matchTargetLeague("Prefix My Exact (U21) League")).toBeNull();

    await writeFile(configPath, JSON.stringify(["German 3.Liga"]), "utf8");
    policy.reloadLeaguePolicyFromDisk();
    expect(policy.matchTargetLeague("Germany 3 Liga")).toBe("German 3.Liga");
    expect(policy.matchTargetLeague("Singapore S-League")).toBeNull();
  });

  it("uses an empty policy to deny every automatic match", async () => {
    const policy = await loadPolicyModule();
    await policy.updateLeaguePolicy([], policy.getLeaguePolicy().revision);

    expect(policy.getLeaguePolicy().mode).toBe("empty");
    expect(policy.matchTargetLeague("Malaysia")).toBeNull();
    expect(policy.TARGET_LEAGUES).toHaveLength(0);
  });

  it("rejects conflicts, duplicates and unrestricted sentinels", async () => {
    const policy = await loadPolicyModule();
    const revision = policy.getLeaguePolicy().revision;
    await policy.updateLeaguePolicy(["Malaysia"], revision);

    await expect(policy.updateLeaguePolicy(["Singapore S-League"], revision)).rejects.toMatchObject({
      code: "conflict",
    });
    await expect(
      policy.updateLeaguePolicy(["Malaysia", "malaysia"], policy.getLeaguePolicy().revision),
    ).rejects.toMatchObject({ code: "validation" });
    await expect(policy.updateLeaguePolicy(["*"], policy.getLeaguePolicy().revision)).rejects.toMatchObject({
      code: "validation",
    });
  });

  it("canonicalizes known labels case-insensitively but preserves custom names", async () => {
    const policy = await loadPolicyModule();
    await policy.updateLeaguePolicy(
      ["singapore s-league", "My Custom League"],
      policy.getLeaguePolicy().revision,
    );

    expect(policy.getLeaguePolicy().entries.map((entry) => entry.name)).toEqual([
      "Singapore S-League",
      "My Custom League",
    ]);
    expect(JSON.parse(await readFile(configPath, "utf8")).map((entry: { name: string }) => entry.name)).toEqual([
      "Singapore S-League",
      "My Custom League",
    ]);
    expect(policy.matchTargetLeague("Singapore Premier League")).toBe("Singapore S-League");

    await writeFile(configPath, JSON.stringify(["german 3.liga", "Another Custom"]), "utf8");
    policy.reloadLeaguePolicyFromDisk();
    expect(policy.getLeaguePolicy().entries.map((entry) => entry.name)).toEqual([
      "German 3.Liga",
      "Another Custom",
    ]);
    expect(policy.matchTargetLeague("Germany 3 Liga")).toBe("German 3.Liga");
  });

  it("leaves the live runtime policy unchanged when persistence fails", async () => {
    const policy = await loadPolicyModule();
    const before = policy.getLeaguePolicy();
    await rm(configPath);
    await mkdir(configPath);

    await expect(policy.updateLeaguePolicy(["German 3.Liga"], before.revision)).rejects.toMatchObject({
      code: "persistence",
    });
    expect(policy.getLeaguePolicy()).toEqual(before);
    expect(policy.matchTargetLeague("Singapore S-League")).toBe("Singapore S-League");
  });
});