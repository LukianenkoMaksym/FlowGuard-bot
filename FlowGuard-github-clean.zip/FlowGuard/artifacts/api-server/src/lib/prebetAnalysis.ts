import type { ExcapperTransaction, ParsedGameDetail } from "./excapper";
import type { UnifiedOddsPoint } from "./unifiedAlert";

const HOUR = 60 * 60_000;
const RETENTION = 2 * HOUR;
const MAX_KEYS = 2_000;
const MAX_ODDS = 200;
const MAX_BETS = 1_000;
const WINDOW = 5 * 60_000;

/**
 * The feed's Date cell is HH:MM DD.MM, with no year or timezone. Interpret it
 * in the server's local timezone, choosing the nearest calendar year. Reject
 * invalid dates and distant dates rather than inventing a precise timestamp.
 */
export function parseExcapperBetTime(date: string, reference: number): number | null {
  const parts = /^(\d{1,2}):(\d{2})\s+(\d{1,2})\.(\d{1,2})$/.exec(date.trim());
  if (!parts || !Number.isFinite(reference)) return null;
  const [, h, m, d, mo] = parts.map(Number);
  if (h! > 23 || m! > 59 || d! < 1 || d! > 31 || mo! < 1 || mo! > 12) return null;
  const year = new Date(reference).getFullYear();
  const candidates = [year - 1, year, year + 1].map((y) => new Date(y, mo! - 1, d!, h!, m!))
    .filter((value) => value.getFullYear() >= year - 1 && value.getMonth() === mo! - 1 &&
      value.getDate() === d && value.getHours() === h && value.getMinutes() === m)
    .map((value) => value.getTime())
    .sort((a, b) => Math.abs(a - reference) - Math.abs(b - reference));
  const nearest = candidates[0];
  return nearest !== undefined && Math.abs(nearest - reference) <= 36 * HOUR ? nearest : null;
}

export function fixedBetTime(tx: ExcapperTransaction, capturedAt: number): number {
  return tx.betTime ?? parseExcapperBetTime(tx.date, capturedAt) ?? capturedAt;
}

export interface PrebetMoney {
  inflow15m: number;
  inflow60m: number;
  betCount15m: number;
}

type OddsObservation = UnifiedOddsPoint;
type BetObservation = { t: number; change: number; summ: number };

/** One independent, bounded source of observed detail snapshots. */
export class PrebetAnalysis {
  private odds = new Map<string, OddsObservation[]>();
  private bets = new Map<string, BetObservation[]>();
  /** Fresh directory presence, independent of detail-page fetch recency. */
  private directorySeen = new Map<string, number>();

  private key(gameId: string, line: number, side: string): string {
    return `${gameId}:${line}:${side}`;
  }

  private prune(now: number): void {
    for (const [game, seen] of this.directorySeen) {
      if (now - seen > RETENTION) this.directorySeen.delete(game);
    }
    while (this.directorySeen.size > MAX_KEYS) {
      this.directorySeen.delete(this.directorySeen.keys().next().value!);
    }
    const pruneStore = <T extends { ts?: number; t?: number }>(store: Map<string, T[]>): void => {
      for (const [key, points] of store) {
        if (!this.directorySeen.has(key.slice(0, key.indexOf(":")))) {
          store.delete(key);
          continue;
        }
        const retained = points.filter((point) => now - (point.ts ?? point.t ?? 0) <= RETENTION);
        if (retained.length) store.set(key, retained);
        else store.delete(key);
      }
      while (store.size > MAX_KEYS) store.delete(store.keys().next().value!);
    };
    pruneStore(this.odds);
    pruneStore(this.bets);
  }

  /** Directory entries absent for two hours are removed, without adding requests. */
  observeDirectory(gameIds: ReadonlyArray<string>, now: number): void {
    for (const id of gameIds) {
      this.directorySeen.delete(id);
      this.directorySeen.set(id, now);
    }
    this.prune(now);
  }

  observeDetail(gameId: string, detail: ParsedGameDetail): void {
    const t = detail.observedAt;
    if (!Number.isFinite(t) || !this.directorySeen.has(gameId)) return;
    for (const sample of detail.samples) {
      for (const [side, odds] of [["Over", sample.overOdds], ["Under", sample.underOdds]] as const) {
        if (!Number.isFinite(odds) || odds == null || odds <= 1) continue;
        const key = this.key(gameId, sample.line, side);
        const points = this.odds.get(key) ?? [];
        // Cached parsed HTML retains its actual fetch timestamp. Do not
        // masquerade repeated reads of that HTML as fresh market observations.
        if (!points.some((point) => point.ts === t)) {
          points.push({ ts: t, line: sample.line, odds });
          points.sort((a, b) => a.ts - b.ts);
        }
        this.odds.delete(key);
        this.odds.set(key, points.filter((point) => t - point.ts <= RETENTION).slice(-MAX_ODDS));
      }
    }
    for (const tx of detail.transactions) {
      const parsed = parseExcapperBetTime(tx.date, t);
      if (parsed === null || !Number.isFinite(tx.change) || tx.change <= 0) continue;
      const key = this.key(gameId, tx.line, tx.side);
      const points = this.bets.get(key) ?? [];
      if (!points.some((point) => point.summ === tx.summ)) {
        points.push({ t: parsed, change: tx.change, summ: tx.summ });
        points.sort((a, b) => a.t - b.t);
      }
      this.bets.delete(key);
      this.bets.set(key, points.filter((point) => t - point.t <= RETENTION).slice(-MAX_BETS));
    }
    this.prune(t);
  }

  timeline(gameId: string, line: number, side: "Over" | "Under", betTime: number): OddsObservation[] {
    return (this.odds.get(this.key(gameId, line, side)) ?? [])
      .filter((point) => point.ts <= betTime && point.ts >= betTime - RETENTION);
  }

  money(gameId: string, tx: ExcapperTransaction, betTime: number): PrebetMoney {
    const existing = this.bets.get(this.key(gameId, tx.line, tx.side)) ?? [];
    // Always use the durable trigger's fixed cutoff for that very row, even if
    // a later snapshot parses the same Summ differently. Never fabricate a
    // timestamp for any other row lacking a Date cell.
    const rows = [...existing.filter((point) => point.summ !== tx.summ),
      { t: betTime, change: tx.change, summ: tx.summ }];
    const in60 = rows.filter((point) => point.t >= betTime - HOUR && point.t <= betTime);
    const in15 = in60.filter((point) => point.t >= betTime - 15 * 60_000);
    return {
      inflow15m: in15.reduce((sum, point) => sum + point.change, 0),
      inflow60m: in60.reduce((sum, point) => sum + point.change, 0),
      betCount15m: in15.length,
    };
  }

  /** The observation window is anchored on the bet, not a later repricing. */
  static window(timeline: ReadonlyArray<UnifiedOddsPoint>, betTime: number): UnifiedOddsPoint[] {
    const eligible = timeline.filter((point) => point.ts <= betTime && point.ts >= betTime - RETENTION)
      .sort((a, b) => a.ts - b.ts);
    return eligible.filter((point) => point.ts >= betTime - WINDOW);
  }

  clear(): void {
    this.odds.clear();
    this.bets.clear();
    this.directorySeen.clear();
  }
}