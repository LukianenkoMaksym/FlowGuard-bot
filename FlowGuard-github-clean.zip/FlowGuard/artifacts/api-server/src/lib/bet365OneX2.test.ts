import { describe, expect, it, vi } from "vitest";

import { fetchBet365OneX2, parseBet365OneX2 } from "./bet365OneX2";

const now = 1_800_000_000_000;
const record = (mt: number, home: string, away: string, type = 0) =>
  ({ odds: { u: home, g: "3.50", d: away }, hs: 0, gs: 0,
    mt, ht: "45", close: false, type });
const response = (op: unknown[]) => JSON.stringify({ ErrCode: 0, Data: { op } });

describe("verified Bet365 full-time 1X2 source", () => {
  it("reads website's cid=8 Data.op in source-time order, never treating draw as an outcome", () => {
    const parsed = parseBet365OneX2(response([
      record(now / 1_000 - 5, "1.70", "2.50"),
      record(now / 1_000 - 45, "1.95", "2.40"),
      record(now / 1_000 - 90, "2.05", "2.20"),
      record(now / 1_000 - 180, "2.20", "2.00", 2), // pre-match: not comparable to live
    ]), now);
    expect(parsed).toMatchObject({
      bookmaker: "Bet365", observedAt: now,
      current: { ts: now - 5_000, home: 1.70, away: 2.50 },
    });
    expect(parsed?.history.map((p) => p.ts)).toEqual([now - 90_000, now - 45_000, now - 5_000]);
  });

  it("rejects HTML/challenge, mirror error, closed, zero, and prematch-only responses", () => {
    expect(parseBet365OneX2("<html>blocked</html>", now)).toBeNull();
    expect(parseBet365OneX2('{"code":1002}', now)).toBeNull();
    expect(parseBet365OneX2(response([{ ...record(now / 1_000, "1.8", "2.0"), close: true }]), now)).toBeNull();
    expect(parseBet365OneX2(response([record(now / 1_000, "0", "0")]), now)).toBeNull();
    expect(parseBet365OneX2(response([record(now / 1_000, "1.8", "2.0", 2)]), now)).toBeNull();
    expect(parseBet365OneX2(response([record(now / 1_000 + 30, "1.8", "2.0")]), now)).toBeNull();
  });

  it("keeps valid home/away quotes when draw is not published", () => {
    expect(parseBet365OneX2(response([
      { ...record(now / 1_000 - 5, "1.8", "2.0"), odds: { u: "1.8", g: "", d: "2.0" } },
    ]), now)?.current).toMatchObject({ home: 1.8, away: 2 });
    expect(parseBet365OneX2(response([record(now / 1_000 - 5, "0", "2.2")]), now)?.current)
      .toMatchObject({ home: null, away: 2.2 });
  });

  it("requests the verified canonical Bet365 bookmaker endpoint, not the OU feed", async () => {
    const request = vi.fn().mockResolvedValueOnce(new Response(
      response([record(now / 1_000 - 5, "1.8", "2.0")]), { status: 200 }));
    vi.stubGlobal("fetch", request);
    vi.spyOn(Date, "now").mockReturnValue(now);
    try {
      expect(await fetchBet365OneX2("3094865")).toMatchObject({ bookmaker: "Bet365" });
      const [url, init] = request.mock.calls[0]!;
      expect(url).toContain("www.nowgoal26.com/Ajax/SoccerAjax?type=14&id=3094865&t=20&cid=8&h=0");
      expect(init.headers.Referer).toBe("https://www.nowgoal26.com/");
      expect(await fetchBet365OneX2("<invalid>")).toBeNull();
      expect(request).toHaveBeenCalledTimes(1);
    } finally {
      vi.restoreAllMocks();
      vi.unstubAllGlobals();
    }
  });

  it("surfaces explicit source failure rather than interpreting a blocked Ajax page as odds", async () => {
    const request = vi.fn().mockResolvedValueOnce(new Response('{"code":1002}', { status: 200 }))
      .mockResolvedValueOnce(new Response("<html>blocked</html>", { status: 200 }));
    vi.stubGlobal("fetch", request);
    try {
      await expect(fetchBet365OneX2("3094865"))
        .rejects.toThrow("bookmaker data unavailable");
      await expect(fetchBet365OneX2("3094865")).rejects.toThrow("not JSON");
    } finally {
      vi.unstubAllGlobals();
    }
  });
});