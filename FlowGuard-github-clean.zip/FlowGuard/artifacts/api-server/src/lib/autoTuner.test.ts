import { mkdtemp, readFile, rm, mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { TrainingRow } from "./autoTunerRules";

const data = vi.hoisted(() => ({ rows: [] as TrainingRow[], wait: null as Promise<void> | null, fail: false }));
const tunerDb = vi.hoisted(() => ({ value: null as unknown }));
vi.mock("./tunerStateStore", () => ({
  loadTunerState: async (seed: unknown) => structuredClone(tunerDb.value ??= seed),
  saveTunerState: async (metadata: unknown, publish: () => Promise<void>) => {
    await publish();
    tunerDb.value = structuredClone(metadata);
  },
}));
vi.mock("./logger", () => ({ logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn(), debug: vi.fn() } }));
vi.mock("@workspace/db", async () => {
  const schema = await import("../../../../lib/db/src/schema");
  return { ...schema, db: { select: () => ({ from: () => ({ where: async () => {
    if (data.wait) await data.wait;
    if (data.fail) throw new Error("injected DB outage");
    return data.rows;
  } }) }) } };
});
vi.mock("./scanner", () => {
  const config = {
    dropThreshold: 0.4, maxSpread: 0.5, tightSpread: 0.15,
    benchmarkConfirmDrop: 0.05, minConfidence: 5, requireDensity: true,
    requireLiquidityConfirmation: false, priorityLeagueIds: ["21"],
    lowLiqMaxSpread: 1, bypassSpreadOnBigDrop: 0.8, absurdSpreadCap: 1.5,
  };
  return { config, getScannerConfig: () => structuredClone(config),
    setScannerConfig: (next: typeof config) => Object.assign(config, structuredClone(next)) };
});

const now = Date.UTC(2026, 8, 20, 12);
const day = 86400000;
function rows(n: number, wins = n): TrainingRow[] {
  return Array.from({ length: n }, (_, i) => ({
    id: i + 1, matchId: String(3000000 + i), team1: "HJK Helsinki", team2: "FC Lahti",
    league: "Finland Kakkonen D3", anomalyType: "ODDS_DROP", targetSide: i % 2 ? "UNDER" : "OVER",
    line: 2.5, status: i < wins ? "WIN" : "LOSS",
    createdAt: new Date(now - day - i * 1000), resolvedAt: new Date(now - i * 1000),
  }));
}
let dir: string;
let file: string;
beforeEach(async () => {
  tunerDb.value = null;
  vi.stubEnv("DROP_THRESHOLD", undefined);
  vi.stubEnv("MAX_SPREAD", undefined);
  vi.stubEnv("BYPASS_SPREAD_ON_BIG_DROP", undefined);
  vi.resetModules();
  vi.useFakeTimers();
  vi.setSystemTime(now);
  dir = await mkdtemp(path.join(tmpdir(), "auto-tuner-"));
  file = path.join(dir, "scanner.json");
  process.env["SCANNER_CONFIG_PATH"] = file;
  data.rows = rows(60);
  data.wait = null;
  data.fail = false;
  (await import("./scanner")).setScannerConfig({
    dropThreshold: 0.4, maxSpread: 0.5, tightSpread: 0.15,
    benchmarkConfirmDrop: 0.05, minConfidence: 5, requireDensity: true,
    requireLiquidityConfirmation: false, priorityLeagueIds: ["21"],
    lowLiqMaxSpread: 1, bypassSpreadOnBigDrop: 0.8, absurdSpreadCap: 1.5,
  });
});
afterEach(async () => {
  (await import("./autoTuner")).stopAutoTuner();
  vi.unstubAllEnvs();
  vi.useRealTimers();
  delete process.env["SCANNER_CONFIG_PATH"];
  await rm(dir, { recursive: true, force: true });
});
async function setup() {
  const tuner = await import("./autoTuner");
  const storage = await import("./scannerConfig");
  const scanner = await import("./scanner");
  await storage.initScannerConfig();
  return { tuner, storage, scanner };
}

describe("adaptive threshold safety", () => {
  it("defaults OFF; GET and enabling never adjust; OFF evaluation never queries", async () => {
    const { tuner, scanner } = await setup();
    data.fail = true;
    await tuner.evaluateAutoTuner();
    expect(tuner.autoTunerSnapshot()).toMatchObject({ enabled: false, state: "off", lastAdjustment: null });
    data.fail = false;
    expect(await tuner.getAutoTunerStatus()).toMatchObject({ sampleSize: 60, winRatePct: 100 });
    await tuner.setAutoTunerEnabled(true);
    expect(scanner.config.dropThreshold).toBe(0.4);
    expect((await tuner.getAutoTunerStatus()).state).toBe("ready");
    expect(scanner.config.dropThreshold).toBe(0.4);
  });

  it("collects 40 before changing only dropThreshold, then respects 24h cooldown", async () => {
    const { tuner, scanner } = await setup();
    await tuner.setAutoTunerEnabled(true);
    data.rows = rows(39);
    await tuner.evaluateAutoTuner();
    expect(tuner.autoTunerSnapshot()).toMatchObject({ state: "collecting", sampleSize: 39 });
    const before = scanner.getScannerConfig();
    data.rows = rows(40, 24); // exactly 60%
    await tuner.evaluateAutoTuner();
    expect(scanner.getScannerConfig()).toEqual({ ...before, dropThreshold: 0.35 });
    expect(tuner.autoTunerSnapshot()).toMatchObject({ state: "cooldown", lastAdjustment: { sampleSize: 40, winRatePct: 60 } });
    vi.setSystemTime(now + day - 1);
    await tuner.evaluateAutoTuner();
    expect(scanner.config.dropThreshold).toBe(0.35);
    vi.setSystemTime(now + day);
    await tuner.evaluateAutoTuner();
    expect(scanner.config.dropThreshold).toBe(0.3);
  });

  it("implements loss/neutral boundaries and bounds without jumping a manual outlier", async () => {
    const { tunerDecision } = await import("./autoTunerRules");
    expect(tunerDecision(0.4, 40, 44.99).next).toBe(0.45);
    for (const pct of [45, 59.99]) expect(tunerDecision(0.4, 40, pct).next).toBe(0.4);
    expect(tunerDecision(0.15, 60, 100).next).toBe(0.15);
    expect(tunerDecision(0.16, 60, 100).next).toBe(0.15);
    expect(tunerDecision(1, 60, 0).next).toBe(1);
    expect(tunerDecision(0.99, 60, 0).next).toBe(1);
    for (const n of [0.05, 1.01, 5]) {
      expect(tunerDecision(n, 60, 100)).toMatchObject({ next: n, reason: expect.stringContaining("outside") });
    }
  });

  it("pauses 7 days for successful same-value manual Apply; toggling preserves clocks", async () => {
    const { tuner, storage, scanner } = await setup();
    await tuner.setAutoTunerEnabled(true);
    await tuner.evaluateAutoTuner();
    const adjustment = tuner.autoTunerSnapshot().lastAdjustment;
    await storage.updateScannerConfig({ dropThreshold: scanner.config.dropThreshold });
    expect(tuner.autoTunerSnapshot()).toMatchObject({ state: "paused", pausedUntil: new Date(now + 7 * day).toISOString() });
    await tuner.setAutoTunerEnabled(false);
    await tuner.evaluateAutoTuner();
    await tuner.setAutoTunerEnabled(true);
    expect(tuner.autoTunerSnapshot().lastAdjustment).toEqual(adjustment);
    vi.setSystemTime(now + 7 * day - 1);
    await tuner.evaluateAutoTuner();
    expect(scanner.config.dropThreshold).toBe(0.35);
    vi.setSystemTime(now + 7 * day);
    await tuner.evaluateAutoTuner();
    expect(scanner.config.dropThreshold).toBe(0.3);
  });

  it("excludes test origins, bad timestamps, nonsettled/type/allowlist rows, dedups before last60", async () => {
    const { selectTunerSample, isTestOrigin } = await import("./autoTunerRules");
    const clean = rows(70);
    const bad = [
      { team1: "Alpha", team2: "Beta" }, { matchId: "test-123" }, { matchId: "rebooted:fixture" },
      { team1: "Fixture Team" }, { status: "PENDING" }, { status: "VOID" }, { anomalyType: "MONEY_SPIKE" },
      { league: "Unknown League" }, { resolvedAt: null }, { resolvedAt: new Date(NaN) },
      { resolvedAt: new Date(now + 1) }, { resolvedAt: new Date(now - 2 * day) },
    ].map((patch, i) => ({ ...clean[0]!, id: 1000 + i, matchId: String(7000000 + i), ...patch }));
    const duplicate = { ...clean[0]!, id: 999, createdAt: new Date(clean[0]!.createdAt.getTime() + 1) };
    const sample = selectTunerSample([...bad, duplicate, ...clean], now);
    expect(sample).toHaveLength(60);
    expect(sample.map((r) => r.id)).toEqual(clean.slice(0, 60).map((r) => r.id));
    expect(isTestOrigin({ ...clean[0]!, team1: "Alpha United", team2: "Real Betis" })).toBe(false);
    expect(isTestOrigin({ ...clean[0]!, team1: "Testaccio FC" })).toBe(false);
  });

  it("persists threshold, pause and cooldown across restart; DB wins over legacy JSON", async () => {
    let { tuner, storage } = await setup();
    await tuner.setAutoTunerEnabled(true);
    await tuner.evaluateAutoTuner();
    await storage.updateScannerConfig({ maxSpread: 0.6 });
    const snapshot = tuner.autoTunerSnapshot();
    const saved = JSON.parse(await readFile(file, "utf8"));
    expect(saved).toMatchObject({ dropThreshold: 0.35, autoTuner: { enabled: true, lastAdjustment: snapshot.lastAdjustment, pausedUntil: snapshot.pausedUntil } });
    vi.resetModules();
    ({ tuner, storage } = await setup());
    expect(tuner.autoTunerSnapshot()).toMatchObject({ enabled: true, state: "paused", dropThreshold: 0.35, lastAdjustment: snapshot.lastAdjustment });
    delete saved.autoTuner;
    await writeFile(file, JSON.stringify(saved));
    vi.resetModules();
    ({ tuner } = await setup());
    expect(tuner.autoTunerSnapshot()).toMatchObject({ enabled: true, pausedUntil: snapshot.pausedUntil, lastAdjustment: snapshot.lastAdjustment, dropThreshold: 0.35 });
  });

  it("fails closed on persistence errors without pausing manual failures or committing cooldown", async () => {
    const { tuner, storage, scanner } = await setup();
    await tuner.setAutoTunerEnabled(true);
    await rm(file);
    await mkdir(file);
    await tuner.evaluateAutoTuner();
    expect(scanner.config.dropThreshold).toBe(0.4);
    expect(tuner.autoTunerSnapshot()).toMatchObject({ state: "error", lastAdjustment: null });
    expect((await storage.updateScannerConfig({ dropThreshold: 0.5 })).persisted).toBe(false);
    expect(tuner.autoTunerSnapshot().pausedUntil).toBeNull();
    expect((await tuner.setAutoTunerEnabled(false)).persisted).toBe(false);
    expect(tuner.autoTunerSnapshot().enabled).toBe(true);
    await rm(file, { recursive: true });
    await tuner.evaluateAutoTuner();
    expect(scanner.config.dropThreshold).toBe(0.4); // fail closed until durable state is reloaded
  });

  it("restores 24h cooldown across restart and rejects invalid Apply without a pause", async () => {
    let { tuner, storage } = await setup();
    await tuner.setAutoTunerEnabled(true);
    expect(await storage.updateScannerConfig({ maxSpread: 9 })).toMatchObject({ persisted: false, invalid: true });
    expect(tuner.autoTunerSnapshot().pausedUntil).toBeNull();
    await tuner.evaluateAutoTuner();
    vi.resetModules();
    ({ tuner, storage } = await setup());
    expect(tuner.autoTunerSnapshot()).toMatchObject({ state: "cooldown", dropThreshold: 0.35 });
    await tuner.evaluateAutoTuner();
    expect(tuner.autoTunerSnapshot().dropThreshold).toBe(0.35);
  });

  it("uses valid DB clocks instead of malformed JSON clocks", async () => {
    const { scanner } = await setup();
    const manualFilters = { ...scanner.getScannerConfig(), dropThreshold: 0.7, maxSpread: 0.6 };
    await writeFile(file, JSON.stringify({ ...manualFilters,
      autoTuner: { enabled: true, pausedUntil: "bad-date", lastAdjustment: null },
    }));
    vi.resetModules();
    const { tuner, scanner: reloadedScanner } = await setup();
    expect(tuner.autoTunerSnapshot()).toMatchObject({
      enabled: false, state: "off", dropThreshold: 0.7,
    });
    expect(reloadedScanner.getScannerConfig()).toEqual(manualFilters);
    await tuner.evaluateAutoTuner();
    expect(reloadedScanner.getScannerConfig()).toEqual(manualFilters);
  });

  it("does not alter other filters to force an invalid automatic increase", async () => {
    const { tuner, storage, scanner } = await setup();
    await storage.updateScannerConfig({ dropThreshold: 0.4, bypassSpreadOnBigDrop: 0.4 });
    await tuner.setAutoTunerEnabled(true);
    data.rows = rows(40, 0);
    const before = scanner.getScannerConfig();
    await tuner.evaluateAutoTuner();
    expect(scanner.getScannerConfig()).toEqual(before);
    expect(tuner.autoTunerSnapshot()).toMatchObject({ state: "error", lastAdjustment: null, error: expect.stringContaining("bypassSpreadOnBigDrop") });
  });

  it.each(["manual", "off"] as const)("rechecks %s changes made during awaited query", async (kind) => {
    const { tuner, storage, scanner } = await setup();
    await tuner.setAutoTunerEnabled(true);
    let release!: () => void;
    data.wait = new Promise<void>((resolve) => { release = resolve; });
    const evaluating = tuner.evaluateAutoTuner();
    if (kind === "manual") await storage.updateScannerConfig({ maxSpread: 0.6 });
    else await tuner.setAutoTunerEnabled(false);
    release();
    await evaluating;
    expect(scanner.config.dropThreshold).toBe(0.4);
    expect(tuner.autoTunerSnapshot().lastAdjustment).toBeNull();
    if (kind === "manual") expect(scanner.config.maxSpread).toBe(0.6);
  });

  it("serializes parallel evaluations and preserves concurrent manual and toggle writes", async () => {
    const { tuner, storage, scanner } = await setup();
    await tuner.setAutoTunerEnabled(true);
    await Promise.all([tuner.evaluateAutoTuner(), tuner.evaluateAutoTuner()]);
    expect(scanner.config.dropThreshold).toBe(0.35);
    await Promise.all([storage.updateScannerConfig({ maxSpread: 0.6 }), tuner.setAutoTunerEnabled(false)]);
    expect(JSON.parse(await readFile(file, "utf8"))).toMatchObject({ maxSpread: 0.6, autoTuner: { enabled: false, pausedUntil: expect.any(String), lastAdjustment: { newThreshold: 0.35 } } });
  });

  it("surfaces database errors, stops an in-flight timer, and never automatically enables", async () => {
    const { tuner, scanner } = await setup();
    await tuner.setAutoTunerEnabled(true);
    data.fail = true;
    await tuner.evaluateAutoTuner();
    expect(tuner.autoTunerSnapshot()).toMatchObject({ state: "error", lastAdjustment: null });
    data.fail = false;
    let release!: () => void;
    data.wait = new Promise<void>((resolve) => { release = resolve; });
    tuner.startAutoTuner();
    await vi.advanceTimersByTimeAsync(60_000);
    tuner.stopAutoTuner();
    release();
    await tuner.evaluateAutoTuner();
    expect(scanner.config.dropThreshold).toBe(0.4);
    expect(vi.getTimerCount()).toBe(0);
  });
});