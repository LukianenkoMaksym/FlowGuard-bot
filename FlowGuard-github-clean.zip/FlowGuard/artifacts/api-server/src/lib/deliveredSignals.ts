import { createHash } from "node:crypto";
import { and, desc, eq, ne } from "drizzle-orm";
import { db, signalHistoryEntriesTable, type InsertSignalHistoryEntry } from "@workspace/db";
import { fetchFreshScoreNow } from "./scanner";
import { logger } from "./logger";

type SignalInput = Pick<InsertSignalHistoryEntry, "rawCard" | "matchId" | "team1" | "team2" | "league" | "anomalyType" | "targetSide" | "line" | "minuteBucket" | "matchMinute" | "homeScoreAtFire" | "awayScoreAtFire" | "oddsAtFire">;
const unescape = (s: string) => s.replace(/\\([_*\[\]()~`>#+\-=|{}.!\\])/g, "$1");

/** Parse only the existing, fully identified signal cards, never bot replies or diagnostics. */
export function parseDeliveredSignal(message: string): SignalInput | null {
  const text = unescape(message);
  const lines = text.split("\n");
  const header = lines[0] ?? "";
  const type = ["👁 ODDS RADAR", "🔴 SMART MONEY", "⚡ SMART EXCAPPER", "💎 SMART EXCAPPER"]
    .find((value) => header === value || header.startsWith(`${value} · `));
  if (!type) return null;
  const league = lines.find((l) => l.startsWith("🏆 "))?.slice(3);
  const fixture = lines.find((l) => l.startsWith("⚽️ "))?.slice(3) ?? "";
  const newFixture = fixture.match(/^(.+) (?:vs|—) (.+) · (\d+):(\d+) \(([^)]+)\)$/);
  const teams = fixture.match(/^(.+) (?:vs|—) (.+?)(?: · |$)/);
  const score = lines.find((l) => l.startsWith("📊 "))?.match(/Live Score: (\d+):(\d+) \| ([^|]+)/);
  const oldClock = lines.find((l) => l.startsWith("📊 "))?.match(/\| ([^|]+)$/)?.[1] ?? null;
  const clock = newFixture?.[5] ?? oldClock;
  const oldMarket = lines.find((l) => l.startsWith("🎯 "))?.match(/Market: (Over|Under) (\d+(?:\.\d+)?)/);
  const signalLine = lines.find((l) => /^(?:📉|📈|⚡|❔|➡️) (?:Тотал |Победа )/.test(l)) ?? "";
  const marketPattern = /(?:Тотал больше|Тотал меньше|Победа хозяев|Победа гостей)/;
  const marketName = signalLine.match(marketPattern)?.[0] ??
    lines.find((l) => l.startsWith("📊 Рынок: "))?.match(marketPattern)?.[0];
  const marketLine = signalLine.match(/(?:Тотал больше|Тотал меньше) (\d+(?:\.\d+)?)/)?.[1] ??
    lines.find((l) => l.startsWith("📊 Рынок: "))?.match(/(?:Тотал больше|Тотал меньше) (\d+(?:\.\d+)?)/)?.[1];
  const inline = signalLine.match(/^(📉|📈|⚡|❔|➡️) (?:Тотал больше|Тотал меньше|Победа хозяев|Победа гостей)(?: \d+(?:\.\d+)?)? · [^:]+: (?:скачок )?([\d.]+) → (?:([\d.]+) → )?([\d.]+)/);
  const named = lines.filter((l) => /^(?:📉|📈|⚡) [^:]+: (?:скачок )?\d/.test(l));
  const priced = (inline ? [{
    emoji: inline[1]!, from: Number(inline[2]), to: Number(inline[4]),
    peak: inline[3] ? Number(inline[3]) : null,
  }] : [])
    .concat(named.flatMap((l) => {
      const found = l.match(/^(📉|📈|⚡) [^:]+: (?:скачок )?([\d.]+) → (?:([\d.]+) → )?([\d.]+)/);
      return found ? [{
        emoji: found[1]!, from: Number(found[2]), to: Number(found[4]),
        peak: found[3] ? Number(found[3]) : null,
      }] : [];
    }))
    .filter((r) => Number.isFinite(r.from) && r.from > 1 && Number.isFinite(r.to) && r.to > 1)
    .sort((a, b) => Math.abs(((b.peak ?? b.to) - b.from) / b.from) -
      Math.abs(((a.peak ?? a.to) - a.from) / a.from));
  const leading = priced[0];
  const side = marketName === "Тотал больше" ? "OVER" :
    marketName === "Тотал меньше" ? "UNDER" :
    marketName === "Победа хозяев" ? "HOME" :
    marketName === "Победа гостей" ? "AWAY" :
    oldMarket?.[1]?.toUpperCase() ?? null;
  const matchId = lines.find((l) => l.includes("nowgoal26.com/match/live-"))?.match(/nowgoal26\.com\/match\/live-(\d+)/)?.[1];
  const parsedLine = marketLine || oldMarket?.[2] ? Number(marketLine ?? oldMarket?.[2]) : null;
  const line = parsedLine !== null && Number.isFinite(parsedLine) && parsedLine > 0 ? parsedLine : null;
  const minute = clock ? /^\d{1,3}/.exec(clock.trim()) : null;
  const matchMinute = minute ? Number(minute[0]) : null;
  const minuteBucket = matchMinute === null ? "unknown" : matchMinute <= 30 ? "early" : matchMinute <= 60 ? "mid" : "late";
  const movement = type === "👁 ODDS RADAR" ? lines.find((l) => l.startsWith("📡 ")) : null;
  const oddsAtFire = leading ? leading.to
    : movement?.match(/\[\d+(?:\.\d+)? -> (\d+(?:\.\d+)?)\]/)?.[1] ??
      [...lines].reverse().find((l) => /\| 🟢 \d+(?:\.\d+)?/.test(l))?.match(/\| 🟢 (\d+(?:\.\d+)?)/)?.[1];
  return {
    rawCard: message, matchId: matchId ?? null, league: league ?? "", team1: teams?.[1] ?? "", team2: teams?.[2] ?? "",
    anomalyType: type === "👁 ODDS RADAR"
      ? `RADAR_${marketName ? leading?.emoji === "⚡" ? "REVERT" : leading?.emoji === "📈" ? "RISE" : "DROP"
        : movement?.includes("Line ") ? "LINE" : movement?.includes("Rise ") ? "RISE" : movement?.includes("Revert ") ? "REVERT" : "DROP"}`
      : type.endsWith("SMART EXCAPPER") ? "EXCAPPER" : "SMART_MONEY",
    targetSide: side, line, minuteBucket, matchMinute,
    homeScoreAtFire: newFixture ? Number(newFixture[3]) : score ? Number(score[1]) : null,
    awayScoreAtFire: newFixture ? Number(newFixture[4]) : score ? Number(score[2]) : null,
    oddsAtFire: oddsAtFire && Number.isFinite(Number(oddsAtFire)) ? Number(oddsAtFire) - 1 : null,
  };
}

// Telegram acknowledged the primary recipient but PostgreSQL may have failed.
// Keep the acknowledgement in-process so retries persist without another send.
// An unacknowledged process crash cannot be made exactly-once at Telegram.
const uncommitted = new Map<string, { input: SignalInput; deliveredAt: Date }>();
let retryTimer: ReturnType<typeof setTimeout> | null = null;
function scheduleRetry(): void {
  if (retryTimer || !uncommitted.size) return;
  retryTimer = setTimeout(() => {
    retryTimer = null;
    void retryAcknowledgedSignals().finally(scheduleRetry);
  }, 30_000);
  retryTimer.unref?.();
}
export async function retryAcknowledgedSignals(): Promise<void> {
  await Promise.all([...uncommitted].map(async ([key, value]) => {
    try { await persistAcknowledgedSignal(key, value.input, value.deliveredAt); }
    catch (err) { logger.error({ err, key }, "[SIGNAL-HISTORY] acknowledged signal persistence retry failed"); }
  }));
}
export function signalDeliveryKey(message: string, deliveryKey?: string): string {
  const digest = createHash("sha256").update(message).digest("hex");
  return deliveryKey
    ? `alert:${deliveryKey}`
    // RADAR does not supply a transport key. Its cooldown can straddle a
    // 30-minute bucket boundary, so use the exact rendered card identity.
    : message.startsWith("👁 ODDS RADAR") ? `radar:${digest}`
    : `card:${digest}:${Math.floor(Date.now() / (30 * 60_000))}`;
}
export async function stageSignal(key: string, input: SignalInput): Promise<void> {
  await db.insert(signalHistoryEntriesTable).values({ ...input, deliveryKey: key, status: "AWAITING_ACK" })
    .onConflictDoNothing({ target: signalHistoryEntriesTable.deliveryKey });
}
export async function persistAcknowledgedSignal(key: string, input: SignalInput, deliveredAt = new Date()): Promise<void> {
  deliveredAt = uncommitted.get(key)?.deliveredAt ?? deliveredAt;
  uncommitted.set(key, { input, deliveredAt });
  scheduleRetry();
  try {
    // Stage may have failed before sending; insert directly as PENDING then
    // promote an existing AWAITING_ACK row. Never reset a settled result.
    await db.insert(signalHistoryEntriesTable).values({ ...input, deliveryKey: key, status: "PENDING", createdAt: deliveredAt })
      .onConflictDoNothing({ target: signalHistoryEntriesTable.deliveryKey });
    await db.update(signalHistoryEntriesTable).set({ status: "PENDING", createdAt: deliveredAt })
      .where(and(eq(signalHistoryEntriesTable.deliveryKey, key), eq(signalHistoryEntriesTable.status, "AWAITING_ACK")));
    uncommitted.delete(key);
  } catch (err) {
    scheduleRetry();
    throw err;
  }
}

export async function resolveDeliveredSignals(
  scoreForMatch: typeof fetchFreshScoreNow = fetchFreshScoreNow,
): Promise<void> {
  const pending = await db.select().from(signalHistoryEntriesTable).where(eq(signalHistoryEntriesTable.status, "PENDING"));
  for (const row of pending) {
    const isOneX2 = row.targetSide === "HOME" || row.targetSide === "AWAY";
    if (!row.matchId || (!isOneX2 && (row.targetSide !== "OVER" && row.targetSide !== "UNDER" || row.line === null))) continue;
    try {
      const final = await scoreForMatch(row.matchId);
      if (!final || final.state === null || final.state >= 0 ||
          !Number.isInteger(final.homeScore) || !Number.isInteger(final.awayScore) ||
          final.homeScore < 0 || final.awayScore < 0) continue;
      const total = final.homeScore + final.awayScore;
      const won = row.targetSide === "HOME" ? final.homeScore > final.awayScore :
        row.targetSide === "AWAY" ? final.awayScore > final.homeScore :
        row.targetSide === "OVER" ? total > row.line! : total < row.line!;
      await db.update(signalHistoryEntriesTable).set({
        status: won ? "WIN" : "LOSS", finalHomeScore: final.homeScore,
        finalAwayScore: final.awayScore, finalTotal: total, resolvedAt: new Date(),
      }).where(and(eq(signalHistoryEntriesTable.id, row.id), eq(signalHistoryEntriesTable.status, "PENDING")));
    } catch (err) {
      logger.error({ err, id: row.id }, "[SIGNAL-HISTORY] final score/settlement failed; remains PENDING");
    }
  }
}

/** Operator-assisted historical import: exact delivered card and independently observed final evidence required. */
export async function backfillDeliveredSignal(
  evidence: { message: string; deliveryKey: string; deliveredAt: Date; final?: { state: number; homeScore: number; awayScore: number } },
  dryRun = true,
): Promise<typeof signalHistoryEntriesTable.$inferInsert> {
  const parsed = parseDeliveredSignal(evidence.message);
  if (!parsed || !parsed.matchId ||
    (!["HOME", "AWAY"].includes(parsed.targetSide ?? "") &&
      (!["OVER", "UNDER"].includes(parsed.targetSide ?? "") || parsed.line == null)) ||
    !evidence.deliveryKey || !Number.isFinite(evidence.deliveredAt.getTime()))
    throw new Error("Backfill requires exact fixture/market metadata, primary delivery ID and timestamp");
  const final = evidence.final;
  if (final && (!Number.isInteger(final.state) || final.state >= 0 ||
    !Number.isInteger(final.homeScore) || !Number.isInteger(final.awayScore) ||
    final.homeScore < 0 || final.awayScore < 0)) throw new Error("Final evidence must include finished state and valid final score");
  const total = final ? final.homeScore + final.awayScore : null;
  const status = total === null ? "PENDING" :
    ((parsed.targetSide === "HOME" ? final!.homeScore > final!.awayScore :
      parsed.targetSide === "AWAY" ? final!.awayScore > final!.homeScore :
      parsed.targetSide === "OVER" ? total > parsed.line! : total < parsed.line!) ? "WIN" : "LOSS");
  const row: typeof signalHistoryEntriesTable.$inferInsert = {
    ...parsed, deliveryKey: `backfill:${evidence.deliveryKey}`, createdAt: evidence.deliveredAt,
    status, finalHomeScore: final?.homeScore ?? null, finalAwayScore: final?.awayScore ?? null,
    finalTotal: total, resolvedAt: final ? new Date() : null,
  };
  if (!dryRun) await db.insert(signalHistoryEntriesTable).values(row).onConflictDoNothing({ target: signalHistoryEntriesTable.deliveryKey });
  return row;
}

export async function listDeliveredSignals() {
  return db.select().from(signalHistoryEntriesTable).where(
    // A pre-send stage is not evidence of delivery.
    ne(signalHistoryEntriesTable.status, "AWAITING_ACK"),
  ).orderBy(desc(signalHistoryEntriesTable.createdAt));
}