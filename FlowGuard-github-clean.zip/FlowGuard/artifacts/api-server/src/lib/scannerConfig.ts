/**
 * Operator filters remain file-backed; tuner state is durable in PostgreSQL.
 * Publish the file inside the staged DB transaction and compensate on failure.
 */
import { existsSync, promises as fs } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { getScannerConfig, setScannerConfig, type ScannerConfig } from "./scanner";
import { logger } from "./logger";
import { defaultTunerMetadata, TUNER_DAY_MS, type TunerMetadata } from "./autoTunerRules";
import { loadTunerState, saveTunerState } from "./tunerStateStore";

/** Resolve packaged config independently of the launcher working directory. */
export function resolveScannerConfigPath(
  moduleUrl = import.meta.url,
  override = process.env["SCANNER_CONFIG_PATH"],
  exists: (file: string) => boolean = existsSync,
): string {
  if (override !== undefined) return path.resolve(override);
  const moduleDir = path.dirname(fileURLToPath(moduleUrl));
  const sourcePath = path.resolve(moduleDir, "../../config/scanner-config.json");
  const bundlePath = path.resolve(moduleDir, "../config/scanner-config.json");
  const candidates = path.basename(moduleDir) === "dist"
    ? [bundlePath, sourcePath]
    : [sourcePath, bundlePath];
  return candidates.find((file) => exists(file)) ?? candidates[0]!;
}

const configPath = () => resolveScannerConfigPath();

const numbers = {
  dropThreshold: [0.05, 10],
  maxSpread: [0.05, 10],
  tightSpread: [0.05, 5],
  benchmarkConfirmDrop: [0.01, 5],
  minConfidence: [1, 10],
  lowLiqMaxSpread: [0.05, 10],
  bypassSpreadOnBigDrop: [0.10, 20],
  absurdSpreadCap: [0.50, 20],
} as const;
const booleans = ["requireDensity", "requireLiquidityConfirmation"] as const;
const keys = [...Object.keys(numbers), ...booleans, "priorityLeagueIds"];

function validate(input: unknown, base: ScannerConfig, full = false): { next: ScannerConfig; errors: string[] } {
  const errors: string[] = [];
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { next: base, errors: ["expected a scanner config object"] };
  }
  const body = input as Record<string, unknown>;
  const next = { ...base, priorityLeagueIds: [...base.priorityLeagueIds] };
  if (full && keys.some((key) => !Object.hasOwn(body, key))) {
    errors.push("persisted scanner config is incomplete");
  }
  for (const [key, [min, max]] of Object.entries(numbers)) {
    if (body[key] === undefined) continue;
    const val = Number(body[key]);
    if (!Number.isFinite(val) || val < min || val > max) {
      errors.push(`${key} must be a number between ${min} and ${max}`);
    } else {
      (next as unknown as Record<string, unknown>)[key] = val;
    }
  }
  for (const key of booleans) {
    if (body[key] === undefined) continue;
    if (typeof body[key] !== "boolean") errors.push(`${key} must be a boolean`);
    else next[key] = body[key];
  }
  if (body["priorityLeagueIds"] !== undefined) {
    const ids = body["priorityLeagueIds"];
    if (!Array.isArray(ids) || !ids.every((id) => typeof id === "string")) {
      errors.push("priorityLeagueIds must be an array of strings");
    } else {
      next.priorityLeagueIds = [...ids];
    }
  }
  if (next.absurdSpreadCap < next.maxSpread) errors.push("absurdSpreadCap must be ≥ maxSpread");
  if (next.absurdSpreadCap < next.lowLiqMaxSpread) errors.push("absurdSpreadCap must be ≥ lowLiqMaxSpread");
  if (next.lowLiqMaxSpread < next.maxSpread) errors.push("lowLiqMaxSpread must be ≥ maxSpread (it's meant to RELAX, not tighten)");
  if (next.tightSpread > next.maxSpread) errors.push("tightSpread must be ≤ maxSpread");
  if (next.bypassSpreadOnBigDrop < next.dropThreshold) errors.push("bypassSpreadOnBigDrop must be ≥ dropThreshold");
  return { next, errors };
}

let initialized = false;
let queue: Promise<unknown> = Promise.resolve();
let tuner = defaultTunerMetadata();
let storageError: string | null = null;
let tunerStorageReady = false;
// Keep the operator's file values separate from the effective runtime overlay.
let fileConfig = getScannerConfig();
let fileFields = new Set<string>();
let fileExtras: Record<string, unknown> = {};
export type ConfigSource = "env" | "file" | "default";
const environmentFields = {
  dropThreshold: "DROP_THRESHOLD",
  maxSpread: "MAX_SPREAD",
  bypassSpreadOnBigDrop: "BYPASS_SPREAD_ON_BIG_DROP",
} as const;
type EnvironmentField = keyof typeof environmentFields;
let sources: Record<EnvironmentField, ConfigSource> = {
  dropThreshold: "default", maxSpread: "default", bypassSpreadOnBigDrop: "default",
};
export const getScannerConfigSources = () => ({ ...sources });

function applyEnvironment(): void {
  const overlay: Partial<Record<EnvironmentField, number>> = {};
  for (const key of Object.keys(environmentFields) as EnvironmentField[]) {
    sources[key] = fileFields.has(key) ? "file" : "default";
    const name = environmentFields[key];
    const raw = process.env[name];
    if (raw === undefined) continue;
    const value = Number(raw);
    const [min, max] = numbers[key];
    if (!raw.trim() || !Number.isFinite(value) || value < min || value > max) {
      logger.warn({ field: key, env: name, min, max }, "[SCANNER CONFIG] invalid environment number — using file/default");
      continue;
    }
    overlay[key] = value;
  }
  const combined = validate(overlay, fileConfig);
  if (combined.errors.length) {
    logger.warn({ errors: combined.errors }, "[SCANNER CONFIG] conflicting environment filters — using file/default");
    setScannerConfig(fileConfig);
    return;
  }
  for (const key of Object.keys(overlay) as EnvironmentField[]) sources[key] = "env";
  setScannerConfig(combined.next);
}

export const getTunerMetadata = (): TunerMetadata => structuredClone(tuner);
export const getScannerStorageError = () => storageError;

function readTunerMetadata(raw: unknown): TunerMetadata {
  if (raw === undefined) return defaultTunerMetadata(); // pre-tuner JSON
  const value = raw as TunerMetadata;
  const date = (v: unknown) => typeof v === "string" && Number.isFinite(Date.parse(v));
  if (!value || typeof value.enabled !== "boolean" ||
      !(value.pausedUntil === null || date(value.pausedUntil))) throw new Error("Invalid persisted tuner metadata");
  const a = value.lastAdjustment;
  if (a !== null && (!a || !date(a.at) ||
      !Number.isFinite(a.oldThreshold) || !Number.isFinite(a.newThreshold) ||
      a.oldThreshold < 0.15 || a.oldThreshold > 1 || a.newThreshold < 0.15 || a.newThreshold > 1 ||
      Math.abs(a.newThreshold - a.oldThreshold) > 0.050000000001 ||
      !Number.isFinite(a.winRatePct) || a.winRatePct < 0 || a.winRatePct > 100 ||
      !Number.isInteger(a.sampleSize) || a.sampleSize < 40 || a.sampleSize > 60)) {
    throw new Error("Invalid persisted tuner adjustment");
  }
  return { enabled: value.enabled, pausedUntil: value.pausedUntil, lastAdjustment: a };
}

/** Stage tuner state in a DB transaction; publish filters, commit, or compensate the file. */
async function persist(next: ScannerConfig, metadata: TunerMetadata): Promise<boolean> {
  if (!tunerStorageReady) {
    storageError = "Tuner database unavailable; configuration mutations and tuning are disabled.";
    return false;
  }
  const file = configPath();
  const dir = path.dirname(file);
  const tmp = path.join(dir, `.${path.basename(file)}.tmp-${process.pid}-${Date.now()}`);
  let previous: string | null = null;
  let published = false;
  try {
    previous = await fs.readFile(file, "utf8").catch((err: NodeJS.ErrnoException) => {
      if (err.code === "ENOENT") return null;
      throw err;
    });
    await fs.mkdir(dir, { recursive: true });
    await fs.writeFile(tmp, JSON.stringify({ ...fileExtras, ...next, autoTuner: { ...(fileExtras.autoTuner as object ?? {}), ...metadata } }, null, 2) + "\n", "utf8");
    await saveTunerState(metadata, async () => {
      await fs.rename(tmp, file);
      published = true;
    });
    fileConfig = next;
    fileFields = new Set(keys);
    applyEnvironment();
    tuner = structuredClone(metadata);
    storageError = null;
    initialized = true;
    return true;
  } catch (err) {
    if (published) {
      try {
        if (previous === null) await fs.rm(file, { force: true });
        else {
          await fs.writeFile(tmp, previous, "utf8");
          await fs.rename(tmp, file);
        }
      } catch (restoreError) {
        logger.error({ err: restoreError }, "[SCANNER CONFIG] file compensation failed; DB/file reconciliation required");
      }
    }
    tunerStorageReady = false;
    storageError = "Scanner filters and tuner state could not be saved; no changes were applied.";
    logger.error({ err, path: file }, "[SCANNER CONFIG] persist failed");
    await fs.rm(tmp, { force: true }).catch(() => {});
    return false;
  }
}

/** Re-read live state inside the existing config queue; never commit stale snapshots. */
export function transactAutoTuner(
  decide: (config: ScannerConfig, metadata: TunerMetadata) =>
    { dropThreshold?: number; metadata: TunerMetadata } | null,
): Promise<{ persisted: boolean; error?: string }> {
  const task = queue.then(async () => {
    if (!tunerStorageReady) return { persisted: false, error: "Tuner database unavailable; mutations and tuning are disabled." };
    const current = getScannerConfig();
    const change = decide(current, getTunerMetadata());
    if (!change) return { persisted: false };
    if (change.dropThreshold !== undefined && sources.dropThreshold === "env") {
      return { persisted: false, error: "dropThreshold is controlled by DROP_THRESHOLD (source: env); automatic adjustment was not applied." };
    }
    const { next, errors } = validate(change.dropThreshold === undefined ? {} : { dropThreshold: change.dropThreshold }, fileConfig);
    if (errors.length) return { persisted: false, error: errors.join(", ") };
    const saved = await persist(next, change.metadata);
    return { persisted: saved, ...(saved ? {} : { error: storageError! }) };
  });
  queue = task.catch(() => {});
  return task;
}

/** Boot-only load, before listen and before any scanner alerts are produced. */
export async function initScannerConfig(): Promise<void> {
  const task = queue.then(async () => {
    if (initialized) return;
    const file = configPath();
    try {
      const raw = await fs.readFile(file, "utf8");
      const parsed = JSON.parse(raw);
      const { next, errors } = validate(parsed, fileConfig);
      if (errors.length) throw new Error(errors.join(", "));
      fileConfig = next;
      fileFields = new Set(Object.keys(parsed));
      fileExtras = parsed;
      // Additive tuner corruption must never reset valid operator filters.
      // Load those independently, while failing the optional tuner closed.
      try {
        tuner = readTunerMetadata(parsed.autoTuner);
        storageError = null;
      } catch (err) {
        tuner = defaultTunerMetadata();
        storageError = "Persisted tuner metadata could not be loaded; manual filters retained and tuner remains OFF.";
        logger.error({ err, path: file }, "[SCANNER CONFIG] tuner metadata invalid — manual filters retained");
      }
      logger.info({ path: file }, "[SCANNER CONFIG] loaded");
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code !== "ENOENT") {
        storageError = "Persisted scanner/tuner configuration could not be loaded; tuner remains OFF.";
        logger.error({ err, path: file }, "[SCANNER CONFIG] load failed — keeping defaults");
      }
    }
    try {
      tuner = readTunerMetadata(await loadTunerState(tuner));
      tunerStorageReady = true;
      // A valid DB singleton supersedes a corrupt/stale JSON tuner snapshot.
      if (storageError?.startsWith("Persisted tuner metadata")) storageError = null;
    } catch (err) {
      tunerStorageReady = false;
      storageError = "Tuner database unavailable or invalid; known state retained, mutations and tuning disabled.";
      logger.error({ err }, "[SCANNER CONFIG] durable tuner state unavailable");
    }
    applyEnvironment();
    initialized = true;
  });
  queue = task.catch(() => {});
  await task;
}

export type ScannerConfigUpdate =
  | { persisted: true; config: ScannerConfig }
  | { persisted: false; config: ScannerConfig; errors: string[]; invalid: boolean };

/** Serialize validation + persistence + live mutation to preserve last-write-wins. */
export function updateScannerConfig(input: unknown): Promise<ScannerConfigUpdate> {
  const ready = initialized ? Promise.resolve() : initScannerConfig();
  const pending = queue;
  const task = ready.then(() => pending).then(async (): Promise<ScannerConfigUpdate> => {
    const { next, errors } = validate(input, fileConfig);
    if (errors.length) return { persisted: false, config: getScannerConfig(), errors, invalid: true };
    const metadata = getTunerMetadata();
    if (metadata.enabled) metadata.pausedUntil = new Date(Date.now() + 7 * TUNER_DAY_MS).toISOString();
    if (await persist(next, metadata)) {
      return { persisted: true, config: getScannerConfig() };
    } else {
      return {
        persisted: false, config: getScannerConfig(), invalid: false,
        errors: ["Scanner filters could not be saved; no changes were applied."],
      };
    }
  });
  queue = task.catch(() => {});
  return task;
}