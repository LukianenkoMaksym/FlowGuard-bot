import { describe, expect, it, vi } from "vitest";
import { boundedEnrichment, chooseBaseBinding, parseBindingKickoff, type BindingBase } from "./excapperScoring";
import { normalizedTeamName } from "./teamIdentity";

const time = new Date(2026, 8, 24, 18, 0).getTime();
const source: BindingBase = { id: "source", team1: "CD Independiente Juniors",
  team2: "Vinotinto de Ecuador", league: "Unmapped source label", kickoffMs: time,
  homeScore: 1, awayScore: 0, period: "second-half" };
const control: BindingBase = { ...source, id: "3071680", team1: "Independiente Juniors",
  team2: "Vinotinto Ecuador", league: "Different league label" };
describe("base identity binding", () => {
  it("binds control 3071680 with prefixes and different leagues, state 3 period", () => {
    expect(chooseBaseBinding(source, [control]).chosen?.id).toBe("3071680");
  });
  it("does not bind similar wrong teams even with equal leagues", () => {
    expect(chooseBaseBinding(source, [{ ...control, league: source.league, team1: "Independiente Seniors" }]).chosen).toBeNull();
  });
  it("allows missing time only with independent teams and exact score/period", () => {
    expect(chooseBaseBinding(source, [{ ...control, kickoffMs: null }]).chosen?.id).toBe(control.id);
    for (const missing of [{ homeScore: null }, { awayScore: null }, { period: null }]) {
      expect(chooseBaseBinding(source, [{ ...control, kickoffMs: null, ...missing }]).chosen).toBeNull();
    }
    expect(chooseBaseBinding(source, [{ ...control, kickoffMs: time + 4 * 3600_000 }]).chosen).toBeNull();
    expect(chooseBaseBinding(source, [{ ...control, homeScore: 2 }]).chosen).toBeNull();
  });
  it("shares exact Paraibano club aliases without stripping AD/PB globally", () => {
    expect(normalizedTeamName("AD Picuiense")).toBe(normalizedTeamName("Picuiense"));
    expect(normalizedTeamName("AD Guarabira")).toBe(normalizedTeamName("Desportiva Guarabira PB"));
    expect(normalizedTeamName("AD Other")).not.toBe(normalizedTeamName("Other"));
    expect(normalizedTeamName("Other PB")).not.toBe(normalizedTeamName("Other"));
    const ng = { ...source, team1: "Picuiense", team2: "Desportiva Guarabira PB", kickoffMs: null };
    const ex = { ...control, team1: "AD Picuiense", team2: "AD Guarabira" };
    const result = chooseBaseBinding(ng, [ex]);
    expect(result.chosen?.id).toBe(ex.id);
    expect(result.scored[0]).toMatchObject({ home: 1, away: 1, delta: null,
      contributions: { corroboration: .25 }, gates: { scorePeriod: true, kickoff: true } });
    for (const team2 of ["Guarabira", "Desportiva Guarabira SP", "AD Guarabira U23", "Desportiva Other PB"]) {
      expect(chooseBaseBinding(ng, [{ ...ex, team2 }]).chosen).toBeNull();
    }
    expect(chooseBaseBinding(ng, [ex, { ...ex, id: "duplicate" }]).ambiguous).toBe(true);
    expect(chooseBaseBinding(ng, [{ ...ex, homeScore: null }]).chosen).toBeNull();
    expect(chooseBaseBinding(ng, [{ ...ex, period: "first-half" }]).chosen).toBeNull();
  });
  it("does not pick insertion order for ambiguous candidates", () => {
    const result = chooseBaseBinding(source, [control, { ...control, id: "other" }]);
    expect(result.ambiguous).toBe(true);
    expect(result.chosen).toBeNull();
  });
  it("rejects reversed and orientation-ambiguous names rather than assuming home/away", () => {
    expect(chooseBaseBinding(source, [{ ...control, team1: control.team2, team2: control.team1 }]).chosen).toBeNull();
    const same = { ...source, team1: "City", team2: "City" };
    expect(chooseBaseBinding(same, [{ ...same, id: "other" }]).scored[0]?.reason).toBe("orientation_ambiguous");
  });
  it("parses yearless kickoff only against a real observation, rejecting invalid dates", () => {
    expect(parseBindingKickoff("24.09.2026 23:30", time)).toBe(new Date(2026, 8, 24, 23, 30).getTime());
    expect(parseBindingKickoff("31.02.2026 23:30", time)).toBeNull();
    expect(parseBindingKickoff("24.09.2026 25:30", time)).toBeNull();
    expect(parseBindingKickoff("18:00 24.09", time)).toBe(time);
    expect(parseBindingKickoff("18:00 31.02", time)).toBeNull();
    expect(parseBindingKickoff("", time)).toBeNull();
    expect(parseBindingKickoff("18:00 24.09", NaN)).toBeNull();
  });
  it("slow enrichment sends fallback within capped deadline", async () => {
    vi.useFakeTimers();
    try {
      const send = vi.fn();
      const pending = boundedEnrichment(new Promise<string>(() => {}), () => "original money card", 999_999).then(send);
      await vi.advanceTimersByTimeAsync(30_000);
      await pending;
      expect(send).toHaveBeenCalledWith("original money card");
    } finally { vi.useRealTimers(); }
  });
  it("uses original evidence on enrichment rejection", async () => {
    await expect(boundedEnrichment(Promise.reject(new Error("offline")), () => "original card")).resolves.toBe("original card");
  });
  it("consumes a late rejection after timeout", async () => {
    let reject!: (error: Error) => void;
    const work = new Promise<string>((_resolve, fail) => { reject = fail; });
    await expect(boundedEnrichment(work, () => "original card", 1)).resolves.toBe("original card");
    reject(new Error("late upstream failure"));
    await Promise.resolve();
  });
});