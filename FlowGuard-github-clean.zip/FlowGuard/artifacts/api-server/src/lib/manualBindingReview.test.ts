import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
const audit = vi.hoisted(() => vi.fn());
vi.mock("./bindingDecisionAudit", async (importOriginal) => ({
  ...await importOriginal<typeof import("./bindingDecisionAudit")>(),
  recordBindingDecision: audit,
}));
import {
  __testOnlyGetManualExcapperBindingCache,
  __testOnlyInstallManualExcapperBindingCache,
  __testOnlyRecordManualCandidateDiagnostic,
  __testOnlyResetExcapperBindingDiagnostics,
  __testOnlyResetManualExcapperBindingCache,
  __testOnlySetLeagueAliasApprovalDependencies,
  __testOnlySetBindingBlockDependencies,
  approveResolvedManualLeagueAlias,
  classifyManualExcapperBindings,
  getExcapperBindingDiagnostic,
  resolveManualExcapperBindings,
  resetManualExcapperBinding,
  type DirectoryRow,
} from "./excapper";
import { __testOnlySetManualBindingsFile } from "./manualBindingsStore";

const candidate = {
  matchId: "710001",
  team1: "Club Atlético Alpha",
  team2: "Beta FC",
  league: "Translated League Name",
  nowGoalLine: 2.5,
  state: 3,
  homeScore: 1,
  awayScore: 0,
  liveMinute: 60,
};
const row: DirectoryRow = {
  gameId: "91001",
  team1: "Alpha",
  team2: "Beta",
  league: "Different Language Competition",
  totalVolume: 500,
  isLive: true,
  activity: "live",
  liveScore: { home: 1, away: 0 },
  livePeriod: "second-half",
  liveMinute: 60,
  observedTime: "20:30 20.09",
};
const page = (score = "1-0") => `
  <div class="matchinfo"><h1>Alpha - Beta</h1><font class="score live">60'</font></div>
  <a href="#tab_content_1">Over/Under 2.5 Goals</a>
  <div id="tab_content_1" class="tab-content">
    <div class="charts-bk__item-title">Over</div><div class="charts-bk__item-coef">100 €</div>
    <div class="charts-bk__item-title">Under</div><div class="charts-bk__item-coef">90 €</div>
    <table><tr><td>live</td><td>20:30 20.09</td><td>Over</td>
    <td>100 €</td><td>10 €</td><td>60</td><td>${score}</td></tr></table>
  </div></body>`;

describe("hybrid manual watchlist binding policy", () => {
  let storeDir: string;
  beforeEach(() => {
    storeDir = mkdtempSync(path.join(tmpdir(), "manual-binding-review-"));
    __testOnlySetManualBindingsFile(path.join(storeDir, "manual-bindings.json"));
    audit.mockReset();
    __testOnlyResetExcapperBindingDiagnostics();
    __testOnlyResetManualExcapperBindingCache();
    __testOnlySetBindingBlockDependencies({
      load: async () => [],
      persist: async () => undefined,
      reset: async (_pairs, entries) => {
        for (const entry of entries) audit(entry.matchId, entry.decision);
      },
      remove: async () => undefined,
    });
  });
  afterEach(() => {
    __testOnlySetLeagueAliasApprovalDependencies();
    __testOnlySetBindingBlockDependencies();
    rmSync(storeDir, { recursive: true, force: true });
  });

  it("requires translated leagues and minor team variations to be reviewed", () => {
    expect(resolveManualExcapperBindings([candidate], [row])).toEqual([]);
  });

  it("auto-binds exact normalized teams and league when score and period agree", () => {
    const exactCandidate = { ...candidate, team1: "Alpha", team2: "Beta", league: "Exact" };
    const exactRow = { ...row, league: "Exact" };
    expect(resolveManualExcapperBindings([exactCandidate], [exactRow])).toEqual([
      expect.objectContaining({ matchId: candidate.matchId, gameId: row.gameId, confidence: 1 }),
    ]);
  });

  it("does not auto-bind when more than one current game is possible", () => {
    const second = { ...row, gameId: "91002" };
    expect(resolveManualExcapperBindings([candidate], [row, second])).toEqual([]);
    expect(classifyManualExcapperBindings([candidate], [row, second]).get(candidate.matchId)?.status)
      .toBe("ambiguous_identity");
  });

  it("binds the exact opaque candidate selected from multiple possibilities", async () => {
    const second = { ...row, gameId: "91002" };
    const classification = classifyManualExcapperBindings([candidate], [row, second])
      .get(candidate.matchId)!;
    __testOnlyRecordManualCandidateDiagnostic(candidate, classification.status, classification.source);
    const reviews = getExcapperBindingDiagnostic(candidate.matchId).candidates!;
    expect(reviews).toHaveLength(2);
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [candidate],
      hasMembership: () => true,
      loadDirectory: async () => [row, second],
      loadGame: async () => page(),
      persist: async () => ({ created: true }),
      hydrate: () => true,
    });
    await expect(approveResolvedManualLeagueAlias(candidate.matchId, reviews[1]!.ref, false))
      .resolves.toMatchObject({ gameId: second.gameId });
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ gameId: second.gameId }),
    ]);
    expect(audit).toHaveBeenCalledOnce();
    expect(audit.mock.calls[0]).toEqual([
      candidate.matchId,
      expect.objectContaining({
        action: "bind", mode: "manual",
        target: expect.objectContaining({ id: candidate.matchId, score: { home: 1, away: 0 }, minute: 60 }),
        source: expect.objectContaining({ id: second.gameId, period: "second-half" }),
      }),
    ]);
    await approveResolvedManualLeagueAlias(candidate.matchId, reviews[1]!.ref, false);
    expect(audit).toHaveBeenCalledOnce();
    await resetManualExcapperBinding(candidate.matchId);
    expect(audit).toHaveBeenCalledTimes(2);
    expect(audit.mock.calls[1]?.[1]).toMatchObject({ action: "reset", mode: "manual" });
    await resetManualExcapperBinding(candidate.matchId);
    expect(audit).toHaveBeenCalledTimes(2);
  });

  it("requires the literal live minutes to align within two minutes", () => {
    const exactCandidate = { ...candidate, team1: "Alpha", team2: "Beta", league: "Exact" };
    const exactRow = { ...row, league: "Exact" };
    expect(resolveManualExcapperBindings(
      [{ ...exactCandidate, liveMinute: 62 }],
      [exactRow],
    )).toHaveLength(1);
    expect(resolveManualExcapperBindings(
      [{ ...exactCandidate, liveMinute: 63 }],
      [exactRow],
    )).toEqual([]);
    expect(resolveManualExcapperBindings(
      [{ ...exactCandidate, liveMinute: null }],
      [exactRow],
    )).toHaveLength(1);
    expect(resolveManualExcapperBindings(
      [exactCandidate],
      [{ ...exactRow, liveMinute: null }],
    )).toHaveLength(1);
  });

  it("requires explicit score confirmation and writes nothing before confirmed approval", async () => {
    const conflictRow = { ...row, liveScore: { home: 2, away: 0 } };
    const classification = classifyManualExcapperBindings([candidate], [conflictRow])
      .get(candidate.matchId)!;
    __testOnlyRecordManualCandidateDiagnostic(candidate, classification.status, classification.source);
    const ref = getExcapperBindingDiagnostic(candidate.matchId).candidates![0]!.ref;

    const persist = vi.fn(async () => ({ created: true }));
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [candidate],
      hasMembership: () => true,
      loadDirectory: async () => [conflictRow],
      loadGame: async () => page("2-0"),
      persist,
      hydrate: () => true,
    });

    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, false))
      .rejects.toThrow("Explicit confirmation");
    await expect(approveResolvedManualLeagueAlias(
      candidate.matchId,
      ref,
      "true" as unknown as boolean,
    )).rejects.toThrow("Explicit confirmation");
    expect(persist).not.toHaveBeenCalled();
    expect(audit).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);

    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .resolves.toMatchObject({ status: "bound_verified" });
    expect(persist).toHaveBeenCalledOnce();
    expect(audit).toHaveBeenCalledOnce();
    expect(audit.mock.calls[0]?.[1]).toMatchObject({
      action: "bind", mode: "manual_override",
      target: { score: { home: 1, away: 0 } },
      source: { score: { home: 2, away: 0 } },
    });
  });

  it("allows explicit approval while NowGoal score and time are still pending", async () => {
    const pendingCandidate = {
      ...candidate,
      state: null,
      homeScore: null,
      awayScore: null,
      liveMinute: null,
    };
    const classification = classifyManualExcapperBindings([pendingCandidate], [row])
      .get(candidate.matchId)!;
    __testOnlyRecordManualCandidateDiagnostic(
      pendingCandidate,
      classification.status,
      classification.source,
    );
    const ref = getExcapperBindingDiagnostic(candidate.matchId).candidates![0]!.ref;
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [pendingCandidate],
      hasMembership: () => true,
      loadDirectory: async () => [row],
      loadGame: async () => page(),
      persist: async () => ({ created: true }),
      hydrate: () => true,
    });

    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .resolves.toMatchObject({ gameId: row.gameId, status: "bound_verified" });
    expect(audit.mock.calls[0]?.[1]).toMatchObject({
      action: "bind",
      mode: "manual_override",
    });
  });

  it("retains authoritative finished rejection even with operator confirmation", async () => {
    const finishedCandidate = { ...candidate, state: -1 };
    const pendingCandidate = {
      ...candidate,
      state: null,
      homeScore: null,
      awayScore: null,
      liveMinute: null,
    };
    const classification = classifyManualExcapperBindings([pendingCandidate], [row])
      .get(candidate.matchId)!;
    __testOnlyRecordManualCandidateDiagnostic(
      pendingCandidate,
      classification.status,
      classification.source,
    );
    const ref = getExcapperBindingDiagnostic(candidate.matchId).candidates![0]!.ref;
    const persist = vi.fn(async () => ({ created: true }));
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [finishedCandidate],
      hasMembership: () => true,
      loadDirectory: async () => [row],
      loadGame: async () => page(),
      persist,
      hydrate: () => true,
    });

    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .rejects.toThrow("finished");
    expect(persist).not.toHaveBeenCalled();
    expect(audit).not.toHaveBeenCalled();
  });

  it("preserves a verified binding when durable reset persistence fails", async () => {
    __testOnlyInstallManualExcapperBindingCache({
      matchId: candidate.matchId,
      gameId: row.gameId,
    });
    __testOnlySetBindingBlockDependencies({
      reset: async () => { throw new Error("database unavailable"); },
    });
    await expect(resetManualExcapperBinding(candidate.matchId))
      .rejects.toThrow("database unavailable");
    expect(audit).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: candidate.matchId, gameId: row.gameId }),
    ]);
  });

  it("fails reset before runtime mutation when the transactional audit write fails", async () => {
    __testOnlyInstallManualExcapperBindingCache({
      matchId: candidate.matchId, gameId: row.gameId,
    });
    __testOnlySetBindingBlockDependencies({
      reset: async () => { throw new Error("audit transaction rolled back"); },
    });
    await expect(resetManualExcapperBinding(candidate.matchId)).rejects.toThrow("audit transaction rolled back");
    expect(audit).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: candidate.matchId, gameId: row.gameId }),
    ]);
  });

  it("fails approval before binding or hydration when local audit admission fails", async () => {
    const conflictRow = { ...row, liveScore: { home: 2, away: 0 } };
    const classification = classifyManualExcapperBindings([candidate], [conflictRow])
      .get(candidate.matchId)!;
    __testOnlyRecordManualCandidateDiagnostic(candidate, classification.status, classification.source);
    const ref = getExcapperBindingDiagnostic(candidate.matchId).candidates![0]!.ref;
    const hydrate = vi.fn(() => true);
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [candidate], hasMembership: () => true,
      loadDirectory: async () => [conflictRow], loadGame: async () => page("2-0"),
      persist: async () => ({ created: true }), hydrate,
    });
    audit.mockImplementationOnce(() => { throw new Error("local outbox unavailable"); });
    await expect(approveResolvedManualLeagueAlias(candidate.matchId, ref, true))
      .rejects.toThrow("local outbox unavailable");
    expect(hydrate).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });

  it("clears a verified binding and blocks the same pair on next discovery", async () => {
    const testCandidate = {
      ...candidate,
      team1: "Test Home",
      team2: "Test Away",
      league: "Test League",
    };
    const testRow = {
      ...row,
      team1: "Test Home",
      team2: "Test Away",
      league: "Translated Test League",
    };
    __testOnlyInstallManualExcapperBindingCache({
      matchId: testCandidate.matchId,
      gameId: testRow.gameId,
    });
    await resetManualExcapperBinding(testCandidate.matchId);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
    expect(resolveManualExcapperBindings([testCandidate], [testRow])).toEqual([]);
    expect(classifyManualExcapperBindings([testCandidate], [testRow])
      .get(testCandidate.matchId)?.status).toBe("score_period_conflict");
  });

  it("invalidates an in-flight approval so reset cannot resurrect it", async () => {
    const conflictRow = { ...row, liveScore: { home: 2, away: 0 } };
    const classification = classifyManualExcapperBindings([candidate], [conflictRow])
      .get(candidate.matchId)!;
    __testOnlyRecordManualCandidateDiagnostic(candidate, classification.status, classification.source);
    const ref = getExcapperBindingDiagnostic(candidate.matchId).candidates![0]!.ref;

    let release!: (html: string) => void;
    const delayed = new Promise<string>((resolve) => { release = resolve; });
    let loadStarted!: () => void;
    const started = new Promise<void>((resolve) => { loadStarted = resolve; });
    const persistAlias = vi.fn(async () => ({ created: true }));
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [candidate],
      hasMembership: () => true,
      loadDirectory: async () => [conflictRow],
      loadGame: async () => { loadStarted(); return delayed; },
      persist: persistAlias,
      hydrate: () => true,
    });
    const approval = approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    await started;
    await resetManualExcapperBinding(candidate.matchId);
    release(page("2-0"));
    await expect(approval).rejects.toThrow("removed or replaced");
    expect(persistAlias).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });

  it("lets reset win when approval is awaiting durable block removal", async () => {
    const conflictRow = { ...row, liveScore: { home: 2, away: 0 } };
    const classification = classifyManualExcapperBindings([candidate], [conflictRow])
      .get(candidate.matchId)!;
    __testOnlyRecordManualCandidateDiagnostic(candidate, classification.status, classification.source);
    const ref = getExcapperBindingDiagnostic(candidate.matchId).candidates![0]!.ref;

    let releaseRemove!: () => void;
    let removeStarted!: () => void;
    const started = new Promise<void>((resolve) => { removeStarted = resolve; });
    const delayedRemove = new Promise<void>((resolve) => { releaseRemove = resolve; });
    const persistBlock = vi.fn(async () => undefined);
    __testOnlySetBindingBlockDependencies({
      persist: persistBlock,
      reset: async (pairs) => { for (const _pair of pairs) await persistBlock(); },
      remove: async () => { removeStarted(); return delayedRemove; },
    });
    __testOnlySetLeagueAliasApprovalDependencies({
      candidates: () => [candidate],
      hasMembership: () => true,
      loadDirectory: async () => [conflictRow],
      loadGame: async () => page("2-0"),
      persist: async () => ({ created: true }),
      hydrate: () => true,
    });
    const approval = approveResolvedManualLeagueAlias(candidate.matchId, ref, true);
    await started;
    await resetManualExcapperBinding(candidate.matchId);
    releaseRemove();
    await expect(approval).rejects.toThrow("reset while approval completed");
    expect(persistBlock).toHaveBeenCalledTimes(2);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });
});
