/**
 * Pre-scan health validator + background watchdog for the NowGoal scanner.
 *
 * Validator runs on demand (boot, /scanner/validate, watchdog) and verifies:
 *   - All 4 upstream endpoints respond 200 with parseable bodies
 *   - Bodies contain expected record counts (no silent stale 13-byte placeholders)
 *   - META feed contains matches with kickoff times near "now" (proves it's not a cached old window)
 *
 * Watchdog runs every 60 s and alarms if liveMatches has been 0 for ≥30 min
 * while pre-match count is healthy — that's the signature of the bug we just hit.
 */
import { logger } from "./logger";
import { sendTelegram, escapeMdV2, isTelegramConfigured } from "./telegram";
import { currentBaseUrl, endpointsFor, getFailoverState, tryFailover, crossVerifyLiveCount, type UpstreamFetcher, type UpstreamFetchDetails } from "./upstream";
import { getLeaguePolicy } from "./targetLeagues";

export interface EndpointCheck {
  url: string;
  ok: boolean;
  status?: number;
  finalUrl?: string;
  redirected?: boolean;
  bytes?: number;
  recordsParsed?: number;
  reason?: string;
  elapsedMs: number;
}

export interface FreshnessCheck {
  ok: boolean;
  matchesNearNow: number;
  oldestKickoffIso: string | null;
  newestKickoffIso: string | null;
  reason?: string;
}

export interface ValidationResult {
  ok: boolean;
  ranAt: string;
  base: string;
  endpoints: EndpointCheck[];
  freshness: FreshnessCheck;
  failover: ReturnType<typeof getFailoverState>;
  summary: string;
}

const STALE_LIVE_MS = 60 * 60 * 1000;          // alarm if no live for 60 min (avoids night-shift false positives)
const WATCHDOG_INTERVAL_MS = 60 * 1000;        // run every 60 s
const MIN_PRE_MATCH_FOR_CONCERN = 50;          // only alarm when there's enough data to reasonably expect lives
const ALARM_COOLDOWN_MS = 60 * 60 * 1000;      // re-alarm at most once an hour
// Freshness check: schedule must contain matches kicking off within the next 36h.
// (NowGoal's META spans ~24-36h of upcoming + recently-finished matches.) If the
// newest kickoff is in the past, the feed is a stale cached snapshot.
const SCHEDULE_FUTURE_HORIZON_MS = 36 * 60 * 60 * 1000;
const SCHEDULE_PAST_HORIZON_MS = 6 * 60 * 60 * 1000;

let watchdogTimer: ReturnType<typeof setTimeout> | null = null;
let watchdogGeneration = 0;                    // bumped on stop; in-flight ticks compare against this to refuse re-arm
let lastLiveSeenAt: number = Date.now();      // pretend "just saw live" at boot so we don't alarm immediately
let lastAlarmAt: number = 0;
let lastValidation: ValidationResult | null = null;

export function noteLiveCount(liveCount: number): void {
  if (liveCount > 0) lastLiveSeenAt = Date.now();
}

export function getWatchdogState() {
  return {
    lastLiveSeenAt: new Date(lastLiveSeenAt).toISOString(),
    lastAlarmAt: lastAlarmAt ? new Date(lastAlarmAt).toISOString() : null,
    staleLiveThresholdSec: STALE_LIVE_MS / 1000,
    watchdogIntervalSec: WATCHDOG_INTERVAL_MS / 1000,
  };
}

export function getLastValidation(): ValidationResult | null {
  return lastValidation;
}

/**
 * Parse `f[3]` ("YYYY,M,D,H,M,S") → UTC epoch ms.
 *
 * Two non-obvious quirks of the NowGoal feed:
 *   - month is 0-indexed (legacy ASP-era format)
 *   - the wall-clock is GMT+8 (Beijing time), not UTC. We confirmed this by
 *     comparing f[2] (display string) to f[3] across hundreds of records:
 *     f[3] is consistently +8h ahead of f[2], i.e. f[3] is Beijing local time.
 */
const FEED_TZ_OFFSET_MS = 8 * 60 * 60 * 1000; // GMT+8

export function parseKickoffMs(commaTime: string): number | null {
  const p = commaTime.split(",").map((x) => parseInt(x.trim(), 10));
  if (p.length < 5 || p.some((n) => Number.isNaN(n))) return null;
  const wallMs = Date.UTC(p[0], p[1], p[2], p[3], p[4], p[5] ?? 0);
  if (!Number.isFinite(wallMs)) return null;
  return wallMs - FEED_TZ_OFFSET_MS;
}

async function checkEndpoint(
  url: string,
  fetchFn: UpstreamFetcher,
  parseRecords: (body: string) => number,
): Promise<EndpointCheck> {
  const t0 = Date.now();
  try {
    const raw = await fetchFn(url);
    const details: UpstreamFetchDetails = typeof raw === "string" ? { body: raw } : raw;
    const body = details.body;
    const elapsedMs = Date.now() - t0;
    const bytes = body.length;
    if (
      details.finalUrl &&
      new URL(details.finalUrl).origin.toLowerCase() !== new URL(url).origin.toLowerCase()
    ) {
      return {
        url,
        ok: false,
        status: details.status,
        finalUrl: details.finalUrl,
        redirected: true,
        bytes,
        reason: "redirected_origin",
        elapsedMs,
      };
    }
    if (bytes < 50) {
      return { url, ok: false, status: details.status, finalUrl: details.finalUrl, redirected: details.redirected, bytes, reason: "body_too_small", elapsedMs };
    }
    const recordsParsed = parseRecords(body);
    if (recordsParsed < 1) {
      return { url, ok: false, status: details.status, finalUrl: details.finalUrl, redirected: details.redirected, bytes, recordsParsed, reason: "no_records_parsed", elapsedMs };
    }
    return { url, ok: true, status: details.status ?? 200, finalUrl: details.finalUrl, redirected: details.redirected, bytes, recordsParsed, elapsedMs };
  } catch (err) {
    return {
      url,
      ok: false,
      reason: err instanceof Error ? err.message : String(err),
      elapsedMs: Date.now() - t0,
    };
  }
}

function countOuRows(xml: string): number {
  return (xml.match(/<m>[^<]+<\/m>/g) ?? []).length;
}

function countMetaRows(text: string): number {
  try {
    const json = JSON.parse(text) as { ErrCode: number; Data: string };
    if (json.ErrCode !== 0 || !json.Data) return 0;
    return json.Data.split("!").filter(Boolean).length;
  } catch {
    return 0;
  }
}

function countLeagueRows(text: string): number {
  try {
    const json = JSON.parse(text) as { ErrCode: number; Data: string };
    if (json.ErrCode !== 0 || !json.Data) return 0;
    return (json.Data.match(/B\[\d+\]=\[/g) ?? []).length;
  } catch {
    return 0;
  }
}

/** Confirm META isn't a stale cached snapshot from days ago. */
function checkFreshness(metaBody: string): FreshnessCheck {
  let json: { ErrCode: number; Data: string };
  try {
    json = JSON.parse(metaBody) as { ErrCode: number; Data: string };
  } catch {
    return { ok: false, matchesNearNow: 0, oldestKickoffIso: null, newestKickoffIso: null, reason: "meta_unparseable" };
  }
  if (json.ErrCode !== 0 || !json.Data) {
    return { ok: false, matchesNearNow: 0, oldestKickoffIso: null, newestKickoffIso: null, reason: "meta_errcode" };
  }

  const now = Date.now();
  let nearNow = 0;
  let oldest: number | null = null;
  let newest: number | null = null;

  for (const record of json.Data.split("!").filter(Boolean)) {
    const f = record.split("^");
    const ms = parseKickoffMs(f[3] ?? "");
    if (ms === null) continue;
    if (oldest === null || ms < oldest) oldest = ms;
    if (newest === null || ms > newest) newest = ms;
    // Schedule window = kicks off within the past 6h or the next 36h.
    if (ms >= now - SCHEDULE_PAST_HORIZON_MS && ms <= now + SCHEDULE_FUTURE_HORIZON_MS) {
      nearNow++;
    }
  }

  // Genuine staleness: every kickoff is in the past, OR no kickoffs in the
  // expected window at all. The first case means the feed is a snapshot from
  // days ago; the second usually means a parse / endpoint failure.
  const allInPast = newest !== null && newest < now - SCHEDULE_PAST_HORIZON_MS;
  let reason: string | undefined;
  if (allInPast) reason = "schedule_entirely_in_past";
  else if (nearNow < 5) reason = "no_kickoffs_in_window";

  return {
    ok: !allInPast && nearNow >= 5,
    matchesNearNow: nearNow,
    oldestKickoffIso: oldest ? new Date(oldest).toISOString() : null,
    newestKickoffIso: newest ? new Date(newest).toISOString() : null,
    reason,
  };
}

/** Run a full validation against the current upstream base. */
export async function validateUpstream(
  fetchFn: UpstreamFetcher,
): Promise<ValidationResult> {
  const base = currentBaseUrl();
  const ep = endpointsFor(base);

  const [primary, bench, meta, leagues] = await Promise.all([
    checkEndpoint(ep.primaryOu, fetchFn, countOuRows),
    checkEndpoint(ep.benchmarkOu, fetchFn, countOuRows),
    checkEndpoint(ep.meta, fetchFn, countMetaRows),
    checkEndpoint(ep.leagues, fetchFn, countLeagueRows),
  ]);

  // Only check freshness if META came back well-formed.
  let freshness: FreshnessCheck;
  if (meta.ok) {
    try {
      const raw = await fetchFn(ep.meta);
      const body = typeof raw === "string" ? raw : raw.body;
      freshness = checkFreshness(body);
    } catch (err) {
      freshness = {
        ok: false,
        matchesNearNow: 0,
        oldestKickoffIso: null,
        newestKickoffIso: null,
        reason: err instanceof Error ? err.message : String(err),
      };
    }
  } else {
    freshness = {
      ok: false,
      matchesNearNow: 0,
      oldestKickoffIso: null,
      newestKickoffIso: null,
      reason: "meta_endpoint_unhealthy",
    };
  }

  const endpoints = [primary, bench, meta, leagues];
  const ok = endpoints.every((e) => e.ok) && freshness.ok;
  const directoryCount = leagues.ok ? leagues.recordsParsed : undefined;
  const whitelistSize = getLeaguePolicy().total;
  const counts = `upstream league directory: ${directoryCount ?? "unknown"} · whitelist leagues: ${whitelistSize}`;

  const summary = ok
    ? `All ${endpoints.length} endpoints healthy · ${freshness.matchesNearNow} scheduled kickoffs in -6/+36h window · ${counts}`
    : `Issues: ${endpoints.filter((e) => !e.ok).map((e) => `${shortName(e.url)}:${e.reason ?? "fail"}`).join(", ")}${freshness.ok ? "" : ` · freshness:${freshness.reason}`} · ${counts}`;

  const result: ValidationResult = {
    ok,
    ranAt: new Date().toISOString(),
    base,
    endpoints,
    freshness,
    failover: getFailoverState(),
    summary,
  };
  lastValidation = result;
  logger.info({ ok, summary, base }, "Upstream validation completed");
  return result;
}

function shortName(url: string): string {
  if (url.includes("goal8.xml")) return "primary";
  if (url.includes("goal3.xml")) return "bench";
  if (url.includes("type=12")) return "meta";
  if (url.includes("type=6")) return "leagues";
  return url;
}

/**
 * Watchdog: every 60s, decide whether the scanner is "stuck".
 *
 * Trigger conditions (ALL must hold):
 *   - we have meaningful pre-match data (>= 50 matches tracked)
 *   - liveMatchesTracked has been 0 continuously for >= 30 min
 *   - we haven't alarmed in the last hour (cooldown)
 *
 * Action: run validateUpstream(); if upstream is broken, attempt host failover;
 *         in either case, send a Telegram alarm summarizing the diagnosis.
 */
export function startWatchdog(opts: {
  fetchFn: UpstreamFetcher;
  getStats: () => { liveMatchesTracked: number; minorMatchesTracked: number; lastError: string | null };
}): void {
  if (watchdogTimer) clearTimeout(watchdogTimer);
  // Bump generation so any in-flight tick from a prior start refuses to re-arm.
  watchdogGeneration++;
  const myGeneration = watchdogGeneration;

  let watchdogTickCount = 0;
  // Overlap guard: if a watchdog tick is genuinely slow (cross-verify probes,
  // failover cascade), don't let the next interval start a second tick on top.
  // Generation guard already prevents stale-generation re-arming; this guard
  // prevents same-generation overlap when a tick exceeds the interval.
  let tickInFlight = false;
  const tick = async () => {
    if (tickInFlight) {
      logger.warn("Watchdog: previous tick still in flight — skipping this interval");
      // Re-arm without running so the loop survives a single slow tick.
      if (myGeneration === watchdogGeneration) {
        watchdogTimer = setTimeout(tick, WATCHDOG_INTERVAL_MS);
      }
      return;
    }
    tickInFlight = true;
    try {
      watchdogTickCount++;
      const stats = opts.getStats();
      // Update last-live timestamp from caller-provided stats (caller also calls noteLiveCount).
      noteLiveCount(stats.liveMatchesTracked);

      // SILENT Telegram liveness probe — calls getMe (read-only, doesn't post
      // anything to the chat). We run it every tick and log to console only.
      // If the probe fails, log loudly to console — we can't notify via the
      // very channel that's broken, but the deployment log surface picks it up.
      // Previously this sent a "System Test: connection OK" message every 30
      // ticks, which spammed the chat; users explicitly do not want that.
      const { probeTelegramSilent } = await import("./telegram");
      const probe = await probeTelegramSilent();
      if (probe.ok) {
        // Use logger (structured) so it doesn't pollute stdout every minute.
        logger.debug({ tick: watchdogTickCount }, "Watchdog: Telegram getMe OK");
      } else {
        logger.error(
          { tick: watchdogTickCount, reason: probe.reason },
          "[WATCHDOG] CRITICAL: Telegram self-check FAILED",
        );
      }

      const stuckForMs = Date.now() - lastLiveSeenAt;
      const enoughData = stats.minorMatchesTracked >= MIN_PRE_MATCH_FOR_CONCERN;
      const stuck = stuckForMs >= STALE_LIVE_MS && enoughData;
      const cooledDown = Date.now() - lastAlarmAt >= ALARM_COOLDOWN_MS;

      if (stuck && cooledDown) {
        logger.warn(
          { stuckForMin: Math.round(stuckForMs / 60000), preMatch: stats.minorMatchesTracked },
          "Watchdog: live count stuck — cross-verifying with alt mirror before alarming",
        );

        // STEP 1 — Cross-verify with TWO independent alt mirrors (cheap
        // META-only fetches). If both alts ALSO see zero live AND have a
        // realistic pre-match volume (proving they're not stale snapshots),
        // this is a genuine quiet hour. We log it for telemetry but do NOT
        // alarm and do NOT failover — failing over from a healthy primary
        // just for a quiet hour wastes probe budget and risks IP-banning
        // a perfectly-good mirror.
        //
        // Two-alt requirement is the masking-risk fix flagged by code review:
        // a single stale alt mirror returning parseable-but-frozen META
        // could otherwise suppress alarms indefinitely.
        const MIN_ALT_PRE_MATCH_FOR_QUIET = 30;
        const bodyFetcher = async (url: string) => {
          const raw = await opts.fetchFn(url);
          return typeof raw === "string" ? raw : raw.body;
        };
        const cv1 = await crossVerifyLiveCount(bodyFetcher);
        const cv2 = await crossVerifyLiveCount(bodyFetcher);
        const bothQuiet =
          cv1.ok &&
          cv2.ok &&
          cv1.agreedQuiet &&
          cv2.agreedQuiet &&
          cv1.altPreMatchCount >= MIN_ALT_PRE_MATCH_FOR_QUIET &&
          cv2.altPreMatchCount >= MIN_ALT_PRE_MATCH_FOR_QUIET;
        if (bothQuiet) {
          logger.info(
            {
              alt1: { host: cv1.altHost, live: cv1.altLiveCount, pre: cv1.altPreMatchCount },
              alt2: { host: cv2.altHost, live: cv2.altLiveCount, pre: cv2.altPreMatchCount },
            },
            "Watchdog: 2 alt mirrors confirm quiet hour — suppressing alarm, no failover",
          );
          // Reset timer — we have high confidence the world is genuinely quiet.
          lastLiveSeenAt = Date.now();
          return;
        }
        // Pick the more informative cross-verify result for the alarm note.
        const cv = cv1.ok ? cv1 : cv2;

        // STEP 2 — Either cross-verify failed OR alt mirror disagrees (sees
        // live matches we don't). Both are signals our primary is broken /
        // silently blocked. Run the full validator + attempt failover.
        const validation = await validateUpstream(opts.fetchFn);
        let failoverNote = "";
        let switchSuppressed = false;
        if (!validation.ok || (cv.ok && !cv.agreedQuiet)) {
          const reason = cv.ok && !cv.agreedQuiet
            ? "watchdog_cross_verify_mismatch"
            : "watchdog_stuck_live";
          const fo = await tryFailover(opts.fetchFn, reason);
          switchSuppressed = fo.suppressed === "switch_cooldown";
          failoverNote = fo.switched
            ? `\n🔁 *Switched mirror:* ${escapeMdV2(fo.from)} → ${escapeMdV2(fo.to)}`
            : switchSuppressed
              ? ""
            : `\n⚠️ *No healthy mirror found* in ${fo.report.length} candidates`;
        }

        const cvNote = cv.ok
          ? `\n*Cross\\-verify:* ${escapeMdV2(cv.altHost ?? "?")} sees ${cv.altLiveCount} live, ${cv.altPreMatchCount} pre\\-match`
          : `\n*Cross\\-verify:* ${escapeMdV2(`failed (${cv.reason ?? "unknown"})`)}`;

        // A cooldown-suppressed switch is intentional duplicate work, not a
        // new incident. Never emit Telegram for that suppressed attempt.
        if (isTelegramConfigured() && !switchSuppressed) {
          const stuckMin = Math.round(stuckForMs / 60000);
          const msg =
            `🚨 *Scanner Watchdog Alarm*` +
            `\n` +
            `\nLive matches \\= *0* for *${stuckMin} min* while tracking *${stats.minorMatchesTracked}* pre\\-match games\\.` +
            `\n` +
            `\n*Validator:* ${escapeMdV2(validation.summary)}` +
            `\n*Base:* ${escapeMdV2(validation.base)}` +
            cvNote +
            failoverNote +
            `\n` +
            `\n_Auto\\-revalidating every hour until resolved\\._`;
          await sendTelegram(msg);
        }

        lastAlarmAt = Date.now();
      }
    } catch (err) {
      logger.error({ err }, "Watchdog tick failed");
    } finally {
      tickInFlight = false;
      // Only re-arm if our generation is still current. Prevents a tick that
      // started before stopWatchdog() from resurrecting the loop.
      if (myGeneration === watchdogGeneration) {
        watchdogTimer = setTimeout(tick, WATCHDOG_INTERVAL_MS);
      }
    }
  };

  watchdogTimer = setTimeout(tick, WATCHDOG_INTERVAL_MS);
  logger.info({ intervalSec: WATCHDOG_INTERVAL_MS / 1000 }, "Scanner watchdog started");
}

export function stopWatchdog(): void {
  watchdogGeneration++;
  if (watchdogTimer) {
    clearTimeout(watchdogTimer);
    watchdogTimer = null;
  }
}
