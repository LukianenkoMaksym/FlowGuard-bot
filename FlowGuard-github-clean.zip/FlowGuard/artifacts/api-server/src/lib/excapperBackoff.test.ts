import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  __testOnlyResetExcapperBackoff,
  ExcapperCooldownError,
  getExcapperHealth,
  onExcapperRecovery,
  parseRetryAfter,
  recordExcapperFailure,
} from "./excapperBackoff";
import {
  __testOnlyClearSharedExcapperFetches,
  fetchExcapperText,
  getExcapperQueueStats,
  InvalidExcapperPayloadError,
} from "./excapperSharedFetch";

const authenticDirectory =
  `<html><head><title>Excapper</title></head><body><table>` +
  `<tr class="a_link" game_id="42"><td>x</td></tr></table>` +
  "x".repeat(1_100) +
  `</body></html>`;

describe("Excapper shared backoff", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-09-21T12:00:00Z"));
    __testOnlyResetExcapperBackoff();
    __testOnlyClearSharedExcapperFetches();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.useRealTimers();
  });

  it("applies bounded exponential backoff with jitter and honors Retry-After", () => {
    const now = Date.now();
    recordExcapperFailure(503, null, "first", now, () => 0.5);
    expect(getExcapperHealth()).toMatchObject({
      state: "backoff",
      retryAt: now + 27_500,
      lastErrorStatus: 503,
    });

    recordExcapperFailure(429, 180_000, "limited", now, () => 0.5);
    expect(getExcapperHealth()).toMatchObject({
      retryAt: now + 180_000,
      lastErrorStatus: 429,
    });
    expect(parseRetryAfter("120", now)).toBe(120_000);
    expect(parseRetryAfter("Sun, 21 Sep 2026 12:03:00 GMT", now)).toBe(180_000);
  });

  it("rejects a rate-limited batch once and lets the next scheduled tick recover", async () => {
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(new Response("busy", {
        status: 429,
        headers: { "Retry-After": "2" },
      }))
      .mockResolvedValueOnce(new Response(authenticDirectory, { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const signal = new AbortController().signal;

    const retained = fetchExcapperText("https://www.excapper.com/", signal, "directory");
    const rejected = expect(retained).rejects.toThrow("HTTP 429");
    await vi.advanceTimersByTimeAsync(0);
    await rejected;
    expect(fetchMock).toHaveBeenCalledTimes(1);

    const retryAt = getExcapperHealth().retryAt!;
    await vi.advanceTimersByTimeAsync(retryAt - Date.now() + 1);
    await expect(fetchExcapperText(
      "https://www.excapper.com/", signal, "directory",
    )).resolves.toBe(authenticDirectory);
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(getExcapperHealth()).toMatchObject({
      state: "healthy",
      retryAt: null,
      lastErrorStatus: null,
    });
    expect(getExcapperHealth().lastSuccessAt).toBeGreaterThanOrEqual(retryAt);
  });

  it("does not fire recovery listeners that would issue an immediate duplicate batch", async () => {
    const recovered = vi.fn();
    const unsubscribe = onExcapperRecovery(recovered);
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(new Response("x".repeat(2_000), { status: 503 }))
      .mockResolvedValueOnce(new Response(authenticDirectory, { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const signal = new AbortController().signal;
    try {
      const retained = fetchExcapperText("https://www.excapper.com/", signal, "directory");
      const rejected = expect(retained).rejects.toThrow("HTTP 503");
      await vi.advanceTimersByTimeAsync(0);
      await rejected;
      expect(recovered).not.toHaveBeenCalled();
      const retryAt = getExcapperHealth().retryAt!;
      await vi.advanceTimersByTimeAsync(retryAt - Date.now() + 1);
      await fetchExcapperText("https://www.excapper.com/", signal, "directory");
      expect(recovered).not.toHaveBeenCalled();
    } finally {
      unsubscribe();
    }
  });

  it("removes an aborted queued batch without blocking the queue", async () => {
    vi.stubGlobal("fetch", vi.fn(async (_url: string | URL | Request, init: RequestInit) =>
      new Promise<Response>((_resolve, reject) => {
        init.signal?.addEventListener("abort", () =>
          reject(new DOMException("Aborted", "AbortError")), { once: true });
      }),
    ));
    const controller = new AbortController();
    const retained = fetchExcapperText(
      "https://www.excapper.com/",
      controller.signal,
      "directory",
    );
    await vi.advanceTimersByTimeAsync(0);
    const rejected = expect(retained).rejects.toMatchObject({ name: "AbortError" });
    controller.abort();
    await rejected;
    expect(getExcapperQueueStats()).toMatchObject({ pending: 0, running: 0 });
  });

  it("treats an HTTP 200 challenge as failure and never resets health", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(
      new Response(`<html><title>Just a moment</title>${"x".repeat(2_000)}cf-chl-</html>`, {
        status: 200,
      }),
    ));
    await expect(
      fetchExcapperText(
        "https://www.excapper.com/",
        new AbortController().signal,
        "directory",
      ),
    ).rejects.toBeInstanceOf(InvalidExcapperPayloadError);
    expect(getExcapperHealth()).toMatchObject({
      state: "backoff",
      lastErrorStatus: 200,
      lastSuccessAt: null,
    });
  });
});