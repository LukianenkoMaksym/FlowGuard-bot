/**
 * Manual Priority Watchlist.
 *
 * Reads a JSON file containing match fragments and exposes a fuzzy matcher
 * that the scanner uses to decide whether a given (team1, team2) pair should
 * be promoted to the priority pool (scanned every tick, bypassing the
 * global-pool throttle).
 *
 * Matching is intentionally cheap: case-insensitive substring against each
 * team name. "Dinamo" matches "Dinamo Zagreb" and "Dinamo Kyiv". A watchlist
 * entry's teams[] are OR'd, and the entry hits when at least one fragment
 * matches either team. This lets users add a single team ("Dinamo") or a
 * specific fixture (["Dinamo", "Besiktas"]) — the latter only matches when
 * BOTH fragments are present in the same fixture.
 *
 * Hot reload: we fs.watch the config file and reload on change. Reads are
 * lock-free — load() swaps the in-memory snapshot atomically.
 */
import { promises as fs, watch, type FSWatcher } from "node:fs";
import path from "node:path";
import { db, manualWatchlistTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";
import { matchTargetLeague } from "./targetLeagues";

const CONFIG_PATH = path.resolve(process.cwd(), "config/watchlist.json");

// Hard cap on a single team-fragment to keep the JSON sane and stop pathological
// inputs from bloating the file. Way more than enough for any real team name.
const MAX_TEAM_LEN = 80;
const MAX_TEAMS_PER_ENTRY = 4;

/**
 * In-process mutex serializing add/remove. Without this, two concurrent
 * POSTs (or a POST racing a DELETE) would both read the same baseline,
 * each append/remove independently, and the second writer would silently
 * drop the first writer's change.
 */
let mutationChain: Promise<unknown> = Promise.resolve();
function withMutationLock<T>(fn: () => Promise<T>): Promise<T> {
  const next = mutationChain.then(fn, fn);
  // Don't let one rejection poison subsequent waiters.
  mutationChain = next.catch(() => undefined);
  return next;
}

/**
 * Atomic write: stage to a sibling temp file in the same directory, fsync,
 * then rename over the target. Crash/interrupt mid-write can never leave
 * config/watchlist.json in a half-written state — either the old bytes
 * survive intact or the new bytes are fully visible.
 */
async function atomicWriteJson(filePath: string, payload: string): Promise<void> {
  const dir = path.dirname(filePath);
  const tmp = path.join(dir, `.${path.basename(filePath)}.tmp-${process.pid}-${Date.now()}`);
  const fh = await fs.open(tmp, "w");
  try {
    await fh.writeFile(payload, "utf8");
    await fh.sync();
  } finally {
    await fh.close();
  }
  await fs.rename(tmp, filePath);
}

interface WatchlistEntry {
  label?: string;
  teams: string[];
  /** Canonical target label captured when the league was resolvable. */
  league?: string;
  // Numeric NowGoal26 match id, extracted from a pasted URL. When present,
  // the scanner can look this fixture up directly in matchStates by id and
  // skip all fuzzy text matching — bulletproof for regional/minor leagues
  // where team-name strings on the site don't match the feed strings.
  matchId?: string;
  /**
   * Provenance of the entry. Existing files predate this field and are
   * treated as manual entries for backwards compatibility.
   */
  origin?: string;
}

interface WatchlistFile {
  matches?: WatchlistEntry[];
}

export type WatchlistOrigin = "manual";

export interface NormalizedEntry {
  label: string;
  fragments: string[]; // lowercased, trimmed
  matchId?: string;
  league?: string;
  /** Explicit user pin versus Excapper automation. */
  origin: WatchlistOrigin;
  /**
   * Stable key used by the UI's Remove button. For id-bearing entries this
   * is `id:<matchId>`; for text-only entries it's the sorted, normalized
   * fragments joined by `|`. The server computes it so the UI doesn't have
   * to keep the algorithm in sync.
   */
  signature: string;
}

/**
 * The single source of truth for matchId normalization. Every code path that
 * reads or writes a matchId (load, add, remove, dedupe) MUST go through this
 * so we can't end up with a value on disk that the in-memory loader rejects.
 * Returns the canonical numeric string or undefined for anything invalid.
 */
function normalizeMatchId(raw: unknown): string | undefined {
  if (typeof raw !== "string") return undefined;
  const trimmed = raw.trim();
  if (!/^\d+$/.test(trimmed)) return undefined;
  return trimmed;
}

/**
 * Compute the stable identity key for an entry.
 *
 * Both branches are NAMESPACED with a fixed prefix so the two key spaces
 * are disjoint — a text fragment exactly equal to "id:123" can never
 * collide with the id-only entry for matchId=123, because the text form
 * becomes "txt:id:123" while the id form is "id:123".
 *
 * - id entries → `id:<matchId>`        (matchId is digits-only by construction)
 * - text entries → `txt:<sorted|fragments>`
 */
function computeSignature(teams: string[], matchId?: string): string {
  const normId = normalizeMatchId(matchId);
  if (normId) return `id:${normId}`;
  const body = teams
    .map((t) => normalize(t))
    .filter((t) => t.length > 0)
    .sort()
    .join("|");
  return `txt:${body}`;
}

let entries: NormalizedEntry[] = [];
let lastLoadedAt: Date | null = null;
let lastError: string | null = null;
let watcher: FSWatcher | null = null;
let reloadTimer: NodeJS.Timeout | null = null;
let watchlistInitialized = false;

export function chooseWatchlistBootstrap(
  stored: unknown[] | null,
  legacy: WatchlistFile | null,
): { matches: WatchlistEntry[] } {
  if (stored !== null) {
    if (!Array.isArray(stored)) throw new Error("Stored watchlist matches are invalid");
    return { matches: stored as WatchlistEntry[] };
  }
  if (legacy !== null && !Array.isArray(legacy.matches)) {
    throw new Error("Existing watchlist matches are invalid");
  }
  return { matches: legacy?.matches ?? [] };
}

export async function readLegacyWatchlistFromPaths(
  paths: readonly string[],
): Promise<{ parsed: WatchlistFile | null; file: string | null }> {
  for (const candidate of paths) {
    try {
      return { parsed: JSON.parse(await fs.readFile(candidate, "utf8")) as WatchlistFile, file: candidate };
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code !== "ENOENT") throw err;
    }
  }
  return { parsed: null, file: null };
}

async function persistMatches(matches: WatchlistEntry[]): Promise<void> {
  await db.insert(manualWatchlistTable)
    .values({ key: "operator", matches })
    .onConflictDoUpdate({
      target: manualWatchlistTable.key,
      set: { matches, updatedAt: new Date() },
    });
}

async function initializeWatchlistStorage(): Promise<void> {
  // DB is authoritative after the first successful import. A missing file in
  // a replacement container must never erase the operator's persisted pins.
  const [stored] = await db.select().from(manualWatchlistTable)
    .where(eq(manualWatchlistTable.key, "operator")).limit(1);
  await fs.mkdir(path.dirname(CONFIG_PATH), { recursive: true });
  let legacy: WatchlistFile | null = null;
  if (!stored) {
    // Historically the server resolved config from process.cwd(). In dev
    // workflows cwd can be the workspace root while the existing operator
    // file lives under artifacts/api-server/config. Prefer the former when
    // present; only probe the latter when the former genuinely does not exist.
    const imported = await readLegacyWatchlistFromPaths([
      CONFIG_PATH,
      path.resolve(process.cwd(), "artifacts/api-server/config/watchlist.json"),
    ]);
    legacy = imported.parsed;
    if (imported.file) logger.info({ path: imported.file }, "Importing existing watchlist into durable storage");
  }
  const parsed = chooseWatchlistBootstrap(stored?.matches ?? null, legacy);
  if (!stored) await persistMatches(parsed.matches);
  await atomicWriteJson(CONFIG_PATH, JSON.stringify(parsed, null, 2) + "\n");
  watchlistInitialized = true;
}

function normalize(s: string): string {
  return s.toLowerCase().trim();
}

async function load(): Promise<void> {
  try {
    const raw = await fs.readFile(CONFIG_PATH, "utf8");
    const parsed = JSON.parse(raw) as WatchlistFile;
    const out: NormalizedEntry[] = [];
    for (const e of parsed.matches ?? []) {
      const teams = Array.isArray(e.teams) ? e.teams : [];
      const matchId = normalizeMatchId(e.matchId);
      const fragments = teams
        .map((t) => (typeof t === "string" ? normalize(t) : ""))
        .filter((t) => t.length > 0);
      // An entry is valid if it has either fragments OR a matchId. id-only
      // entries (e.g. URL-pasted regional matches the user hasn't named yet)
      // are explicitly allowed.
      if (fragments.length === 0 && !matchId) continue;
      const label = (e.label ?? (matchId ? `Match #${matchId}` : fragments.join(" vs "))).trim();
      // Skip the seeded example placeholder so it doesn't accidentally
      // promote unrelated matches when the user hasn't edited the file yet.
      if (label === "example — remove me") continue;
      const league = matchTargetLeague(e.league) ?? undefined;
      // Preserve legacy automated rows on disk for historical recovery, but
      // never admit them into active runtime membership.
      if (e.origin === "excapper-auto") continue;
      const origin: WatchlistOrigin = "manual";
      out.push({
        label,
        fragments,
        matchId,
        league,
        origin,
        signature: computeSignature(teams, matchId),
      });
    }
    entries = out;
    lastLoadedAt = new Date();
    lastError = null;
    logger.info(
      { count: entries.length, path: CONFIG_PATH },
      "Watchlist loaded",
    );
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
    // Don't wipe the previous snapshot on parse error — keep serving the
    // last good config so a typo in the file doesn't blind the scanner.
    logger.error({ err, path: CONFIG_PATH }, "Watchlist load failed — keeping previous entries");
  }
}

/**
 * Returns the matching entry label if the (team1, team2) fixture is on the
 * watchlist, or null otherwise.
 *
 * A single-fragment entry matches when that fragment appears in either team.
 * A multi-fragment entry matches when EVERY fragment appears in at least one
 * of the two teams (so ["Dinamo", "Besiktas"] only fires on Dinamo–Besiktas,
 * not on Dinamo–Anyone).
 */
export function matchesWatchlist(team1: string, team2: string, matchId?: string): string | null {
  if (entries.length === 0) return null;
  const a = normalize(team1);
  const b = normalize(team2);
  const combined = `${a} || ${b}`;
  for (const e of entries) {
    // ID-fast-path: if the user pasted a URL with a numeric id, the scanner
    // promotes that exact matchId regardless of how the team names render.
    if (e.matchId && matchId && e.matchId === matchId) return e.label;
    if (e.fragments.length === 0) continue;
    const allHit = e.fragments.every((f) => combined.includes(f));
    if (allHit) return e.label;
  }
  return null;
}

/** Read-only access to the loaded entries. Used by the scanner so it can
 *  do id-direct lookups when populating the live snapshot. */
export function getNormalizedEntries(): readonly NormalizedEntry[] {
  return entries;
}

/**
 * An exact numeric id pin added by the operator is allowed to remain visible
 * even when its resolved competition is outside the automated target
 * allowlist. This is deliberately narrower than matchesWatchlist(): team
 * fragments and Excapper-originated rows never gain this override.
 */
export function isManualWatchlistId(matchId: string): boolean {
  return entries.some(
    (entry) => entry.origin === "manual" && entry.matchId === matchId,
  );
}

export function getWatchlistSnapshot() {
  // Persisted history is intentionally retained on disk, but non-target and
  // unresolved entries are not active automated scanner output. An explicit
  // manual numeric pin is the one intentional exception: it must remain
  // visible while direct enrichment resolves its teams/league, including when
  // that league is outside the automated target allowlist.
  const visibleEntries = entries.filter(
    (entry) =>
      matchTargetLeague(entry.league) !== null ||
      (entry.origin === "manual" && entry.matchId !== undefined),
  );
  return {
    path: CONFIG_PATH,
    count: visibleEntries.length,
    entries: visibleEntries.map((e) => ({
      label: e.label,
      fragments: e.fragments,
      matchId: e.matchId ?? null,
      league: e.league ?? null,
      origin: e.origin,
      signature: e.signature,
    })),
    lastLoadedAt: lastLoadedAt ? lastLoadedAt.toISOString() : null,
    lastError,
  };
}

export async function initWatchlist(): Promise<void> {
  await initializeWatchlistStorage();
  await load();
  try {
    // Coalesce rapid fs events (editors often emit several "change" events on
    // a single save). Wait 300ms after the last event before reloading.
    watcher = watch(path.dirname(CONFIG_PATH), { persistent: false }, (_event, filename) => {
      if (filename && filename.toString() !== path.basename(CONFIG_PATH)) return;
      if (reloadTimer) clearTimeout(reloadTimer);
      reloadTimer = setTimeout(() => {
        reloadTimer = null;
        // External edits still hot-reload and become durable; malformed edits
        // retain both the last good DB record and the in-memory snapshot.
        void fs.readFile(CONFIG_PATH, "utf8").then(async (raw) => {
          const parsed = JSON.parse(raw) as WatchlistFile;
          if (!Array.isArray(parsed.matches)) throw new Error("Invalid watchlist matches");
          await persistMatches(parsed.matches);
          await load();
        }).catch((err) => {
          lastError = err instanceof Error ? err.message : String(err);
          logger.error({ err }, "Watchlist hot reload failed; retaining previous entries");
        });
      }, 300);
    });
    watcher.on("error", (err) => {
      logger.warn({ err }, "Watchlist fs.watch error — hot reload disabled");
    });
  } catch (err) {
    logger.warn({ err }, "Watchlist fs.watch unavailable — running without hot reload");
  }
}

export function stopWatchlist(): void {
  if (watcher) {
    watcher.close();
    watcher = null;
  }
  if (reloadTimer) {
    clearTimeout(reloadTimer);
    reloadTimer = null;
  }
  watchlistInitialized = false;
}

// ----- Mutation API (used by the dashboard's "Add to Monitor" button) -----

export type ParsedWatchlistInput =
  | { kind: "entry"; label: string; teams: string[]; matchId?: string }
  | { kind: "matchId"; matchId: string }
  | { kind: "error"; error: string };

/**
 * Parses raw user input from the dashboard. Accepts either:
 *  - plain text like "Dinamo vs Besiktas", "Real Madrid - Barcelona", or a
 *    single team name like "Dinamo".
 *  - a NowGoal26 match URL. We try to extract a team slug from the path
 *    ("…/match/dinamo-zagreb-vs-besiktas-12345"); if there's only a numeric
 *    match id we return kind:"matchId" so the caller can resolve it against
 *    the scanner's live meta map.
 */
export function parseWatchlistInput(input: string): ParsedWatchlistInput {
  const trimmed = input.trim();
  if (!trimmed) return { kind: "error", error: "Input is empty" };

  // URL branch
  if (/^https?:\/\//i.test(trimmed)) {
    let u: URL;
    try {
      u = new URL(trimmed);
    } catch {
      return { kind: "error", error: "Invalid URL" };
    }
    // Pattern A: slug like ".../dinamo-zagreb-vs-besiktas..."
    const slug = u.pathname.match(/([a-z0-9]+(?:-[a-z0-9]+)*)-vs-([a-z0-9]+(?:-[a-z0-9]+)*)/i);
    if (slug) {
      const t1 = slug[1].replace(/-/g, " ").trim();
      const t2 = slug[2].replace(/-/g, " ").trim();
      const slugId = u.pathname.match(/(\d{5,})/)?.[1];
      return {
        kind: "entry",
        label: `${t1} vs ${t2}`,
        teams: [t1, t2],
        ...(slugId ? { matchId: slugId } : {}),
      };
    }
    // Pattern B: numeric match id (NowGoal26 IDs are typically 6-8 digits).
    // Caller must resolve it via the scanner's last-seen-meta map.
    const idMatch = u.pathname.match(/(\d{5,})/) ?? u.search.match(/(\d{5,})/);
    if (idMatch) return { kind: "matchId", matchId: idMatch[1] };
    return { kind: "error", error: "URL contained no match id or team slug" };
  }

  // Plain numeric input is also a direct NowGoal match pin. Treating it as a
  // team fragment would lose the canonical id and make regional fixtures
  // impossible to resolve reliably.
  if (/^\d{5,}$/.test(trimmed)) {
    return { kind: "matchId", matchId: trimmed };
  }

  // Plain text branch — split on common fixture separators.
  const parts = trimmed
    .split(/\s+vs\.?\s+|\s+v\s+|\s+-\s+|\s+x\s+|\s+@\s+/i)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
  if (parts.length === 0) return { kind: "error", error: "Could not parse team names" };
  return { kind: "entry", label: trimmed, teams: parts };
}

/**
 * Appends an entry to config/watchlist.json and immediately reloads the
 * in-memory snapshot so the next scanner tick picks it up — we don't wait
 * for the fs.watch debounce (which will also fire, but is idempotent).
 *
 * Dedupes by normalized-fragment signature so clicking "Add" twice on the
 * same fixture is a no-op rather than bloating the file.
 *
 * Returns the resulting snapshot.
 */
const ALLOWED_WATCHLIST_SOURCES = new Set(["manual"]);

export async function addWatchlistEntry(entry: {
  label?: string;
  teams: string[];
  matchId?: string;
  /** Optional resolved league. Missing manual values remain stored but inert
   * until scanner metadata resolves a target league. */
  league?: unknown;
  /** Origin of this add. Defaults to "manual". See guard note above. */
  source?: string;
}): Promise<{
  added: boolean;
  reason?: string;
  existingMatchId?: string;
  snapshot: ReturnType<typeof getWatchlistSnapshot>;
}> {
  const source = entry.source ?? "manual";
  if (!ALLOWED_WATCHLIST_SOURCES.has(source)) {
    logger.error(
      { source, teams: entry.teams, matchId: entry.matchId },
      "Watchlist add refused — only direct manual ingestion is allowed",
    );
    return { added: false, reason: `ingestion source "${source}" is forbidden — only manual additions are supported`, snapshot: getWatchlistSnapshot() };
  }
  const canonicalLeague = entry.league == null ? null : matchTargetLeague(entry.league);
  if (entry.league != null && !canonicalLeague) {
    return {
      added: false,
      reason: "league is missing or not in the target league allowlist",
      snapshot: getWatchlistSnapshot(),
    };
  }
  const cleanTeams = entry.teams
    .map((t) => (typeof t === "string" ? t.trim().slice(0, MAX_TEAM_LEN) : ""))
    .filter((t) => t.length > 0)
    .slice(0, MAX_TEAMS_PER_ENTRY);
  const matchId = normalizeMatchId(entry.matchId);
  if (cleanTeams.length === 0 && !matchId) {
    return { added: false, reason: "no team fragments or matchId", snapshot: getWatchlistSnapshot() };
  }
  const label = (entry.label?.trim() || (matchId ? `Match #${matchId}` : cleanTeams.join(" vs "))).slice(0, 120);
  const signature = computeSignature(cleanTeams, matchId);

  return withMutationLock(async () => {
    // Read current file. If it's missing entirely (ENOENT) we'll treat that
    // as an empty list — that's a legitimate first-write case. But any
    // OTHER error (parse failure, permission, partial truncation) MUST
    // fail closed: silently "starting fresh" would clobber the user's
    // entire watchlist.
    let parsed: WatchlistFile & { _comment?: string };
    try {
      const raw = await fs.readFile(CONFIG_PATH, "utf8");
      parsed = JSON.parse(raw) as typeof parsed;
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (code === "ENOENT") {
        parsed = { matches: [] };
      } else {
        logger.error(
          { err, path: CONFIG_PATH },
          "Watchlist file unreadable on add — refusing to clobber existing data",
        );
        throw new Error(
          "Watchlist file is unreadable or invalid JSON. Refusing to overwrite — fix the file and retry.",
        );
      }
    }
    const matches = Array.isArray(parsed.matches) ? parsed.matches : [];

    const dupe = matches.some((m) => {
      const mTeams = Array.isArray(m.teams) ? m.teams : [];
      const mMatchId = normalizeMatchId(m.matchId);
      return computeSignature(mTeams, mMatchId) === signature;
    });
    if (dupe) {
      // Make sure in-memory reflects what's on disk anyway, then return.
      await load();
      const existing = matches.find((m) => {
        const mTeams = Array.isArray(m.teams) ? m.teams : [];
        const mMatchId = normalizeMatchId(m.matchId);
        return computeSignature(mTeams, mMatchId) === signature;
      });
      return {
        added: false,
        reason: "already in watchlist",
        existingMatchId: normalizeMatchId(existing?.matchId),
        snapshot: getWatchlistSnapshot(),
      };
    }

    const newEntry: WatchlistEntry = {
      label,
      teams: cleanTeams,
      origin: source as WatchlistOrigin,
    };
    if (matchId) newEntry.matchId = matchId;
    if (canonicalLeague) newEntry.league = canonicalLeague;
    matches.push(newEntry);
    const next = { ...parsed, matches };
    if (!watchlistInitialized) throw new Error("Watchlist storage is not initialized");
    await persistMatches(matches);
    await atomicWriteJson(CONFIG_PATH, JSON.stringify(next, null, 2) + "\n");
    // Immediate reload — don't wait for fs.watch debounce.
    await load();
    return { added: true, snapshot: getWatchlistSnapshot() };
  });
}

/**
 * Removes a watchlist entry by its fragment signature (the normalized,
 * sorted, pipe-joined fragments). Returns the new snapshot.
 */
export async function removeWatchlistEntry(signature: string): Promise<{
  removed: boolean;
  snapshot: ReturnType<typeof getWatchlistSnapshot>;
}> {
  return withMutationLock(async () => {
    let parsed: WatchlistFile & { _comment?: string };
    try {
      const raw = await fs.readFile(CONFIG_PATH, "utf8");
      parsed = JSON.parse(raw) as typeof parsed;
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (code === "ENOENT") {
        return { removed: false, snapshot: getWatchlistSnapshot() };
      }
      logger.error(
        { err, path: CONFIG_PATH },
        "Watchlist file unreadable on remove — refusing to clobber existing data",
      );
      throw new Error(
        "Watchlist file is unreadable or invalid JSON. Refusing to overwrite — fix the file and retry.",
      );
    }
    const before = Array.isArray(parsed.matches) ? parsed.matches : [];
    const after = before.filter((m) => {
      const mTeams = Array.isArray(m.teams) ? m.teams : [];
      const mMatchId = normalizeMatchId(m.matchId);
      return computeSignature(mTeams, mMatchId) !== signature;
    });
    if (after.length === before.length) {
      return { removed: false, snapshot: getWatchlistSnapshot() };
    }
    if (!watchlistInitialized) throw new Error("Watchlist storage is not initialized");
    await persistMatches(after);
    await atomicWriteJson(CONFIG_PATH, JSON.stringify({ ...parsed, matches: after }, null, 2) + "\n");
    await load();
    return { removed: true, snapshot: getWatchlistSnapshot() };
  });
}

/**
 * Signature helper exported so the route + UI can refer to the same entry
 * by a stable key (used for the "Remove" button). For id-bearing entries
 * the signature is `id:<matchId>`, which is stable regardless of how the
 * team names render. For text-only entries it's the sorted, normalized
 * fragments joined by `|`.
 */
export function entrySignature(teams: string[], matchId?: string): string {
  return computeSignature(teams, matchId);
}
