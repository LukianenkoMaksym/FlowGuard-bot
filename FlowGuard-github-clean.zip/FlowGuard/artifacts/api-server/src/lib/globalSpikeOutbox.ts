import { pool } from "@workspace/db";
import { getControls } from "./controls";
import { logger } from "./logger";
import {
  sendTelegramOutboxRecipient,
  snapshotTelegramRecipients,
  type TelegramDeliveryRecipient,
} from "./telegram";
import type { ExcapperTransaction } from "./excapper";
import { fixedBetTime } from "./prebetAnalysis";
import { recordExcapperCardDelivered } from "./telegramDiagnostics";

type Recipient = TelegramDeliveryRecipient & { state: "pending" | "acked" | "blocked" };
export type GlobalSpikeBuild = (gameId: string, tx: ExcapperTransaction) =>
  Promise<string | "closed" | null>;
const LOCK_KEY = 1_163_413_319;
const MAX_AGE_SECONDS = 15 * 60;
let schemaReady: Promise<void> | null = null;
let draining = false;

function ensureSchema(): Promise<void> {
  if (schemaReady) return schemaReady;
  schemaReady = pool.query(`
    CREATE TABLE IF NOT EXISTS global_spike_outbox (
      event_key text PRIMARY KEY,
      game_id text NOT NULL,
      transaction jsonb NOT NULL,
      message text,
      recipient_state jsonb,
      completed_at timestamptz,
      created_at timestamptz NOT NULL DEFAULT now(),
      next_attempt_at timestamptz NOT NULL DEFAULT now(),
      attempts integer NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS global_spike_outbox_due_idx
      ON global_spike_outbox (next_attempt_at) WHERE completed_at IS NULL;
  `).then(() => undefined).catch((error: unknown) => {
    schemaReady = null;
    throw error;
  });
  return schemaReady;
}

/** Admission means durable raw evidence, NOT an attempted network send. */
export async function admitGlobalSpike(gameId: string, tx: ExcapperTransaction): Promise<boolean> {
  await ensureSchema();
  const key = `${gameId}:${tx.line}:${tx.side}:${tx.summ}`;
  await pool.query(`
    INSERT INTO global_spike_outbox (event_key, game_id, transaction)
    VALUES ($1, $2, $3::jsonb) ON CONFLICT (event_key) DO NOTHING
  `, [key, gameId, JSON.stringify({ ...tx, betTime: fixedBetTime(tx, Date.now()) })]);
  return true;
}

/** Serialized across processes; each recipient is acked independently. */
export async function drainGlobalSpikeOutbox(build: GlobalSpikeBuild): Promise<void> {
  if (draining || getControls().alertsMuted) return;
  draining = true;
  try {
    await ensureSchema();
    const client = await pool.connect();
    try {
      const lock = await client.query<{ locked: boolean }>(
        "SELECT pg_try_advisory_lock($1) AS locked", [LOCK_KEY],
      );
      if (!lock.rows[0]?.locked) return;
      try {
        await client.query(`
          UPDATE global_spike_outbox SET completed_at = now()
          WHERE completed_at IS NULL
            AND created_at < now() - make_interval(secs => $1)
        `, [MAX_AGE_SECONDS]);
        const due = await client.query<{
          event_key: string; game_id: string; transaction: ExcapperTransaction;
          recipient_state: Recipient[] | null; attempts: number; created_at: Date;
        }>(`
          SELECT event_key, game_id, transaction, recipient_state, attempts, created_at
          FROM global_spike_outbox
          WHERE completed_at IS NULL AND next_attempt_at <= now()
          ORDER BY created_at LIMIT 20
        `);
        for (const row of due.rows) {
          try {
            // Rebuild using a FRESH live directory and detail before every retry.
            // A missing fixture/closed line never uses stale persisted card text.
            const tx = { ...row.transaction,
              betTime: fixedBetTime(row.transaction, new Date(row.created_at).getTime()) };
            const message = await build(row.game_id, tx);
            if (message === "closed") {
              await client.query(
                "UPDATE global_spike_outbox SET completed_at = now() WHERE event_key = $1",
                [row.event_key],
              );
              continue;
            }
            if (!message) throw new Error("Live alert context unavailable");
            let recipients = row.recipient_state;
            if (!recipients) {
              const audience = await snapshotTelegramRecipients();
              if (!audience.ok) throw new Error(`Telegram audience unavailable: ${audience.reason}`);
              recipients = audience.recipients.map((recipient) => ({ ...recipient, state: "pending" }));
              await client.query(`
                UPDATE global_spike_outbox SET message = $2, recipient_state = $3::jsonb
                WHERE event_key = $1
              `, [row.event_key, message, JSON.stringify(recipients)]);
            }
            for (const recipient of recipients) {
              if (recipient.state !== "pending") continue;
              // Recheck against live evidence if a previous send took long enough
              // for the line to close before the next recipient.
              if (getControls().alertsMuted) break;
              const latest = await build(row.game_id, tx);
              if (latest === "closed") {
                await client.query(
                  "UPDATE global_spike_outbox SET completed_at = now() WHERE event_key = $1",
                  [row.event_key],
                );
                break;
              }
              if (!latest) throw new Error("Live context unavailable before recipient send");
              const result = await sendTelegramOutboxRecipient(recipient, latest);
              if (result === "ok") {
                recipient.state = "acked";
                recordExcapperCardDelivered();
              }
              else if (result === "blocked") recipient.state = "blocked";
              await client.query(`
                UPDATE global_spike_outbox SET recipient_state = $2::jsonb
                WHERE event_key = $1
              `, [row.event_key, JSON.stringify(recipients)]);
            }
            if (recipients.every((recipient) => recipient.state !== "pending")) {
              await client.query(
                "UPDATE global_spike_outbox SET completed_at = now() WHERE event_key = $1",
                [row.event_key],
              );
            }
          } catch (error) {
            logger.warn({ error, eventKey: row.event_key }, "[GLOBAL-SPIKE] Outbox delivery deferred");
          }
          await client.query(`
            UPDATE global_spike_outbox
            SET attempts = attempts + 1,
                next_attempt_at = now() + make_interval(secs => $2)
            WHERE event_key = $1 AND completed_at IS NULL
          `, [row.event_key, Math.min(300, 30 * 2 ** Math.min(row.attempts, 4))]);
        }
      } finally {
        await client.query("SELECT pg_advisory_unlock($1)", [LOCK_KEY]);
      }
    } finally {
      client.release();
    }
  } finally {
    draining = false;
  }
}