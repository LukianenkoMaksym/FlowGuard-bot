import { db, radarScoreContextTable } from "@workspace/db";
import { eq } from "drizzle-orm";

export type ScoreContext = {
  home: number;
  away: number;
  observedAt: number;
  goalAt: number | null;
  safeAfter: number;
  revision: number;
};

const WINDOW_MS = 5 * 60_000;

/** One locked, durable score epoch for every observation path. Never fail open. */
export async function observeRadarScore(
  matchId: string, home: number, away: number, sharedGoalAt: number | null,
): Promise<ScoreContext> {
  if (!Number.isInteger(home) || home < 0 || !Number.isInteger(away) || away < 0)
    throw new Error("RADAR score context: invalid score");
  const now = Date.now();
  return db.transaction(async (tx) => {
    // Insert first so concurrent first observers serialize on the same row.
    await tx.insert(radarScoreContextTable).values({
      matchId, homeScore: home, awayScore: away, observedAt: new Date(now),
      goalAt: null, safeAfter: new Date(now + WINDOW_MS), revision: 1,
    }).onConflictDoNothing();
    const [row] = await tx.select().from(radarScoreContextTable)
      .where(eq(radarScoreContextTable.matchId, matchId)).for("update");
    if (!row) throw new Error("RADAR score context: missing locked row");
    const observedAt = row.observedAt?.getTime();
    const safeAfterAt = row.safeAfter?.getTime();
    const goalAt = row.goalAt?.getTime() ?? null;
    if (!Number.isFinite(observedAt) || observedAt! <= 0 || observedAt! > now + 5_000 ||
        !Number.isFinite(safeAfterAt) || safeAfterAt! <= 0 ||
        safeAfterAt! > now + WINDOW_MS + 5_000 ||
        (goalAt != null && (!Number.isFinite(goalAt) || goalAt <= 0 ||
          goalAt > now + 5_000 ||
          safeAfterAt! < goalAt + WINDOW_MS)) ||
        !Number.isInteger(row.homeScore) || row.homeScore < 0 ||
        !Number.isInteger(row.awayScore) || row.awayScore < 0 ||
        !Number.isInteger(row.revision) || row.revision < 1)
      throw new Error("RADAR score context: invalid persisted epoch");
    const changed = row.homeScore !== home || row.awayScore !== away;
    // A persisted score from a previous live interval or extended data outage
    // is not evidence that no goal occurred while this process was offline.
    const stale = now - observedAt! > 10 * 60_000;
    // A scanner marker can be reported after a RADAR heartbeat, although its
    // observation timestamp is older. Merge by the last *goal*, not heartbeat;
    // the same marker is only applied once and never rolls the boundary back.
    const externalGoal = sharedGoalAt != null && Number.isFinite(sharedGoalAt) &&
      sharedGoalAt > 0 && sharedGoalAt <= now &&
      (goalAt == null || sharedGoalAt > goalAt);
    if (changed || externalGoal || stale) {
      const at = changed ? now : externalGoal ? sharedGoalAt! : now;
      const safeAfter = Math.max(safeAfterAt!, (changed || stale ? now : at) + WINDOW_MS);
      const [updated] = await tx.update(radarScoreContextTable).set({
        homeScore: home, awayScore: away, observedAt: new Date(now),
        goalAt: changed || externalGoal ? new Date(at) : row.goalAt,
        safeAfter: new Date(safeAfter),
        revision: row.revision + 1,
      }).where(eq(radarScoreContextTable.matchId, matchId)).returning();
      if (!updated) throw new Error("RADAR score context: update failed");
      return { home, away, observedAt: now, goalAt: updated.goalAt?.getTime() ?? null,
        safeAfter, revision: updated.revision };
    }
    if (now > observedAt!) await tx.update(radarScoreContextTable).set({
      observedAt: new Date(now),
    }).where(eq(radarScoreContextTable.matchId, matchId));
    return {
      home: row.homeScore, away: row.awayScore,
      observedAt: now, goalAt: row.goalAt?.getTime() ?? null,
      safeAfter: safeAfterAt!, revision: row.revision,
    };
  });
}