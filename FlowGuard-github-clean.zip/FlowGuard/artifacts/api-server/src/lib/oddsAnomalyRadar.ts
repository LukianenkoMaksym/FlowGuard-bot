import { randomUUID } from "node:crypto";
import { nowgoalMatchUrl } from "./config";
import { getControls } from "./controls";
import { logger } from "./logger";
import { fetchFreshScoreNow, getOddsRadarFixtureSnapshot } from "./scanner";
import { matchTargetLeague } from "./targetLeagues";
import { isTelegramConfigured, sendTelegram } from "./telegram";
import { formatUnifiedAlert } from "./unifiedAlert";
import { ANOMALY_ODDS_FLOOR, parseMatchMinute, passesValueGuards } from "./winRate";
import { refreshRadarBooks, type BookMarket, type BookMovement } from "./radarBookMarkets";
import { observeRadarScore, type ScoreContext } from "./radarScoreContext";

type Fixture = ReturnType<typeof getOddsRadarFixtureSnapshot>[number];
type Kind = BookMovement["type"];
type BookState = {
  sent: Partial<Record<Kind, number>>;
  previous: number | null;
  previousAt?: number;
  excursion?: { baseline: number; baselineAt: number; peak: number; at: number };
};
type BookCandidate = BookMovement & {
  qualifies: boolean;
  comparisonFirstAt: number;
  comparisonLastAt: number;
};

// Only the dynamic per-match roster may admit bookmaker prices. The scanner's
// primary Bet365 feed is deliberately NOT a fallback: a roster failure does
// not prove that the other bookmakers were quiet.
const bookStates = new Map<string, BookState>();
// Track the active handicap independently of the per-line cooldown keys.
// Returning to an old line must not revive that line's previous excursion.
const activeLines = new Map<string, number | null>();
const marketCooldown = new Map<string, number>();
const bootId = randomUUID();
const scoreEpochs = new Map<string, number>();
// Confirmed markets outlive the 30-minute kind cooldown, permitting repeats.
const deliveredMarkets = new Map<string, Map<string, number>>();
const TICK_MS = 60_000;
const WINDOW_MS = 5 * 60_000;
const REVERT_MS = 10 * 60_000;
const FRESH_MS = 2 * 60_000;
const MAX_MATCHES = 2_000;
let active = false;
let busy = false;
let generation = 0;
let timer: ReturnType<typeof setTimeout> | null = null;
let lastDiagnosticsCheckAt: number | null = null;

function positive(raw: string | undefined, fallback: number): number {
  const value = Number(raw);
  return raw && Number.isFinite(value) && value > 0 ? value : fallback;
}
export function getRadarTelegramDiagnostics() {
  const now = Date.now();
  const cooldown = positive(process.env["RADAR_COOLDOWN_MS"], 30 * 60_000);
  return {
    expectedActive: active,
    lastCompletedAt: lastDiagnosticsCheckAt,
    cooldownSignals: [...marketCooldown.values()].filter((at) => now - at < cooldown).length,
  };
}
function eligibleFixture(row: Pick<Fixture, "meta" | "lastScoreChangeAt">, now: number): boolean {
  const { meta } = row;
  return !!matchTargetLeague(meta.leagueName) &&
    meta.isLive === true && (meta.state == null || meta.state > 0) &&
    Number.isFinite(meta.homeScore) && meta.homeScore >= 0 &&
    Number.isFinite(meta.awayScore) && meta.awayScore >= 0 &&
    Number.isFinite(meta.updatedAt) && meta.updatedAt <= now + 5_000 &&
    now - meta.updatedAt <= FRESH_MS;
}
function eligibleCandidate(row: Fixture, now: number): boolean {
  if (!row.needsVerification) return eligibleFixture(row, now);
  const { meta } = row;
  return !!matchTargetLeague(meta.leagueName) &&
    (meta.state == null || meta.state > 0) && !!meta.team1 && !!meta.team2 &&
    Number.isFinite(meta.updatedAt) && meta.updatedAt <= now + 5_000 &&
    now - meta.updatedAt <= FRESH_MS;
}
async function verifiedFixture(row: Fixture): Promise<Fixture | null> {
  if (!row.needsVerification) return row;
  // Directory identity and an inferred kickoff are not proof of a live match.
  const score = await fetchFreshScoreNow(row.matchId);
  if (!score || score.state == null || score.state <= 0 ||
      !Number.isInteger(score.homeScore) || !Number.isInteger(score.awayScore) ||
      score.homeScore < 0 || score.awayScore < 0) return null;
  return {
    ...row, meta: { ...row.meta, homeScore: score.homeScore, awayScore: score.awayScore,
      isLive: true, state: score.state, clockLabel: score.clockLabel, updatedAt: Date.now() },
    lastScoreChangeAt: row.lastScoreChangeAt,
  };
}
function wasDelivered(id: string, market: string): boolean {
  const previousAt = deliveredMarkets.get(id)?.get(market);
  return previousAt !== undefined && Date.now() - previousAt >=
    positive(process.env["RADAR_COOLDOWN_MS"], 30 * 60_000);
}
function markDelivered(id: string, market: string): void {
  const seen = deliveredMarkets.get(id) ?? new Map<string, number>();
  seen.set(market, Date.now());
  deliveredMarkets.delete(id);
  deliveredMarkets.set(id, seen);
  while (deliveredMarkets.size > MAX_MATCHES) deliveredMarkets.delete(deliveredMarkets.keys().next().value!);
}
function marketIdentity(m: BookMarket): string {
  return m.side === "HOME" || m.side === "AWAY"
    ? `1X2:${m.side}` : `OU:${m.side}:${m.line}`;
}
function bookKey(id: string, m: BookMarket): string {
  return `${id}:${m.cid}:${marketIdentity(m)}`;
}
function resetSegment(state: BookState): void {
  state.previous = null;
  state.previousAt = undefined;
  state.excursion = undefined;
}
function resetMatchSegments(id: string): void {
  for (const [key, state] of bookStates)
    if (key.startsWith(`${id}:`)) resetSegment(state);
}
function traceScore(id: string, context: ScoreContext | null, reason: string,
  firstAt: number | null = null, lastAt: number | null = null): void {
  logger.info({
    matchId: id, bootId, confirmedScore: context && [context.home, context.away],
    goalAt: context?.goalAt ?? null, blackoutEnd: context?.safeAfter ?? null,
    firstAt, lastAt, reason,
  }, "[ODDS-RADAR] score boundary");
}
function bookCandidate(row: Fixture, m: BookMarket, state: BookState, now: number,
  postGoalAt: number): BookCandidate | null {
  const current = m.current;
  // A goal reprices the entire market. The first *new* comparable segment
  // starts only after the goal has left RADAR's five-minute lookback window.
  if (current.ts <= postGoalAt) {
    resetSegment(state);
    return null;
  }
  if (now - m.observedAt > FRESH_MS || now - current.ts > FRESH_MS ||
      current.ts > now + 5_000 || current.odds < ANOMALY_ODDS_FLOOR) {
    resetSegment(state);
    return null;
  }
  if ((m.side === "OVER" || m.side === "UNDER") &&
      (m.line == null || !passesValueGuards({
        decimalOdds: current.odds, targetSide: m.side, line: m.line,
        totalGoals: row.meta.homeScore + row.meta.awayScore, isLive: true,
        minute: parseMatchMinute(row.meta.clockLabel),
      }).ok)) {
    resetSegment(state);
    return null;
  }
  // A different handicap, missing/micro price, or goal blackout interrupts
  // the comparable segment. Do not filter out the interruption and bridge it.
  const recent: typeof m.history = [];
  for (let i = m.history.length - 1; i >= 0; i--) {
    const p = m.history[i]!;
    if (p.line !== m.line ||
         p.ts <= postGoalAt ||
        p.ts < current.ts - WINDOW_MS || p.ts > current.ts ||
        p.odds < ANOMALY_ODDS_FLOOR || p.odds > 20) break;
    recent.unshift(p);
  }
  // An intervening line can be visible in source history even if RADAR never
  // polled it. The old quote must still belong to the current contiguous run.
  if (state.previousAt != null &&
      !recent.some((p) => p.ts === state.previousAt)) resetSegment(state);
  const previous = state.previous;
  state.previous = current.odds;
  state.previousAt = current.ts;
  if (state.excursion &&
      state.excursion.at <= postGoalAt) {
    state.excursion = undefined;
  }
  if (state.excursion && current.ts - state.excursion.at > REVERT_MS) state.excursion = undefined;
  const exc = state.excursion;
  let type: Kind | null = null;
  let qualifies = false;
  let from = 0;
  let baseline: number | undefined;
  let peak: number | undefined;
  let durationMs: number | undefined;
  let comparisonFirstAt: number | null = null;
  if (exc && previous != null && previous !== current.odds &&
      Math.abs(current.odds - exc.baseline) <= 0.03 &&
      Math.abs(exc.peak - exc.baseline) >=
        positive(process.env[exc.peak < exc.baseline ? "RADAR_DROP_THRESHOLD" : "RADAR_RISE_THRESHOLD"], 0.20) &&
      Math.sign(current.odds - previous) === -Math.sign(exc.peak - exc.baseline)) {
    type = "revert";
    qualifies = true;
    from = previous;
    baseline = exc.baseline;
    comparisonFirstAt = exc.baselineAt;
    peak = exc.peak;
    durationMs = current.ts - exc.at;
    state.excursion = undefined;
  } else if (recent.length >= 2 && recent[0]!.ts < current.ts) {
    from = recent[0]!.odds;
    comparisonFirstAt = recent[0]!.ts;
    const delta = current.odds - from;
    if (delta < 0) type = "drop";
    if (delta > 0) type = "rise";
    qualifies = delta <= -positive(process.env["RADAR_DROP_THRESHOLD"], 0.20) ||
      delta >= positive(process.env["RADAR_RISE_THRESHOLD"], 0.20);
    if (qualifies && (!exc || Math.sign(exc.peak - exc.baseline) !== Math.sign(delta))) {
      state.excursion = { baseline: from, baselineAt: recent[0]!.ts,
        peak: current.odds, at: current.ts };
    } else if (qualifies && exc) {
      if (delta < 0 && current.odds < exc.peak) exc.peak = current.odds;
      if (delta > 0 && current.odds > exc.peak) exc.peak = current.odds;
    }
  }
  if (!type || comparisonFirstAt == null || state.sent[type] != null) return null;
  return {
    cid: m.cid, bookmaker: m.bookmaker, type, qualifies, from, to: current.odds,
    percent: (current.odds - from) / from * 100, quoteAt: current.ts,
    comparisonFirstAt, comparisonLastAt: current.ts,
    // Locally collected t=11 observations can prove a move but are not the
    // bookmaker's server-side history shown in the five-point card.
    history: m.timeSource === "observed" ? [] :
      recent.map(({ ts, odds }) => ({ ts, odds })),
    ...(baseline === undefined ? {} : { baseline, peak, durationMs }),
  };
}
async function sendBookSignals(rows: Fixture[], bookMarkets: Map<string, BookMarket[]>,
  epoch: number, signal: AbortSignal): Promise<void> {
  for (const fixture of rows) {
    if (signal.aborted || !active || epoch !== generation) break;
    const found = bookMarkets.get(fixture.matchId);
    if (!found?.length) continue;
    let verified: Fixture | null = fixture;
    try {
      // Scanner and directory candidates enter the same persisted score epoch.
      verified = await verifiedFixture(fixture);
      if (!fixture.needsVerification) {
        const fresh = await fetchFreshScoreNow(fixture.matchId);
        if (!fresh?.isLive || fresh.state == null || fresh.state <= 0 ||
            !Number.isInteger(fresh.homeScore) || !Number.isInteger(fresh.awayScore)) verified = null;
        else verified = { ...fixture, meta: { ...fixture.meta,
          homeScore: fresh.homeScore, awayScore: fresh.awayScore,
          updatedAt: Date.now() } };
      }
    } catch (err) {
      logger.warn({ err, matchId: fixture.matchId }, "[ODDS-RADAR] fixture verification unavailable");
      verified = null;
    }
    if (!verified || !eligibleFixture(verified, Date.now())) {
      resetMatchSegments(fixture.matchId);
      traceScore(fixture.matchId, null, "score_unverified");
      continue;
    }
    let context: ScoreContext;
    try {
      context = await observeRadarScore(fixture.matchId,
        verified.meta.homeScore, verified.meta.awayScore, verified.lastScoreChangeAt);
    } catch (err) {
      resetMatchSegments(fixture.matchId);
      logger.warn({ err, matchId: fixture.matchId, bootId }, "[ODDS-RADAR] durable score context unavailable; fail closed");
      traceScore(fixture.matchId, null, "durable_context_unavailable");
      continue;
    }
    if (scoreEpochs.get(fixture.matchId) !== context.revision) {
      resetMatchSegments(fixture.matchId);
      scoreEpochs.set(fixture.matchId, context.revision);
    }
    if (context.home !== fixture.meta.homeScore || context.away !== fixture.meta.awayScore ||
        Date.now() <= context.safeAfter) {
      resetMatchSegments(fixture.matchId);
      const times = found.flatMap((m) => m.history.map((p) => p.ts));
      traceScore(fixture.matchId, context, "blackout_or_score_change",
        times.length ? Math.min(...times) : null, times.length ? Math.max(...times) : null);
      continue;
    }
    const groups = new Map<string, { market: BookMarket; movements: BookCandidate[] }>();
    for (const m of found) {
      const key = bookKey(fixture.matchId, m);
      const state = bookStates.get(key) ?? { previous: null, sent: {} };
      bookStates.set(key, state);
      const sideKey = `${fixture.matchId}:${m.cid}:${m.side}`;
      if (activeLines.has(sideKey) && activeLines.get(sideKey) !== m.line) resetSegment(state);
      activeLines.set(sideKey, m.line);
      for (const kind of ["drop", "rise", "revert"] as const) {
        if (state.sent[kind] != null && Date.now() - state.sent[kind]! >=
            positive(process.env["RADAR_COOLDOWN_MS"], 30 * 60_000)) delete state.sent[kind];
      }
      const movement = bookCandidate(verified, m, state, Date.now(), context.safeAfter);
      if (!movement) {
        if (m.current.ts <= context.safeAfter ||
            m.history.some((p) => p.ts <= context.safeAfter)) {
          traceScore(fixture.matchId, context,
            m.current.ts <= context.safeAfter ? "quote_before_safe_boundary" : "history_before_safe_boundary",
            m.history[0]?.ts ?? m.current.ts, m.current.ts);
        }
        continue;
      }
      const market = marketIdentity(m);
      const group = groups.get(market) ?? { market: m, movements: [] };
      group.movements.push(movement);
      groups.set(market, group);
    }
    // Same authoritative live-score guard used by the classic scanner before
    // delivery: a goal may arrive while RADAR is fetching bookmaker histories.
    // No Telegram attempt (and hence no pending delivery) on an unverified score.
    if ([...groups.values()].some((group) => group.movements.some((m) => m.qualifies))) {
      const candidateTimes = [...groups.values()].flatMap((group) =>
        group.movements.flatMap((movement) =>
          [movement.comparisonFirstAt, movement.comparisonLastAt]));
      const firstAt = Math.min(...candidateTimes);
      const lastAt = Math.max(...candidateTimes);
      let fresh: Awaited<ReturnType<typeof fetchFreshScoreNow>> = null;
      try { fresh = await fetchFreshScoreNow(fixture.matchId); }
      catch (err) {
        logger.warn({ err, matchId: fixture.matchId }, "[ODDS-RADAR] live score verification unavailable");
      }
      if (!fresh || !fresh.isLive || fresh.state == null || fresh.state <= 0) {
        traceScore(fixture.matchId, context, "preflight_unverified", firstAt, lastAt);
        continue;
      }
      try {
        const preflight = await observeRadarScore(fixture.matchId,
          fresh.homeScore, fresh.awayScore, verified.lastScoreChangeAt);
        if (preflight.revision !== context.revision ||
            preflight.home !== context.home || preflight.away !== context.away ||
            preflight.safeAfter !== context.safeAfter ||
            Date.now() <= preflight.safeAfter) {
          resetMatchSegments(fixture.matchId);
          scoreEpochs.set(fixture.matchId, preflight.revision);
          traceScore(fixture.matchId, preflight, "preflight_score_epoch_changed", firstAt, lastAt);
          continue;
        }
      } catch (err) {
        resetMatchSegments(fixture.matchId);
        logger.warn({ err, matchId: fixture.matchId, bootId }, "[ODDS-RADAR] preflight context unavailable; fail closed");
        continue;
      }
    }
    for (const [market, group] of groups) {
      if (signal.aborted || !active || epoch !== generation || getControls().alertsMuted) break;
      const latest = getOddsRadarFixtureSnapshot().find((r) => r.matchId === fixture.matchId);
      let current = latest ?? null;
      if (current?.needsVerification) {
        try { current = await verifiedFixture(current); } catch { current = null; }
      }
      if (!current || !eligibleFixture(current, Date.now()) ||
          current.meta.homeScore !== verified.meta.homeScore ||
          current.meta.awayScore !== verified.meta.awayScore) {
        // A goal observed by the scanner while this cycle was fetching odds
        // must advance the durable epoch even though this card is discarded.
        if (current && (current.meta.homeScore !== verified.meta.homeScore ||
            current.meta.awayScore !== verified.meta.awayScore)) {
          try {
            const fresh = await fetchFreshScoreNow(fixture.matchId);
            if (fresh?.isLive && fresh.state != null && fresh.state > 0) {
              const changed = await observeRadarScore(fixture.matchId,
                fresh.homeScore, fresh.awayScore, current.lastScoreChangeAt);
              scoreEpochs.set(fixture.matchId, changed.revision);
            }
          } catch (err) {
            logger.warn({ err, matchId: fixture.matchId, bootId },
              "[ODDS-RADAR] snapshot score reconciliation unavailable");
          }
          resetMatchSegments(fixture.matchId);
        }
        traceScore(fixture.matchId, context, "snapshot_score_changed");
        continue;
      }
      const movements = group.movements.filter((movement) =>
        Date.now() - movement.quoteAt <= FRESH_MS &&
        movement.quoteAt > context.safeAfter &&
        (movement.history.length === 0 || movement.history[0]!.ts > context.safeAfter));
      if (!movements.some((movement) => movement.qualifies)) continue;
      movements.sort((a, b) =>
        Math.abs(b.peak === undefined ? b.to - b.from : b.peak - b.baseline!) -
        Math.abs(a.peak === undefined ? a.to - a.from : a.peak - a.baseline!) ||
        Number(a.cid) - Number(b.cid));
      const strongest = movements[0]!;
      const cooldownKey = `${fixture.matchId}:${market}:${strongest.type}`;
      const lastSent = marketCooldown.get(cooldownKey);
      if (lastSent != null && Date.now() - lastSent <
          positive(process.env["RADAR_COOLDOWN_MS"], 30 * 60_000)) continue;
      const m = group.market;
      const message = formatUnifiedAlert({
        source: "odds-radar",
        market: m.side === "HOME" || m.side === "AWAY"
          ? { kind: "1X2", outcome: m.side } : undefined,
        radarMovement: { type: strongest.type, from: strongest.from,
          to: strongest.to, percent: Math.abs(strongest.percent) },
        radarBooks: movements,
        matchId: fixture.matchId, league: current.meta.leagueName,
        home: current.meta.team1, away: current.meta.team2,
        homeScore: current.meta.homeScore, awayScore: current.meta.awayScore,
        minute: current.meta.clockLabel ?? null, isLive: true,
        side: m.side === "HOME" || m.side === "AWAY" ? "OVER" : m.side,
        line: m.line ?? 0, bookmaker: strongest.bookmaker,
        alertAt: Date.now(), quoteAt: strongest.quoteAt,
        timeline: m.side === "OVER" || m.side === "UNDER"
          ? strongest.history.map(({ ts, odds }) => ({ ts, odds, line: m.line! })) : [],
        oneX2Timeline: m.side === "HOME" || m.side === "AWAY" ? strongest.history : [],
        isRepeat: wasDelivered(fixture.matchId, market),
        link: nowgoalMatchUrl(fixture.matchId),
      });
      try {
        // One final authoritative observation per market, immediately before
        // delivery. Even a mismatch is persisted before this send is rejected.
        const beforeSend = await fetchFreshScoreNow(fixture.matchId);
        if (!beforeSend?.isLive || beforeSend.state == null || beforeSend.state <= 0) {
          traceScore(fixture.matchId, context, "dispatch_score_unverified");
          continue;
        }
        const finalContext = await observeRadarScore(fixture.matchId,
          beforeSend.homeScore, beforeSend.awayScore, current.lastScoreChangeAt);
        if (finalContext.revision !== context.revision ||
            finalContext.home !== context.home || finalContext.away !== context.away ||
            finalContext.safeAfter !== context.safeAfter ||
            Date.now() <= finalContext.safeAfter) {
          resetMatchSegments(fixture.matchId);
          scoreEpochs.set(fixture.matchId, finalContext.revision);
          traceScore(fixture.matchId, finalContext, "dispatch_score_epoch_changed",
            strongest.comparisonFirstAt, strongest.comparisonLastAt);
          continue;
        }
        traceScore(fixture.matchId, context, "admit",
          strongest.comparisonFirstAt, strongest.comparisonLastAt);
        const result = await sendTelegram(message);
        if (result.primaryDelivered && active && epoch === generation) {
          marketCooldown.set(cooldownKey, Date.now());
          for (const movement of movements) {
            const state = bookStates.get(`${fixture.matchId}:${movement.cid}:${market}`);
            if (state) state.sent[movement.type] = Date.now();
          }
          markDelivered(fixture.matchId, market);
        }
      } catch (err) {
        resetMatchSegments(fixture.matchId);
        logger.warn({ err, matchId: fixture.matchId, market }, "[ODDS-RADAR] bookmaker delivery/context retryable");
      }
    }
  }
  while (bookStates.size > MAX_MATCHES * 12) bookStates.delete(bookStates.keys().next().value!);
  while (activeLines.size > MAX_MATCHES * 12) activeLines.delete(activeLines.keys().next().value!);
  while (scoreEpochs.size > MAX_MATCHES) scoreEpochs.delete(scoreEpochs.keys().next().value!);
  while (marketCooldown.size > MAX_MATCHES * 12) marketCooldown.delete(marketCooldown.keys().next().value!);
}

export async function runOddsAnomalyRadarCycle(): Promise<void> {
  if (active && !busy && (!isTelegramConfigured() || getControls().alertsMuted)) lastDiagnosticsCheckAt = Date.now();
  if (!active || busy || !isTelegramConfigured() || getControls().alertsMuted) return;
  busy = true;
  const epoch = generation;
  try {
    const fixtures = getOddsRadarFixtureSnapshot();
    const eligible = fixtures.filter((row) => eligibleCandidate(row, Date.now()));
    const controller = new AbortController();
    const budget = setTimeout(() => controller.abort(), 20_000);
    budget.unref?.();
    try {
      const markets = await refreshRadarBooks(eligible.map((row) => row.matchId), controller.signal);
      if (active && epoch === generation && !controller.signal.aborted) {
        await sendBookSignals(eligible, markets, epoch, controller.signal);
      }
    } catch (err) {
      logger.warn({ err }, "[ODDS-RADAR] dynamic bookmaker evidence unavailable");
    } finally {
      clearTimeout(budget);
      controller.abort();
    }
    // A failed roster or quote request is NOT a Bet365-only signal.
  } finally {
    lastDiagnosticsCheckAt = Date.now();
    busy = false;
  }
}
export function startOddsAnomalyRadar(): void {
  if (active || !isTelegramConfigured()) return;
  active = true;
  generation++;
  const epoch = generation;
  const schedule = () => {
    if (!active || epoch !== generation) return;
    timer = setTimeout(() => {
      void runOddsAnomalyRadarCycle()
        .catch((err: unknown) => logger.warn({ err }, "[ODDS-RADAR] Cycle failed"))
        .finally(schedule);
    }, TICK_MS);
    timer.unref?.();
  };
  schedule();
}
export function stopOddsAnomalyRadar(): void {
  active = false;
  generation++;
  if (timer) clearTimeout(timer);
  timer = null;
  bookStates.clear();
  activeLines.clear();
  marketCooldown.clear();
  scoreEpochs.clear();
  deliveredMarkets.clear();
}