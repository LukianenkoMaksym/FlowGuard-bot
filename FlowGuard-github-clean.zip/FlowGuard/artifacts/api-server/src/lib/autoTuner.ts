import { and, eq, inArray } from "drizzle-orm";
import { anomaliesTable, db } from "@workspace/db";
import { getScannerConfig } from "./scanner";
import { getScannerStorageError, getTunerMetadata, transactAutoTuner } from "./scannerConfig";
import { selectTunerSample, tunerDecision, TUNER_DAY_MS, type TunerMetadata } from "./autoTunerRules";
import { logger } from "./logger";

let sampleSize = 0;
let winRatePct: number | null = null;
let evaluationError: string | null = null;
let query: Promise<void> | null = null;
let evaluation: Promise<void> | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;
let generation = 0;

function refreshSample(): Promise<void> {
  if (query) return query;
  query = (async () => {
    // Do not limit in SQL: allowlist, fixtures and legacy duplicates must be
    // removed before selecting the rolling settled window. Both sides count.
    const rows = await db.select().from(anomaliesTable).where(and(
      eq(anomaliesTable.anomalyType, "ODDS_DROP"),
      inArray(anomaliesTable.status, ["WIN", "LOSS"]),
    ));
    const sample = selectTunerSample(rows, Date.now());
    sampleSize = sample.length;
    winRatePct = sampleSize ? sample.filter((r) => r.status === "WIN").length / sampleSize * 100 : null;
  })().finally(() => { query = null; });
  return query;
}

function clocks(metadata: TunerMetadata) {
  return {
    pause: metadata.pausedUntil ? Date.parse(metadata.pausedUntil) : 0,
    cooldown: metadata.lastAdjustment ? Date.parse(metadata.lastAdjustment.at) + TUNER_DAY_MS : 0,
  };
}

export function autoTunerSnapshot() {
  const metadata = getTunerMetadata();
  const now = Date.now();
  const { pause, cooldown } = clocks(metadata);
  const dropThreshold = getScannerConfig().dropThreshold;
  const decision = tunerDecision(dropThreshold, sampleSize, winRatePct);
  const error = evaluationError ?? getScannerStorageError();
  const state = error ? "error" : !metadata.enabled ? "off" : pause > now ? "paused" :
    cooldown > now ? "cooldown" : sampleSize < 40 ? "collecting" : decision.next === dropThreshold ? "holding" : "ready";
  return {
    ...metadata, state, sampleSize, minSamples: 40 as const, winRatePct,
    nextAdjustmentAt: Math.max(pause, cooldown) > now ? new Date(Math.max(pause, cooldown)).toISOString() : null,
    dropThreshold,
    ...(error ? { error } : state === "holding" && decision.reason ? { error: decision.reason } : {}),
  };
}

/** Read-only with respect to configuration, clocks and adjustments. */
export async function getAutoTunerStatus() {
  try {
    await refreshSample();
    evaluationError = null;
  } catch (err) {
    evaluationError = "Auto-tuner training data unavailable; no automatic changes will be applied.";
    logger.error({ err }, "[AUTO-TUNER] dataset read failed");
  }
  return autoTunerSnapshot();
}

export async function setAutoTunerEnabled(enabled: boolean) {
  const result = await transactAutoTuner((_config, metadata) => ({
    metadata: { ...metadata, enabled },
  }));
  if (result.error) evaluationError = result.error;
  else evaluationError = null;
  return { ...autoTunerSnapshot(), ...result };
}

/** Singleflight and rechecked after the query, inside the manual config queue. */
export function evaluateAutoTuner(isCurrent: () => boolean = () => true): Promise<void> {
  if (evaluation) return evaluation;
  evaluation = (async () => {
    if (!getTunerMetadata().enabled || !isCurrent()) return;
    try {
      await refreshSample();
      if (!isCurrent()) return;
      const result = await transactAutoTuner((config, metadata) => {
        const now = Date.now();
        const { pause, cooldown } = clocks(metadata);
        if (!isCurrent() || !metadata.enabled || now < pause || now < cooldown) return null;
        const decision = tunerDecision(config.dropThreshold, sampleSize, winRatePct);
        if (decision.next === config.dropThreshold) return null;
        return {
          dropThreshold: decision.next,
          metadata: {
            ...metadata,
            lastAdjustment: {
              at: new Date(now).toISOString(), oldThreshold: config.dropThreshold,
              newThreshold: decision.next, winRatePct: winRatePct!, sampleSize,
            },
          },
        };
      });
      evaluationError = result.error ?? null;
      if (result.persisted) logger.info(getTunerMetadata().lastAdjustment, "[AUTO-TUNER] dropThreshold adjusted");
      if (result.error) logger.error({ error: result.error }, "[AUTO-TUNER] adjustment rejected");
    } catch (err) {
      evaluationError = "Auto-tuner evaluation failed; no automatic changes were applied.";
      logger.error({ err }, "[AUTO-TUNER] evaluation failed");
    }
  })().finally(() => { evaluation = null; });
  return evaluation;
}

export function stopAutoTuner() {
  generation++;
  if (timer) clearTimeout(timer);
  timer = null;
}

/** Completion-anchored: no overlapping runs and no startup adjustment. */
export function startAutoTuner() {
  stopAutoTuner();
  const token = generation;
  const schedule = () => {
    timer = setTimeout(async () => {
      if (token !== generation) return;
      await evaluateAutoTuner(() => token === generation);
      if (token === generation) schedule();
    }, 60_000);
    timer.unref();
  };
  schedule();
}