import {
  closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync,
  renameSync, unlinkSync, writeFileSync,
} from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import type { BindingDecision } from "./bindingDecisionAudit";

export interface PendingBindingDecision {
  matchId: string;
  decision: BindingDecision;
}

/**
 * Local write-ahead outbox: same sibling-temp + fsync + rename convention as
 * watchlist persistence, but synchronous so no state mutation can race the
 * durable write. Ordinary restarts replay IDs; container filesystem replacement
 * can still lose entries not yet copied to PostgreSQL.
 */
export class BindingDecisionOutbox {
  private pending = new Map<string, PendingBindingDecision>();
  private loaded = false;

  constructor(readonly filePath: string) {}

  load(): void {
    if (this.loaded) return;
    if (existsSync(this.filePath)) {
      const data = JSON.parse(readFileSync(this.filePath, "utf8"));
      if (data.version !== 1 || !Array.isArray(data.entries)) {
        throw new Error("Binding decision outbox format is invalid");
      }
      for (const entry of data.entries) {
        if (typeof entry?.matchId !== "string" || typeof entry?.decision?.id !== "string" ||
            !["bind", "reset"].includes(entry.decision.action) ||
            !["automatic", "manual", "manual_override"].includes(entry.decision.mode) ||
            !entry.decision.target || !entry.decision.source ||
            typeof entry.decision.reason !== "string" ||
            !Number.isFinite(Date.parse(entry.decision.occurredAt))) {
          throw new Error("Binding decision outbox entry is invalid");
        }
        this.pending.set(entry.decision.id, entry);
      }
    }
    this.loaded = true;
  }

  entries(): PendingBindingDecision[] {
    this.load();
    return [...this.pending.values()];
  }

  append(entries: PendingBindingDecision[]): void {
    this.load();
    const next = new Map(this.pending);
    for (const entry of entries) {
      if (!next.has(entry.decision.id)) next.set(entry.decision.id, entry);
    }
    this.save(next);
    this.pending = next;
  }

  acknowledge(id: string): void {
    this.load();
    const next = new Map(this.pending);
    next.delete(id);
    this.save(next);
    this.pending = next;
  }

  private save(entries: Map<string, PendingBindingDecision>): void {
    const directory = path.dirname(this.filePath);
    mkdirSync(directory, { recursive: true });
    const temporary = `${this.filePath}.${randomUUID()}.tmp`;
    try {
      const fd = openSync(temporary, "wx", 0o600);
      try {
        writeFileSync(fd, JSON.stringify({ version: 1, entries: [...entries.values()] }), "utf8");
        fsyncSync(fd);
      } finally {
        closeSync(fd);
      }
      renameSync(temporary, this.filePath);
      const dir = openSync(directory, "r");
      try { fsyncSync(dir); } finally { closeSync(dir); }
    } finally {
      if (existsSync(temporary)) unlinkSync(temporary);
    }
  }
}