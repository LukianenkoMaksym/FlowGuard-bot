import { bindingDecisionsTable, db, manualActiveBindingsTable, manualBindingBlocksTable } from "@workspace/db";
import { and, eq, sql } from "drizzle-orm";
import type { PendingBindingDecision } from "./bindingDecisionOutbox";

export async function initManualBindingBlocks(): Promise<Array<{
  diagnosticId: string;
  gameId: string;
}>> {
  return db.select({
    diagnosticId: manualBindingBlocksTable.diagnosticId,
    gameId: manualBindingBlocksTable.gameId,
  }).from(manualBindingBlocksTable);
}

export async function persistManualBindingBlock(
  diagnosticId: string,
  gameId: string,
): Promise<void> {
  await db.insert(manualBindingBlocksTable).values({ diagnosticId, gameId })
    .onConflictDoNothing();
}

export async function removeManualBindingBlock(
  diagnosticId: string,
  gameId: string,
): Promise<void> {
  await db.delete(manualBindingBlocksTable).where(and(
    eq(manualBindingBlocksTable.diagnosticId, diagnosticId),
    eq(manualBindingBlocksTable.gameId, gameId),
  ));
}

/**
 * Reset already requires PostgreSQL for its safety block. Commit its audit in
 * that same transaction rather than coordinating a database block with a
 * separately fallible local outbox. Neither can survive without the other.
 * Existing blocks are preserved and do not create repeated reset history.
 */
export async function persistManualBindingReset(
  pairs: Array<{ diagnosticId: string; gameId: string }>,
  decisions: PendingBindingDecision[],
  activeMatchId?: string,
): Promise<void> {
  await db.transaction(async (tx) => {
    const matchIds = new Set(pairs.map((pair) => pair.diagnosticId));
    if (activeMatchId) matchIds.add(activeMatchId);
    for (const id of [...matchIds].sort()) {
      await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${id}, 53))`);
    }
    for (const matchId of activeMatchId ? [activeMatchId] : [...matchIds]) {
      await tx.delete(manualActiveBindingsTable).where(eq(manualActiveBindingsTable.nowgoalId, matchId));
    }
    for (const pair of pairs) {
      const inserted = await tx.insert(manualBindingBlocksTable).values(pair)
        .onConflictDoNothing().returning({ gameId: manualBindingBlocksTable.gameId });
      if (!inserted.length) continue;
      const entry = decisions.find((item) =>
        item.matchId === pair.diagnosticId &&
        item.decision.source.id === (pair.gameId === "*" ? null : pair.gameId));
      if (!entry) throw new Error("Reset audit evidence is missing; no reset was saved");
      await tx.insert(bindingDecisionsTable).values({
        ...entry.decision, matchId: entry.matchId,
        occurredAt: new Date(entry.decision.occurredAt),
      }).onConflictDoNothing({ target: bindingDecisionsTable.id });
    }
  });
}