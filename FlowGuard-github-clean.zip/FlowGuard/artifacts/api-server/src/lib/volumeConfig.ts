/**
 * Volume scanner runtime config (hot-reloadable from dashboard).
 *
 * Three knobs, all changeable live without a restart:
 *  - minSingleSpikeEur  → minimum native-feed EUR delta on one side
 *  - minCumulativeEur   → minimum native-feed EUR running total. It never
 *                         excludes approved fixtures from Excapper ingestion
 *                         or master membership.
 *  - linesToTrack     [] → if empty, all OU lines (0.5...6.5); else only
 *                          the listed integer-.5 lines (e.g. [2.5, 3.5])
 *
 * Persistence: JSON file at config/volumeConfig.json, atomically replaced
 * on every update. Loaded once at boot; in-memory state IS the source of
 * truth thereafter. Routes mutate via updateConfig() which patches +
 * persists + returns the new snapshot.
 *
 * The global Excapper worker calls getConfig() on EVERY tick so dashboard
 * edits take effect on the very next cycle — no server restart required.
 */
import { promises as fs } from "node:fs";
import path from "node:path";
import { logger } from "./logger";

const CONFIG_PATH = path.resolve(process.cwd(), "config/volumeConfig.json");

export interface VolumeConfig {
  /** Minimum single-window native-feed EUR inflow on one side. */
  minSingleSpikeEur: number;
  /** Minimum running native-feed EUR traded on a line for qualification.
   *  Not an ingestion/membership filter. */
  minCumulativeEur: number;
  /**
   * Whitelist of OU lines (e.g. [1.5, 2.5, 3.5, 4.5]). Empty = all lines.
   * Only integer-.5 values are kept (0.5...6.5).
   */
  linesToTrack: number[];
}

const DEFAULTS: VolumeConfig = {
  minSingleSpikeEur: 500,
  minCumulativeEur: 2_000,
  linesToTrack: [],
};

const VALID_LINES = [0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5];

let current: VolumeConfig = { ...DEFAULTS };
let loaded = false;

/** Clamp + dedupe + drop-invalid; never throws — coerces to a safe shape. */
type PersistedVolumeConfig = Partial<VolumeConfig> & {
  /** @deprecated Pre-EUR field name. The numeric value was already native EUR. */
  minSingleSpikeUsd?: number;
  /** @deprecated Pre-EUR field name. The numeric value was already native EUR. */
  minCumulativeUsd?: number;
};

function sanitize(input: PersistedVolumeConfig): VolumeConfig {
  // Legacy "Usd" names were labels only: migrate the exact numeric values with
  // no FX arithmetic. Canonical EUR fields win if both names are present.
  const singleInput = input.minSingleSpikeEur ?? input.minSingleSpikeUsd;
  const cumulativeInput = input.minCumulativeEur ?? input.minCumulativeUsd;
  const minSingleSpikeEur =
    typeof singleInput === "number" && isFinite(singleInput)
      ? Math.max(500, singleInput)
      : DEFAULTS.minSingleSpikeEur;
  const minCumulativeEur =
    typeof cumulativeInput === "number" && isFinite(cumulativeInput)
      ? Math.max(2_000, cumulativeInput)
      : DEFAULTS.minCumulativeEur;
  const rawLines = Array.isArray(input.linesToTrack) ? input.linesToTrack : [];
  const linesToTrack = Array.from(
    new Set(
      rawLines
        .map((x) => (typeof x === "number" ? x : parseFloat(String(x))))
        .filter((n) => isFinite(n) && VALID_LINES.includes(n)),
    ),
  ).sort((a, b) => a - b);
  return { minSingleSpikeEur, minCumulativeEur, linesToTrack };
}

export const __testOnlyMigrateVolumeConfig = sanitize;

/** Atomic write — same pattern as watchlist.ts, never half-written. */
async function atomicWriteJson(filePath: string, payload: string): Promise<void> {
  const dir = path.dirname(filePath);
  const tmp = path.join(dir, `.${path.basename(filePath)}.tmp-${process.pid}-${Date.now()}`);
  await fs.mkdir(dir, { recursive: true });
  const fh = await fs.open(tmp, "w");
  try {
    await fh.writeFile(payload, "utf8");
    await fh.sync();
  } finally {
    await fh.close();
  }
  await fs.rename(tmp, filePath);
}

export async function initVolumeConfig(): Promise<void> {
  try {
    const raw = await fs.readFile(CONFIG_PATH, "utf8");
    const parsed = JSON.parse(raw) as PersistedVolumeConfig;
    current = sanitize(parsed);
    loaded = true;
    if (
      !("minSingleSpikeEur" in parsed) ||
      !("minCumulativeEur" in parsed) ||
      "minSingleSpikeUsd" in parsed ||
      "minCumulativeUsd" in parsed
    ) {
      try {
        await atomicWriteJson(CONFIG_PATH, JSON.stringify(current, null, 2) + "\n");
      } catch (writeErr) {
        // A migration write failure must not discard the successfully loaded
        // in-memory values. The next successful update will persist EUR names.
        logger.warn({ err: writeErr, path: CONFIG_PATH }, "Could not persist EUR config migration");
      }
    }
    logger.info({ config: current, path: CONFIG_PATH }, "Volume config loaded");
  } catch (err) {
    const code = (err as NodeJS.ErrnoException).code;
    if (code === "ENOENT") {
      current = { ...DEFAULTS };
      loaded = true;
      logger.info({ config: current, path: CONFIG_PATH }, "Volume config: no file yet, using defaults");
      // Write defaults so the file exists for next boot. Best-effort.
      void atomicWriteJson(CONFIG_PATH, JSON.stringify(current, null, 2) + "\n").catch(
        (writeErr) => logger.warn({ err: writeErr }, "Could not seed volume config file"),
      );
    } else {
      logger.error({ err, path: CONFIG_PATH }, "Volume config load failed — using defaults");
      current = { ...DEFAULTS };
      loaded = true;
    }
  }
}

/**
 * Hot-path getter — called every Excapper global tick. Returns a frozen
 * snapshot so the worker can't accidentally mutate config mid-cycle.
 */
export function getVolumeConfig(): Readonly<VolumeConfig> {
  if (!loaded) return { ...DEFAULTS };
  return current;
}

/**
 * Patch + persist. Unknown fields ignored; invalid values silently snap to
 * defaults or get dropped (linesToTrack). Returns the new snapshot.
 *
 * Safe to call concurrently from multiple POSTs — we replace `current`
 * with a fresh object atomically, then await the disk write. Even if the
 * write fails, in-memory remains the new value (intentional: dashboard
 * tuning should never silently revert).
 */
export async function updateVolumeConfig(
  patch: Partial<VolumeConfig>,
): Promise<VolumeConfig> {
  const next = sanitize({ ...current, ...patch });
  current = next;
  try {
    await atomicWriteJson(CONFIG_PATH, JSON.stringify(next, null, 2) + "\n");
  } catch (err) {
    logger.error(
      { err, path: CONFIG_PATH },
      "Volume config: in-memory updated but disk write failed (will retry on next change)",
    );
  }
  return next;
}
