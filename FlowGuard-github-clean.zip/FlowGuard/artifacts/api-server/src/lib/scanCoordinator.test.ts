import { afterEach, describe, expect, it, vi } from "vitest";
import {
  ACTIVE_SCAN_CADENCE_MS,
  DISCOVERY_SCAN_CADENCE_MS,
  SequentialScanCoordinator,
  runCoordinatorDiscoveryCycle,
} from "./scanCoordinator";
import { selectLiveVerificationIds } from "./liveVerification";

async function flush(): Promise<void> {
  await Promise.resolve();
  await Promise.resolve();
}

describe("SequentialScanCoordinator", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("has one owner, does not overlap, and preserves active/discovery order", async () => {
    vi.useFakeTimers();
    let release: (() => void) | undefined;
    let concurrent = 0;
    let maxConcurrent = 0;
    const calls: string[] = [];
    const active = vi.fn(async () => {
      calls.push("active");
      concurrent++;
      maxConcurrent = Math.max(maxConcurrent, concurrent);
      await new Promise<void>((resolve) => { release = resolve; });
      concurrent--;
    });
    const discovery = vi.fn(async () => { calls.push("discovery"); });
    const engine = new SequentialScanCoordinator({ active, discovery });

    expect(engine.snapshot()).toMatchObject({
      activeCadenceMs: 12_000,
      discoveryCadenceMs: 60_000,
    });
    expect(ACTIVE_SCAN_CADENCE_MS).toBe(12_000);
    expect(DISCOVERY_SCAN_CADENCE_MS).toBe(60_000);

    expect(engine.start()).toBe(true);
    expect(engine.start()).toBe(false);
    await vi.advanceTimersByTimeAsync(0);
    engine.requestRun();
    await vi.advanceTimersByTimeAsync(120_000);
    expect(active).toHaveBeenCalledTimes(1);
    expect(maxConcurrent).toBe(1);

    release?.();
    await flush();
    expect(calls).toEqual(["active", "discovery"]);
    expect(engine.snapshot().cyclesCompleted).toBe(1);
    await vi.advanceTimersByTimeAsync(11_999);
    expect(active).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(1);
    expect(active).toHaveBeenCalledTimes(2);
    expect(maxConcurrent).toBe(1);
    engine.stop();
  });

  it("anchors cadence after completion and stop cancels future cycles", async () => {
    vi.useFakeTimers();
    const active = vi.fn(async () => {});
    const discovery = vi.fn(async () => {});
    const engine = new SequentialScanCoordinator({ active, discovery });

    engine.start();
    await vi.advanceTimersByTimeAsync(0);
    expect(active).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(11_999);
    expect(active).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(1);
    expect(active).toHaveBeenCalledTimes(2);

    expect(engine.stop()).toBe(true);
    expect(engine.stop()).toBe(false);
    await vi.advanceTimersByTimeAsync(120_000);
    expect(active).toHaveBeenCalledTimes(2);
    expect(engine.snapshot()).toMatchObject({ running: false, inFlight: false, nextActiveAt: null });
  });

  it("runs discovery no more often than its minimum cadence", async () => {
    vi.useFakeTimers();
    const active = vi.fn(async () => {});
    const discovery = vi.fn(async () => {});
    const engine = new SequentialScanCoordinator({ active, discovery });
    engine.start();

    await vi.advanceTimersByTimeAsync(59_999);
    expect(active.mock.calls.length).toBeGreaterThanOrEqual(3);
    expect(discovery).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(1);
    expect(discovery).toHaveBeenCalledTimes(2);
  });

  it("refreshes the live directory at every due discovery cycle, after cache expiry too", async () => {
    vi.useFakeTimers();
    let directoryFetchedAt = -1;
    let directory = new Set(["old-live"]);
    let newMatchConfirmed = false;
    const cursors = { manual: 0, discovery: 0, other: 0 };
    const refreshDirectory = vi.fn(async () => {
      directoryFetchedAt = Date.now();
      if (Date.now() >= 120_000) directory = new Set(["new-live"]);
    });
    const discover = () => runCoordinatorDiscoveryCycle(refreshDirectory, async () => {});
    const engine = new SequentialScanCoordinator({
      active: async () => {
        if (directoryFetchedAt >= 0) {
          expect(Date.now() - directoryFetchedAt).toBeLessThan(120_000);
          const selected = selectLiveVerificationIds(
            ["old-live", "new-live"], new Set(), directory, 1, cursors,
          );
          if (selected.includes("new-live") && Date.now() > 120_000) newMatchConfirmed = true;
        }
      },
      discovery: discover,
    });
    engine.start();
    await vi.advanceTimersByTimeAsync(240_000);
    expect(refreshDirectory.mock.calls.length).toBeGreaterThanOrEqual(4);
    expect(newMatchConfirmed).toBe(true);
    expect(engine.snapshot().lastError).toBeNull();
    engine.stop();
  });

  it("hands ownership to a restart after the stopped generation settles", async () => {
    vi.useFakeTimers();
    let release: (() => void) | undefined;
    const active = vi.fn()
      .mockImplementationOnce(() => new Promise<void>((resolve) => { release = resolve; }))
      .mockResolvedValue(undefined);
    const discovery = vi.fn(async () => {});
    const engine = new SequentialScanCoordinator({ active, discovery });

    engine.start();
    await vi.advanceTimersByTimeAsync(0);
    engine.stop();
    engine.start();
    await vi.advanceTimersByTimeAsync(0);
    expect(active).toHaveBeenCalledTimes(1);
    expect(discovery).not.toHaveBeenCalled();

    release?.();
    await flush();
    await vi.advanceTimersByTimeAsync(0);
    expect(active).toHaveBeenCalledTimes(2);
    expect(discovery).toHaveBeenCalledTimes(1);
    expect(engine.snapshot()).toMatchObject({ running: true, inFlight: false });
  });

  it("still runs due discovery when active work fails", async () => {
    vi.useFakeTimers();
    const active = vi.fn(async () => { throw new Error("primary unavailable"); });
    const discovery = vi.fn(async () => {});
    const engine = new SequentialScanCoordinator({ active, discovery });
    engine.start();
    await vi.advanceTimersByTimeAsync(0);

    expect(active).toHaveBeenCalledTimes(1);
    expect(discovery).toHaveBeenCalledTimes(1);
    expect(engine.snapshot().lastError).toContain("primary unavailable");
  });
});