import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";

// ---------------------------------------------------------------------------
// Regression coverage for the "global scan OFF" decoupling.
//
// The scanner boots with the global scanner OFF by default. The contract under
// test: even while global scan is OFF, watchlist (pinned) matches must stay
// fully armed — once their metadata is known, both the odds-drop Pro Alert
// evaluation and the smart-money / volume eligibility must keep running. We
// also lock down the invariant that each processed match appends EXACTLY ONE
// odds-history entry per tick, in both the normal global loop and the
// hyper-focus (paused) loop.
//
// These tests drive the real internal loop bodies (`tick`, `runHyperFocusTick`)
// via the `__testOnly` seam, with sibling modules stubbed so nothing touches
// the network, Telegram, or the filesystem.
// ---------------------------------------------------------------------------

// Mutable test control, hoisted so the vi.mock factories can read it.
const ctl = vi.hoisted(() => ({
  watchlistIds: new Set<string>(),
  manualTextEntries: [] as Array<{ label: string; fragments: string[]; signature: string }>,
}));

vi.mock("./logger", () => {
  const noop = () => {};
  const log = {
    debug: noop,
    info: vi.fn(),
    warn: noop,
    error: noop,
    fatal: noop,
    trace: noop,
    child: () => log,
  };
  return { logger: log };
});
vi.mock("./excapper", () => ({ releaseManualExcapperBinding: vi.fn() }));

vi.mock("./telegram", () => ({
  sendTelegram: vi.fn(async () => ({
    status: "delivered" as const,
    primaryDelivered: true,
    delivered: 1,
    attempted: 1,
    skippedAlreadyDelivered: 0,
    failed: 0,
    blocked: 0,
  })),
  // vi.fn so individual tests can override the return value (e.g. to true for
  // the volume-alert dispatch test), while the default stays false so the
  // existing odds-drop tests are unaffected (the Pro Alert path calls
  // sendTelegram directly without checking isTelegramConfigured).
  isTelegramConfigured: vi.fn(() => false),
  escapeMdV2: (s: string) => s,
}));

vi.mock("./vcbetPerMatch", () => ({
  fetchVcbetBatch: vi.fn(async () => new Map()),
  probeVcbet: vi.fn(async () => null),
}));

// These Alpha/Beta fixtures exercise the real scanner tick and alert path.
// Never allow their recordAnomaly calls to reach a persistent database.
vi.mock("./winRate", async (importOriginal) => ({
  ...await importOriginal<typeof import("./winRate")>(),
  recordAnomaly: vi.fn(),
}));

vi.mock("./watchlist", () => ({
  initWatchlist: vi.fn(async () => {}),
  matchesWatchlist: (t1: string, t2: string, id?: string) => {
    if (id && ctl.watchlistIds.has(id)) return id;
    const combined = `${t1.toLowerCase()} || ${t2.toLowerCase()}`;
    return ctl.manualTextEntries.find((entry) =>
      entry.fragments.every((fragment) => combined.includes(fragment)),
    )?.label ?? null;
  },
  getWatchlistSnapshot: () => ({
    path: "test",
    count: ctl.watchlistIds.size + ctl.manualTextEntries.length,
    entries: [
      ...[...ctl.watchlistIds].map((id) => ({
        label: id,
        fragments: [] as string[],
        matchId: id,
        signature: id,
      })),
      ...ctl.manualTextEntries.map((entry) => ({
        ...entry,
        matchId: null,
        origin: "manual" as const,
      })),
    ],
    lastLoadedAt: null,
    lastError: null,
  }),
  getNormalizedEntries: () =>
    [
      ...[...ctl.watchlistIds].map((id) => ({
        label: id,
        fragments: [] as string[],
        matchId: id,
        origin: "manual" as const,
        signature: id,
      })),
      ...ctl.manualTextEntries.map((entry) => ({
        ...entry,
        origin: "manual" as const,
      })),
    ],
  isManualWatchlistId: (id: string) => ctl.watchlistIds.has(id),
}));

import {
  __testOnly,
  getRuntimeArchiveRows,
  getOddsRadarFixtureSnapshot,
  RUNTIME_ARCHIVE_CAP,
  RUNTIME_ARCHIVE_TTL_MS,
  mergeAltOddsSnapshot,
  getWatchlistMatchesForVolume,
  getManualWatchlistMatchesForExcapper,
  hydrateManualMatchVolume,
  clearManualMatchVolumeBinding,
  setGlobalScannerPaused,
  getGlobalScannerPaused,
  _internalGetMatchStates,
  requestManualWatchlistRefresh,
  getWatchlistLiveSnapshot,
  fetchRaw,
  HTTP_REQUEST_TIMEOUT_MS,
  EXTRA_BOOK_TIMEOUT_MS,
  UpstreamTimeoutError,
  scannerStats,
  parsePerMatchScore,
  setExternalScore,
  getScannerAlertContext,
} from "./scanner";
import { sendTelegram } from "./telegram";
import { recordAnomaly } from "./winRate";
import { logger } from "./logger";
import { refreshRadarBooks, getCachedBookMovements } from "./radarBookMarkets";

describe("manual-volume exact-market odds window", () => {
  beforeEach(() => __testOnly.reset());

  it("retains the original in-window baseline instead of replacing it with current", () => {
    const now = Date.now();
    __testOnly.recordManualExactQuote("m1", 2.5, "OVER", {
      odds: 2,
      collectedAt: now - 60_000,
    });
    __testOnly.recordManualExactQuote("m1", 2.5, "OVER", {
      odds: 1.9,
      collectedAt: now - 30_000,
    });
    const history = __testOnly.recordManualExactQuote("m1", 2.5, "OVER", {
      odds: 1.8,
      collectedAt: now,
    });
    expect(history).toEqual([
      { ts: now - 60_000, line: 2.5, odds: 2 },
      { ts: now - 30_000, line: 2.5, odds: 1.9 },
      { ts: now, line: 2.5, odds: 1.8 },
    ]);
    expect(__testOnly.recordManualExactQuote("m1", 3.5, "OVER", {
      odds: 1.7,
      collectedAt: now,
    })).toHaveLength(1);
    expect(__testOnly.recordManualExactQuote("m1", 2.5, "UNDER", {
      odds: 2.1,
      collectedAt: now,
    })).toHaveLength(1);
  });
});

describe("per-match fixture header clock parsing", () => {
  const body = (Data: Record<string, unknown>) =>
    JSON.stringify({
      ErrCode: 0,
      Data: {
        state: 1,
        html: "<div class='score'>1</div><div class='score'>0</div>",
        ...Data,
      },
    });

  it.each([
    ["38'", "38"],
    ["72'", "72"],
    ["45+2'", "45+2"],
  ])("reads direct JSON clock %s", (minute, expected) => {
    expect(parsePerMatchScore(body({ minute }))?.clockLabel).toBe(expected);
  });

  it("reads nested main-header phase markup", () => {
    expect(parsePerMatchScore(body({
      state: 2,
      period: 2,
      html:
        "<div class='score'>1</div><div class='score'>0</div>" +
        "<span class='fixture-status'><b>HT</b></span>",
    }))?.clockLabel).toBe("HT");
  });

  it("prefers a real header clock over numeric period phase codes", () => {
    expect(parsePerMatchScore(body({
      state: 3,
      period: 2,
      html:
        "<div class='score'>1</div><div class='score'>0</div>" +
        "<span class='main-minute'><i>72'</i></span>",
    }))?.clockLabel).toBe("72");
  });

  it("does not fabricate 0-0 when a live scoreboard is missing", () => {
    expect(parsePerMatchScore(JSON.stringify({
      ErrCode: 0,
      Data: { state: 3, html: "<span class='main-minute'>72'</span>" },
    }))).toBeNull();
  });
});

// ----- Upstream fixture builders -----

// malayToDecimal: for malay >= 0, decimal = malay + 1. So to express a target
// decimal price we feed (decimal - 1) as the malay field.
function ouRow(
  id: string,
  line: number,
  overDecimal: number,
  underDecimal: number,
): string {
  const f = [
    id,
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    String(line),
    String(overDecimal - 1),
    String(underDecimal - 1),
  ];
  return `<m>${f.join(",")}</m>`;
}

function ouXml(rows: string[]): string {
  return `<root>${rows.join("")}</root>`;
}

function metaJson(
  matches: { id: string; t1: string; t2: string; league: string; homeScore?: number; awayScore?: number }[],
): string {
  const records = matches.map((m) => {
    const f: string[] = new Array(13).fill("");
    f[0] = m.id;
    f[3] = ""; // kickoff omitted → parseKickoffMs null (isLive false; irrelevant here)
    f[4] = m.league;
    f[9] = m.t1;
    f[10] = m.t2;
    f[11] = String(m.homeScore ?? 0);
    f[12] = String(m.awayScore ?? 0);
    return f.join("^");
  });
  return JSON.stringify({ ErrCode: 0, Data: records.join("!") });
}

// Per-test mutable bodies returned by the stubbed global fetch.
let primaryBody = "";
let metaBody = "";
let directoryBody = "";
let perMatchScoreBody = "";

function makeMeta(id: string) {
  return {
    team1: "Alpha",
    team2: "Beta",
    leagueId: "999",
    leagueName: "Finland Kakkonen",
    homeScore: 0,
    awayScore: 0,
    isLive: true,
  } as Parameters<typeof mergeAltOddsSnapshot>[1] extends Map<string, infer M>
    ? M
    : never;
}

describe("active runtime source admission", () => {
  const id = "987654";
  const odds = (key: string) => new Map([[key, { matchId: key, line: 2.5, overDecimal: 2, underDecimal: 1.9 }]]);
  it("removes finished manual pins from runtime without removing configuration", () => {
    ctl.watchlistIds.add(id);
    mergeAltOddsSnapshot(odds(id), new Map([[id, makeMeta(id)]]));
    expect(_internalGetMatchStates().has(id)).toBe(true);
    mergeAltOddsSnapshot(odds(id), new Map([[id, { ...makeMeta(id), state: -1, isLive: true }]]));
    expect(_internalGetMatchStates().has(id)).toBe(false);
    expect(ctl.watchlistIds.has(id)).toBe(true);
    expect(getWatchlistLiveSnapshot().entries).toHaveLength(0);
    expect(getWatchlistLiveSnapshot().savedEntries).toHaveLength(1);
    expect(getRuntimeArchiveRows().find((row) => row.nowGoalMatchId === id)?.matchPhase).toBe("Finished");
  });
  it("blocks cached, missing-meta, and late alternate resurrection", () => {
    mergeAltOddsSnapshot(odds(id), new Map([[id, { ...makeMeta(id), state: 0 }]]));
    mergeAltOddsSnapshot(odds(id), new Map([[id, makeMeta(id)]]));
    mergeAltOddsSnapshot(odds("987655"), new Map());
    expect(_internalGetMatchStates().size).toBe(0);
  });
  it("permits manual live identity outside discovery leagues but not arbitrary candidates", () => {
    const meta = { ...makeMeta(id), leagueName: "Unknown regional league", state: 1 };
    mergeAltOddsSnapshot(odds(id), new Map([[id, meta]]));
    expect(_internalGetMatchStates().has(id)).toBe(false);
    ctl.watchlistIds.add(id);
    mergeAltOddsSnapshot(odds(id), new Map([[id, meta]]));
    expect(_internalGetMatchStates().has(id)).toBe(true);
  });
  it("bounds lightweight history by both cap and TTL", () => {
    for (let n = 0; n < RUNTIME_ARCHIVE_CAP + 10; n++) {
      const key = String(800000 + n);
      mergeAltOddsSnapshot(odds(key), new Map([[key, { ...makeMeta(key), state: -1 }]]));
    }
    expect(getRuntimeArchiveRows()).toHaveLength(RUNTIME_ARCHIVE_CAP);
    expect(_internalGetMatchStates().size).toBe(0);
    vi.spyOn(Date, "now").mockReturnValue(Date.now() + RUNTIME_ARCHIVE_TTL_MS + 1);
    expect(getRuntimeArchiveRows()).toHaveLength(0);
    vi.restoreAllMocks();
  });
});

beforeEach(() => {
  __testOnly.reset();
  ctl.watchlistIds.clear();
  ctl.manualTextEntries.length = 0;
  (sendTelegram as ReturnType<typeof vi.fn>).mockClear();
  vi.mocked(recordAnomaly).mockClear();
  vi.mocked(logger.info).mockClear();
  primaryBody = "";
  metaBody = "";
  directoryBody = "";
  perMatchScoreBody = JSON.stringify({
    ErrCode: 0,
    Data: { state: 1, html: "<div class='score'>0</div><div class='score'>0</div>" },
  });

  vi.stubGlobal(
    "fetch",
    vi.fn(async (input: unknown) => {
      const u = String(input);
      let body = "";
      if (u.includes("goal8.xml")) body = primaryBody; // primary OU feed
      else if (u.includes("type=12")) body = metaBody; // bulk meta feed
      else if (u.includes("type=11")) body = perMatchScoreBody;
      else if (u.includes("type=6")) body = directoryBody;
      else body = ""; // benchmark + extra books → empty
      return {
        ok: true,
        status: 200,
        text: async () => body,
      };
    }) as unknown as typeof fetch,
  );
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

const ID = "100001";

describe("type=6 live discovery", () => {
  async function prepare() {
    directoryBody = JSON.stringify({ ErrCode: 0, Data:
      "B[4]=[1398,'ECU B','Liga Pro Ecuador Serie B'];" +
      "A[0]=[3071680,4,123,456,'CD Independiente Juniors','Vinotinto de Ecuador','2026,8,24,22,00,00',3,1,1];" });
    await __testOnly.refreshLeagueNames();
    metaBody = JSON.stringify({ ErrCode: 0, Data: "" });
    primaryBody = ouXml([ouRow("3071680", 2.5, 2.0, 1.9)]);
  }
  it("discovers an absent type=12 Ecuador match after state/scoreboard confirmation", async () => {
    await prepare();
    perMatchScoreBody = JSON.stringify({ ErrCode: 0, Data: {
      state: 3, html: "<div class='score'>1</div><div class='score'>1</div>",
    } });
    await __testOnly.tick();
    expect(_internalGetMatchStates().get("3071680")?.lastMeta).toMatchObject({
      leagueId: "1398", state: 3, homeScore: 1, awayScore: 1, isLive: true,
    });
  });
  it("exposes verified live-directory identity to 1X2 radar without manufacturing OU odds", async () => {
    await prepare();
    primaryBody = ouXml([]);
    perMatchScoreBody = JSON.stringify({ ErrCode: 0, Data: {
      state: 3, html: "<div class='score'>1</div><div class='score'>1</div>",
    } });
    await __testOnly.tick();
    expect(_internalGetMatchStates().has("3071680")).toBe(false);
    expect(getOddsRadarFixtureSnapshot().find((r) => r.matchId === "3071680")).toMatchObject({
      needsVerification: true,
      meta: { leagueName: "Liga Pro Ecuador Serie B", team1: "CD Independiente Juniors" },
    });
  });
  it.each([
    { state: 3, html: "" },
    { state: 0, html: "<div class='score'>0</div><div class='score'>0</div>" },
    { state: -1, html: "<div class='score'>1</div><div class='score'>1</div>" },
  ])("does not track unconfirmed candidates: %j", async (data) => {
    await prepare();
    perMatchScoreBody = JSON.stringify({ ErrCode: 0, Data: data });
    await __testOnly.tick();
    expect(_internalGetMatchStates().has("3071680")).toBe(false);
  });
});

describe("watchlist stays armed while global scan is OFF", () => {
  it("boots with the global scanner ACTIVE and honors manual pause/resume", () => {
    expect(getGlobalScannerPaused()).toBe(false);
    // Manual pause is honored (nothing pauses automatically — the only
    // production caller is the dashboard toggle route).
    expect(setGlobalScannerPaused(true)).toBe(true);
    expect(getGlobalScannerPaused()).toBe(true);
    expect(setGlobalScannerPaused(false)).toBe(false);
    expect(getGlobalScannerPaused()).toBe(false);
  });

  it("does not let a pinned ID bypass the target league gate while paused", async () => {
    setGlobalScannerPaused(true, { force: true }); // test-only: enter hyper-focus
    expect(getGlobalScannerPaused()).toBe(true);
    ctl.watchlistIds.add(ID);

    // Hyper-focus has no metadata source, so it cannot create a state for an
    // unresolved pinned ID. Priority/watchlist status is not an allowlist
    // bypass.
    primaryBody = ouXml([ouRow(ID, 2.5, 2.5, 2.4)]);
    await __testOnly.runHyperFocusTick();

    const st = _internalGetMatchStates().get(ID);
    expect(st).toBeUndefined();

    // Smart-money eligibility remains closed as well.
    expect(getWatchlistMatchesForVolume()).toHaveLength(0);

    // A genuine odds drop also cannot create or alert the unknown state.
    primaryBody = ouXml([ouRow(ID, 2.5, 2.0, 2.1)]);
    await __testOnly.runHyperFocusTick();
    expect(_internalGetMatchStates().get(ID)).toBeUndefined();
    expect(sendTelegram).not.toHaveBeenCalled();
  });

  it("keeps target watchlist odds-drop + smart-money paths armed while paused", async () => {
    setGlobalScannerPaused(true, { force: true });
    ctl.watchlistIds.add(ID);

    // Alternate metadata is an explicit target-league source, so it may seed
    // the state while the bulk metadata feed is unavailable.
    const altPrimary = new Map([
      [ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }],
    ]);
    const altMeta = new Map([[ID, makeMeta(ID)]]);
    const res = mergeAltOddsSnapshot(altPrimary, altMeta, { source: "test" });
    expect(res.seeded).toBe(1);
    expect(res.skippedFresh).toBe(0);
    expect(res.refreshed).toBe(0);
    const st = _internalGetMatchStates().get(ID);
    expect(st!.lastMeta).toBeDefined();
    expect(st!.lastMeta!.team1).toBe("Alpha");

    // Manual membership is the only retained Excapper hydration path.
    const vol = getWatchlistMatchesForVolume();
    expect(vol).toHaveLength(1);
    expect(vol[0]!.matchId).toBe(ID);

    // The next target-league drop fires the Pro Alert while paused.
    // The alternate seed and first primary sample can otherwise share a
    // millisecond, which is not a positive historical odds drop.
    st!.history[0]!.ts = Date.now() - 1_000;
    primaryBody = ouXml([ouRow(ID, 2.5, 1.5, 1.6)]);
    await __testOnly.runHyperFocusTick();
    await vi.waitFor(() => expect(sendTelegram).toHaveBeenCalledTimes(1));
  });

  it("drops a pending alert when a fresh goal has already settled its total", async () => {
    setGlobalScannerPaused(true, { force: true });
    ctl.watchlistIds.add(ID);
    mergeAltOddsSnapshot(
      new Map([[ID, { matchId: ID, line: 1.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[ID, makeMeta(ID)]]),
      { source: "test" },
    );
    perMatchScoreBody = JSON.stringify({
      ErrCode: 0,
      Data: {
        state: 1,
        html: "<div class='score'>2</div><div class='score'>0</div>",
      },
    });
    const suppressedBefore = scannerStats.alertsSuppressedByGoalBlackout;
    primaryBody = ouXml([ouRow(ID, 1.5, 1.5, 1.6)]);
    await __testOnly.runHyperFocusTick();
    await vi.waitFor(() =>
      expect(scannerStats.alertsSuppressedByGoalBlackout).toBeGreaterThan(suppressedBefore),
    );
    expect(sendTelegram).not.toHaveBeenCalled();
  });
});

describe("SMART MONEY match-wide admission", () => {
  function prepare() {
    ctl.watchlistIds.add(ID);
    mergeAltOddsSnapshot(
      new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[ID, makeMeta(ID)]]),
      { source: "test" },
    );
    const state = _internalGetMatchStates().get(ID)!;
    state.history[0]!.ts = Date.now() - 1_000;
    const args = {
      matchId: ID, state, prev: state.history[0],
      ou: { matchId: ID, line: 2.5, overDecimal: 1.5, underDecimal: 1.6 },
      meta: { ...makeMeta(ID), kickoffMs: null },
      leagueName: "Finland Kakkonen", isLowLiq: false, now: Date.now(),
    };
    return { state, evaluate: () => __testOnly.evaluateOddsDropAlert(args) };
  }

  it("reserves before awaiting score: simultaneous OVER/UNDER creates only one Telegram and PENDING", async () => {
    const { state, evaluate } = prepare();
    const originalFetch = globalThis.fetch;
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const fetchMock = vi.fn(async (...args: Parameters<typeof fetch>) => {
      await gate;
      return originalFetch(...args);
    });
    vi.stubGlobal("fetch", fetchMock);
    evaluate();
    evaluate(); // another evaluation while the first score lookup is pending
    expect(state.oddsDropAlertInFlight).toBe(true);
    expect(state.lastAlertAt).toBe(0);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(sendTelegram).not.toHaveBeenCalled();
    expect(recordAnomaly).not.toHaveBeenCalled();
    release();
    await vi.waitFor(() => expect(state.oddsDropAlertInFlight).toBe(false));
    expect(sendTelegram).toHaveBeenCalledTimes(1);
    expect(recordAnomaly).toHaveBeenCalledTimes(1);
    expect(recordAnomaly).toHaveBeenCalledWith(expect.objectContaining({
      anomalyType: "ODDS_DROP", targetSide: "OVER",
    }));
    expect(state.lastAlertAt).toBeGreaterThan(0);
    evaluate();
    expect(sendTelegram).toHaveBeenCalledTimes(1);
    expect(recordAnomaly).toHaveBeenCalledTimes(1);
  });

  it.each(["missing score", "network failure"])(
    "releases admission without cooldown after %s so the same event can retry",
    async (failure) => {
      const { state, evaluate } = prepare();
      const originalFetch = globalThis.fetch;
      vi.stubGlobal("fetch", vi.fn(async () => {
        if (failure === "network failure") throw new Error("score unavailable");
        return { ok: true, text: async () => "{}" };
      }));
      evaluate();
      await vi.waitFor(() => expect(state.oddsDropAlertInFlight).toBe(false));
      expect(state.lastAlertAt).toBe(0);
      expect(sendTelegram).not.toHaveBeenCalled();
      expect(recordAnomaly).not.toHaveBeenCalled();
      vi.stubGlobal("fetch", originalFetch);
      evaluate();
      await vi.waitFor(() => expect(state.oddsDropAlertInFlight).toBe(false));
      expect(sendTelegram).toHaveBeenCalledTimes(1);
      expect(recordAnomaly).toHaveBeenCalledTimes(1);
    },
  );
});

describe("goal blackout", () => {
  for (const hyperFocus of [false, true]) {
    it(`omits cached pre-goal bookmaker evidence from the delivered card (${hyperFocus ? "hyper-focus" : "normal"})`, async () => {
      const now = 1_800_000_000_000;
      vi.spyOn(Date, "now").mockReturnValue(now);
      const id = hyperFocus ? "101002" : "101001";
      const scannerFetch = globalThis.fetch;
      const html = `<tr cid="987"><a onclick="_oddsDetailWin.open('${id}',987, 'Old House', -1, 0)">Trends</a></tr>`;
      vi.stubGlobal("fetch", vi.fn(async (url: string) => new Response(
        url.includes("/oddscomp/") ? html :
          url.includes("t=11") ? JSON.stringify({ ErrCode: 0, Data: { roddsList: [{ cid: 987 }] } }) :
            JSON.stringify({ ErrCode: 0, Data: { op: [], ou: [
              { mt: (now - 92_000) / 1000, type: 0, close: false, odds: { u: "0.2", d: "0.9", g: "2.5" } },
              { mt: (now - 110_000) / 1000, type: 0, close: false, odds: { u: "2.8", d: "0.9", g: "2.5" } },
            ] } }), { status: 200 },
      )));
      await refreshRadarBooks([id]);
      expect(getCachedBookMovements(id, "OVER", 2.5, now)).toMatchObject([
        { bookmaker: "Old House", from: 3.8, to: 1.2 },
      ]);
      vi.stubGlobal("fetch", scannerFetch);
      setGlobalScannerPaused(hyperFocus, { force: true });
      ctl.watchlistIds.add(id);
      __testOnly.setLeagueNames(new Map([["999", "Finland Kakkonen"]]));
      mergeAltOddsSnapshot(
        new Map([[id, { matchId: id, line: 2.5, overDecimal: 1.95, underDecimal: 1.6 }]]),
        new Map([[id, makeMeta(id)]]), { source: "test" },
      );
      const state = _internalGetMatchStates().get(id)!;
      (state as { lastScoreChangeAt?: number }).lastScoreChangeAt = now - 91_000;
      state.history[0]!.ts = now - 1_000;
      metaBody = metaJson([{ id, t1: "Alpha", t2: "Beta", league: "999" }]);
      primaryBody = ouXml([ouRow(id, 2.5, 1.5, 1.6)]);
      if (hyperFocus) await __testOnly.runHyperFocusTick();
      else await __testOnly.tick();
      await vi.waitFor(() => expect(sendTelegram).toHaveBeenCalledTimes(1));
      const card = vi.mocked(sendTelegram).mock.calls[0]![0];
      expect(card).toContain("Bet365");
      expect(card).toContain("1.95");
      expect(card).toContain("1.50");
      expect(card).not.toContain("Old House");
      expect(card).not.toContain("3.80");
      expect(card).not.toContain("1.20");
      // The shared cache and other consumers are intentionally untouched.
      expect(getCachedBookMovements(id, "OVER", 2.5, now)).toHaveLength(1);
    });

    it.each(["OVER", "UNDER"] as const)(
      `isolates a >90s quote gap per match and resumes clean %s moves (${hyperFocus ? "hyper-focus" : "normal"})`,
      async (side) => {
        const clock = vi.spyOn(Date, "now");
        const start = 1_800_000_000_000;
        clock.mockReturnValue(start);
        const otherId = "100002";
        setGlobalScannerPaused(hyperFocus, { force: true });
        __testOnly.setLeagueNames(new Map([["999", "Finland Kakkonen"]]));
        for (const id of [ID, otherId]) {
          ctl.watchlistIds.add(id);
          mergeAltOddsSnapshot(
            new Map([[id, { matchId: id, line: 2.5,
              overDecimal: side === "OVER" ? 2.5 : 1.6,
              underDecimal: side === "UNDER" ? 2.5 : 1.6 }]]),
            new Map([[id, makeMeta(id)]]), { source: "test" },
          );
        }
        const state = _internalGetMatchStates().get(ID)!;
        clock.mockReturnValue(start + 1_000);
        setExternalScore(ID, 1, 0, "test");
        const goalAt = state.lastScoreChangeAt!;
        // Both fixtures now have the same authoritative score, but only ID
        // has a score transition. The other match must keep its baseline.
        _internalGetMatchStates().get(otherId)!.lastMeta!.homeScore = 1;
        perMatchScoreBody = JSON.stringify({
          ErrCode: 0,
          Data: { state: 1, html: "<div class='score'>1</div><div class='score'>0</div>" },
        });
        metaBody = metaJson([ID, otherId].map((id) => ({
          id, t1: "Alpha", t2: "Beta", league: "999", homeScore: 1,
        })));
        const row = (id: string, price: number) =>
          ouRow(id, 2.5, side === "OVER" ? price : 1.6, side === "UNDER" ? price : 1.6);
        const tick = () => hyperFocus ? __testOnly.runHyperFocusTick() : __testOnly.tick();
        // No primary quotes arrived during blackout.
        clock.mockReturnValue(goalAt + 91_000);
        primaryBody = ouXml([row(ID, 1.95), row(otherId, 1.5)]);
        await tick();
        await vi.waitFor(() => expect(sendTelegram).toHaveBeenCalledTimes(1));
        expect(recordAnomaly).toHaveBeenCalledTimes(1);
        expect(vi.mocked(recordAnomaly).mock.calls[0]![0].matchId).toBe(otherId);
        expect(state.lastAlertAt).toBe(0);
        expect(state.history.some((h) => h.ts < goalAt)).toBe(true);

        // A genuine post-goal baseline followed by a new drop is eligible.
        vi.mocked(sendTelegram).mockClear();
        vi.mocked(recordAnomaly).mockClear();
        clock.mockReturnValue(goalAt + 101_000);
        primaryBody = ouXml([row(ID, 1.5), row(otherId, 1.5)]);
        await tick();
        await vi.waitFor(() => expect(sendTelegram).toHaveBeenCalledTimes(1));
        expect(recordAnomaly).toHaveBeenCalledTimes(1);
        expect(vi.mocked(recordAnomaly).mock.calls[0]![0]).toMatchObject({ matchId: ID, targetSide: side });
        expect(state.lastAlertAt).toBe(goalAt + 101_000);
      },
    );

    it.each(["dropping", "diverging", "clean"] as const)(
      `uses only post-goal pressure and benchmark: %s (${hyperFocus ? "hyper-focus" : "normal"})`,
      async (benchmark) => {
        const now = 1_800_000_000_000;
        vi.spyOn(Date, "now").mockReturnValue(now);
        setGlobalScannerPaused(hyperFocus, { force: true });
        ctl.watchlistIds.add(ID);
        __testOnly.setLeagueNames(new Map([["999", "Finland Kakkonen"]]));
        mergeAltOddsSnapshot(
          new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 1.95, underDecimal: 1.6 }]]),
          new Map([[ID, makeMeta(ID)]]), { source: "test" },
        );
        const state = _internalGetMatchStates().get(ID)!;
        const cutoff = now - 91_000;
        (state as { lastScoreChangeAt?: number }).lastScoreChangeAt = cutoff;
        state.history.splice(0, state.history.length, ...[2.7, 2.6, 2.5, 2.4].map((overDecimal, i) => ({
          ts: cutoff - (3 - i) * 1_000, line: 2.5, overDecimal, underDecimal: 1.6,
        })));
        state.history.push({ ts: now - 1_000, line: 2.5, overDecimal: 1.95, underDecimal: 1.6 });
        state.benchmarkHistory.push(
          { ts: benchmark === "clean" ? now - 2_000 : cutoff, line: 2.5,
            overDecimal: benchmark === "diverging" ? 1.5 : 2, underDecimal: 1.6 },
          { ts: now - 1_000, line: 2.5, overDecimal: 1.8, underDecimal: 1.6 },
        );
        metaBody = metaJson([{ id: ID, t1: "Alpha", t2: "Beta", league: "999" }]);
        primaryBody = ouXml([ouRow(ID, 2.5, 1.5, 1.6)]);
        if (hyperFocus) await __testOnly.runHyperFocusTick();
        else await __testOnly.tick();
        await vi.waitFor(() => expect(sendTelegram).toHaveBeenCalledTimes(1));
        const fired = vi.mocked(logger.info).mock.calls.find((args) => args[1] === "Pro alert fired");
        expect(fired?.[0]).toMatchObject({
          pressure: 1,
          benchStatus: benchmark === "clean" ? "dropping" : "no-data",
          confidence: benchmark === "clean" ? 10 : 6,
        });
      },
    );
  }

  it("arms blackout after a non-main score override, including during hyper-focus", async () => {
    setGlobalScannerPaused(true, { force: true });
    ctl.watchlistIds.add(ID);
    mergeAltOddsSnapshot(
      new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[ID, makeMeta(ID)]]),
      { source: "test" },
    );
    const state = _internalGetMatchStates().get(ID)!;
    state.history[0]!.ts = Date.now() - 1_000;
    expect(state.lastScoreChangeAt).toBeUndefined();
    const start = Date.now();
    expect(setExternalScore(ID, 1, 0, "test").changed).toBe(true);
    expect(state.lastScoreChangeAt).toBeGreaterThanOrEqual(start);
    perMatchScoreBody = JSON.stringify({
      ErrCode: 0,
      Data: { state: 1, html: "<div class='score'>1</div><div class='score'>0</div>" },
    });
    primaryBody = ouXml([ouRow(ID, 2.5, 1.5, 1.6)]);
    const before = scannerStats.alertsSuppressedByGoalBlackout;
    await __testOnly.runHyperFocusTick();
    expect(scannerStats.alertsSuppressedByGoalBlackout).toBe(before + 1);
    expect(sendTelegram).not.toHaveBeenCalled();
  });

  it("hyper-focus direct score refresh detects a fresh goal before the odds drop", async () => {
    setGlobalScannerPaused(true, { force: true });
    ctl.watchlistIds.add(ID);
    mergeAltOddsSnapshot(
      new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[ID, makeMeta(ID)]]),
      { source: "test" },
    );
    const state = _internalGetMatchStates().get(ID)!;
    state.history[0]!.ts = Date.now() - 1_000;
    perMatchScoreBody = JSON.stringify({
      ErrCode: 0,
      Data: { state: 1, html: "<div class='score'>1</div><div class='score'>0</div>" },
    });
    primaryBody = ouXml([ouRow(ID, 2.5, 1.5, 1.6)]);
    const before = scannerStats.alertsSuppressedByGoalBlackout;
    await __testOnly.runHyperFocusTick();
    expect(state.lastScoreChangeAt).toBeDefined();
    expect(scannerStats.alertsSuppressedByGoalBlackout).toBe(before + 1);
    expect(sendTelegram).not.toHaveBeenCalled();
  });

  for (const hyperFocus of [false, true]) {
    it.each([30_000, 90_000, 91_000, undefined])(
      `gates the ${hyperFocus ? "hyper-focus" : "normal"} path with score-change age %s`,
      async (age) => {
        setGlobalScannerPaused(hyperFocus, { force: true });
        ctl.watchlistIds.add(ID);
        __testOnly.setLeagueNames(new Map([["999", "Finland Kakkonen"]]));
        mergeAltOddsSnapshot(
          new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
          new Map([[ID, makeMeta(ID)]]),
          { source: "test" },
        );
        const state = _internalGetMatchStates().get(ID)! as { lastScoreChangeAt?: number };
        // The positive-drop validator requires a genuinely earlier quote;
        // the alt seed and tick can otherwise land in the same millisecond.
        _internalGetMatchStates().get(ID)!.history[0]!.ts = Date.now() - 1_000;
        state.lastScoreChangeAt = age === undefined ? undefined : Date.now() - age;
        metaBody = metaJson([{ id: ID, t1: "Alpha", t2: "Beta", league: "999" }]);
        primaryBody = ouXml([ouRow(ID, 2.5, 1.5, 1.6)]);
        const before = scannerStats.alertsSuppressedByGoalBlackout;
        if (hyperFocus) await __testOnly.runHyperFocusTick();
        else await __testOnly.tick();
        if (age !== undefined && age < 90_000) {
          expect(scannerStats.alertsSuppressedByGoalBlackout).toBe(before + 1);
          expect(sendTelegram).not.toHaveBeenCalled();
        } else {
          await vi.waitFor(() => expect(sendTelegram).toHaveBeenCalledTimes(1));
          expect(scannerStats.alertsSuppressedByGoalBlackout).toBe(before);
        }
      },
    );
  }

  it("stamps a changed score before normal-path evaluation, but not first sight or unchanged scores", async () => {
    ctl.watchlistIds.add(ID);
    __testOnly.setLeagueNames(new Map([["999", "Finland Kakkonen"]]));
    metaBody = metaJson([{ id: ID, t1: "Alpha", t2: "Beta", league: "999" }]);
    primaryBody = ouXml([ouRow(ID, 2.5, 2.5, 2.4)]);
    await __testOnly.tick();
    const state = _internalGetMatchStates().get(ID)!;
    expect(state.lastScoreChangeAt).toBeUndefined();
    metaBody = metaJson([{ id: ID, t1: "Alpha", t2: "Beta", league: "999", homeScore: 1 }]);
    // The normal tick verifies the bulk score against type=11 before evaluating.
    perMatchScoreBody = JSON.stringify({
      ErrCode: 0,
      Data: { state: 1, html: "<div class='score'>1</div><div class='score'>0</div>" },
    });
    primaryBody = ouXml([ouRow(ID, 2.5, 1.5, 1.6)]);
    const before = scannerStats.alertsSuppressedByGoalBlackout;
    const started = Date.now();
    await __testOnly.tick();
    expect(state.lastScoreChangeAt).toBeGreaterThanOrEqual(started);
    expect(scannerStats.alertsSuppressedByGoalBlackout).toBe(before + 1);
    expect(sendTelegram).not.toHaveBeenCalled();
    const stamped = state.lastScoreChangeAt;
    await __testOnly.tick();
    expect(state.lastScoreChangeAt).toBe(stamped);
  });
});

describe("exact-line benchmark and scanner alert evidence", () => {
  it("reports no benchmark data when two samples exist only across other lines", () => {
    const now = Date.now();
    const snap = (ts: number, line: number, overDecimal: number) =>
      ({ ts, line, overDecimal, underDecimal: 2 });
    expect(__testOnly.evalBenchmark([
      snap(now - 10_000, 3.5, 2.5),
      snap(now - 5_000, 3.5, 1.5),
    ], 2.5, now, "OVER")).toEqual({
      status: "no-data", delta: null, matchedLine: false,
    });
    expect(__testOnly.evalBenchmark([
      snap(now - 10_000, 2.5, 2.5),
      snap(now - 8_000, 3.5, 1.5),
      snap(now - 5_000, 2.5, 1.5),
    ], 2.5, now, "OVER")).toMatchObject({
      status: "dropping", matchedLine: true,
    });
  });

  it("returns only fresh exact-line primary odds and refuses stale/other-line evidence", () => {
    ctl.watchlistIds.add(ID);
    mergeAltOddsSnapshot(
      new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[ID, makeMeta(ID)]]),
      { source: "test" },
    );
    expect(getScannerAlertContext(ID, 2.5, "OVER")).toMatchObject({
      timeline: [{ line: 2.5, odds: 2.5 }],
      currentQuote: { line: 2.5, odds: 2.5 },
    });
    expect(getScannerAlertContext(ID, 3.5, "OVER")).toBeNull();
    _internalGetMatchStates().get(ID)!.history[0]!.ts = Date.now() - 300_000;
    expect(getScannerAlertContext(ID, 2.5, "OVER")).toBeNull();
  });
});

describe("frozen-odds volatility policy", () => {
  it("requires five minutes and successful active samples before declaring stale", () => {
    const { staleWindowMs, minSuccessfulSamples } = __testOnly.volatilityPolicy;
    expect(staleWindowMs).toBeGreaterThanOrEqual(300_000);
    expect(minSuccessfulSamples).toBeGreaterThanOrEqual(5);

    const startedAt = Date.parse("2026-01-01T00:00:00Z");
    expect(__testOnly.recordVolatilityAndCheckStale("10:abc", 10, 10, startedAt)).toBe(false);
    for (let i = 1; i < minSuccessfulSamples; i++) {
      expect(
        __testOnly.recordVolatilityAndCheckStale(
          "10:abc",
          10,
          10,
          startedAt + i * 10_000,
        ),
      ).toBe(false);
    }
    expect(
      __testOnly.recordVolatilityAndCheckStale(
        "10:abc",
        10,
        10,
        startedAt + staleWindowMs - 1,
      ),
    ).toBe(false);
    expect(
      __testOnly.recordVolatilityAndCheckStale(
        "10:abc",
        10,
        10,
        startedAt + staleWindowMs,
      ),
    ).toBe(true);
  });

  it("never counts empty or pre-match-only snapshots as stale", () => {
    const startedAt = Date.parse("2026-01-01T00:00:00Z");
    const late = startedAt + __testOnly.volatilityPolicy.staleWindowMs * 2;
    expect(__testOnly.recordVolatilityAndCheckStale("0:empty", 0, 0, startedAt)).toBe(false);
    expect(__testOnly.recordVolatilityAndCheckStale("50:quiet", 50, 0, late)).toBe(false);
    expect(scannerStats.dataVolatility.lastSignature).toBeNull();
    expect(scannerStats.dataVolatility.successfulUnchangedSamples).toBe(0);
  });

  it("clears a changed baseline so the next active tick only seeds", () => {
    const startedAt = Date.parse("2026-01-01T00:00:00Z");
    __testOnly.recordVolatilityAndCheckStale("10:old", 10, 10, startedAt);
    __testOnly.recordVolatilityAndCheckStale("10:old", 10, 10, startedAt + 10_000);

    expect(
      __testOnly.recordVolatilityAndCheckStale("10:new", 10, 10, startedAt + 20_000),
    ).toBe(false);
    expect(scannerStats.dataVolatility.lastSignature).toBeNull();
    expect(scannerStats.dataVolatility.successfulUnchangedSamples).toBe(0);

    expect(
      __testOnly.recordVolatilityAndCheckStale(
        "10:new",
        10,
        10,
        startedAt + __testOnly.volatilityPolicy.staleWindowMs + 20_000,
      ),
    ).toBe(false);
    expect(scannerStats.dataVolatility.successfulUnchangedSamples).toBe(1);
  });
});

describe("exactly one odds-history append per processed match per tick", () => {
  it("hyper-focus (paused) loop appends once per tick", async () => {
    setGlobalScannerPaused(true, { force: true }); // test-only: enter hyper-focus
    expect(getGlobalScannerPaused()).toBe(true);
    ctl.watchlistIds.add(ID);
    mergeAltOddsSnapshot(
      new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[ID, makeMeta(ID)]]),
      { source: "test" },
    );

    primaryBody = ouXml([ouRow(ID, 2.5, 2.5, 2.4)]);
    await __testOnly.runHyperFocusTick();
    const st = _internalGetMatchStates().get(ID);
    expect(st).toBeDefined();
    expect(st!.history.length).toBe(2);

    primaryBody = ouXml([ouRow(ID, 2.5, 2.45, 2.4)]); // different odds → fresh tick
    await __testOnly.runHyperFocusTick();
    expect(st!.history.length).toBe(3);
  });

  it("normal global loop appends once per tick", async () => {
    ctl.watchlistIds.add(ID);
    setGlobalScannerPaused(false); // turn global scan ON
    expect(getGlobalScannerPaused()).toBe(false);

    __testOnly.setLeagueNames(new Map([["999", "Finland Kakkonen"]]));
    metaBody = metaJson([{ id: ID, t1: "Alpha", t2: "Beta", league: "999" }]);
    primaryBody = ouXml([ouRow(ID, 2.5, 2.5, 2.4)]);
    await __testOnly.tick();

    const st = _internalGetMatchStates().get(ID);
    expect(st).toBeDefined();
    expect(st!.history.length).toBe(1);
    // The normal loop seeds metadata for retained manual hydration.
    expect(st!.lastMeta).toBeDefined();
    expect(getWatchlistMatchesForVolume()).toHaveLength(1);

    primaryBody = ouXml([ouRow(ID, 2.5, 2.45, 2.4)]); // different odds → fresh tick
    await __testOnly.tick();
    expect(st!.history.length).toBe(2);
  });
});

describe("manual numeric refreshes", () => {
  const OUTSIDE_ID = "3999999";
  const HISTORICAL_ID = "3068862";

  function response(body: string): Response {
    return {
      ok: true,
      status: 200,
      text: async () => body,
    } as unknown as Response;
  }

  function directHtml(): string {
    return [
      "<title>Regional Home VS Regional Away - Live Score</title>",
      "<script>var leagueName = 'Unknown Regional Competition';",
      "var _homeTeamID = '11'; var _guestTeamID = '22';</script>",
    ].join("");
  }

  function liveScore(): string {
    return JSON.stringify({
      ErrCode: 0, Data: { state: 1, html: "<div class='score'>0</div><div class='score'>0</div>" },
    });
  }

  it("refreshes manual-only odds, score and source clock across paused cycles without an Excapper id", async () => {
    ctl.watchlistIds.add(OUTSIDE_ID);
    let cycle = 0;
    const start = Date.now();
    vi.spyOn(Date, "now").mockImplementation(() => start + cycle * 13_000);
    vi.stubGlobal("fetch", vi.fn(async (input: unknown) => {
      const url = String(input);
      if (url.includes(`/match/live-${OUTSIDE_ID}.html`)) return response(directHtml());
      if (url.includes("type=11")) return response(JSON.stringify({
        ErrCode: 0, Data: {
          state: 3, minute: 57 + cycle,
          html: `<div class='score'>${cycle}</div><div class='score'>2</div>`,
        },
      }));
      if (url.includes("goal8.xml")) return response(ouXml([
        ouRow(OUTSIDE_ID, 3.25, 2.0 + cycle / 10, 1.8),
      ]));
      return response("");
    }));
    for (cycle = 0; cycle < 3; cycle++) {
      await __testOnly.runHyperFocusTick();
      const state = _internalGetMatchStates().get(OUTSIDE_ID)!;
      expect(state.lastMeta).toMatchObject({
        homeScore: cycle, awayScore: 2, clockLabel: String(57 + cycle),
      });
      expect(state.history.at(-1)?.overDecimal).toBeCloseTo(2.0 + cycle / 10);
      expect(state.volumes ?? []).toHaveLength(0);
    }
    vi.mocked(Date.now).mockRestore();
  });

  it("does not resurrect a manual pin removed while metadata is in flight", async () => {
    ctl.watchlistIds.add(OUTSIDE_ID);
    let releaseScore!: (response: Response) => void;
    let entered!: () => void;
    const scoreEntered = new Promise<void>((resolve) => { entered = resolve; });
    vi.stubGlobal("fetch", vi.fn(async (input: unknown) => {
      const url = String(input);
      if (url.includes(`/match/live-${OUTSIDE_ID}.html`)) return response(directHtml());
      if (url.includes("type=11")) {
        entered();
        return new Promise<Response>((resolve) => { releaseScore = resolve; });
      }
      return response("");
    }));
    const pending = requestManualWatchlistRefresh([OUTSIDE_ID]);
    await scoreEntered;
    ctl.watchlistIds.delete(OUTSIDE_ID);
    releaseScore(response(liveScore()));
    await pending;
    expect(_internalGetMatchStates().has(OUTSIDE_ID)).toBe(false);
  });

  it("keeps an out-of-whitelist manual id visible with metadata before odds exist", async () => {
    ctl.watchlistIds.add(OUTSIDE_ID);
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: unknown) => {
        const url = String(input);
        if (url.includes(`/match/live-${OUTSIDE_ID}.html`)) return response(directHtml());
        if (url.includes("type=11")) return response(liveScore());
        return response("");
      }) as unknown as typeof fetch,
    );

    await requestManualWatchlistRefresh([OUTSIDE_ID]);

    const row = getWatchlistLiveSnapshot().entries.find((entry) => entry.matchId === OUTSIDE_ID);
    expect(row).toMatchObject({
      matchId: OUTSIDE_ID,
      status: "loading",
      live: {
        team1: "Regional Home",
        team2: "Regional Away",
        league: "Unknown Regional Competition",
        historyPoints: 0,
        overHk: null,
        underHk: null,
      },
    });
  });

  it("reports historical 3068862 as finished 3-1 without inventing live odds", async () => {
    ctl.watchlistIds.add(HISTORICAL_ID);
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: unknown) => {
        const url = String(input);
        if (url.includes(`/match/live-${HISTORICAL_ID}.html`)) {
          // Metadata is intentionally synthetic test scaffolding; the
          // historical assertion below is limited to the audited 3-1 score,
          // finished state, and absence of a current odds market.
          return response(directHtml());
        }
        if (url.includes("SoccerAjax?type=11")) {
          return response(
            JSON.stringify({
              ErrCode: 0,
              Data: {
                state: -1,
                MatchState: 0,
                html: "<div class='score'>3</div><div class='score'>1</div>",
              },
            }),
          );
        }
        // Historical fixture is deliberately absent from every current odds
        // feed. Returning an empty authentic feed shape verifies no odds are
        // synthesized merely because the match was manually pinned.
        return response("");
      }) as unknown as typeof fetch,
    );

    await requestManualWatchlistRefresh([HISTORICAL_ID]);

    const row = getWatchlistLiveSnapshot().savedEntries.find(
      (entry) => entry.matchId === HISTORICAL_ID,
    );
    expect(row).toMatchObject({
      matchId: HISTORICAL_ID,
      live: null,
    });
    expect(getWatchlistLiveSnapshot().entries).toHaveLength(0);
    expect(_internalGetMatchStates().has(HISTORICAL_ID)).toBe(false);
    expect(getRuntimeArchiveRows()).toContainEqual(expect.objectContaining({
      nowGoalMatchId: HISTORICAL_ID, matchPhase: "Finished", score: "3-1",
    }));
  });

  it("queries and commits Bet365, Crown, and every extra bookmaker on forced refresh", async () => {
    ctl.watchlistIds.add(OUTSIDE_ID);
    const calls: string[] = [];
    const allBooksBody = ouXml([ouRow(OUTSIDE_ID, 2.5, 2.5, 2.4)]);
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: unknown) => {
        const url = String(input);
        calls.push(url);
        if (url.includes(`/match/live-${OUTSIDE_ID}.html`)) return response(directHtml());
        if (url.includes("type=11")) return response(liveScore());
        if (
          url.includes("goal8.xml") ||
          url.includes("goal3.xml") ||
          url.includes("goal31.xml") ||
          url.includes("goal17.xml") ||
          url.includes("goal24.xml") ||
          url.includes("goal42.xml") ||
          url.includes("goal14.xml")
        ) {
          return response(allBooksBody);
        }
        return response("");
      }) as unknown as typeof fetch,
    );

    await requestManualWatchlistRefresh([OUTSIDE_ID]);

    for (const endpoint of ["goal8.xml", "goal3.xml", "goal31.xml", "goal17.xml", "goal24.xml", "goal42.xml", "goal14.xml"]) {
      expect(calls.filter((url) => url.includes(endpoint))).toHaveLength(1);
    }
    const state = _internalGetMatchStates().get(OUTSIDE_ID);
    expect(state?.history).toHaveLength(1);
    expect(state?.benchmarkHistory).toHaveLength(1);
    for (const book of ["Sbobet", "M88", "12Bet", "18Bet", "VSBet"] as const) {
      expect(state?.bookHistory?.get(book)).toHaveLength(1);
    }
  });

  it("retains manual Excapper hydration for an out-of-target manual id", () => {
    ctl.watchlistIds.add(OUTSIDE_ID);
    mergeAltOddsSnapshot(
      new Map([[OUTSIDE_ID, { matchId: OUTSIDE_ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([
        [
          OUTSIDE_ID,
          {
            ...makeMeta(OUTSIDE_ID),
            leagueName: "Unknown Regional Competition",
          },
        ],
      ]),
      { source: "test" },
    );

    expect(getWatchlistMatchesForVolume()).toHaveLength(1);
  });

  it("hydrates an unapproved manual league and exposes totals/shares through the UI API", () => {
    const manualId = OUTSIDE_ID;
    ctl.watchlistIds.add(manualId);
    mergeAltOddsSnapshot(
      new Map([[manualId, { matchId: manualId, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[
        manualId,
        { ...makeMeta(manualId), leagueName: "Verified Regional Competition" },
      ]]),
      { source: "manual-hydration-test" },
    );

    expect(getManualWatchlistMatchesForExcapper()).toEqual([
      expect.objectContaining({
        matchId: manualId,
        team1: "Alpha",
        team2: "Beta",
        league: "Verified Regional Competition",
        nowGoalLine: 2.5,
      }),
    ]);
    expect(
      hydrateManualMatchVolume(
        manualId,
        [{ line: 2.5, over: 1_200, under: 800 }],
        "ex-game-1",
      ),
    ).toBe(true);
    expect(
      getWatchlistLiveSnapshot().entries.find((entry) => entry.matchId === manualId)
        ?.live?.volumes,
    ).toEqual([
      expect.objectContaining({
        line: 2.5,
        over: 1_200,
        under: 800,
        totalVolume: 2_000,
        overSharePct: 60,
        underSharePct: 40,
      }),
    ]);

    expect(clearManualMatchVolumeBinding(manualId)).toBe(true);
    expect(_internalGetMatchStates().get(manualId)?.volumes?.size).toBe(0);
    expect(_internalGetMatchStates().get(manualId)?.excapperGameId).toBeUndefined();

    // Removal invalidates the association immediately; a stale in-flight
    // Excapper fetch may not overwrite the detached manual row.
    ctl.watchlistIds.delete(manualId);
    expect(
      hydrateManualMatchVolume(
        manualId,
        [{ line: 2.5, over: 9_999, under: 1 }],
        "ex-game-1",
      ),
    ).toBe(false);
    expect(_internalGetMatchStates().get(manualId)?.volumes?.size).toBe(0);
  });

  it("binds a unique complete text-only manual fixture for volume enrichment only", () => {
    ctl.manualTextEntries.push({
      label: "Alpha vs Beta",
      fragments: ["alpha", "beta"],
      signature: "txt:alpha|beta",
    });
    mergeAltOddsSnapshot(
      new Map([[OUTSIDE_ID, { matchId: OUTSIDE_ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[OUTSIDE_ID, makeMeta(OUTSIDE_ID)]]),
      { source: "text-manual-hydration-test" },
    );

    expect(getManualWatchlistMatchesForExcapper()).toEqual([
      expect.objectContaining({
        matchId: OUTSIDE_ID,
        diagnosticId: "manual-text:txt:alpha|beta",
        team1: "Alpha",
        team2: "Beta",
        league: "Finland Kakkonen",
      }),
    ]);
    expect(
      hydrateManualMatchVolume(
        OUTSIDE_ID,
        [{ line: 2.5, over: 700, under: 300 }],
        "text-ex-game",
      ),
    ).toBe(true);
    expect(getWatchlistMatchesForVolume()).toHaveLength(1);
    expect(sendTelegram).not.toHaveBeenCalled();
  });

  it("surfaces an ambiguous text-only scanner identity without making it hydratable", () => {
    ctl.manualTextEntries.push({
      label: "Alpha vs Beta",
      fragments: ["alpha", "beta"],
      signature: "txt:alpha|beta",
    });
    for (const id of ["text-1", "text-2"]) {
      mergeAltOddsSnapshot(
        new Map([[id, { matchId: id, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
        new Map([[id, makeMeta(id)]]),
        { source: "ambiguous-text-manual-test" },
      );
    }
    expect(getManualWatchlistMatchesForExcapper()).toEqual([
      {
        matchId: "manual-text:txt:alpha|beta",
        diagnosticId: "manual-text:txt:alpha|beta",
        identityAmbiguous: true,
        team1: "alpha",
        team2: "beta",
        league: "",
        nowGoalLine: null,
      },
    ]);
    expect(sendTelegram).not.toHaveBeenCalled();
  });

  it("hydrates a text-only row directly when no NowGoal numeric state exists", () => {
    ctl.manualTextEntries.push({
      label: "Direct Home vs Direct Away",
      fragments: ["direct home", "direct away"],
      signature: "txt:direct away|direct home",
    });
    expect(getManualWatchlistMatchesForExcapper()).toEqual([
      {
        matchId: "manual-text:txt:direct away|direct home",
        diagnosticId: "manual-text:txt:direct away|direct home",
        team1: "direct home",
        team2: "direct away",
        league: "",
        nowGoalLine: null,
      },
    ]);
    expect(
      hydrateManualMatchVolume(
        "manual-text:txt:direct away|direct home",
        [{ line: 3.5, over: 900, under: 600 }],
        "direct-game",
      ),
    ).toBe(true);
    const row = getWatchlistLiveSnapshot().savedEntries.find(
      (entry) => entry.signature === "txt:direct away|direct home",
    );
    expect(row?.live).toBeNull();
    expect(row?.excapperVolumes).toEqual([
      expect.objectContaining({
        line: 3.5,
        over: 900,
        under: 600,
        totalVolume: 1_500,
        overSharePct: 60,
        underSharePct: 40,
      }),
    ]);
    expect(sendTelegram).not.toHaveBeenCalled();
  });

  it("coalesces duplicate forced refreshes into one bounded all-book request set", async () => {
    ctl.watchlistIds.add(OUTSIDE_ID);
    const calls: string[] = [];
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: unknown) => {
        const url = String(input);
        calls.push(url);
        if (url.includes(`/match/live-${OUTSIDE_ID}.html`)) return response(directHtml());
        if (url.includes("type=11")) return response(liveScore());
        if (url.includes("goal8.xml")) return response(ouXml([ouRow(OUTSIDE_ID, 2.5, 2.5, 2.4)]));
        if (
          url.includes("goal3.xml") ||
          url.includes("goal31.xml") ||
          url.includes("goal17.xml") ||
          url.includes("goal24.xml") ||
          url.includes("goal42.xml") ||
          url.includes("goal14.xml")
        ) {
          return response(ouXml([ouRow(OUTSIDE_ID, 2.5, 2.5, 2.4)]));
        }
        return response("");
      }) as unknown as typeof fetch,
    );

    await Promise.all([
      requestManualWatchlistRefresh([OUTSIDE_ID]),
      requestManualWatchlistRefresh([OUTSIDE_ID]),
    ]);

    for (const endpoint of ["goal8.xml", "goal3.xml", "goal31.xml", "goal17.xml", "goal24.xml", "goal42.xml", "goal14.xml"]) {
      expect(calls.filter((url) => url.includes(endpoint))).toHaveLength(1);
    }
    expect(_internalGetMatchStates().get(OUTSIDE_ID)?.history).toHaveLength(1);
  });

  it("keeps an unchanged-score manual match finished against inferred-live metadata", async () => {
    ctl.watchlistIds.add(OUTSIDE_ID);
    let state = 1;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: unknown) => {
        const url = String(input);
        if (url.includes(`/match/live-${OUTSIDE_ID}.html`)) return response(directHtml());
        if (url.includes("SoccerAjax?type=11")) {
          return response(
            JSON.stringify({
              ErrCode: 0,
              Data: {
                state,
                html: "<div class='score'>1</div><div class='score'>0</div>",
              },
            }),
          );
        }
        if (url.includes("goal")) {
          return response(ouXml([ouRow(OUTSIDE_ID, 2.5, 2.5, 2.4)]));
        }
        return response("");
      }) as unknown as typeof fetch,
    );

    await requestManualWatchlistRefresh([OUTSIDE_ID]);
    expect(_internalGetMatchStates().get(OUTSIDE_ID)?.lastMeta).toMatchObject({
      homeScore: 1,
      awayScore: 0,
      isLive: true,
      state: 1,
      liveStateSource: "explicit",
    });

    state = -1;
    await __testOnly.runWatchlistScoreRefreshTick();
    expect(_internalGetMatchStates().has(OUTSIDE_ID)).toBe(false);
    expect(ctl.watchlistIds.has(OUTSIDE_ID)).toBe(true);
    expect(getRuntimeArchiveRows()).toContainEqual(expect.objectContaining({
      nowGoalMatchId: OUTSIDE_ID, matchPhase: "Finished", score: "1-0",
    }));

    // A parallel bulk/alt writer only has kickoff-derived live inference.
    // It may refresh odds/labels, but cannot resurrect explicit finished state.
    mergeAltOddsSnapshot(
      new Map([
        [
          OUTSIDE_ID,
          { matchId: OUTSIDE_ID, line: 2.5, overDecimal: 2.45, underDecimal: 2.35 },
        ],
      ]),
      new Map([
        [
          OUTSIDE_ID,
          {
            ...makeMeta(OUTSIDE_ID),
            leagueName: "Unknown Regional Competition",
            isLive: true,
          },
        ],
      ]),
      { source: "inferred-live-regression", altStaleAfterMs: 0 },
    );
    expect(_internalGetMatchStates().has(OUTSIDE_ID)).toBe(false);
  });
});

describe("scanner HTTP cancellation and recovery", () => {
  function pendingUntilAbort(init: RequestInit | undefined): Promise<Response> {
    return new Promise<Response>((_resolve, reject) => {
      const abort = () => {
        const err = new Error("This operation was aborted");
        err.name = "AbortError";
        reject(err);
      };
      if (init?.signal?.aborted) {
        abort();
      } else {
        init?.signal?.addEventListener("abort", abort, { once: true });
      }
    });
  }

  it("reports an internal request timeout distinctly from AbortError cancellation", async () => {
    vi.useFakeTimers();
    try {
      vi.stubGlobal(
        "fetch",
        vi.fn((_input: unknown, init?: RequestInit) => pendingUntilAbort(init)),
      );

      const request = fetchRaw("https://mirror.example/goal8.xml");
      // Attach the rejection consumer before advancing fake time. The timer
      // callback can settle the promise synchronously, and waiting to call
      // expect(...).rejects until afterward makes Node report an unhandled
      // rejection even though the assertion eventually handles it.
      const rejection = request.catch((error: unknown) => error);
      await vi.advanceTimersByTimeAsync(HTTP_REQUEST_TIMEOUT_MS + 1);

      const error = await rejection;
      expect(error).toBeInstanceOf(UpstreamTimeoutError);
      expect(error).toMatchObject({
        name: "UpstreamTimeoutError",
        code: "UPSTREAM_TIMEOUT",
      });
    } finally {
      vi.useRealTimers();
    }
  });

  it("preserves expected AbortError cancellation without poisoning scanner failure state", async () => {
    const requestAbort = new AbortController();
    vi.stubGlobal(
      "fetch",
      vi.fn((_input: unknown, init?: RequestInit) => pendingUntilAbort(init)),
    );

    const request = fetchRaw(
      "https://mirror.example/goal8.xml",
      0,
      requestAbort.signal,
    );
    const rejection = request.catch((error: unknown) => error);
    requestAbort.abort();

    await expect(rejection).resolves.toMatchObject({ name: "AbortError" });
  });

  it("retries a transient upstream 5xx and resolves on the recovery response", async () => {
    vi.useFakeTimers();
    try {
      let calls = 0;
      vi.stubGlobal(
        "fetch",
        vi.fn(async () => {
          calls++;
          if (calls === 1) return { ok: false, status: 503 };
          return { ok: true, status: 200, text: async () => "healthy" };
        }) as unknown as typeof fetch,
      );

      const request = fetchRaw("https://mirror.example/goal8.xml");
      await vi.advanceTimersByTimeAsync(500);

      await expect(request).resolves.toBe("healthy");
      expect(calls).toBe(2);
    } finally {
      vi.useRealTimers();
    }
  });

  it("keeps a healthy primary tick when one optional bookmaker fails", async () => {
    __testOnly.reset();
    scannerStats.consecutiveFailures = 0;
    scannerStats.lastError = null;
    setGlobalScannerPaused(true, { force: true });
    ctl.watchlistIds.add(ID);
    mergeAltOddsSnapshot(
      new Map([[ID, { matchId: ID, line: 2.5, overDecimal: 2.5, underDecimal: 2.4 }]]),
      new Map([[ID, makeMeta(ID)]]),
      { source: "test" },
    );
    primaryBody = ouXml([ouRow(ID, 2.5, 2.5, 2.4)]);

    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: unknown) => {
        const u = String(input);
        if (u.includes("goal31.xml")) throw new Error("Sbobet unavailable");
        return {
          ok: true,
          status: 200,
          text: async () => (u.includes("goal8.xml") ? primaryBody : ""),
        };
      }) as unknown as typeof fetch,
    );

    await expect(__testOnly.runHyperFocusTick()).resolves.toBe(true);
    expect(scannerStats.consecutiveFailures).toBe(0);
    expect(scannerStats.lastError).toBeNull();
    expect(scannerStats.perBookFetch.Sbobet.fail).toBeGreaterThan(0);
  });

  it("records a real primary timeout instead of the opaque abort message", async () => {
    vi.useFakeTimers();
    try {
      __testOnly.reset();
      scannerStats.consecutiveFailures = 0;
      scannerStats.lastError = null;
      vi.stubGlobal(
        "fetch",
        vi.fn((_input: unknown, init?: RequestInit) => pendingUntilAbort(init)),
      );

      const tick = __testOnly.tick();
      await vi.advanceTimersByTimeAsync(Math.max(HTTP_REQUEST_TIMEOUT_MS, EXTRA_BOOK_TIMEOUT_MS) + 1);
      await tick;

      expect(scannerStats.consecutiveFailures).toBe(1);
      expect(scannerStats.lastError).toContain("Upstream request timed out");
      expect(scannerStats.lastError).not.toBe("This operation was aborted");
    } finally {
      vi.useRealTimers();
    }
  });
});
