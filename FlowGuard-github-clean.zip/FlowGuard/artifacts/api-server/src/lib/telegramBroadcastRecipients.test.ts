import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import pinnedRecipients from "./telegramBroadcastRecipients.json";

const OWNER = "742987633";
const FRIEND = "6277358005";
// Test fixture only: NOT the real group's ID and NOT included in deployed config.
const FIXTURE_GROUP = "-1001234567890";
const cards = [
  "👁 ODDS RADAR\nTest match",
  "💎 SMART EXCAPPER\nTest match",
  "🔴 SMART MONEY\nTest match",
  "Scanner alert\nTest match",
];

let subscriberChatIds: number[] = [];
const removeSubscriber = vi.fn(async (_id: number) => true);
vi.mock("./logger", () => ({
  logger: { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() },
}));
vi.mock("./controls", () => ({ getControls: () => ({ alertsMuted: false }) }));
vi.mock("./telegramSubscribers", () => ({
  ensureSubscribersLoaded: vi.fn(async () => {}),
  listSubscriberChatIds: () => subscriberChatIds,
  removeSubscriber: (id: number) => removeSubscriber(id),
}));

type Telegram = typeof import("./telegram");
let telegram: Telegram;
let sent: Array<{ chatId: string; message: string }>;

beforeEach(async () => {
  vi.resetModules();
  vi.stubEnv("TELEGRAM_TOKEN", "fake-test-token");
  vi.stubEnv("TELEGRAM_CHAT_ID", OWNER);
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("REPLIT_DEPLOYMENT", "1");
  subscriberChatIds = [];
  removeSubscriber.mockClear();
  sent = [];
  vi.stubGlobal("fetch", vi.fn(async (_url: unknown, init?: RequestInit) => {
    const body = JSON.parse(String(init?.body)) as { chat_id: string; text: string };
    sent.push({ chatId: body.chat_id, message: body.text });
    return new Response("{}", { status: 200 });
  }));
  telegram = await import("./telegram");
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("additive Telegram broadcast audience", () => {
  it("bundles both verified DMs, including the mandatory owner, without guessing a group", async () => {
    expect(pinnedRecipients.chatIds).toContain(OWNER);
    expect(pinnedRecipients.chatIds).toContain(FRIEND);
    expect(pinnedRecipients.chatIds).toHaveLength(2);
    expect(pinnedRecipients.chatIds).not.toContain(FIXTURE_GROUP);

    const snapshot = await telegram.snapshotTelegramRecipients();
    expect(snapshot).toEqual({ ok: true, recipients: [
      { id: OWNER, primary: true },
      { id: FRIEND, primary: false },
    ] });
    for (const card of cards) {
      sent.length = 0;
      expect(await telegram.sendTelegram(card)).toMatchObject({
        status: "delivered", primaryDelivered: true, attempted: 2, delivered: 2,
      });
      expect(sent).toEqual([
        { chatId: OWNER, message: card },
        { chatId: FRIEND, message: card },
      ]);
    }
  });

  it("unions the primary, both pinned chats and existing subscribers with deduplication", async () => {
    subscriberChatIds = [Number(FRIEND), 999111222];
    const snapshot = await telegram.snapshotTelegramRecipients();
    expect(snapshot).toEqual({ ok: true, recipients: [
      { id: OWNER, primary: true },
      { id: FRIEND, primary: false },
      { id: "999111222", primary: false },
    ] });
    await telegram.sendTelegram("Scanner alert");
    expect(sent.map((entry) => entry.chatId)).toEqual([OWNER, FRIEND, "999111222"]);
  });

  it("simulates a third, negative group ID for every card without installing a made-up ID", async () => {
    vi.doMock("./telegramBroadcastRecipients.json", () => ({
      default: { chatIds: [...pinnedRecipients.chatIds, FIXTURE_GROUP] },
    }));
    try {
      vi.resetModules();
      const withFixtureGroup = await import("./telegram");
      const snapshot = await withFixtureGroup.snapshotTelegramRecipients();
      expect(snapshot).toEqual({ ok: true, recipients: [
        { id: OWNER, primary: true },
        { id: FRIEND, primary: false },
        { id: FIXTURE_GROUP, primary: false },
      ] });
      for (const card of cards) {
        sent.length = 0;
        expect(await withFixtureGroup.sendTelegram(card)).toMatchObject({
          status: "delivered", primaryDelivered: true, attempted: 3, delivered: 3,
        });
        expect(sent.map((entry) => entry.chatId)).toEqual([OWNER, FRIEND, FIXTURE_GROUP]);
        expect(sent.map((entry) => entry.message)).toEqual([card, card, card]);
      }
    } finally {
      vi.doUnmock("./telegramBroadcastRecipients.json");
    }
  });

  it("does not prune a pinned friend on 403 or prevent the owner's delivery", async () => {
    vi.stubGlobal("fetch", vi.fn(async (_url: unknown, init?: RequestInit) => {
      const body = JSON.parse(String(init?.body)) as { chat_id: string };
      return new Response("{}", { status: body.chat_id === FRIEND ? 403 : 200 });
    }));
    const result = await telegram.sendTelegram("blocked friend");
    expect(result).toMatchObject({ primaryDelivered: true, blocked: 1, attempted: 2 });
    expect(removeSubscriber).not.toHaveBeenCalled();
    expect((await telegram.snapshotTelegramRecipients())).toMatchObject({
      ok: true, recipients: [{ id: OWNER, primary: true }, { id: FRIEND, primary: false }],
    });
  });

  it("keeps dev send-gate closed even with configured recipients", async () => {
    vi.stubEnv("NODE_ENV", "development");
    const result = await telegram.sendTelegram("not sent");
    expect(result).toMatchObject({ reason: "non_production", attempted: 0 });
    expect(fetch).not.toHaveBeenCalled();
  });
});