import { escapeMdV2 } from "./telegram";

export type UnifiedAlertSide = "OVER" | "UNDER";

export interface UnifiedInflow {
  matchId: string;
  line: number;
  side: UnifiedAlertSide;
  /** Native-feed EUR amount for the exact transaction; no FX conversion. */
  single: number;
  /** Native-feed EUR cumulative amount for this market; no FX conversion. */
  total: number;
  minute: string | null;
  observedAt: number;
}

export interface UnifiedOddsPoint {
  ts: number;
  line: number;
  odds: number;
}

/** Independently observed, exact-market price movement at one bookmaker.
 * Only confirmed moving bookmakers belong here; never fill from another book. */
export interface RadarBookMovement {
  cid: string;
  bookmaker: string;
  type: "drop" | "rise" | "revert";
  from: number;
  to: number;
  percent: number;
  quoteAt: number;
  history: ReadonlyArray<{ ts: number; odds: number }>;
  baseline?: number;
  peak?: number;
  durationMs?: number;
}

export interface UnifiedAlertInput {
  /** Omitted for the original scanner SMART MONEY card. */
  source?: "scanner" | "excapper-global" | "odds-radar";
  /** Radar-only 1X2 selection. OU callers retain their original side and line contract. */
  market?: { kind: "1X2"; outcome: "HOME" | "AWAY" };
  bookmaker?: string;
  isRepeat?: boolean;
  alertAt?: number;
  /** Observation timestamp of the trigger quote, distinct from Telegram send time. */
  quoteAt?: number;
  oneX2Timeline?: ReadonlyArray<{ ts: number; odds: number }>;
  /** Price evidence for every moving bookmaker; an empty list is not a signal. */
  radarBooks?: ReadonlyArray<RadarBookMovement>;
  /** The radar's verified, exact-market movement (not inferred by formatter). */
  radarMovement?: { type: "drop" | "rise" | "line" | "revert"; from: number; to: number; percent?: number };
  matchId: string;
  league: string;
  home: string;
  away: string;
  isLive: boolean;
  homeScore: number | null;
  awayScore: number | null;
  minute: string | null;
  side: UnifiedAlertSide;
  line: number;
  timeline: ReadonlyArray<UnifiedOddsPoint>;
  /** Authentic current exact-line quote when no historical ticks exist. */
  currentQuote?: UnifiedOddsPoint | null;
  /** Present when confirmation is a primary OU handicap move rather than a
   * same-line price shortening. */
  lineMovement?: { from: number; to: number; magnitude: number };
  inflow?: UnifiedInflow | null;
  /** Only set to 300000 when the inflow amount truly spans five minutes. */
  volumeWindowMs?: number;
  /** Optional pre-bet evidence for standalone global cards only. */
  prebet?: {
    betTime: number;
    inflow15m: number;
    inflow60m: number;
    betCount15m: number;
    observationDepth: number;
    firstObservedAt: number | null;
    dateTimeIsApproximate?: boolean;
  };
  link: string | null;
}

const INFLOW_TTL_MS = 15 * 60_000;
/**
 * Odds evidence belongs to the five-minute signal window. The earliest exact
 * market quote in this bounded window is either the quote nearest five minutes
 * before the trigger or, for a younger market, its authentic trigger baseline.
 */
export const ODDS_DROP_WINDOW_MS = 5 * 60_000;
/** A delayed/recovered alert must not turn an old quote into a current signal. */
export const ODDS_QUOTE_MAX_AGE_MS = 2 * 60_000;
const EVENT_DEDUP_TTL_MS = 30 * 60_000;
const MAX_REGISTRY_SIZE = 2_000;
const inflows = new Map<string, UnifiedInflow>();
const seenTransactions = new Map<string, number>();
const sentEvents = new Map<string, number>();

function marketKey(matchId: string, line: number, side: UnifiedAlertSide): string {
  return `${matchId}:${line}:${side}`;
}

function pruneRegistry(registry: Map<string, number>, cutoff: number): void {
  for (const [key, timestamp] of registry) {
    if (timestamp < cutoff) registry.delete(key);
  }
  while (registry.size > MAX_REGISTRY_SIZE) {
    const oldest = registry.keys().next().value as string | undefined;
    if (oldest === undefined) break;
    registry.delete(oldest);
  }
}

function pruneInflows(now: number): void {
  for (const [key, inflow] of inflows) {
    if (now - inflow.observedAt > INFLOW_TTL_MS) inflows.delete(key);
  }
  while (inflows.size > MAX_REGISTRY_SIZE) {
    const oldest = inflows.keys().next().value as string | undefined;
    if (oldest === undefined) break;
    inflows.delete(oldest);
  }
}

/**
 * Captures authentic Excapper transaction data for the next odds-drop alert.
 * This function intentionally performs no I/O: a volume transaction can enrich
 * a consolidated alert, but can never emit a standalone Telegram message.
 */
export function recordUnifiedInflow(input: {
  matchId: string;
  line: number;
  side: UnifiedAlertSide;
  single: number;
  total: number;
  minute?: string | null;
  observedAt?: number;
}): boolean {
  if (
    !input.matchId ||
    !Number.isFinite(input.line) ||
    !Number.isFinite(input.single) ||
    !Number.isFinite(input.total) ||
    input.single <= 0 ||
    input.total <= 0
  ) {
    return false;
  }

  const observedAt = input.observedAt ?? Date.now();
  // Excapper's cumulative total is a natural transaction identity. This
  // prevents the same row seen in consecutive scrapes from refreshing its TTL.
  const transactionKey = `${marketKey(input.matchId, input.line, input.side)}:${input.total}`;
  if (seenTransactions.has(transactionKey)) return false;
  seenTransactions.set(transactionKey, observedAt);
  pruneRegistry(seenTransactions, observedAt - EVENT_DEDUP_TTL_MS);

  const key = marketKey(input.matchId, input.line, input.side);
  // Refresh insertion order as well as value so hard-cap eviction remains LRU.
  inflows.delete(key);
  inflows.set(key, {
    matchId: input.matchId,
    line: input.line,
    side: input.side,
    single: input.single,
    total: input.total,
    minute: input.minute?.trim() || null,
    observedAt,
  });
  pruneInflows(observedAt);
  return true;
}

export function getRecentUnifiedInflow(
  matchId: string,
  line: number,
  side: UnifiedAlertSide,
  now = Date.now(),
): UnifiedInflow | null {
  pruneInflows(now);
  const key = marketKey(matchId, line, side);
  const inflow = inflows.get(key);
  if (!inflow) return null;
  return inflow;
}

export interface PositiveOddsDrop {
  initial: UnifiedOddsPoint;
  current: UnifiedOddsPoint;
  percent: number;
}

/**
 * Resolve a real decimal-odds shortening for this exact line and side.
 *
 * The baseline is the earliest quote inside the bounded five-minute event
 * window: nearest to five minutes prior when that history exists, otherwise
 * the authentic trigger baseline from the shorter history. It is never an
 * arbitrary all-time high. The current quote must be genuinely newer, fresh
 * at admission time, and lower. Callers construct the timeline for one side,
 * so no opposite-side or other-line quote can enter the calculation.
 */
export function resolvePositiveOddsDrop(
  input: UnifiedAlertInput,
  referenceAt: number | null = Date.now(),
): PositiveOddsDrop | null {
  const history = normalizedTimeline(input.timeline, input.line);
  const suppliedCurrent =
    input.currentQuote?.line === input.line &&
    Number.isFinite(input.currentQuote.ts) &&
    Number.isFinite(input.currentQuote.odds) &&
    input.currentQuote.odds > 1
      ? input.currentQuote
      : null;
  const current = suppliedCurrent ?? history[history.length - 1];
  if (
    !current ||
    (referenceAt !== null && current.ts > referenceAt + 5_000) ||
    (referenceAt !== null && referenceAt - current.ts > ODDS_QUOTE_MAX_AGE_MS)
  ) return null;

  const windowStart = current.ts - ODDS_DROP_WINDOW_MS;
  const initial = history.find(
    (point) => point.ts >= windowStart && point.ts < current.ts,
  );
  if (!initial || !(initial.odds > current.odds)) return null;
  const percent = ((initial.odds - current.odds) / initial.odds) * 100;
  if (!Number.isFinite(percent) || percent <= 0) return null;
  return { initial, current, percent };
}

function eventKey(input: UnifiedAlertInput, now: number | null = Date.now()): string | null {
  const drop = resolvePositiveOddsDrop(input, now);
  if (!drop) return null;
  return [
    input.matchId,
    input.side,
    input.line,
    drop.initial.odds.toFixed(3),
    drop.current.odds.toFixed(3),
    input.lineMovement ? `${input.lineMovement.from}>${input.lineMovement.to}` : "",
  ].join(":");
}

/** Returns false when the same consolidated market event was already sent. */
export function claimUnifiedAlertEvent(input: UnifiedAlertInput, now = Date.now()): boolean {
  const key = eventKey(input, now);
  if (!key) return false;
  const previous = sentEvents.get(key);
  if (previous != null && now - previous < EVENT_DEDUP_TTL_MS) return false;
  sentEvents.set(key, now);
  pruneRegistry(sentEvents, now - EVENT_DEDUP_TTL_MS);
  return true;
}

/** Release a claim when awaited delivery fails so the same event can retry. */
export function releaseUnifiedAlertEvent(input: UnifiedAlertInput): void {
  const key = eventKey(input, null);
  if (key) sentEvents.delete(key);
}

function normalizedTimeline(
  timeline: ReadonlyArray<UnifiedOddsPoint>,
  line: number,
): UnifiedOddsPoint[] {
  const sorted = timeline
    .filter(
      (point) =>
        point.line === line &&
        Number.isFinite(point.ts) &&
        Number.isFinite(point.odds) &&
        point.odds > 1,
    )
    .sort((a, b) => a.ts - b.ts);

  // A scanner tick with an unchanged quote adds no information to an odds-drop
  // table. Keep only actual price transitions. In particular, preserve the
  // FIRST timestamp for a run of unchanged odds: replacing it with every later
  // poll understates the event's true duration.
  const changed: UnifiedOddsPoint[] = [];
  for (const point of sorted) {
    const previous = changed[changed.length - 1];
    if (!previous || previous.odds !== point.odds) {
      changed.push(point);
    }
  }
  return changed;
}

function resolvedExactMarketTimeline(input: UnifiedAlertInput): UnifiedOddsPoint[] {
  const history = input.timeline
    .filter((point) =>
      point.line === input.line &&
      Number.isFinite(point.ts) &&
      Number.isFinite(point.odds) &&
      point.odds > 1
    )
    .sort((a, b) => a.ts - b.ts);
  const suppliedCurrent =
    input.currentQuote?.line === input.line &&
    Number.isFinite(input.currentQuote.ts) &&
    Number.isFinite(input.currentQuote.odds) &&
    input.currentQuote.odds > 1
      ? input.currentQuote
      : null;
  const current = suppliedCurrent ?? history[history.length - 1];
  if (!current) return [];
  const initial = history.find(
    (point) =>
      point.ts >= current.ts - ODDS_DROP_WINDOW_MS &&
      point.ts < current.ts,
  );
  return initial ? [initial, current] : [];
}

/**
 * Prefer the scanner's own live metadata for the displayed minute. NowGoal's
 * bulk payload exposes kickoff rather than a clock, so mark the derived value
 * with "~" instead of presenting it as an exact upstream minute. Fall back to
 * Excapper's literal minute only when scanner metadata cannot provide one.
 */
export function resolveUnifiedAlertMinute(
  meta: {
    isLive: boolean;
    kickoffMs: number | null;
    clockLabel?: string | null;
    state?: number | null;
  },
  excapperMinute: string | null | undefined,
  _now = Date.now(),
): string | null {
  if (meta.isLive && meta.state === 2) return "HT";
  const fixtureClock = normalizeFixtureClock(meta.clockLabel);
  if (fixtureClock) return fixtureClock;
  if (meta.isLive) {
    // Kickoff time is not an elapsed clock. Preserve only an observed phase.
    return "Live";
  }
  return excapperMinute?.trim() || null;
}

/**
 * Canonical display form for fixture-header clocks. This deliberately accepts
 * only observed values; it never derives elapsed minutes from wall-clock time.
 */
export function normalizeFixtureClock(value: unknown): string | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const raw = String(value).trim();
  if (!raw) return null;
  const compact = raw
    .replace(/[’′]/g, "'")
    .replace(/\s+/g, "")
    .toLowerCase();
  if (/^(?:ht|half-?time|halftime)$/.test(compact)) return "HT";
  if (/^(?:live|inplay|in-play)$/.test(compact)) return "Live";
  if (/^(?:secondhalf|second-half|2ndhalf|2h)$/.test(compact)) return "2H";
  if (/^(?:firsthalf|first-half|1sthalf|1h)$/.test(compact)) return "1H";
  const minute = /^(\d{1,3})(?:\+(\d{1,2}))?'?$/.exec(compact);
  if (!minute) return null;
  const base = Number(minute[1]);
  const added = minute[2] === undefined ? null : Number(minute[2]);
  if (!Number.isFinite(base) || base < 0 || base > 150) return null;
  if (added !== null && (!Number.isFinite(added) || added < 0 || added > 30)) return null;
  return added === null ? String(base) : `${base}+${added}`;
}

function clock(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function amount(value: number): string {
  return Math.round(value).toLocaleString("en-US");
}

function formatLine(line: number): string {
  return line % 1 === 0 ? line.toFixed(1) : String(line);
}

function observedOdds(points: ReadonlyArray<{ ts: number; odds: number }>): { ts: number; odds: number }[] {
  return [...points]
    .filter((point) => Number.isFinite(point.ts) && Number.isFinite(point.odds) && point.odds > 1)
    .sort((a, b) => a.ts - b.ts);
}

function movementEmoji(type: "drop" | "rise" | "revert"): string {
  return type === "revert" ? "⚡" : type === "drop" ? "📉" : "📈";
}

function signedChange(from: number, to: number): string {
  const percent = (to - from) / from * 100;
  const precision = Math.abs(percent) < 0.1 && percent !== 0 ? 2 : 1;
  return `${percent > 0 ? "+" : ""}${percent.toFixed(precision)}%`;
}

function hasConfirmedRevert(book: RadarBookMovement): boolean {
  if (book.baseline === undefined || book.peak === undefined || book.durationMs === undefined ||
      !Number.isFinite(book.baseline) || book.baseline <= 1 ||
      !Number.isFinite(book.peak) || book.peak <= 1 ||
      !Number.isFinite(book.durationMs) || book.durationMs < 0) return false;
  const excursion = book.peak - book.baseline;
  return excursion !== 0 &&
    Math.sign(book.to - book.from) === -Math.sign(excursion) &&
    Math.abs(book.to - book.baseline) < Math.abs(excursion);
}

/** Formatting never invents market evidence; this does not affect admission/claim logic. */
export function formatUnifiedAlert(input: UnifiedAlertInput): string {
  const isRadar = input.source === "odds-radar";
  const movement = isRadar ? input.radarMovement : undefined;
  if (isRadar && (!movement || movement.type === "line")) {
    throw new Error("Odds radar requires a price drop, rise or revert");
  }
  const isOneX2 = isRadar && input.market?.kind === "1X2";
  const label = isOneX2
    ? input.market?.outcome === "HOME" ? "Победа хозяев" : "Победа гостей"
    : `${input.side === "OVER" ? "Тотал больше" : "Тотал меньше"} ${formatLine(input.line)}`;
  // Standalone global transactions may be observed later than their actual
  // bet: show only evidence available at the genuine bet time.
  const prebet = input.source === "excapper-global" ? input.prebet : undefined;
  const cutoff = prebet?.betTime ?? Infinity;
  const exact = isOneX2
    ? observedOdds((input.oneX2Timeline ?? []).filter((point) => point.ts <= cutoff))
    : observedOdds(input.timeline.filter((point) => point.line === input.line && point.ts <= cutoff));
  const current = !isOneX2 && input.currentQuote?.line === input.line &&
    input.currentQuote.ts <= cutoff && Number.isFinite(input.currentQuote.ts) &&
    Number.isFinite(input.currentQuote.odds) && input.currentQuote.odds > 1
    ? input.currentQuote : null;
  if (current && (exact.length === 0 || current.ts > exact[exact.length - 1]!.ts)) exact.push(current);
  // For SMART MONEY, baseline selection must stay the exact five-minute
  // selection used by the existing admission logic (not an all-time high).
  const pair = !isRadar ? resolvedExactMarketTimeline({
    ...input,
    timeline: input.timeline.filter((point) => point.ts <= cutoff),
    currentQuote: current,
  }) : [];
  const from = movement?.from ?? (pair.length === 2 ? pair[0]!.odds : null);
  const to = movement?.to ?? (pair.length === 2 ? pair[1]!.odds : current?.odds ?? null);
  const validFrom = from !== null && Number.isFinite(from) && from > 1;
  const validTo = to !== null && Number.isFinite(to) && to > 1;
  const percent = validFrom && validTo ? ((to! - from!) / from!) * 100 : null;
  const precision = percent !== null && Math.abs(percent) < 0.1 && percent !== 0 ? 2 : 1;
  const signed = percent === null ? "—" : `${percent > 0 ? "+" : ""}${percent.toFixed(precision)}%`;
  const direction = movement?.type === "revert" ? "⚡" :
    percent === null ? "❔" : percent < 0 ? "📉" : percent > 0 ? "📈" : "➡️";
  const score = Number.isInteger(input.homeScore) && Number.isInteger(input.awayScore)
    ? `${input.homeScore}:${input.awayScore}` : "—";
  const normalizedMinute = normalizeFixtureClock(input.minute) ?? (input.isLive ? "Live" : "—");
  const minute = /^(?:\d{1,3})(?:\+\d{1,2})?$/.test(normalizedMinute)
    ? `${normalizedMinute}'` : normalizedMinute;
  // Header is the dispatch time, not the upstream quote or an Excapper bet
  // timestamp whose timezone/year may be approximate.
  const eventAt = Number.isFinite(input.alertAt) ? input.alertAt! : Date.now();
  const header = isRadar ? "👁 ODDS RADAR" :
    input.source === "excapper-global" ? "💎 SMART EXCAPPER" : "🔴 SMART MONEY";

  // The detector passes only moving books. Never fabricate a quote from a
  // quiet book or mix one company's history into another company's alert.
  const books = input.radarBooks?.filter((book) =>
    book.cid && book.bookmaker.trim() &&
    // A RADAR card and its history contain only independently confirmed books
    // of the trigger's movement type, never ordinary moves on a revert card.
    (!isRadar || book.type === movement?.type) &&
    Number.isFinite(book.from) && book.from > 1 &&
    Number.isFinite(book.to) && book.to > 1 &&
    Number.isFinite(book.quoteAt) && book.quoteAt <= eventAt + 5_000 &&
    (isRadar && book.type === "revert" ? hasConfirmedRevert(book) :
      book.from !== book.to || (book.type === "revert" &&
        Number.isFinite(book.peak) && book.peak! > 1 &&
        book.peak !== (book.baseline ?? book.from))) &&
    Math.sign(book.to - book.from) === (book.type === "drop" ? -1 : book.type === "rise" ? 1 : Math.sign(book.to - book.from)),
  ) ?? [];
  const ordered = [...books].sort((a, b) =>
    Math.abs(((b.type === "revert" ? b.peak ?? b.to : b.to) - (b.baseline ?? b.from)) / (b.baseline ?? b.from)) -
    Math.abs(((a.type === "revert" ? a.peak ?? a.to : a.to) - (a.baseline ?? a.from)) / (a.baseline ?? a.from)) ||
    a.cid.localeCompare(b.cid));
  const strongest = ordered[0];
  const observedTriggerAt = strongest?.quoteAt ?? input.quoteAt ?? (isRadar ? null :
    pair.length === 2 ? pair[1]!.ts : current?.ts ?? null);
  // Five actual observations through the trigger quote (including it if the
  // source supplied it), never a future quote or a post-bet observation.
  const evidence = strongest ? observedOdds(strongest.history.filter((point) =>
    point.ts <= cutoff && point.ts <= eventAt)) : exact.filter((point) => point.ts <= eventAt);
  const throughTrigger = evidence.filter((point) =>
    observedTriggerAt === null || point.ts <= observedTriggerAt);
  const history = throughTrigger.slice(-5);
  const marketOnly = ordered.length === 0 && (input.radarBooks !== undefined ||
    (isRadar && movement?.type === "revert") ||
    (validFrom && validTo && from === to) ||
    (input.source === "excapper-global" && !validFrom && !validTo));
  const lines = [
    `${header} · ${escapeMdV2(clock(eventAt))}`,
    `🏆 ${escapeMdV2(input.league || "—")}`,
    `⚽️ ${escapeMdV2(input.home)} — ${escapeMdV2(input.away)} · ${escapeMdV2(`${score} (${minute})`)}`,
  ];
  if (ordered.length === 1) {
    const book = strongest!;
    const detail = book.type === "revert" && book.peak != null &&
      Number.isFinite(book.baseline ?? book.from) && Number.isFinite(book.peak) && book.durationMs != null &&
      Number.isFinite(book.durationMs) && book.durationMs >= 0
      ? `скачок ${(book.baseline ?? book.from).toFixed(2)} → ${book.peak.toFixed(2)} → ${book.to.toFixed(2)} за ${Math.round(book.durationMs / 60_000)} мин`
      : `${book.from.toFixed(2)} → ${book.to.toFixed(2)} (${signedChange(book.from, book.to)})`;
    lines.push(`${movementEmoji(book.type)} ${escapeMdV2(`${label} · ${book.bookmaker}: ${detail}`)}`);
  } else if (ordered.length > 1) {
    lines.push(escapeMdV2(`${movementEmoji(strongest!.type)} ${label}:`));
    for (const book of ordered) {
      const detail = book.type === "revert" && book.peak != null &&
        Number.isFinite(book.baseline ?? book.from) && Number.isFinite(book.peak) && book.durationMs != null &&
        Number.isFinite(book.durationMs) && book.durationMs >= 0
        ? `скачок ${(book.baseline ?? book.from).toFixed(2)} → ${book.peak.toFixed(2)} → ${book.to.toFixed(2)} за ${Math.round(book.durationMs / 60_000)} мин`
        : `${book.from.toFixed(2)} → ${book.to.toFixed(2)} (${signedChange(book.from, book.to)})`;
      lines.push(`${movementEmoji(book.type)} ${escapeMdV2(`${book.bookmaker}: ${detail}`)}`);
    }
  } else if (marketOnly) {
    lines.push(`📊 ${escapeMdV2(`Рынок: ${label}`)}`);
  } else {
    lines.push(`${direction} ${escapeMdV2(`${label} · ${input.bookmaker?.trim() || "букмекер неизвестен"}: ${validFrom ? from!.toFixed(2) : "—"} → ${validTo ? to!.toFixed(2) : "—"} (${signed})`)}`);
  }
  if (history.length >= 2 && !marketOnly) {
    lines.push(escapeMdV2(`🕘 Как шёл кэф${strongest ? ` (${strongest.bookmaker})` : input.bookmaker ? ` (${input.bookmaker})` : ""}:`));
    for (const point of history) {
      const position = evidence.indexOf(point);
      const preceding = position > 0 ? evidence[position - 1] : null;
      const arrow = preceding
        ? point.odds > preceding.odds ? "📈" : point.odds < preceding.odds ? "📉" : "→"
        : "—";
      lines.push(`  ${escapeMdV2(`${clock(point.ts)} · ${point.odds.toFixed(2)} ${arrow}`)}`);
    }
  }
  if (!isRadar) {
    const inflow = input.inflow;
    const knownSingle = inflow && Number.isFinite(inflow.single) && inflow.single > 0;
    const knownTotal = inflow && Number.isFinite(inflow.total) && inflow.total > 0;
    const volumeText = input.source === "excapper-global"
      ? `Вливание: ${knownSingle ? `+€${amount(inflow.single)}` : "—"} ${input.volumeWindowMs === 300_000 ? "за 5 мин" : "за раз"} / ${knownTotal ? `€${amount(inflow.total)}` : "—"} всего`
      : `Excapper ${knownSingle ? `+€${amount(inflow.single)}` : "—"} за раз / ${knownTotal ? `€${amount(inflow.total)}` : "—"} всего`;
    if (input.source === "excapper-global" && marketOnly) {
      lines.splice(3, 0, `💰 ${escapeMdV2(volumeText)}`);
    } else {
      lines.push(`💰 ${escapeMdV2(volumeText)}`);
    }
  }
  if (input.isRepeat) lines.push(escapeMdV2("🔁 повторный сигнал"));
  lines.push(input.link
    ? `🔗 [${escapeMdV2("Match Details")}](${input.link})`
    : `🔗 ${escapeMdV2("Match Details: N/A")}`);
  return lines.join("\n");
}

export function resetUnifiedAlertStateForTests(): void {
  inflows.clear();
  seenTransactions.clear();
  sentEvents.clear();
}