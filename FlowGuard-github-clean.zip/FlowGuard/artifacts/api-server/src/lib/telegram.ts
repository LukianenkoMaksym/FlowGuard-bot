import { logger } from "./logger";
import {
  telegramGetChatUrl,
  telegramGetMeUrl,
  telegramSendMessageUrl,
} from "./config";
import { getControls } from "./controls";
import { resolveTelegramOutboundMode } from "./telegramOutboundPolicy";
import {
  listSubscriberChatIds,
  removeSubscriber,
  ensureSubscribersLoaded,
} from "./telegramSubscribers";
import broadcastRecipients from "./telegramBroadcastRecipients.json";

// Telegram caps bots at ~30 messages/sec across distinct chats. Send in paced
// chunks so a broadcast to a large audience never trips a global 429 (which
// would silently drop recipients). Per-send 429s are additionally retried below.
const BROADCAST_CHUNK = 25;
const BROADCAST_CHUNK_GAP_MS = 1_100;
const MAX_429_RETRIES = 2;
const TELEGRAM_FETCH_TIMEOUT_MS = 15_000;

function outboundAllowed(): boolean {
  const mode = resolveTelegramOutboundMode();
  if (!mode.allowed) logger.warn({ reason: mode.reason }, "[TG-SEND] SUPPRESSED — non-production instance");
  return mode.allowed;
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** A slow database must not hold an already-approved Telegram alert hostage. */
async function boundedSignalWrite(work: Promise<void>): Promise<void> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    await Promise.race([
      work,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error("Signal history write timed out")), 2_000);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

/**
 * Bound every Telegram HTTP request. Node's fetch has no response timeout by
 * default, so one dead socket would otherwise leave an awaited alert (or bot
 * command reply) pending forever.
 */
function fetchTelegram(url: string, init: RequestInit): Promise<Response> {
  if (!outboundAllowed()) return Promise.reject(new Error("Telegram network request suppressed outside production deployment"));
  return fetch(url, {
    ...init,
    signal: AbortSignal.timeout(TELEGRAM_FETCH_TIMEOUT_MS),
  });
}

/** Telegram 429 body: { parameters: { retry_after: <seconds> } }; header is a fallback. */
function retryAfterMs(body: string, headers: Headers): number {
  let seconds = 0;
  try {
    const parsed = JSON.parse(body) as { parameters?: { retry_after?: number } };
    if (typeof parsed?.parameters?.retry_after === "number") seconds = parsed.parameters.retry_after;
  } catch {
    /* not JSON — fall through to header */
  }
  if (!seconds) {
    const header = Number(headers.get("retry-after"));
    if (!Number.isNaN(header)) seconds = header;
  }
  // Clamp so a pathological value can't wedge an awaited caller for minutes.
  return Math.min(Math.max(seconds, 1), 30) * 1_000;
}

const TELEGRAM_TOKEN = process.env["TELEGRAM_TOKEN"];
// The "admin" chat — always receives every broadcast, in addition to any users
// who registered via /start. Kept for backward compatibility (this was the only
// recipient before the multi-subscriber model) and so the owner never has to
// /start their own bot. Never auto-removed on a 403 (only dynamic subscribers
// are pruned), so a transient block can't silently unsubscribe the owner.
const TELEGRAM_CHAT_ID = process.env["TELEGRAM_CHAT_ID"]?.trim();

// Build-bundled, operator-verified recipients survive a deployment even when
// the mutable /start subscriber file does not. Never replace the env primary:
// the owner is also explicitly pinned here so changing the primary cannot
// silently remove the owner's DM. Add a group only after verifying its numeric
// chat ID; a public @username is not proof that it identifies a group.
const REQUIRED_BROADCAST_CHAT_IDS: readonly string[] = broadcastRecipients.chatIds;

/** Primary + pinned recipients + /start subscribers; shared by both delivery paths. */
export function resolveTelegramBroadcastRecipients(
  primaryChatId: string | undefined,
  subscriberChatIds: readonly (number | string)[],
  pinnedChatIds: readonly string[] = REQUIRED_BROADCAST_CHAT_IDS,
): string[] {
  const ids = new Set<string>();
  if (primaryChatId) ids.add(primaryChatId);
  for (const id of pinnedChatIds) ids.add(id);
  for (const id of subscriberChatIds) ids.add(String(id));
  return [...ids];
}

export function getTelegramConfigurationStatus(
  env: Record<string, string | undefined> = process.env,
): { configured: true } | { configured: false; reason: "token_missing" | "chat_missing" } {
  if (!env["TELEGRAM_TOKEN"]?.trim()) return { configured: false, reason: "token_missing" };
  if (!env["TELEGRAM_CHAT_ID"]?.trim()) return { configured: false, reason: "chat_missing" };
  return { configured: true };
}

export function isTelegramConfigured(): boolean {
  return Boolean(TELEGRAM_TOKEN && TELEGRAM_CHAT_ID);
}

/**
 * Escape user-supplied text for Telegram MarkdownV2.
 * MUST be applied to every dynamic value (team name, league, numbers, URLs in text)
 * but NOT to the Markdown control characters you intentionally emit.
 * See https://core.telegram.org/bots/api#markdownv2-style
 */
export function escapeMdV2(s: string | number): string {
  const str = String(s);
  return str.replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, "\\$1");
}

/** Strip MarkdownV2 escape backslashes so a message can be sent as plain text. */
function unescapeMdV2(message: string): string {
  return message.replace(/\\([_*\[\]()~`>#+\-=|{}.!\\])/g, "$1");
}

/**
 * SILENT health probe for the Telegram bot — calls `getMe`, which returns the
 * bot identity without posting anything to the chat. Use this for periodic
 * watchdog liveness checks so we don't spam the chat with "I'm alive" pings.
 *
 * Returns true if the bot token is valid AND the Telegram API is reachable.
 * Returns false on auth failure, network error, or HTTP non-2xx.
 */
export async function probeTelegramSilent(): Promise<{ ok: boolean; reason?: string }> {
  if (!TELEGRAM_TOKEN || !TELEGRAM_CHAT_ID) {
    return { ok: false, reason: "credentials_missing" };
  }
  const url = telegramGetMeUrl(TELEGRAM_TOKEN);
  try {
    const res = await fetchTelegram(url, { method: "GET" });
    if (!res.ok) return { ok: false, reason: `getMe_http_${res.status}` };
    // getMe validates the token; getChat independently validates that the
    // configured primary destination exists and is reachable by this bot.
    // POST keeps the private address out of URLs/proxy access logs.
    const chat = await fetchTelegram(telegramGetChatUrl(TELEGRAM_TOKEN), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID }),
    });
    return chat.ok
      ? { ok: true }
      : { ok: false, reason: `getChat_http_${chat.status}` };
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : String(err) };
  }
}

export const TELEGRAM_SYSTEM_CHECK_MESSAGE =
  "🤖 [SYSTEM CHECK] Telegram Alert Pipeline Active & Connected";

/**
 * Explicit operator-only diagnostic. It targets only the configured primary
 * chat, never subscribers, and is never called from startup/runtime loops.
 */
export async function sendPrimaryTelegramSystemCheck(): Promise<SendResult> {
  if (!TELEGRAM_TOKEN || !TELEGRAM_CHAT_ID) return "failed";
  return sendTelegramTo(
    TELEGRAM_CHAT_ID,
    TELEGRAM_SYSTEM_CHECK_MESSAGE,
    { parseMode: "plain" },
  );
}

export type SendResult = "ok" | "blocked" | "failed";
export interface TelegramDeliveryRecipient {
  /** Private transport address. Never include this value in logs or API data. */
  id: string;
  primary: boolean;
}
export type BroadcastResult =
  | { status: "delivered"; primaryDelivered: true; delivered: number; attempted: number; skippedAlreadyDelivered: number; failed: number; blocked: number }
  | { status: "muted"; reason: "alerts_muted"; primaryDelivered: false; delivered: 0; attempted: 0; skippedAlreadyDelivered: 0; failed: 0; blocked: 0 }
  | { status: "not_configured"; reason: "token_missing" | "chat_missing"; primaryDelivered: false; delivered: 0; attempted: 0; skippedAlreadyDelivered: 0; failed: 0; blocked: 0 }
  | { status: "failed"; reason: "non_production" | "no_recipients" | "all_deliveries_failed" | "primary_delivery_failed"; primaryDelivered: false; delivered: number; attempted: number; skippedAlreadyDelivered: number; failed: number; blocked: number };

const DELIVERY_LEDGER_TTL_MS = 30 * 60_000;
const deliveredRecipientsByEvent = new Map<string, { recipients: Set<string>; updatedAt: number }>();

function deliveryLedger(key: string | undefined): Set<string> | null {
  if (!key) return null;
  const now = Date.now();
  for (const [eventKey, entry] of deliveredRecipientsByEvent) {
    if (now - entry.updatedAt > DELIVERY_LEDGER_TTL_MS) deliveredRecipientsByEvent.delete(eventKey);
  }
  const existing = deliveredRecipientsByEvent.get(key);
  if (existing) {
    existing.updatedAt = now;
    return existing.recipients;
  }
  const recipients = new Set<string>();
  deliveredRecipientsByEvent.set(key, { recipients, updatedAt: now });
  return recipients;
}

/**
 * Send a message to a SINGLE chat. MarkdownV2 by default with an automatic
 * plain-text retry (so a bad escape never loses an alert); pass
 * `parseMode: "plain"` for bot conversational replies that aren't pre-escaped.
 *
 * Returns "blocked" when the recipient has blocked the bot (HTTP 403) so the
 * caller can prune them; "failed" for any other error; "ok" on success.
 */
export async function sendTelegramTo(
  chatId: string | number,
  message: string,
  opts?: { parseMode?: "MarkdownV2" | "plain"; retriesLeft?: number },
): Promise<SendResult> {
  if (!outboundAllowed()) return "failed";
  if (!TELEGRAM_TOKEN) {
    logger.warn("[TG-SEND] ABORT — TELEGRAM_TOKEN missing");
    return "failed";
  }
  const url = telegramSendMessageUrl(TELEGRAM_TOKEN);
  const useMarkdown = (opts?.parseMode ?? "MarkdownV2") === "MarkdownV2";
  const retriesLeft = opts?.retriesLeft ?? MAX_429_RETRIES;

  try {
    const res = await fetchTelegram(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: useMarkdown ? message : unescapeMdV2(message),
        ...(useMarkdown ? { parse_mode: "MarkdownV2" } : {}),
        disable_web_page_preview: true,
      }),
    });

    if (res.ok) return "ok";

    const body = await res.text();
    if (res.status === 403) {
      logger.info("[TG-SEND] 403 — recipient blocked the bot");
      return "blocked";
    }
    if (res.status === 429) {
      if (retriesLeft > 0) {
        const waitMs = retryAfterMs(body, res.headers);
        logger.warn({ waitMs, retriesLeft }, "[TG-SEND] 429 rate-limited — backing off");
        await delay(waitMs);
        return sendTelegramTo(chatId, message, { ...opts, retriesLeft: retriesLeft - 1 });
      }
      logger.error("[TG-SEND] 429 rate-limited — retries exhausted");
      return "failed";
    }
    logger.error(
      { status: res.status, statusText: res.statusText, body, msgLen: message.length },
      "[TG-SEND] FAILED — Telegram API error",
    );

    // Fallback: retry as plain text so a MarkdownV2 escaping bug never loses an
    // alert. Only meaningful when we tried MarkdownV2 in the first place.
    if (useMarkdown) {
      const plain = unescapeMdV2(message);
      try {
        const res2 = await fetchTelegram(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: chatId, text: plain, disable_web_page_preview: true }),
        });
        if (res2.ok) {
          logger.info("[TG-SEND] plain-text fallback succeeded");
          return "ok";
        }
        if (res2.status === 403) return "blocked";
        const b2 = await res2.text();
        logger.error({ status: res2.status, body: b2 }, "[TG-SEND] plain-text fallback ALSO failed");
      } catch (err2) {
        logger.error({ err: err2 }, "[TG-SEND] plain-text fallback threw");
      }
    }
    return "failed";
  } catch (err) {
    logger.error(
      { err, stack: err instanceof Error ? err.stack : undefined },
      "[TG-SEND] Network/fetch threw",
    );
    return "failed";
  }
}

/** Capture the audience once, before an outbox row is committed. */
export async function snapshotTelegramRecipients(): Promise<
  | { ok: true; recipients: TelegramDeliveryRecipient[] }
  | { ok: false; reason: "token_missing" | "chat_missing" | "no_recipients" }
> {
  if (!TELEGRAM_TOKEN) return { ok: false, reason: "token_missing" };
  if (!TELEGRAM_CHAT_ID) return { ok: false, reason: "chat_missing" };
  await ensureSubscribersLoaded();
  const recipients = resolveTelegramBroadcastRecipients(TELEGRAM_CHAT_ID, listSubscriberChatIds()).map((id) => ({
    id,
    primary: id === TELEGRAM_CHAT_ID,
  }));
  return recipients.length
    ? { ok: true, recipients }
    : { ok: false, reason: "no_recipients" };
}

/** Outbox transport seam; deliberately does not log the private address. */
export async function sendTelegramOutboxRecipient(
  recipient: TelegramDeliveryRecipient,
  message: string,
  opts?: { parseMode?: "MarkdownV2" | "plain" },
): Promise<SendResult> {
  const result = await sendTelegramTo(recipient.id, message, opts);
  if (result === "blocked" && !recipient.primary && !REQUIRED_BROADCAST_CHAT_IDS.includes(recipient.id)) {
    const numericId = Number(recipient.id);
    if (Number.isFinite(numericId)) await removeSubscriber(numericId);
  }
  return result;
}

/**
 * Broadcast a message to the admin chat, pinned recipients AND every /start subscriber.
 *
 * Recipients are de-duplicated (the admin may also have /start-ed) and sent in
 * paced chunks (BROADCAST_CHUNK per ~BROADCAST_CHUNK_GAP_MS) to stay under
 * Telegram's ~30 msg/s global cap. Any subscriber who has blocked the bot (HTTP
 * 403) is pruned from the persisted list; the admin env chat is never auto-pruned.
 *
 * Subscribers are lazily loaded on first use so an alert that fires immediately
 * after a restart still reaches the persisted audience (no startup race).
 *
 * Signature is unchanged from the original single-chat version, so every
 * existing caller now broadcasts with no code change on their side.
 */
export async function sendTelegram(
  message: string,
  opts?: { deliveryKey?: string },
): Promise<BroadcastResult> {
  // Do not stage a signal or mark any recipients delivered for suppressed work.
  if (!outboundAllowed()) {
    return { status: "failed", reason: "non_production", primaryDelivered: false, delivered: 0, attempted: 0, skippedAlreadyDelivered: 0, failed: 0, blocked: 0 };
  }
  if (!TELEGRAM_TOKEN) {
    logger.warn("[TG-SEND] ABORT — TELEGRAM_TOKEN missing");
    return { status: "not_configured", reason: "token_missing", primaryDelivered: false, delivered: 0, attempted: 0, skippedAlreadyDelivered: 0, failed: 0, blocked: 0 };
  }
  if (!TELEGRAM_CHAT_ID) {
    logger.warn("[TG-SEND] ABORT — TELEGRAM_CHAT_ID missing");
    return { status: "not_configured", reason: "chat_missing", primaryDelivered: false, delivered: 0, attempted: 0, skippedAlreadyDelivered: 0, failed: 0, blocked: 0 };
  }

  // Manual mute control: broadcasts are suppressed (but logged) while the
  // user has alerts muted. Direct replies (sendTelegramTo) are unaffected.
  if (getControls().alertsMuted) {
    logger.warn(
      { msgLen: message.length, preview: message.slice(0, 120) },
      "[TG-SEND] SUPPRESSED — alerts are manually muted via dashboard control",
    );
    return { status: "muted", reason: "alerts_muted", primaryDelivered: false, delivered: 0, attempted: 0, skippedAlreadyDelivered: 0, failed: 0, blocked: 0 };
  }

  // Classify the existing rendered card at the common transport seam, not in
  // individual detectors. An acknowledged primary send is the only commit.
  const { parseDeliveredSignal, signalDeliveryKey, stageSignal, persistAcknowledgedSignal } =
    await import("./deliveredSignals");
  const signal = parseDeliveredSignal(message);
  const signalKey = signal ? signalDeliveryKey(message, opts?.deliveryKey) : null;
  if (signal && signalKey) {
    try { await boundedSignalWrite(stageSignal(signalKey, signal)); }
    catch (err) { logger.error({ err }, "[SIGNAL-HISTORY] pre-send stage failed; Telegram delivery continues"); }
  }

  await ensureSubscribersLoaded();

  const recipients = resolveTelegramBroadcastRecipients(TELEGRAM_CHAT_ID, listSubscriberChatIds());

  if (recipients.length === 0) {
    logger.warn("[TG-SEND] No recipients (no admin chat, no subscribers) — skipping");
    return { status: "failed", reason: "no_recipients", primaryDelivered: false, delivered: 0, attempted: 0, skippedAlreadyDelivered: 0, failed: 0, blocked: 0 };
  }

  const ledger = deliveryLedger(opts?.deliveryKey);
  const allRecipients = recipients;
  const all = ledger ? allRecipients.filter((chatId) => !ledger.has(chatId)) : allRecipients;
  const skippedAlreadyDelivered = allRecipients.length - all.length;
  logger.debug(
    { recipients: all.length, msgLen: message.length, preview: message.slice(0, 200) },
    "[TG-SEND] broadcasting",
  );

  let ok = 0;
  let failed = 0;
  let blocked = 0;
  let primaryAcknowledgedAt: Date | null = null;
  const successfulRecipients = new Set<string>();
  for (let i = 0; i < all.length; i += BROADCAST_CHUNK) {
    const chunk = all.slice(i, i + BROADCAST_CHUNK);
    const results = await Promise.allSettled(
      chunk.map(async (chatId) => {
        const result = await sendTelegramTo(chatId, message);
        if (result === "ok") {
          if (chatId === TELEGRAM_CHAT_ID) primaryAcknowledgedAt = new Date();
          successfulRecipients.add(chatId);
          ledger?.add(chatId);
        }
        if (result === "blocked" && chatId !== TELEGRAM_CHAT_ID && !REQUIRED_BROADCAST_CHAT_IDS.includes(chatId)) {
          const numId = Number(chatId);
          if (!Number.isNaN(numId)) {
            await removeSubscriber(numId);
            logger.info("[TG-SEND] pruned blocked subscriber");
          }
        }
        return result;
      }),
    );
    ok += results.filter((r) => r.status === "fulfilled" && r.value === "ok").length;
    blocked += results.filter((r) => r.status === "fulfilled" && r.value === "blocked").length;
    failed += results.filter(
      (r) => r.status === "rejected" || (r.status === "fulfilled" && r.value === "failed"),
    ).length;
    if (i + BROADCAST_CHUNK < all.length) await delay(BROADCAST_CHUNK_GAP_MS);
  }

  const primaryDelivered =
    ledger?.has(TELEGRAM_CHAT_ID) ?? successfulRecipients.has(TELEGRAM_CHAT_ID);
  logger.info({ ok, total: all.length, primaryDelivered }, "[TG-SEND] broadcast complete");
  if (primaryDelivered) {
    if (signal && signalKey) {
      try { await boundedSignalWrite(persistAcknowledgedSignal(signalKey, signal, primaryAcknowledgedAt ?? new Date())); }
      catch (err) { logger.error({ err }, "[SIGNAL-HISTORY] primary acknowledged; history persistence queued for retry"); }
    }
    return {
      status: "delivered",
      primaryDelivered: true,
      delivered: ok,
      attempted: all.length,
      skippedAlreadyDelivered,
      failed,
      blocked,
    };
  }
  return {
    status: "failed",
    reason: ok > 0 ? "primary_delivery_failed" : "all_deliveries_failed",
    primaryDelivered: false,
    delivered: ok,
    attempted: all.length,
    skippedAlreadyDelivered,
    failed,
    blocked,
  };
}
