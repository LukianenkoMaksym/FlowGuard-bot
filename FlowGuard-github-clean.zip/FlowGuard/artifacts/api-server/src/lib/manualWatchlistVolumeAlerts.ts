import { createHash } from "node:crypto";
import { pool } from "@workspace/db";
import { getControls } from "./controls";
import { logger } from "./logger";
import {
  formatUnifiedAlert,
  type UnifiedAlertInput,
} from "./unifiedAlert";
import {
  sendTelegramOutboxRecipient,
  snapshotTelegramRecipients,
  type TelegramDeliveryRecipient,
} from "./telegram";

export const MANUAL_WATCHLIST_DELTA_EUR = 500;
export const MANUAL_WATCHLIST_ACCUMULATED_EUR = 2_000;
const LOCK_KEY = 1_163_413_315;
const RETRY_MS = 30_000;
export const MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS = 10 * 60_000;
const TELEGRAM_DIGEST_MAX_CHARS = 3_800;

export interface ManualVolumeObservation {
  gameId: string;
  matchLabel: string;
  league: string;
  line: number;
  side: "OVER" | "UNDER";
  total: number;
  /** Authentic time at which this cumulative volume was fetched. */
  observedAt: number;
  /** Snapshot injected by scanner at hydration time; never reconstructed. */
  alertContext?: Omit<UnifiedAlertInput, "inflow"> | null;
}

export interface ManualVolumeDelta extends ManualVolumeObservation {
  /** Increase since the immediately preceding fresh observation. */
  delta: number;
  /** Increase since seed or the last admitted/muted trigger. */
  accumulatedDelta: number;
}

export interface ManualVolumeBaseline {
  lastObserved: number;
  lastTrigger: number;
}

type FreshManualVolumeScore = {
  homeScore: number;
  awayScore: number;
  isLive: boolean;
};

type FreshManualVolumeScoreValidator = (
  matchId: string,
) => Promise<FreshManualVolumeScore | null>;

let freshScoreValidator: FreshManualVolumeScoreValidator | null = null;

/**
 * Injected at composition-root startup to avoid a circular scanner import.
 * Recovery fails closed until the authoritative score reader is registered.
 */
export function registerManualVolumeFreshScoreValidator(
  validator: FreshManualVolumeScoreValidator | null,
): void {
  freshScoreValidator = validator;
}

/**
 * Network/storage-free reference collector used by tests and by operators
 * reasoning about the matcher. Runtime state is persisted in Postgres below.
 */
export function collectManualVolumeDeltas(
  baseline: Map<string, ManualVolumeBaseline>,
  observations: readonly ManualVolumeObservation[],
): ManualVolumeDelta[] {
  const eligible: ManualVolumeDelta[] = [];
  for (const observation of observations) {
    if (!Number.isFinite(observation.total) || observation.total < 0) continue;
    const key = `${observation.gameId}:${observation.line}:${observation.side}`;
    const state = baseline.get(key);
    if (state === undefined) {
      baseline.set(key, {
        lastObserved: observation.total,
        lastTrigger: observation.total,
      });
      continue;
    }
    // A stale/partial upstream response must not lower the cumulative high-water.
    if (observation.total <= state.lastObserved) continue;
    const delta = observation.total - state.lastObserved;
    const accumulatedDelta = observation.total - state.lastTrigger;
    state.lastObserved = observation.total;
    if (
      delta >= MANUAL_WATCHLIST_DELTA_EUR ||
      accumulatedDelta >= MANUAL_WATCHLIST_ACCUMULATED_EUR
    ) {
      state.lastTrigger = observation.total;
      eligible.push({ ...observation, delta, accumulatedDelta });
    }
  }
  return eligible;
}

export function formatManualVolumeDigest(
  events: readonly ManualVolumeDelta[],
): string {
  const included: string[] = [];
  for (const event of events) {
    const [home = event.matchLabel, away = "N/A"] = event.matchLabel.split(/\s+vs\s+/i, 2);
    const context = event.alertContext ?? {
      matchId: "",
      league: event.league || "N/A",
      home,
      away,
      isLive: false,
      homeScore: null,
      awayScore: null,
      minute: null,
      side: event.side,
      line: event.line,
      timeline: [],
      link: null,
    };
    const block = formatUnifiedAlert({
      ...context,
      side: event.side,
      line: event.line,
      inflow: {
        matchId: context.matchId,
        line: event.line,
        side: event.side,
        single: event.delta,
        total: event.total,
        minute: context.minute,
        observedAt: event.observedAt,
      },
    });
    const omittedAfter = events.length - included.length - 1;
    const suffix = omittedAfter > 0
      ? `\n\n… ${omittedAfter} additional complete alert block${omittedAfter === 1 ? "" : "s"} omitted`
      : "";
    if (`${included.join("\n\n")}${included.length ? "\n\n" : ""}${block}${suffix}`.length >
      TELEGRAM_DIGEST_MAX_CHARS) break;
    included.push(block);
  }
  const omitted = events.length - included.length;
  const suffix = omitted > 0
    ? `${included.length ? "\n\n" : ""}… ${omitted} additional complete alert block${omitted === 1 ? "" : "s"} omitted`
    : "";
  return `${included.join("\n\n")}${suffix}`;
}

let schemaReady: Promise<void> | null = null;
function ensureSchema(): Promise<void> {
  if (schemaReady) return schemaReady;
  schemaReady = pool.query(`
    CREATE TABLE IF NOT EXISTS manual_watchlist_volume_baseline (
      market_key text PRIMARY KEY,
      cumulative_eur double precision NOT NULL,
      trigger_baseline_eur double precision,
      updated_at timestamptz NOT NULL DEFAULT now()
    );
    ALTER TABLE manual_watchlist_volume_baseline
      ADD COLUMN IF NOT EXISTS trigger_baseline_eur double precision;
    UPDATE manual_watchlist_volume_baseline
      SET trigger_baseline_eur = cumulative_eur
      WHERE trigger_baseline_eur IS NULL;
    CREATE TABLE IF NOT EXISTS manual_watchlist_telegram_outbox (
      event_key text PRIMARY KEY,
      message text NOT NULL,
      parse_mode text NOT NULL DEFAULT 'plain',
      recipient_state jsonb NOT NULL,
      completed_at timestamptz,
      attempts integer NOT NULL DEFAULT 0,
      next_attempt_at timestamptz NOT NULL DEFAULT now(),
      created_at timestamptz NOT NULL DEFAULT now()
    );
    ALTER TABLE manual_watchlist_telegram_outbox
      ADD COLUMN IF NOT EXISTS parse_mode text NOT NULL DEFAULT 'plain';
    ALTER TABLE manual_watchlist_telegram_outbox
      ADD COLUMN IF NOT EXISTS odds_observed_at timestamptz;
    ALTER TABLE manual_watchlist_telegram_outbox
      ADD COLUMN IF NOT EXISTS evidence jsonb;
    ALTER TABLE manual_watchlist_telegram_outbox
      ADD COLUMN IF NOT EXISTS volume_observed_at timestamptz;
  `).then(() => undefined).catch((error) => {
    schemaReady = null;
    throw error;
  });
  return schemaReady;
}

type PendingRecipient = TelegramDeliveryRecipient & {
  state: "pending" | "acked" | "blocked";
};

interface ManualVolumeOutboxEvidence {
  version: 1;
  events: ManualVolumeDelta[];
}

function parseOutboxEvidence(value: unknown): ManualVolumeOutboxEvidence | null {
  if (!value || typeof value !== "object") return null;
  const record = value as Partial<ManualVolumeOutboxEvidence>;
  if (record.version !== 1 || !Array.isArray(record.events) || record.events.length === 0) {
    return null;
  }
  return { version: 1, events: record.events };
}

async function validateOutboxEvents(
  evidenceValue: unknown,
  now = Date.now(),
): Promise<ManualVolumeDelta[]> {
  const evidence = parseOutboxEvidence(evidenceValue);
  if (!evidence) return [];
  const valid: ManualVolumeDelta[] = [];
  for (const event of evidence.events) {
    const context = event.alertContext;
    if (
      !context ||
      typeof context !== "object" ||
      typeof context.matchId !== "string" ||
      context.matchId.length === 0 ||
      !Number.isFinite(event.line) ||
      (event.side !== "OVER" && event.side !== "UNDER") ||
      !Array.isArray(context.timeline) ||
      context.line !== event.line ||
      context.side !== event.side ||
      !Number.isFinite(event.observedAt) ||
      event.observedAt > now + 5_000 ||
      now - event.observedAt > MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS
    ) continue;

    if (!context.isLive) {
      valid.push(event);
      continue;
    }
    if (!freshScoreValidator) continue;
    const fresh = await freshScoreValidator(context.matchId);
    if (
      !fresh ||
      !fresh.isLive ||
      !Number.isFinite(fresh.homeScore) ||
      !Number.isFinite(fresh.awayScore) ||
      event.line <= fresh.homeScore + fresh.awayScore
    ) continue;
    valid.push({
      ...event,
      alertContext: {
        ...context,
        homeScore: fresh.homeScore,
        awayScore: fresh.awayScore,
      },
    });
  }
  return valid;
}

async function processOutbox(): Promise<void> {
  if (getControls().alertsMuted) return;
  await ensureSchema();
  const client = await pool.connect();
  try {
    const lock = await client.query<{ locked: boolean }>(
      "SELECT pg_try_advisory_lock($1) AS locked",
      [LOCK_KEY],
    );
    if (!lock.rows[0]?.locked) return;
    try {
      await client.query(`
        UPDATE manual_watchlist_telegram_outbox
        SET completed_at = now()
        WHERE completed_at IS NULL
          AND (
            created_at <= now() - make_interval(secs => $1)
            OR evidence IS NULL
            OR volume_observed_at IS NULL
            OR (
              volume_observed_at <= now() - make_interval(secs => $1)
            )
          )
      `, [
        MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS / 1_000,
      ]);
      const due = await client.query<{
        event_key: string;
        message: string;
        parse_mode: "MarkdownV2" | "plain";
        recipient_state: PendingRecipient[];
        attempts: number;
        evidence: unknown;
      }>(`
        SELECT event_key, message, parse_mode, recipient_state, attempts, evidence
        FROM manual_watchlist_telegram_outbox
        WHERE completed_at IS NULL
          AND created_at > now() - make_interval(secs => $1)
          AND next_attempt_at <= now()
        ORDER BY created_at LIMIT 20
      `, [MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS / 1_000]);
      for (const row of due.rows) {
        const recipients = row.recipient_state;
        let suppressed = false;
        for (const recipient of recipients) {
          if (recipient.state !== "pending") continue;
          const eligible = await validateOutboxEvents(row.evidence);
          if (eligible.length === 0) {
            // Suppress the whole durable event, including recipients not yet
            // attempted. It remains stored as completed audit history.
            for (const pending of recipients) {
              if (pending.state === "pending") pending.state = "blocked";
            }
            suppressed = true;
            logger.info(
              { eventKey: row.event_key, reason: "fresh-volume-score-or-provenance-validation-failed" },
              "[MANUAL-VOLUME] outbox alert suppressed before delivery",
            );
            break;
          }
          const result = await sendTelegramOutboxRecipient(
            recipient,
            formatManualVolumeDigest(eligible),
            { parseMode: row.parse_mode === "MarkdownV2" ? "MarkdownV2" : "plain" },
          );
          if (result === "ok") recipient.state = "acked";
          else if (result === "blocked") recipient.state = "blocked";
        }
        const primaryAcked = recipients.some(
          (recipient) => recipient.primary && recipient.state === "acked",
        );
        const allTerminal = recipients.every((recipient) => recipient.state !== "pending");
        await client.query(`
          UPDATE manual_watchlist_telegram_outbox
          SET recipient_state = $2::jsonb,
              attempts = attempts + 1,
              next_attempt_at = now() + make_interval(secs => $3),
              completed_at = CASE WHEN ($4 AND $5) OR $6 THEN now() ELSE completed_at END
          WHERE event_key = $1
        `, [
          row.event_key,
          JSON.stringify(recipients),
          Math.min(300, 30 * 2 ** Math.min(row.attempts, 4)),
          primaryAcked,
          allTerminal,
          suppressed,
        ]);
      }
    } finally {
      await client.query("SELECT pg_advisory_unlock($1)", [LOCK_KEY]);
    }
  } finally {
    client.release();
  }
}

/** Network-free test/diagnostic seam; normal runtime uses the recovery worker. */
export const drainManualWatchlistVolumeOutbox = processOutbox;

/**
 * Accept one complete manual-hydration pass. All eligible match/line/side
 * movements from this pass are committed as one durable Telegram digest.
 */
export async function queueManualWatchlistVolumeDigest(
  observations: readonly ManualVolumeObservation[],
): Promise<{ eligible: number; queued: boolean; reason?: string }> {
  if (observations.length === 0) return { eligible: 0, queued: false };
  await ensureSchema();
  const client = await pool.connect();
  let eligible: ManualVolumeDelta[] = [];
  let transactionOpen = false;
  try {
    await client.query("BEGIN");
    transactionOpen = true;
    await client.query("SELECT pg_advisory_xact_lock($1)", [LOCK_KEY]);
    for (const observation of observations) {
      if (!Number.isFinite(observation.total) || observation.total < 0) continue;
      const marketKey = `${observation.gameId}:${observation.line}:${observation.side}`;
      if (
        !Number.isFinite(observation.observedAt) ||
        observation.observedAt > Date.now() + 5_000 ||
        Date.now() - observation.observedAt > MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS
      ) continue;
      const current = await client.query<{
        cumulative_eur: number;
        trigger_baseline_eur: number;
      }>(
        "SELECT cumulative_eur, trigger_baseline_eur FROM manual_watchlist_volume_baseline WHERE market_key = $1 FOR UPDATE",
        [marketKey],
      );
      const previous = current.rows[0]?.cumulative_eur;
      const lastTrigger = current.rows[0]?.trigger_baseline_eur ?? previous;
      if (previous === undefined) {
        await client.query(
          "INSERT INTO manual_watchlist_volume_baseline (market_key, cumulative_eur, trigger_baseline_eur) VALUES ($1, $2, $2) ON CONFLICT DO NOTHING",
          [marketKey, observation.total],
        );
      } else if (observation.total > previous) {
        const delta = observation.total - previous;
        const accumulatedDelta = observation.total - lastTrigger!;
        const triggered =
          delta >= MANUAL_WATCHLIST_DELTA_EUR ||
          accumulatedDelta >= MANUAL_WATCHLIST_ACCUMULATED_EUR;
        await client.query(
          `UPDATE manual_watchlist_volume_baseline
           SET cumulative_eur = $2,
               trigger_baseline_eur = CASE WHEN $3 THEN $2 ELSE trigger_baseline_eur END,
               updated_at = now()
           WHERE market_key = $1`,
          [marketKey, observation.total, triggered],
        );
        if (triggered) {
          eligible.push({ ...observation, delta, accumulatedDelta });
        }
      }
    }
    if (eligible.length === 0) {
      await client.query("COMMIT");
      transactionOpen = false;
      return { eligible: 0, queued: false };
    }

    eligible = eligible.sort((a, b) =>
      a.gameId.localeCompare(b.gameId) || a.line - b.line || a.side.localeCompare(b.side),
    );
    // Volume is the primary signal. Odds, when available, are display metadata
    // and never gate durable admission.
    eligible = eligible.filter((event) => {
      const context = event.alertContext;
      return context !== null &&
        context !== undefined &&
        context.line === event.line &&
        context.side === event.side;
    });
    if (eligible.length === 0) {
      await client.query("COMMIT");
      transactionOpen = false;
      return { eligible: 0, queued: false, reason: "alert_provenance_required" };
    }
    // Muting is an admission control as well as a delivery control. Commit the
    // new high-water so unmuting cannot release a stale backlog.
    if (getControls().alertsMuted) {
      await client.query("COMMIT");
      transactionOpen = false;
      return {
        eligible: eligible.length,
        queued: false,
        reason: "alerts_muted",
      };
    }
    const audience = await snapshotTelegramRecipients();
    if (!audience.ok) {
      // Keep the prior durable baseline. Once credentials recover, the next
      // observation can still admit the accumulated positive movement instead
      // of silently discarding it.
      await client.query("ROLLBACK");
      transactionOpen = false;
      logger.error({ reason: audience.reason }, "[MANUAL-VOLUME] admission failed: Telegram configuration incomplete");
      return { eligible: eligible.length, queued: false, reason: audience.reason };
    }
    // Recheck immediately before durable admission in case the operator muted
    // while subscriber state was loading.
    if (getControls().alertsMuted) {
      await client.query("COMMIT");
      transactionOpen = false;
      return {
        eligible: eligible.length,
        queued: false,
        reason: "alerts_muted",
      };
    }
    const eventKey = `manual-volume:${createHash("sha256")
      .update(eligible.map((event) => `${event.gameId}:${event.line}:${event.side}:${event.total}`).join("|"))
      .digest("hex")}`;
    await client.query(`
       INSERT INTO manual_watchlist_telegram_outbox
          (event_key, message, parse_mode, recipient_state, volume_observed_at, evidence)
       VALUES ($1, $2, 'MarkdownV2', $3::jsonb, to_timestamp($4 / 1000.0), $5::jsonb)
       ON CONFLICT (event_key) DO NOTHING
    `, [
      eventKey,
      formatManualVolumeDigest(eligible),
      JSON.stringify(audience.recipients.map((recipient) => ({ ...recipient, state: "pending" }))),
      Math.min(...eligible.map((event) => event.observedAt)),
      JSON.stringify({ version: 1, events: eligible } satisfies ManualVolumeOutboxEvidence),
    ]);
    await client.query("COMMIT");
    transactionOpen = false;
  } catch (error) {
    if (transactionOpen) await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
  void processOutbox().catch(() =>
    logger.error("[MANUAL-VOLUME] durable Telegram delivery failed; retry retained"),
  );
  return { eligible: eligible.length, queued: true };
}

let recoveryTimer: NodeJS.Timeout | null = null;
export function startManualWatchlistVolumeAlertRecovery(): void {
  if (recoveryTimer) return;
  void processOutbox().catch(() =>
    logger.error("[MANUAL-VOLUME] startup recovery unavailable"),
  );
  recoveryTimer = setInterval(() => {
    void processOutbox().catch(() =>
      logger.error("[MANUAL-VOLUME] retry recovery unavailable"),
    );
  }, RETRY_MS);
  recoveryTimer.unref();
}