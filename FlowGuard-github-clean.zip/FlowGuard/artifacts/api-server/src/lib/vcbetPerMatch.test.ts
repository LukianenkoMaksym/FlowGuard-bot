import { describe, expect, it } from "vitest";
import { extractRedirectHost } from "./vcbetPerMatch";

describe("extractRedirectHost (SSRF guard)", () => {
  it("accepts an https NowGoal-family redirect", () => {
    const body = `<head><title>Document Moved</title></head><body><h1>Object Moved</h1>This document may be found <a HREF="https://live10.nowgoal26.com/ajax/soccerajax?type=14">here</a></body>`;
    expect(extractRedirectHost(body)).toBe("https://live10.nowgoal26.com");
  });

  it("rejects hosts outside the NowGoal family", () => {
    const body = `<a HREF="https://evil.example.com/ajax/x">here</a>`;
    expect(extractRedirectHost(body)).toBeNull();
  });

  it("rejects lookalike suffix hosts (evilnowgoal26.com)", () => {
    const body = `<a HREF="https://evilnowgoal26.com/x">here</a>`;
    expect(extractRedirectHost(body)).toBeNull();
  });

  it("rejects arbitrary nested subdomains inside the NowGoal family", () => {
    const body = `<a HREF="https://a.b.nowgoal8.com/x">here</a>`;
    expect(extractRedirectHost(body)).toBeNull();
  });

  it("rejects a suffixless nowgoal.com host", () => {
    const body = `<a HREF="https://nowgoal.com/x">here</a>`;
    expect(extractRedirectHost(body)).toBeNull();
  });

  it("rejects plain-http redirects", () => {
    const body = `<a HREF="http://live10.nowgoal26.com/x">here</a>`;
    expect(extractRedirectHost(body)).toBeNull();
  });

  it("ignores JSON bodies and oversized bodies", () => {
    expect(extractRedirectHost(`{"ErrCode":0}`)).toBeNull();
    expect(extractRedirectHost(`<a HREF="https://live10.nowgoal26.com/x">${"x".repeat(5000)}</a>`)).toBeNull();
  });

  it("accepts bare and future numbered live mirrors", () => {
    expect(extractRedirectHost(`<a HREF="https://nowgoal26.com/x">h</a>`)).toBe("https://nowgoal26.com");
    expect(extractRedirectHost(`<a HREF="https://live12.nowgoal29.com/x">h</a>`)).toBe("https://live12.nowgoal29.com");
    expect(extractRedirectHost(`<a HREF="https://www.nowgoal28.com/x">h</a>`)).toBe("https://www.nowgoal28.com");
  });
});
