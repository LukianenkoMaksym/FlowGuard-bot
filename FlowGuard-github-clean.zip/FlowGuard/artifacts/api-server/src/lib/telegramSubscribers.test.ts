/**
 * Tests for telegramSubscribers.ts — restart / offset-resume guarantees.
 *
 * Key invariant verified here:
 *
 *   After a production restart the polling loop resumes from
 *   `getLastUpdateId() + 1`, which is exactly the offset Telegram needs to
 *   deliver all updates that arrived during the downtime window.  Updates are
 *   held by Telegram for up to 24 h, so a brief restart gap causes a *delay*
 *   in processing (not a loss) — every /start command sent while the server
 *   was down is replayed on the first successful getUpdates call.
 *
 * Test strategy:
 *   Each test calls `_resetForTests(tmpFile)` which resets all module-level
 *   state and redirects reads/writes to a temp file, so tests are fully
 *   isolated from each other and from the production config directory.
 */
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  _resetForTests,
  addSubscriber,
  getLastUpdateId,
  listSubscriberChatIds,
  loadSubscribers,
  removeSubscriber,
  setLastUpdateId,
  subscriberCount,
} from "./telegramSubscribers";

// ---------------------------------------------------------------------------
// Per-test temp directory setup / teardown
// ---------------------------------------------------------------------------

let tmpDir = "";
let tmpFile = "";

beforeEach(async () => {
  tmpDir = await mkdtemp(path.join(tmpdir(), "tg-subs-test-"));
  tmpFile = path.join(tmpDir, "telegram-subscribers.json");
  _resetForTests(tmpFile);
});

afterEach(async () => {
  _resetForTests(); // restore state; path stays pointing at tmpFile (gets deleted below)
  await rm(tmpDir, { recursive: true, force: true });
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function writeSubs(content: object): Promise<void> {
  await writeFile(tmpFile, JSON.stringify(content), "utf8");
}

// ---------------------------------------------------------------------------
// Fresh start — no config file yet (ENOENT)
// ---------------------------------------------------------------------------

describe("telegramSubscribers — fresh start (no persisted file)", () => {
  it("initialises lastUpdateId to 0 when the config file does not exist", async () => {
    // tmpFile does not exist yet
    await loadSubscribers();
    expect(getLastUpdateId()).toBe(0);
  });

  it("poll offset starts at 1 when no file exists (nothing to skip)", async () => {
    await loadSubscribers();
    // The poll loop uses: offset = getLastUpdateId() + 1
    expect(getLastUpdateId() + 1).toBe(1);
  });

  it("starts with an empty subscriber list when no config file exists", async () => {
    await loadSubscribers();
    expect(subscriberCount()).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// Restart / offset-resume
// ---------------------------------------------------------------------------

describe("telegramSubscribers — restart / offset-resume", () => {
  it("restores lastUpdateId from a persisted file after restart", async () => {
    await writeSubs({ subscribers: [], lastUpdateId: 42 });
    await loadSubscribers();
    expect(getLastUpdateId()).toBe(42);
  });

  it("poll offset after restart is lastUpdateId+1, covering the downtime window", async () => {
    // lastUpdateId=99 means update 99 was the last processed before shutdown.
    // On restart, offset=100 tells Telegram to deliver updates ≥100, which
    // includes any /start commands sent during the downtime window, so no
    // subscription is silently dropped.
    await writeSubs({ subscribers: [], lastUpdateId: 99 });
    await loadSubscribers();
    expect(getLastUpdateId() + 1).toBe(100);
  });

  it("defaults lastUpdateId to 0 when the field is absent from the file", async () => {
    // Legacy or hand-edited file without the lastUpdateId key.
    await writeSubs({ subscribers: [] });
    await loadSubscribers();
    expect(getLastUpdateId()).toBe(0);
  });

  it("restores subscribers persisted before the restart", async () => {
    await writeSubs({
      subscribers: [
        { chatId: 111, username: "alice", subscribedAt: "2026-01-01T00:00:00.000Z" },
        { chatId: 222, username: "bob", subscribedAt: "2026-06-01T00:00:00.000Z" },
      ],
      lastUpdateId: 7,
    });
    await loadSubscribers();
    expect(subscriberCount()).toBe(2);
    expect(listSubscriberChatIds()).toContain(111);
    expect(listSubscriberChatIds()).toContain(222);
  });

  it("recovers both subscribers and offset together on reload", async () => {
    await writeSubs({
      subscribers: [{ chatId: 999, username: "carol", subscribedAt: "2026-08-01T00:00:00.000Z" }],
      lastUpdateId: 321,
    });
    await loadSubscribers();
    expect(subscriberCount()).toBe(1);
    expect(getLastUpdateId()).toBe(321);
    expect(getLastUpdateId() + 1).toBe(322);
  });
});

// ---------------------------------------------------------------------------
// setLastUpdateId — persist & reload
// ---------------------------------------------------------------------------

describe("telegramSubscribers — setLastUpdateId persists across simulated restarts", () => {
  it("persists a new offset so a subsequent reload recovers it", async () => {
    await writeSubs({ subscribers: [], lastUpdateId: 10 });
    await loadSubscribers();
    expect(getLastUpdateId()).toBe(10);

    await setLastUpdateId(55);
    expect(getLastUpdateId()).toBe(55);

    // --- simulate restart ---
    _resetForTests(tmpFile); // reset in-memory state, keep same file
    await loadSubscribers();
    expect(getLastUpdateId()).toBe(55);
  });

  it("does not regress the offset when a lower id arrives out of order", async () => {
    await writeSubs({ subscribers: [], lastUpdateId: 20 });
    await loadSubscribers();

    // An out-of-order or duplicate call with a lower id must not lower the offset.
    await setLastUpdateId(5);
    expect(getLastUpdateId()).toBe(20);
  });

  it("advances the offset monotonically through a sequence of updates", async () => {
    await writeSubs({ subscribers: [], lastUpdateId: 0 });
    await loadSubscribers();

    for (const id of [1, 2, 3, 4, 5]) {
      await setLastUpdateId(id);
    }
    expect(getLastUpdateId()).toBe(5);
  });

  it("persists the subscriber list alongside an updated offset", async () => {
    await writeSubs({ subscribers: [], lastUpdateId: 0 });
    await loadSubscribers();

    await addSubscriber(777, "dave");
    await setLastUpdateId(88);

    // --- simulate restart ---
    _resetForTests(tmpFile);
    await loadSubscribers();
    expect(subscriberCount()).toBe(1);
    expect(listSubscriberChatIds()).toContain(777);
    expect(getLastUpdateId()).toBe(88);
  });
});

// ---------------------------------------------------------------------------
// /start and /stop round-trips
// ---------------------------------------------------------------------------

describe("telegramSubscribers — /start and /stop", () => {
  beforeEach(async () => {
    await writeSubs({ subscribers: [], lastUpdateId: 0 });
    await loadSubscribers();
  });

  it("addSubscriber returns true for a new subscriber", async () => {
    const isNew = await addSubscriber(100, "eve");
    expect(isNew).toBe(true);
    expect(subscriberCount()).toBe(1);
  });

  it("addSubscriber returns false (idempotent) for a repeated /start", async () => {
    await addSubscriber(100, "eve");
    const isNew = await addSubscriber(100, "eve");
    expect(isNew).toBe(false);
    expect(subscriberCount()).toBe(1);
  });

  it("removeSubscriber returns true and removes the subscriber", async () => {
    await addSubscriber(100, "eve");
    const removed = await removeSubscriber(100);
    expect(removed).toBe(true);
    expect(subscriberCount()).toBe(0);
  });

  it("removeSubscriber returns false when the chat was not subscribed", async () => {
    const removed = await removeSubscriber(999);
    expect(removed).toBe(false);
  });

  it("/start subscription survives a simulated restart", async () => {
    await addSubscriber(555, "frank");
    expect(subscriberCount()).toBe(1);

    // simulate restart
    _resetForTests(tmpFile);
    await loadSubscribers();
    expect(subscriberCount()).toBe(1);
    expect(listSubscriberChatIds()).toContain(555);
  });
});

// ---------------------------------------------------------------------------
// Concurrent mutation safety
// ---------------------------------------------------------------------------

describe("telegramSubscribers — concurrent mutation safety", () => {
  beforeEach(async () => {
    await writeSubs({ subscribers: [], lastUpdateId: 0 });
    await loadSubscribers();
  });

  it("addSubscriber and setLastUpdateId are serialised; final state is consistent", async () => {
    await Promise.all([
      addSubscriber(111, "alice"),
      addSubscriber(222, "bob"),
      setLastUpdateId(10),
      setLastUpdateId(11),
    ]);

    expect(subscriberCount()).toBe(2);
    expect(getLastUpdateId()).toBe(11);
  });
});
