import { USER_AGENT_POOL } from "./config";
import { logger } from "./logger";

export type MarketSide = "OVER" | "UNDER" | "HOME" | "AWAY";
export interface BookPoint { ts: number; odds: number; line: number | null }
export interface BookMarket {
  cid: string;
  bookmaker: string;
  side: MarketSide;
  line: number | null;
  observedAt: number;
  current: BookPoint;
  history: BookPoint[];
  /** Source `mt` if available; otherwise genuine local collection instants
   * from t=11, never passed off as upstream quote timestamps. */
  timeSource: "upstream" | "observed";
}
export interface BookMovement {
  cid: string;
  bookmaker: string;
  type: "drop" | "rise" | "revert";
  from: number;
  to: number;
  percent: number;
  quoteAt: number;
  history: { ts: number; odds: number }[];
  baseline?: number;
  peak?: number;
  durationMs?: number;
}
type Roster = { at: number; books: { cid: string; bookmaker: string }[] };
const base = "https://www.nowgoal26.com";
const rosters = new Map<string, Roster>();
const snapshots = new Map<string, { at: number; markets: BookMarket[] }>();
const observed = new Map<string, BookMarket[]>();
const RETAIN_MS = 60 * 60_000;
const MAX_FIXTURES = 2000;
const FRESH_MS = 2 * 60_000;
const MAX_BOOK_REQUESTS_PER_CYCLE = 48;
let fixtureCursor = 0;
const lastQueried = new Map<string, number>();
const lastWarning = new Map<string, number>();
function warnUnavailable(key: string, context: Record<string, unknown>, err: unknown): void {
  const previous = lastWarning.get(key);
  if (previous != null && Date.now() - previous < 5 * 60_000) return;
  lastWarning.set(key, Date.now());
  logger.warn({ ...context, err }, "[ODDS-RADAR] bookmaker source unavailable");
  while (lastWarning.size > MAX_FIXTURES * 24) lastWarning.delete(lastWarning.keys().next().value!);
}

async function request(path: string, signal?: AbortSignal): Promise<string> {
  const res = await fetch(`${base}${path}`, {
    headers: {
      Referer: `${base}/`,
      "User-Agent": USER_AGENT_POOL[0]!,
      "X-Requested-With": "XMLHttpRequest",
      Accept: "application/json, text/html, */*",
    },
    signal: AbortSignal.any([AbortSignal.timeout(5_000), ...(signal ? [signal] : [])]),
  });
  if (!res.ok) throw new Error(`NowGoal bookmaker feed HTTP ${res.status}`);
  return res.text();
}
function envelope(body: string): Record<string, unknown> {
  let json: unknown;
  try { json = JSON.parse(body); }
  catch { throw new Error("NowGoal bookmaker response is not JSON"); }
  if (!json || typeof json !== "object" ||
      (json as { ErrCode?: unknown }).ErrCode !== 0 ||
      !(json as { Data?: unknown }).Data ||
      typeof (json as { Data: unknown }).Data !== "object") {
    throw new Error("NowGoal bookmaker response has no valid Data envelope");
  }
  return (json as { Data: Record<string, unknown> }).Data;
}
function odds(value: unknown, hk: boolean): number | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  if (String(value).trim() === "") return null;
  const n = Number(value);
  const decimal = hk ? n + 1 : n;
  return Number.isFinite(decimal) && decimal > 1 && decimal <= 20 ? decimal : null;
}
function line(value: unknown): number | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const raw = String(value).trim();
  const split = /^(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/.exec(raw);
  const parsed = split ? (Number(split[1]) + Number(split[2])) / 2 : Number(raw);
  return raw && Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}
function parseHistory(rows: unknown, side: MarketSide, observedAt: number): BookPoint[] {
  if (!Array.isArray(rows)) return [];
  const result: BookPoint[] = [];
  let lastTs = Infinity;
  for (const input of rows) {
    if (!input || typeof input !== "object") break;
    const item = input as { type?: unknown; close?: unknown; mt?: unknown; odds?: Record<string, unknown> };
    // The endpoint is newest-first. Never compare live with a pre-match or
    // closed segment or leap over an invalid quote.
    if (item.type !== 0 || item.close !== false) break;
    const ts = Number(item.mt) * 1000;
    const marketLine = side === "HOME" || side === "AWAY" ? null : line(item.odds?.g);
    const price = odds(item.odds?.[side === "HOME" || side === "OVER" ? "u" : "d"],
      side === "OVER" || side === "UNDER");
    if (!Number.isSafeInteger(ts) || ts > observedAt + 5000 || ts <= 0 ||
        ts >= lastTs || price === null ||
        ((side === "OVER" || side === "UNDER") && marketLine === null)) break;
    result.push({ ts, odds: price, line: marketLine });
    lastTs = ts;
  }
  return result.reverse();
}
export function parseBookHistory(body: string, cid: string, bookmaker: string,
  observedAt = Date.now()): BookMarket[] {
  const data = envelope(body);
  const markets: BookMarket[] = [];
  for (const [field, sides] of [
    ["op", ["HOME", "AWAY"]],
    ["ou", ["OVER", "UNDER"]],
  ] as const) {
    for (const side of sides) {
      const history = parseHistory(data[field], side, observedAt);
      const current = history.at(-1);
      if (current) markets.push({ cid, bookmaker, side, line: current.line,
        observedAt, current, history, timeSource: "upstream" });
    }
  }
  return markets;
}
/** The per-match company grid, not a static allow-list, is the source of cid/name.
 * Require the cid also to be present in the exact match's Ajax quote roster. */
export function parseBookRoster(html: string, body: string): { cid: string; bookmaker: string }[] {
  const data = envelope(body);
  if (!Array.isArray(data.roddsList)) throw new Error("NowGoal match has no bookmaker quote roster");
  const quoted = new Set((data.roddsList as { cid?: unknown }[])
    .filter((r) => r && Number.isSafeInteger(Number(r.cid)) && Number(r.cid) > 0)
    .map((r) => String(Number(r.cid))));
  const roster = new Map<string, string>();
  for (const row of html.matchAll(/<tr\b[^>]*\bcid=["'](\d+)["'][^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cid = row[1]!;
    if (!quoted.has(cid)) continue;
    const escaped = row[2]!.match(/_oddsDetailWin\.open\([^,]+,\s*\d+,\s*'([^']+)'/);
    const name = escaped?.[1]?.trim();
    if (name && !/[<>]/.test(name)) roster.set(cid, name);
  }
  if (!roster.size) throw new Error("NowGoal bookmaker names unavailable for match");
  return [...roster].map(([cid, bookmaker]) => ({ cid, bookmaker }));
}
function observeCurrent(matchId: string, roster: Roster, body: string, at: number): void {
  const data = envelope(body);
  if (!Array.isArray(data.roddsList)) throw new Error("NowGoal current quote list missing");
  const named = new Map(roster.books.map((book) => [book.cid, book.bookmaker]));
  const previous = observed.get(matchId) ?? [];
  const next: BookMarket[] = [];
  for (const input of data.roddsList) {
    if (!input || typeof input !== "object") continue;
    const row = input as { cid?: unknown; euro?: Record<string, unknown>; ou?: Record<string, unknown> };
    const cid = String(Number(row.cid));
    const bookmaker = named.get(cid);
    if (!bookmaker) continue;
    for (const side of ["HOME", "AWAY", "OVER", "UNDER"] as const) {
      const ou = side === "OVER" || side === "UNDER";
      const source = ou ? row.ou : row.euro;
      const targetLine = ou ? line(source?.g) : null;
      const price = odds(source?.[side === "HOME" || side === "OVER" ? "u" : "d"], ou);
      if (price === null || (ou && targetLine === null)) continue;
      const point = { ts: at, odds: price, line: targetLine };
      const old = previous.find((m) => m.cid === cid && m.side === side);
      // A changed handicap starts a new, independent price history.
      const history = old?.line === targetLine &&
        old.current.ts < at && at - old.current.ts <= FRESH_MS
        ? [...old.history.filter((p) => p.ts >= at - 6 * 60_000), point] : [point];
      next.push({ cid, bookmaker, side, line: targetLine, observedAt: at,
        current: point, history, timeSource: "observed" });
    }
  }
  observed.set(matchId, next);
  while (observed.size > MAX_FIXTURES) observed.delete(observed.keys().next().value!);
}
async function rosterFor(matchId: string, signal?: AbortSignal): Promise<Roster> {
  const existing = rosters.get(matchId);
  const freshNames = existing && Date.now() - existing.at < 90_000;
  const [html, list] = await Promise.all([
    freshNames ? Promise.resolve(null) : request(`/oddscomp/${matchId}`, signal),
    request(`/Ajax/SoccerAjax?type=14&id=${matchId}&t=11&h=0`, signal),
  ]);
  const roster = html === null ? existing! : {
    at: Date.now(), books: parseBookRoster(html, list),
  };
  observeCurrent(matchId, roster, list, Date.now());
  rosters.set(matchId, roster);
  while (rosters.size > MAX_FIXTURES) rosters.delete(rosters.keys().next().value!);
  return roster;
}
/** Fair bounded refresh: rotating fixture inspection and oldest-first book
 * queries, including failures. Unvisited companies are never declared quiet. */
export async function refreshRadarBooks(matchIds: readonly string[], signal?: AbortSignal):
  Promise<Map<string, BookMarket[]>> {
  const fixtures = [...new Set(matchIds.filter((id) => /^\d+$/.test(id)))];
  // Bound directory traffic too, including on a cold boot with hundreds of
  // live matches. The rotating cursor eventually visits every active match.
  const visit = fixtures.slice(fixtureCursor).concat(fixtures.slice(0, fixtureCursor)).slice(0, 12);
  fixtureCursor = fixtures.length ? (fixtureCursor + visit.length) % fixtures.length : 0;
  const discovered = await Promise.allSettled(visit.map((id) => rosterFor(id, signal)));
  const failedRosters = new Set<string>();
  for (let i = 0; i < discovered.length; i++) {
    if (discovered[i]!.status === "fulfilled") continue;
    const matchId = visit[i]!;
    failedRosters.add(matchId);
    rosters.delete(matchId);
    snapshots.delete(matchId);
    observed.delete(matchId);
    if (!signal?.aborted) warnUnavailable(`roster:${matchId}`, { matchId, transport: "roster" },
      (discovered[i] as PromiseRejectedResult).reason);
  }
  const pairs = fixtures.flatMap((matchId) =>
    failedRosters.has(matchId) ? [] :
      rosters.get(matchId)?.books.map((book) => ({ matchId, ...book })) ?? []);
  pairs.sort((a, b) =>
    (lastQueried.get(`${a.matchId}:${a.cid}`) ?? 0) -
    (lastQueried.get(`${b.matchId}:${b.cid}`) ?? 0) ||
    a.matchId.localeCompare(b.matchId, undefined, { numeric: true }) ||
    Number(a.cid) - Number(b.cid));
  const batch = pairs.slice(0, MAX_BOOK_REQUESTS_PER_CYCLE);
  for (const p of batch) lastQueried.set(`${p.matchId}:${p.cid}`, Date.now());
  const output = new Map<string, BookMarket[]>();
  const queried = new Map<string, Set<string>>();
  for (let i = 0; i < batch.length; i += 6) {
    const group = batch.slice(i, i + 6);
    const settled = await Promise.allSettled(group.map(async (b) => {
      const body = await request(`/Ajax/SoccerAjax?type=14&id=${b.matchId}&t=20&cid=${b.cid}&h=0&r1=0&r2=0&r3=0`, signal);
      return { ...b, markets: parseBookHistory(body, b.cid, b.bookmaker) };
    }));
    for (let index = 0; index < settled.length; index++) {
      const item = settled[index]!;
      const queriedBook = group[index]!;
      const queriedBooks = queried.get(queriedBook.matchId) ?? new Set<string>();
      queriedBooks.add(queriedBook.cid);
      queried.set(queriedBook.matchId, queriedBooks);
      if (item.status !== "fulfilled") {
        if (!signal?.aborted) warnUnavailable(`history:${queriedBook.matchId}:${queriedBook.cid}`,
          { matchId: queriedBook.matchId, cid: queriedBook.cid, transport: "history" }, item.reason);
        continue;
      }
      const { matchId, markets } = item.value;
      if (!markets.length) continue;
      output.set(matchId, [...output.get(matchId) ?? [], ...markets]);
    }
  }
  for (const [matchId, touched] of queried) {
    const markets = output.get(matchId) ?? [];
    const existing = snapshots.get(matchId)?.markets.filter((old) =>
      Date.now() - old.observedAt <= FRESH_MS &&
      !touched.has(old.cid)) ?? [];
    snapshots.set(matchId, { at: Date.now(), markets: [...existing, ...markets] });
  }
  for (const [id, value] of snapshots) if (Date.now() - value.at > RETAIN_MS) snapshots.delete(id);
  while (snapshots.size > MAX_FIXTURES) snapshots.delete(snapshots.keys().next().value!);
  while (lastQueried.size > MAX_FIXTURES * 24) lastQueried.delete(lastQueried.keys().next().value!);
  const fresh = new Map<string, BookMarket[]>();
  for (const id of fixtures) {
    if (failedRosters.has(id)) continue;
    const upstream = snapshots.get(id)?.markets.filter((m) =>
      Date.now() - m.observedAt <= FRESH_MS && Date.now() - m.current.ts <= FRESH_MS) ?? [];
    const markets = [...upstream];
    for (const local of observed.get(id) ?? []) {
      if (Date.now() - local.observedAt > FRESH_MS || local.history.length < 2 ||
          markets.some((remote) => remote.cid === local.cid && remote.side === local.side &&
            remote.line === local.line)) continue;
      markets.push(local);
    }
    if (markets.length) fresh.set(id, markets);
  }
  return fresh;
}
/** Display-only enrichment. Synchronous and empty on unavailable evidence:
 * this is never an admission rule for SMART MONEY or SMART EXCAPPER. */
export function getCachedBookMovements(matchId: string, side: "OVER" | "UNDER",
  targetLine: number, cutoff: number): BookMovement[] {
  const cached = snapshots.get(matchId);
  const markets = [
    ...(cached && Date.now() - cached.at <= FRESH_MS ? cached.markets : []),
    ...observed.get(matchId) ?? [],
  ];
  return markets.filter((m) => m.side === side && m.line === targetLine &&
      Date.now() - m.observedAt <= FRESH_MS &&
      // Prefer original upstream timestamps when both transports expose a book.
      (m.timeSource === "upstream" || !markets.some((other) =>
        other.timeSource === "upstream" && other.cid === m.cid &&
        other.side === m.side && other.line === m.line)))
    .flatMap((m) => {
      const past = m.history.filter((point) => point.ts <= cutoff);
      const exact: BookPoint[] = [];
      for (let i = past.length - 1; i >= 0; i--) {
        const point = past[i]!;
        if (point.line !== targetLine || point.ts < cutoff - 5 * 60_000) break;
        exact.unshift(point);
      }
      if (exact.length < 2 || cutoff - exact.at(-1)!.ts > FRESH_MS) return [];
      const first = exact[0]!, last = exact.at(-1)!;
      if (first.ts >= last.ts || first.odds === last.odds) return [];
      const delta = last.odds - first.odds;
      return [{ cid: m.cid, bookmaker: m.bookmaker, type: delta < 0 ? "drop" as const : "rise" as const,
        from: first.odds, to: last.odds, percent: delta / first.odds * 100,
        quoteAt: last.ts, history: m.timeSource === "observed" ? [] :
          exact.map(({ ts, odds }) => ({ ts, odds })) }];
    });
}