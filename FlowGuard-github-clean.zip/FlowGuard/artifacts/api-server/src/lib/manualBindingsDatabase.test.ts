import { mkdtemp, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  rows: new Map<string, Record<string, unknown>>(),
  marker: false,
  fail: false,
  active: { kind: "active", nowgoalId: "nowgoalId", payload: "payload" },
  markerTable: { kind: "marker", name: "name" },
  blocks: { kind: "blocks", diagnosticId: "diagnosticId", gameId: "gameId" },
  decisions: { kind: "decisions", id: "id" },
}));

vi.mock("@workspace/db", () => ({
  manualActiveBindingsTable: state.active,
  manualBindingsImportTable: state.markerTable,
  manualBindingBlocksTable: state.blocks,
  bindingDecisionsTable: state.decisions,
  db: {
    select: () => ({
      from: (table: unknown) => {
        const result = table === state.markerTable
          ? (state.marker ? [{ name: "active_bindings_v1" }] : [])
          : table === state.active
            ? [...state.rows.values()].map((row) => ({ payload: row.payload }))
            : [];
        return { where: async () => result, then: (resolve: (rows: unknown[]) => void) => resolve(result) };
      },
    }),
    transaction: async (run: (tx: unknown) => Promise<unknown>) => {
      const rows = new Map(state.rows);
      let marker = state.marker;
      const tx = {
        execute: async () => undefined,
        select: () => ({ from: () => ({ where: async () => [] }) }),
        insert: (table: unknown) => ({
          values: (row: Record<string, unknown>) => ({
            onConflictDoNothing: () => ({
              returning: async () => {
                if (table === state.markerTable) {
                  if (marker) return [];
                  marker = true;
                  return [{ name: row.name }];
                }
                rows.set(row.nowgoalId as string, row);
                return [row];
              },
              then: (resolve: (value: unknown) => void) => {
                rows.set(row.nowgoalId as string, row);
                resolve(undefined);
              },
            }),
            onConflictDoUpdate: async () => {
              if (state.fail) throw new Error("database write failed");
              rows.set(row.nowgoalId as string, row);
            },
          }),
        }),
      };
      const result = await run(tx);
      state.rows = rows;
      state.marker = marker;
      return result;
    },
  },
}));

import {
  __testOnlySetManualBindingsPaths, __testOnlyUseManualBindingsDatabase,
  getPersistedManualBindings, initManualBindingsStore, savePersistedManualBinding,
} from "./manualBindingsStore";

describe("PostgreSQL authoritative manual bindings", () => {
  let dir: string;
  afterEach(async () => { await rm(dir, { recursive: true, force: true }); });

  it("imports once and restores after the container file disappears", async () => {
    dir = await mkdtemp(path.join(os.tmpdir(), "bindings-db-"));
    const file = path.join(dir, "active_bindings.json");
    const binding = {
      nowgoalId: "42", excapperId: "FORCE_MANUAL",
      boundAt: "2026-09-22T00:00:00.000Z", status: "Verified" as const, autoBound: false,
    };
    state.rows = new Map();
    state.marker = false;
    state.fail = false;
    await writeFile(file, JSON.stringify({ bindings: [binding] }));
    const legacy = path.join(dir, "legacy.json");
    await writeFile(legacy, JSON.stringify({ bindings: [{
      nowgoalId: "old-reset", excapperId: "101",
      boundAt: "2026-09-20T00:00:00.000Z", status: "Verified", autoBound: false,
    }] }));
    __testOnlySetManualBindingsPaths(file, legacy);
    __testOnlyUseManualBindingsDatabase();
    expect(await initManualBindingsStore()).toEqual([binding]);
    await rm(file);
    __testOnlyUseManualBindingsDatabase();
    expect(await initManualBindingsStore()).toEqual([binding]);
    expect(state.marker).toBe(true);
  });

  it("does not resurrect a stale file after an empty first boot and reports write failures", async () => {
    dir = await mkdtemp(path.join(os.tmpdir(), "bindings-db-"));
    const file = path.join(dir, "active_bindings.json");
    state.rows = new Map();
    state.marker = false;
    state.fail = false;
    const legacy = path.join(dir, "legacy.json");
    await writeFile(legacy, JSON.stringify({ bindings: [{
      nowgoalId: "old-reset", excapperId: "101",
      boundAt: "2026-09-20T00:00:00.000Z", status: "Verified", autoBound: false,
    }] }));
    __testOnlySetManualBindingsPaths(file, legacy);
    __testOnlyUseManualBindingsDatabase();
    expect(await initManualBindingsStore()).toEqual([]);
    const binding = {
      nowgoalId: "42", excapperId: "91001",
      boundAt: "2026-09-22T00:00:00.000Z", status: "Verified" as const, autoBound: false,
    };
    await writeFile(file, JSON.stringify({ bindings: [binding] }));
    __testOnlyUseManualBindingsDatabase();
    expect(await initManualBindingsStore()).toEqual([]);
    state.fail = true;
    await expect(savePersistedManualBinding(binding)).rejects.toThrow("database write failed");
    expect(getPersistedManualBindings()).toEqual([]);
  });
});