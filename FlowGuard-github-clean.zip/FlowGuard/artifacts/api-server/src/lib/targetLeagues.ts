/**
 * Canonical target-league policy.
 *
 * Every ingestion path (NowGoal, Excapper, manual watchlist and manual
 * promotion) must use this module.  A missing, blank or unrecognised league
 * name is deliberately rejected: team names, priority flags and user intent
 * are not evidence that a fixture belongs to an approved competition.
 */

import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { mkdir, rename, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

export interface TargetLeague {
  readonly label: string;
  readonly patterns: readonly RegExp[];
  readonly allowsCup?: boolean;
  readonly allowsYouth?: boolean;
  readonly allowsLowerTier?: boolean;
}

export interface LeaguePolicyEntry {
  name: string;
  aliases: string[];
  displayNameRu: string;
  custom: boolean;
  patterns: string[];
}

export interface LeaguePolicySnapshot {
  revision: string;
  mode: "whitelist" | "empty";
  total: number;
  entries: LeaguePolicyEntry[];
  rulesRu: string[];
  storageNoticeRu: string;
}

export class LeaguePolicyError extends Error {
  constructor(
    public readonly code: "validation" | "conflict" | "persistence",
    message: string,
  ) {
    super(message);
    this.name = "LeaguePolicyError";
  }
}

/**
 * The only leagues the scanner is allowed to ingest or alert on.
 *
 * The labels are stable/canonical and are also used by the pre-match scheduler
 * for its message metadata. The persisted JSON array below is the policy
 * authority; definitions not present there are disabled fail-closed.
 */
const TARGET_DEFINITIONS: readonly TargetLeague[] = [
  { label: "Ecuadorian Serie B", patterns: [/^Ecuadorian Serie B$/i], allowsLowerTier: true },
  { label: "Finland Kakkonen D3", patterns: [/\bfinland(?:ian)?\b.*\bkakkonen\b/i] },
  {
    label: "Singapore S-League",
    patterns: [
      /\bsingapore(?:an)?\b.*\bs[-\s]?league\b/i,
      /\bsingapore(?:an)?\b.*\bpremier\s+league\b/i,
      /\bs[-\s]?league\b.*\bsingapore(?:an)?\b/i,
      /\bpremier\s+league\b.*\bsingapore(?:an)?\b/i,
    ],
  },
  {
    label: "Peruvian Segunda Division",
    patterns: [
      /\bperu(?:vian)?\b.*\bsegunda(?:\s+division)?\b/i,
      /\bsegunda(?:\s+division)?\b.*\bperu(?:vian)?\b/i,
      /\bperu(?:vian)?\b.*\bliga\s*2\b/i,
      /\bliga\s*2\b.*\bperu(?:vian)?\b/i,
    ],
  },
  {
    label: "Liga Super Malaysia",
    patterns: [
      /\bliga\s+super\s+malaysia[n]?\b/i,
      /\bmalaysia[n]?\b.*\bsuper\s+league\b/i,
    ],
  },
  {
    label: "FA Cup Malaysia",
    patterns: [
      /\bfa[-\s]*cup\s+malaysia[n]?\b/i,
      /\bmalaysia[n]?\b.*\bfa[-\s]*cup\b/i,
    ],
  },
  {
    // Malaysia is the explicit country-wide exception. Keep named
    // competitions above this broad fallback for canonical display labels.
    label: "Malaysia",
    patterns: [/\bmalaysia[n]?\b/i],
  },
  {
    label: "Indian I-League 2nd Division",
    patterns: [
      /\b(?:india|indian)\b.*\bi-?\s*league\b.*\b(?:2nd|second|ii)\s+division\b/i,
      /\bi-?\s*league\b.*\b(?:2nd|second|ii)\s+division\b.*\b(?:india|indian)\b/i,
      /\b(?:india|indian)\b.*\bi-?\s*league\s*(?:2|2nd|second|ii)(?:\s+division)?\b/i,
      /\bi-?\s*league\s*(?:2|2nd|second|ii)(?:\s+division)?\b.*\b(?:india|indian)\b/i,
    ],
  },
  {
    label: "Hong Kong 1st Division League",
    patterns: [
      /\bhong\s*kong\b.*\b(?:1st|first)\s+division(?:\s+league)?\b/i,
      /\b(?:1st|first)\s+division(?:\s+league)?\b.*\bhong\s*kong\b/i,
      /\bhong\s*kong\b.*\bdivision\s*1(?:\s+league)?\b/i,
      /\bdivision\s*1(?:\s+league)?\b.*\bhong\s*kong\b/i,
    ],
  },
  {
    label: "Hong Kong 2nd Division League",
    patterns: [
      /\bhong\s*kong\b.*\b(?:2nd|second)\s+division(?:\s+league)?\b/i,
      /\b(?:2nd|second)\s+division(?:\s+league)?\b.*\bhong\s*kong\b/i,
      /\bhong\s*kong\b.*\bdivision\s*2(?:\s+league)?\b/i,
      /\bdivision\s*2(?:\s+league)?\b.*\bhong\s*kong\b/i,
    ],
  },
  {
    label: "German 3.Liga",
    patterns: [/\b(?:germany|german)\b.*\b3\.?\s*liga\b/i, /\b3\.?\s*liga\b.*\b(?:germany|german)\b/i],
  },
  {
    label: "Costa Rican Liga de Ascenso",
    patterns: [
      /\bcosta\s*rica[n]?\b.*\bliga\s+de\s+ascenso\b/i,
      /\bliga\s+de\s+ascenso\b.*\bcosta\s*rica[n]?\b/i,
    ],
  },
  {
    label: "Colombian Primera B",
    patterns: [
      /\bcolombia[n]?\b.*\bprimera\s+b\b/i,
      /\bprimera\s+b\b.*\bcolombia[n]?\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Bolivian Liga de Futbol Profesional",
    patterns: [
      /\bbolivia[n]?\b.*\bliga\s+de\s+f(?:u|ú)tbol\s+profesional\b/i,
      /\bliga\s+de\s+f(?:u|ú)tbol\s+profesional\b.*\bbolivia[n]?\b/i,
      /\bbolivia[n]?\b.*\bdivisi(?:o|ó)n\s+profesional\b/i,
      /\bdivisi(?:o|ó)n\s+profesional\b.*\bbolivia[n]?\b/i,
    ],
  },
  {
    label: "Bolivian Copa Simon Bolivar",
    patterns: [
      /\bbolivia[n]?\b.*\bcopa\s+sim(?:o|ó)n\s+bol(?:i|í)var\b/i,
      /\bcopa\s+sim(?:o|ó)n\s+bol(?:i|í)var\b.*\bbolivia[n]?\b/i,
    ],
    allowsCup: true,
    allowsLowerTier: true,
  },
  {
    label: "Bhutan Premier",
    patterns: [/\bbhutan(?:ese)?\b.*\bpremier\s+league\b/i],
  },
  {
    label: "Armenian Premier",
    patterns: [/\barmenia[n]?\b.*\bpremier\s+league\b/i],
  },
  {
    label: "Argentinian Primera B Metropolitana",
    patterns: [
      /\bargentin(?:a|ian)\b.*\bprimera\s+b\b.*\bmetropolitana\b/i,
      /\bprimera\s+b\b.*\bmetropolitana\b.*\bargentin(?:a|ian)\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Argentinian Primera C Metropolitana",
    patterns: [
      /\bargentin(?:a|ian)\b.*\bprimera\s+c(?:\s+metropolitana)?\b/i,
      /\bprimera\s+c(?:\s+metropolitana)?\b.*\bargentin(?:a|ian)\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Argentinian Primera D",
    patterns: [
      /\bargentin(?:a|ian)\b.*\bprimera\s+d(?:\s+metropolitana)?\b/i,
      /\bprimera\s+d(?:\s+metropolitana)?\b.*\bargentin(?:a|ian)\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Argentinian Torneo Federal A",
    patterns: [
      /\bargentin(?:a|ian)\b.*\btorneo\s+federal\s+a\b/i,
      /\btorneo\s+federal\s+a\b.*\bargentin(?:a|ian)\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Indian Mumbai Super Division",
    patterns: [
      /\b(?:india|indian)\b.*\bmumbai\s+super\s+division\b/i,
      /\bmumbai\s+super\s+division\b/i,
    ],
  },
  {
    label: "Indian Shillong Premier League",
    patterns: [
      /\b(?:india|indian)\b.*\bshillong\s+premier(?:\s+league)?\b/i,
      /\bshillong\s+premier(?:\s+league)?\b/i,
    ],
  },
  {
    label: "Myanmar U21 League",
    patterns: [/\bmyanmar\b.*\bu[-\s]?21\b/i, /\bu[-\s]?21\b.*\bmyanmar\b/i],
  },
  {
    label: "Puerto Rico League",
    patterns: [/\bpuerto\s*rico\s+(?:soccer\s+)?league\b/i],
  },
  {
    label: "Paraguay Reserve Team League",
    patterns: [
      /\bparaguay(?:an)?\b.*\breserve\s+team(?:\s+league)?\b/i,
      /\breserve\s+team(?:\s+league)?\b.*\bparaguay(?:an)?\b/i,
    ],
  },
  {
    label: "Bangladesh Premier League",
    patterns: [/\bbangladesh(?:i)?\b.*\bpremier\s+league\b/i],
  },
  {
    label: "Brazilian Paulista A3",
    patterns: [
      /\b(?:brazil|brasil)(?:ian|eiro)?\b.*\b(?:campeonato\s+)?paulista\s+(?:s(?:e|é)rie\s+)?a[-\s]?3\b/i,
      /\b(?:campeonato\s+)?paulista\s+(?:s(?:e|é)rie\s+)?a[-\s]?3\b.*\b(?:brazil|brasil)(?:ian|eiro)?\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Brazilian Paulista A4",
    patterns: [
      /\b(?:brazil|brasil)(?:ian|eiro)?\b.*\b(?:campeonato\s+)?paulista\s+(?:s(?:e|é)rie\s+)?a[-\s]?4\b/i,
      /\b(?:campeonato\s+)?paulista\s+(?:s(?:e|é)rie\s+)?a[-\s]?4\b.*\b(?:brazil|brasil)(?:ian|eiro)?\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Brazilian Carioca B1",
    patterns: [
      /\b(?:brazil|brasil)(?:ian|eiro)?\b.*\b(?:campeonato\s+)?carioca\s+(?:s(?:e|é)rie\s+)?b[-\s]?1\b/i,
      /\b(?:campeonato\s+)?carioca\s+(?:s(?:e|é)rie\s+)?b[-\s]?1\b.*\b(?:brazil|brasil)(?:ian|eiro)?\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Brazilian Carioca B2",
    patterns: [
      /\b(?:brazil|brasil)(?:ian|eiro)?\b.*\b(?:campeonato\s+)?carioca\s+(?:s(?:e|é)rie\s+)?b[-\s]?2\b/i,
      /\b(?:campeonato\s+)?carioca\s+(?:s(?:e|é)rie\s+)?b[-\s]?2\b.*\b(?:brazil|brasil)(?:ian|eiro)?\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Brazilian State Cups",
    patterns: [
      /\b(?:brazil|brasil)(?:ian|eiro)?\b.*\bstate\s+cups?\b/i,
      /\b(?:brazil|brasil)(?:ian|eiro)?\b.*\bcopa\s+(?:paulista|rio|ga(?:u|ú)cha|paran(?:a|á)|santa\s+catarina|f(?:a|á)res\s+lopes)\b/i,
      /\bcopa\s+(?:paulista|rio|ga(?:u|ú)cha|paran(?:a|á)|santa\s+catarina|f(?:a|á)res\s+lopes)\b.*\b(?:brazil|brasil)(?:ian|eiro)?\b/i,
    ],
    allowsCup: true,
  },
  {
    label: "Vietnam V-League 2",
    patterns: [
      /\bvietnam(?:ese)?\b.*\b(?:v[-\s]?(?:league|leauge)\s*2|first\s+division)\b/i,
      /\b(?:v[-\s]?(?:league|leauge)\s*2|first\s+division)\b.*\bvietnam(?:ese)?\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Vietnam U19 Championship",
    patterns: [
      /\bvietnam(?:ese)?\b.*\bu[-\s]?19\s+(?:national\s+)?championship\b/i,
      /\bu[-\s]?19\s+(?:national\s+)?championship\b.*\bvietnam(?:ese)?\b/i,
    ],
    allowsYouth: true,
  },
  {
    label: "Vietnam U21 Championship",
    patterns: [
      /\bvietnam(?:ese)?\b.*\bu[-\s]?21\s+(?:national\s+)?championship\b/i,
      /\bu[-\s]?21\s+(?:national\s+)?championship\b.*\bvietnam(?:ese)?\b/i,
    ],
    allowsYouth: true,
  },
  {
    label: "Indonesia Liga 2",
    patterns: [/\bindonesia[n]?\b.*\bliga\s*2\b/i, /\bliga\s*2\b.*\bindonesia[n]?\b/i],
    allowsLowerTier: true,
  },
  {
    label: "Indonesia Liga 3",
    patterns: [/\bindonesia[n]?\b.*\bliga\s*3\b/i, /\bliga\s*3\b.*\bindonesia[n]?\b/i],
    allowsLowerTier: true,
  },
  {
    label: "Philippines National/Premier League",
    patterns: [
      /\b(?:philippines?|filipino)\b.*\b(?:football|national|premier)\s+league\b/i,
      /\b(?:football|national|premier)\s+league\b.*\b(?:philippines?|filipino)\b/i,
      /\bphilippines?\s+ufl\b/i,
    ],
  },
  {
    label: "Australia NPL Victoria",
    patterns: [
      /\baustralia[n]?\b.*\b(?:npl\s+victoria|victoria\s+(?:npl|premier\s+league))\b/i,
      /\b(?:npl\s+victoria|victoria\s+(?:npl|premier\s+league))\b.*\baustralia[n]?\b/i,
    ],
  },
  {
    label: "Australia NPL New South Wales",
    patterns: [
      /\baustralia[n]?\b.*\b(?:npl\s+(?:nsw|new\s+south\s+wales)|(?:nsw|new\s+south\s+wales)\s+(?:npl|premier\s+league))\b/i,
      /\b(?:npl\s+(?:nsw|new\s+south\s+wales)|(?:nsw|new\s+south\s+wales)\s+(?:npl|premier\s+league))\b.*\baustralia[n]?\b/i,
    ],
  },
  {
    label: "Australia NPL Queensland",
    patterns: [
      /\baustralia[n]?\b.*\b(?:npl\s+(?:qld|queensland)|(?:qld|queensland)\s+(?:npl|premier\s+league))\b/i,
      /\b(?:npl\s+(?:qld|queensland)|(?:qld|queensland)\s+(?:npl|premier\s+league))\b.*\baustralia[n]?\b/i,
    ],
  },
  {
    label: "Greece Super League 2",
    patterns: [
      /\b(?:greece|greek)\b.*\bsuper\s+league\s*2\b/i,
      /\bsuper\s+league\s*2\b.*\b(?:greece|greek)\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Serbia Prva Liga",
    patterns: [/\bserbia[n]?\b.*\bprva\s+liga\b/i, /\bprva\s+liga\b.*\bserbia[n]?\b/i],
    allowsLowerTier: true,
  },
  {
    label: "North Macedonia Prva Liga",
    patterns: [
      /\b(?:north\s+macedonia|macedonia[n]?)\b.*\bprva\s+liga\b/i,
      /\bprva\s+liga\b.*\b(?:north\s+macedonia|macedonia[n]?)\b/i,
    ],
  },
  {
    label: "Bulgaria Second League",
    patterns: [
      /\b(?:bulgaria[n]?)\b.*\b(?:second\s+league|vtora\s+liga)\b/i,
      /\b(?:second\s+league|vtora\s+liga)\b.*\b(?:bulgaria[n]?)\b/i,
      /(?:^|\s)българия.*(?:втора\s+лига)(?:\s|$)/iu,
      /(?:^|\s)втора\s+лига.*българия(?:\s|$)/iu,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Czech 3 Liga",
    patterns: [
      /\b(?:czechia|czech(?:\s+republic)?)\b.*\b3\.?\s*(?:liga|league)\b/i,
      /\b3\.?\s*(?:liga|league)\b.*\b(?:czechia|czech(?:\s+republic)?)\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Czech MSFL",
    patterns: [
      /\b(?:czechia|czech(?:\s+republic)?)\b.*\bmsfl\b/i,
      /\bmsfl\b.*\b(?:czechia|czech(?:\s+republic)?)\b/i,
      /\b(?:czechia|czech(?:\s+republic)?)\b.*\bmoravskoslezsk(?:a|á)\s+fotbalov(?:a|á)\s+liga\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Czech CFL",
    patterns: [
      /\b(?:czechia|czech(?:\s+republic)?)\b.*(?:^|\s)(?:cfl|čfl)(?=\s|$)/iu,
      /(?:^|\s)(?:cfl|čfl)(?=\s|$).*\b(?:czechia|czech(?:\s+republic)?)\b/iu,
      /\b(?:czechia|czech(?:\s+republic)?)\b.*\bčesk(?:a|á)\s+fotbalov(?:a|á)\s+liga\b/iu,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Slovakia 3 Liga",
    patterns: [
      /\bslovak(?:ia|ian)?\b.*\b3\.?\s*(?:liga|league)\b/i,
      /\b3\.?\s*(?:liga|league)\b.*\bslovak(?:ia|ian)?\b/i,
    ],
    allowsLowerTier: true,
  },
  {
    label: "Czech Winter Cup",
    patterns: [
      /\b(?:czechia|czech(?:\s+republic)?)\b.*\b(?:winter|tipsport)\s+(?:league|cup|liga)\b/i,
      /\b(?:winter|tipsport)\s+(?:league|cup|liga)\b.*\b(?:czechia|czech(?:\s+republic)?)\b/i,
    ],
    allowsCup: true,
  },
  {
    label: "Slovakia Winter Cup",
    patterns: [
      /\bslovak(?:ia|ian)?\b.*\b(?:winter|tipsport)\s+(?:league|cup|liga)\b/i,
      /\b(?:winter|tipsport)\s+(?:league|cup|liga)\b.*\bslovak(?:ia|ian)?\b/i,
    ],
    allowsCup: true,
  },
  {
    label: "International Club Friendlies",
    patterns: [
      /^\s*(?:international\s+)?clubs?\s+friendl(?:y|ies)(?:\s+games?)?\s*$/i,
      /^\s*international\s+friendl(?:y|ies)\s+clubs?\s*$/i,
    ],
  },
  {
    label: "U19 League",
    patterns: [/^\s*(?:international\s+)?u[-\s]?19\s+(?:football\s+)?league\s*$/i],
    allowsYouth: true,
  },
  {
    label: "U21 League",
    patterns: [/^\s*(?:international\s+)?u[-\s]?21\s+(?:football\s+)?league\s*$/i],
    allowsYouth: true,
  },
  {
    label: "U23 League",
    patterns: [/^\s*(?:international\s+)?u[-\s]?23\s+(?:football\s+)?league\s*$/i],
    allowsYouth: true,
  },
];

const TARGET_LEAGUE_CONFIG = "config/target-leagues.json";

const CONFIG_PATH_ENV = "TARGET_LEAGUES_CONFIG_PATH";
const MAX_POLICY_ENTRIES = 256;
const MAX_LEAGUE_NAME_LENGTH = 200;

function configCandidates(): string[] {
  const explicit = process.env[CONFIG_PATH_ENV];
  if (explicit) return [path.resolve(explicit)];
  return [
    path.resolve(process.cwd(), TARGET_LEAGUE_CONFIG),
    path.resolve(process.cwd(), "artifacts/api-server", TARGET_LEAGUE_CONFIG),
    path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../", TARGET_LEAGUE_CONFIG),
    path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../", TARGET_LEAGUE_CONFIG),
  ];
}

interface StoredLeague { name: string; aliases: string[] }

function readConfiguredNames(): { entries: StoredLeague[]; filePath: string } {
  // The service is normally started from artifacts/api-server. The additional
  // locations keep bundled builds, unit tests and workspace-root invocations
  // on the same persisted policy without silently falling back to a
  // TypeScript-only list.
  const candidates = configCandidates();
  for (const filePath of candidates) {
    try {
      const parsed: unknown = JSON.parse(readFileSync(filePath, "utf8"));
      if (!Array.isArray(parsed)) continue;
      return { entries: validatePolicyEntries(parsed, true), filePath };
    } catch {
      // Try the workspace-root candidate next. If neither exists or parses,
      // the empty set below deliberately fails closed.
    }
  }
  return { entries: [], filePath: candidates[0]! };
}

const RUSSIAN_LABELS: Readonly<Record<string, string>> = {
  "Ecuadorian Serie B": "Эквадор — Серия B",
  "Finland Kakkonen D3": "Финляндия — Какконен (Д3)",
  "Singapore S-League": "Сингапур — S-Лига",
  "Peruvian Segunda Division": "Перу — Второй дивизион",
  "Liga Super Malaysia": "Малайзия — Суперлига",
  "FA Cup Malaysia": "Малайзия — Кубок ФА",
  Malaysia: "Малайзия — все соревнования",
  "Indian I-League 2nd Division": "Индия — Второй дивизион I-Лиги",
  "Hong Kong 1st Division League": "Гонконг — Первый дивизион",
  "Hong Kong 2nd Division League": "Гонконг — Второй дивизион",
  "German 3.Liga": "Германия — Третья лига",
  "Costa Rican Liga de Ascenso": "Коста-Рика — Лига де Ассенсо",
  "Colombian Primera B": "Колумбия — Примера B",
  "Bolivian Liga de Futbol Profesional": "Боливия — Профессиональная футбольная лига",
  "Bolivian Copa Simon Bolivar": "Боливия — Кубок Симона Боливара",
  "Bhutan Premier": "Бутан — Премьер-лига",
  "Armenian Premier": "Армения — Премьер-лига",
  "Argentinian Primera B Metropolitana": "Аргентина — Примера B Метрополитана",
  "Argentinian Primera C Metropolitana": "Аргентина — Примера C Метрополитана",
  "Argentinian Primera D": "Аргентина — Примера D",
  "Argentinian Torneo Federal A": "Аргентина — Федеральный турнир A",
  "Indian Mumbai Super Division": "Индия — Супердивизион Мумбаи",
  "Indian Shillong Premier League": "Индия — Премьер-лига Шиллонга",
  "Myanmar U21 League": "Мьянма — Лига до 21 года",
  "Puerto Rico League": "Пуэрто-Рико — Лига",
  "Paraguay Reserve Team League": "Парагвай — Лига резервных команд",
  "Bangladesh Premier League": "Бангладеш — Премьер-лига",
  "Brazilian Paulista A3": "Бразилия — Паулиста A3",
  "Brazilian Paulista A4": "Бразилия — Паулиста A4",
  "Brazilian Carioca B1": "Бразилия — Кариока B1",
  "Brazilian Carioca B2": "Бразилия — Кариока B2",
  "Brazilian State Cups": "Бразилия — Кубки штатов",
  "Vietnam V-League 2": "Вьетнам — V-Лига 2",
  "Vietnam U19 Championship": "Вьетнам — Чемпионат до 19 лет",
  "Vietnam U21 Championship": "Вьетнам — Чемпионат до 21 года",
  "Indonesia Liga 2": "Индонезия — Лига 2",
  "Indonesia Liga 3": "Индонезия — Лига 3",
  "Philippines National/Premier League": "Филиппины — Национальная/Премьер-лига",
  "Australia NPL Victoria": "Австралия — НПЛ Виктория",
  "Australia NPL New South Wales": "Австралия — НПЛ Новый Южный Уэльс",
  "Australia NPL Queensland": "Австралия — НПЛ Квинсленд",
  "Greece Super League 2": "Греция — Суперлига 2",
  "Serbia Prva Liga": "Сербия — Первая лига",
  "North Macedonia Prva Liga": "Северная Македония — Первая лига",
  "Bulgaria Second League": "Болгария — Вторая лига",
  "Czech 3 Liga": "Чехия — Третья лига",
  "Czech MSFL": "Чехия — МСФЛ",
  "Czech CFL": "Чехия — ЧФЛ",
  "Slovakia 3 Liga": "Словакия — Третья лига",
  "Czech Winter Cup": "Чехия — Зимний кубок",
  "Slovakia Winter Cup": "Словакия — Зимний кубок",
  "International Club Friendlies": "Международные клубные товарищеские матчи",
  "U19 League": "Лига до 19 лет",
  "U21 League": "Лига до 21 года",
  "U23 League": "Лига до 23 лет",
};
const KNOWN_TARGET_LABELS = new Set(TARGET_DEFINITIONS.map((target) => target.label));
const KNOWN_TARGET_LABELS_CASE_INSENSITIVE = new Map(
  TARGET_DEFINITIONS.map((target) => [target.label.toLocaleLowerCase("en-US"), target.label]),
);

export const LEAGUE_POLICY_RULES_RU = [
  "Автоматическое сканирование разрешено только для соревнований из этого белого списка.",
  "Пустое, отсутствующее или неизвестное название лиги блокируется; идентификаторы приоритетных лиг не являются белым списком.",
  "Известные соревнования распознаются по каноническому названию и проверенным вариантам исходного названия; регистр канонического названия исправляется при сохранении и загрузке.",
  "Женские соревнования запрещены для известных правил; Малайзия является единственным исключением на уровне всей страны.",
  "Молодёжные соревнования запрещены, кроме явно разрешённых лиги Мьянмы до 21 года, чемпионатов Вьетнама до 19 и 21 года, лиг до 19, 21 и 23 лет и любых соревнований Малайзии.",
  "Резервные соревнования запрещены, кроме лиги резервных команд Парагвая и любых соревнований Малайзии.",
  "Кубки запрещены, кроме Кубка ФА Малайзии, Кубка Симона Боливара в Боливии, кубков штатов Бразилии, зимних кубков Чехии и Словакии и любых соревнований Малайзии.",
  "Нижние дивизионы разрешены только для явно перечисленных правил: Какконен Д3 Финляндии; второго дивизиона Перу; второго дивизиона Индии; первого и второго дивизионов Гонконга; третьей лиги Германии; Примеры Б Колумбии; Кубка Симона Боливара; Примеры Б, С, Д и Федерального турнира А Аргентины; Паулисты А3, А4 и Кариоки Б1, Б2 Бразилии; второй лиги Вьетнама; второй и третьей лиг Индонезии; Суперлиги 2 Греции; первой лиги Сербии; второй лиги Болгарии; третьей лиги, МСФЛ и ЧФЛ Чехии; третьей лиги Словакии. Широкое исключение действует только для всех соревнований Малайзии.",
  "Новое пользовательское название разрешается только как полное буквальное совпадение без учёта регистра; регулярные выражения и ключевые слова не создаются.",
  "Пустой список запрещает все автоматические сканирования, продвижения и оповещения.",
  "Ручное закрепление остаётся исключением только для показа и обогащения данных и не разрешает автоматические оповещения.",
] as const;

function literalPattern(name: string): RegExp {
  return new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i");
}

function targetsForNames(names: readonly string[]): TargetLeague[] {
  const known = new Map(TARGET_DEFINITIONS.map((target) => [target.label, target]));
  return names.map((name) => known.get(name) ?? { label: name, patterns: [literalPattern(name)] });
}

let loaded = readConfiguredNames();
let configuredEntries = loaded.entries;
let configuredNames = configuredEntries.map((entry) => entry.name);
let configuredFilePath = loaded.filePath;
const mutableTargetLeagues: TargetLeague[] = targetsForNames(configuredNames);
export const TARGET_LEAGUES: readonly TargetLeague[] = mutableTargetLeagues;
const TARGET_LABELS = new Set(configuredNames);

function replaceRuntimePolicy(entries: StoredLeague[], filePath = configuredFilePath): void {
  const names = entries.map((entry) => entry.name);
  const targets = targetsForNames(names);
  mutableTargetLeagues.splice(0, mutableTargetLeagues.length, ...targets);
  TARGET_LABELS.clear();
  for (const name of names) TARGET_LABELS.add(name);
  configuredNames = [...names];
  configuredEntries = entries;
  configuredFilePath = filePath;
}

function revisionFor(entries: readonly StoredLeague[]): string {
  return createHash("sha256").update(JSON.stringify(entries)).digest("hex");
}

export function getLeaguePolicy(): LeaguePolicySnapshot {
  return {
    revision: revisionFor(configuredEntries),
    mode: configuredNames.length > 0 ? "whitelist" : "empty",
    total: configuredNames.length,
    entries: mutableTargetLeagues.map((target) => ({
      name: target.label,
      aliases: [...(configuredEntries.find((entry) => entry.name === target.label)?.aliases ?? [])],
      displayNameRu: RUSSIAN_LABELS[target.label] ?? target.label,
      custom: !KNOWN_TARGET_LABELS.has(target.label),
      patterns: target.patterns.map((pattern) => pattern.toString()),
    })),
    rulesRu: [...LEAGUE_POLICY_RULES_RU],
    storageNoticeRu: `Политика хранится в файле ${configuredFilePath}. Изменения записываются атомарно, применяются без перезапуска процесса и сохраняются после его перезапуска. При замене или повторном развёртывании файловой системы этот файл может быть заменён; это не хранилище базы данных.`,
  };
}

function validatePolicyNames(value: unknown): string[] {
  if (!Array.isArray(value)) {
    throw new LeaguePolicyError("validation", "Поле names должно быть массивом строк.");
  }
  if (value.length > MAX_POLICY_ENTRIES) {
    throw new LeaguePolicyError("validation", `Разрешено не более ${MAX_POLICY_ENTRIES} названий лиг.`);
  }
  const names: string[] = [];
  const folded = new Set<string>();
  for (const item of value) {
    if (typeof item !== "string") {
      throw new LeaguePolicyError("validation", "Каждое название лиги должно быть строкой.");
    }
    if (!item || item !== item.trim() || item.length > MAX_LEAGUE_NAME_LENGTH || /[\u0000-\u001f\u007f]/u.test(item)) {
      throw new LeaguePolicyError(
        "validation",
        `Название лиги должно содержать от 1 до ${MAX_LEAGUE_NAME_LENGTH} символов, без краевых пробелов и управляющих символов.`,
      );
    }
    if (/^(?:all|\*)$/iu.test(item)) {
      throw new LeaguePolicyError(
        "validation",
        "Значения ALL и * запрещены: неограниченный режим нельзя включить автоматически.",
      );
    }
    const key = item.toLocaleLowerCase("en-US");
    if (folded.has(key)) {
      throw new LeaguePolicyError("validation", `Повторяющееся название лиги: ${item}.`);
    }
    folded.add(key);
    names.push(KNOWN_TARGET_LABELS_CASE_INSENSITIVE.get(key) ?? item);
  }
  return names;
}

let policyUpdateQueue: Promise<void> = Promise.resolve();

function validatePolicyEntries(value: unknown, allowLegacy = false): StoredLeague[] {
  if (!Array.isArray(value) || value.length > MAX_POLICY_ENTRIES) {
    throw new LeaguePolicyError("validation", `entries должен быть массивом не более ${MAX_POLICY_ENTRIES} лиг.`);
  }
  const raw = value.map((item: unknown) => {
    if (allowLegacy && typeof item === "string") return { name: item, aliases: [] };
    if (!item || typeof item !== "object" || Array.isArray(item)
      || Object.keys(item).some((key) => key !== "name" && key !== "aliases")) {
      throw new LeaguePolicyError("validation", "Каждая лига должна содержать только name и aliases.");
    }
    const entry = item as StoredLeague;
    if (typeof entry.name !== "string" || !Array.isArray(entry.aliases) || entry.aliases.length > 64) {
      throw new LeaguePolicyError("validation", "name должен быть строкой, aliases — массивом не более 64 строк.");
    }
    return { name: entry.name.trim(), aliases: entry.aliases };
  });
  const names = validatePolicyNames(raw.map((entry) => entry.name));
  const owners = new Map(names.map((name) => [name.toLowerCase(), name]));
  return raw.map((entry, index) => ({
    name: names[index]!,
    aliases: entry.aliases.map((alias: unknown) => {
      if (typeof alias !== "string") throw new LeaguePolicyError("validation", "Алиас должен быть строкой.");
      const trimmed = alias.trim();
      validatePolicyNames([trimmed]);
      const key = trimmed.toLowerCase();
      if (owners.has(key) || KNOWN_TARGET_LABELS_CASE_INSENSITIVE.has(key)) {
        throw new LeaguePolicyError("validation", `Конфликт алиаса «${trimmed}»: имя уже принадлежит лиге «${owners.get(key) ?? KNOWN_TARGET_LABELS_CASE_INSENSITIVE.get(key)}».`);
      }
      // Do not let an explicit alias steal another existing compiled identity.
      const compiled = TARGET_DEFINITIONS.find((target) => target.label !== names[index]
        && target.label !== "Malaysia" && target.patterns.some((pattern) => pattern.test(trimmed)));
      if (compiled) throw new LeaguePolicyError("validation", `Конфликт алиаса «${trimmed}» с лигой «${compiled.label}».`);
      owners.set(key, names[index]!);
      return trimmed;
    }),
  }));
}

export async function updateLeaguePolicy(namesValue: unknown, expectedRevision: unknown, entriesMode = false): Promise<LeaguePolicySnapshot> {
  const operation = policyUpdateQueue.then(async () => {
    if (typeof expectedRevision !== "string" || !/^[a-f0-9]{64}$/u.test(expectedRevision)) {
      throw new LeaguePolicyError(
        "validation",
        "Поле revision должно содержать действительную текущую ревизию политики.",
      );
    }
    if (expectedRevision !== revisionFor(configuredEntries)) {
      throw new LeaguePolicyError(
        "conflict",
        "Политика уже изменена. Получите актуальную ревизию и повторите запрос.",
      );
    }
    const entries = entriesMode ? validatePolicyEntries(namesValue) : validatePolicyEntries(
      validatePolicyNames(namesValue).map((name) => ({
        name,
        aliases: configuredEntries.find((entry) => entry.name.toLowerCase() === name.toLowerCase())?.aliases ?? [],
      })),
    );
    const tempPath = `${configuredFilePath}.${process.pid}.${Date.now()}.tmp`;
    try {
      await mkdir(path.dirname(configuredFilePath), { recursive: true });
      await writeFile(tempPath, `${JSON.stringify(entries, null, 2)}\n`, { encoding: "utf8", flag: "wx" });
      await rename(tempPath, configuredFilePath);
    } catch (error) {
      await unlink(tempPath).catch(() => undefined);
      throw new LeaguePolicyError(
        "persistence",
        `Не удалось безопасно сохранить политику лиг: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
    replaceRuntimePolicy(entries);
    return getLeaguePolicy();
  });
  policyUpdateQueue = operation.then(
    () => undefined,
    () => undefined,
  );
  return operation;
}

/** Reload hook used by startup-equivalence tests and controlled maintenance. */
export function reloadLeaguePolicyFromDisk(): LeaguePolicySnapshot {
  loaded = readConfiguredNames();
  replaceRuntimePolicy(loaded.entries, loaded.filePath);
  return getLeaguePolicy();
}

// Competition qualifiers are rejected unless their presence is the explicitly
// named target.  This keeps a target-country pattern from admitting women,
// youth, reserve, cup or sibling/lower-tier competitions.
const WOMEN_MARKER =
  /\b(?:women|woman|women's|womens|female|ladies|frauen|femin(?:ine|ino)|w[-\s]?league)\b|\(\s*w\s*\)/i;
const YOUTH_MARKER =
  /\b(?:youth|junior|juniors|u[-\s]?\d{1,2}|under[-\s]?\d{1,2}|sub[-\s]?\d{1,2})\b/i;
const RESERVE_MARKER = /\b(?:reserves?|res)\b/i;
const CUP_MARKER = /\b(?:cups?|copa|trophy)\b/i;
const LOWER_TIER_MARKER =
  /\b(?:division|div\.?|tier|level)\s*(?:[2-9]|[ivx]{2,})\b|\b(?:league|liga)\s*[2-9]\b|\b[dm][-\s]?[2-9]\b/i;

function hasDisallowedQualifier(name: string, label: string): boolean {
  // Malaysia is the explicit country-wide exception. Every Malaysian match
  // is allowed, including cups, youth, women's, reserve and lower-tier rows.
  if (label === "Malaysia" || label === "Liga Super Malaysia" || label === "FA Cup Malaysia") {
    return false;
  }

  // No target in this policy is a women's competition.
  if (WOMEN_MARKER.test(name)) return true;

  // These are the only explicit youth/reserve/cup exceptions in the policy.
  const target = TARGET_LEAGUES.find((candidate) => candidate.label === label);
  if (YOUTH_MARKER.test(name) && label !== "Myanmar U21 League" && !target?.allowsYouth) return true;
  if (RESERVE_MARKER.test(name) && label !== "Paraguay Reserve Team League") return true;
  if (CUP_MARKER.test(name) && label !== "FA Cup Malaysia" && !target?.allowsCup) return true;

  // The named lower divisions are the only lower-tier exceptions. A target
  // country pattern must not admit a sibling "Division 2", "League 2", etc.
  // (The explicit qualifier is required for each of the accepted lower-tier
  // labels, except Finland Kakkonen where only D3 is valid.)
  if (LOWER_TIER_MARKER.test(name)) {
    if (target?.allowsLowerTier) return false;
    const explicitLowerTier =
      (label === "Finland Kakkonen D3" && /\bd[-\s]?3\b/i.test(name)) ||
      (label === "Peruvian Segunda Division" && /\bliga\s*2\b/i.test(name)) ||
      (label === "Indian I-League 2nd Division" && /\b(?:2nd|second|ii)\s+division\b/i.test(name)) ||
      (label === "Indian I-League 2nd Division" &&
        /\bi-?\s*league\s*(?:2|2nd|second|ii)(?:\s+division)?\b/i.test(name)) ||
      (label === "Hong Kong 1st Division League" && /\b(?:1st|first)\s+division\b/i.test(name)) ||
      (label === "Hong Kong 1st Division League" && /\bdivision\s*1\b/i.test(name)) ||
      (label === "Hong Kong 2nd Division League" && /\b(?:2nd|second)\s+division\b/i.test(name)) ||
      (label === "Hong Kong 2nd Division League" && /\bdivision\s*2\b/i.test(name)) ||
      (label === "German 3.Liga" && /\b3\.?\s*liga\b/i.test(name));
    if (!explicitLowerTier) return true;
  }

  return false;
}

/**
 * Return the canonical label for a raw upstream league name.
 *
 * This is intentionally fail-closed.  `unknown`, `undefined`, numeric IDs,
 * blank strings and non-authorised country-only labels never match. Malaysia
 * is intentionally the sole country-wide exception in this policy.
 */
export function matchTargetLeague(leagueName: unknown): string | null {
  if (typeof leagueName !== "string") return null;
  const name = leagueName.trim();
  if (!name) return null;

  // Stored canonical labels are accepted as canonical evidence. This lets
  // persisted pre-match state remain usable across a directory refresh.
  if (TARGET_LABELS.has(name)) return name;
  const aliasOwner = configuredEntries.find((entry) =>
    entry.aliases.some((alias) => alias.toLowerCase() === name.toLowerCase()));
  if (aliasOwner) return aliasOwner.name;

  for (const target of TARGET_LEAGUES) {
    if (!target.patterns.some((pattern) => pattern.test(name))) continue;
    // A custom entry is an explicit full competition identity. Qualifier
    // filtering is only needed for the broader aliases of known definitions.
    if (!KNOWN_TARGET_LABELS.has(target.label)) return target.label;
    if (hasDisallowedQualifier(name, target.label)) continue;
    return target.label;
  }
  return null;
}

export function isTargetLeague(leagueName: unknown): boolean {
  return matchTargetLeague(leagueName) !== null;
}

export function getTargetLeagueLabel(leagueName: unknown): string | null {
  return matchTargetLeague(leagueName);
}