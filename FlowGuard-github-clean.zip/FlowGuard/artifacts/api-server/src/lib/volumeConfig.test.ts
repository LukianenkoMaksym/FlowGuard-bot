import { describe, expect, it } from "vitest";
import { __testOnlyMigrateVolumeConfig } from "./volumeConfig";

describe("volume config sanitization", () => {
  it("uses the operator defaults when thresholds are absent or invalid", () => {
    expect(__testOnlyMigrateVolumeConfig({})).toEqual({
      minSingleSpikeEur: 500,
      minCumulativeEur: 2_000,
      linesToTrack: [],
    });
    expect(__testOnlyMigrateVolumeConfig({
      minSingleSpikeEur: Number.NaN,
      minCumulativeEur: Number.POSITIVE_INFINITY,
    })).toEqual({
      minSingleSpikeEur: 500,
      minCumulativeEur: 2_000,
      linesToTrack: [],
    });
  });

  it("clamps canonical and legacy thresholds to their safe minimums", () => {
    expect(__testOnlyMigrateVolumeConfig({
      minSingleSpikeEur: 499,
      minCumulativeEur: 1_999,
    })).toMatchObject({
      minSingleSpikeEur: 500,
      minCumulativeEur: 2_000,
    });
    expect(__testOnlyMigrateVolumeConfig({
      minSingleSpikeUsd: 100,
      minCumulativeUsd: 100,
    })).toMatchObject({
      minSingleSpikeEur: 500,
      minCumulativeEur: 2_000,
    });
  });

  it("retains valid configured values and sanitizes tracked lines", () => {
    expect(__testOnlyMigrateVolumeConfig({
      minSingleSpikeEur: 725.5,
      minCumulativeEur: 54_321,
      linesToTrack: [3.5, 2.5, 3.5, 4, "1.5" as unknown as number],
    })).toEqual({
      minSingleSpikeEur: 725.5,
      minCumulativeEur: 54_321,
      linesToTrack: [1.5, 2.5, 3.5],
    });
  });
});