import { beforeEach, describe, expect, it, vi } from "vitest";
const state = vi.hoisted(() => ({ row: null as unknown, fail: false, staged: null as unknown }));
const query = vi.hoisted(() => vi.fn(async (sql: string, args?: string[]) => {
  if (state.fail) throw new Error("database unavailable");
  if (sql.startsWith("INSERT")) state.row ??= JSON.parse(args![0]!);
  if (sql.startsWith("UPDATE")) state.staged = JSON.parse(args![0]!);
  if (sql === "COMMIT") state.row = state.staged;
  if (sql === "ROLLBACK") state.staged = null;
  return { rows: state.row ? [{ metadata: state.row }] : [], rowCount: state.row ? 1 : 0 };
}));
vi.mock("@workspace/db", () => ({ pool: { query, connect: async () => ({ query, release: vi.fn() }) } }));
import { loadTunerState, saveTunerState } from "./tunerStateStore";
const seed = { enabled: true, pausedUntil: "2030-01-01T00:00:00.000Z", lastAdjustment: null };
beforeEach(() => { state.row = null; state.staged = null; state.fail = false; query.mockClear(); });
describe("durable tuner singleton", () => {
  it("imports once and ignores stale or missing file seeds after container replacement", async () => {
    expect(await loadTunerState(seed)).toEqual(seed);
    expect(await loadTunerState({ enabled: false, pausedUntil: null, lastAdjustment: null })).toEqual(seed);
    const publish = vi.fn(async () => {});
    await saveTunerState({ ...seed, enabled: false }, publish);
    expect(publish).toHaveBeenCalledOnce();
    expect(await loadTunerState(seed)).toEqual({ ...seed, enabled: false });
  });
  it("never seeds or publishes during outage", async () => {
    await loadTunerState(seed);
    state.fail = true;
    await expect(loadTunerState({ ...seed, enabled: false })).rejects.toThrow("unavailable");
    const publish = vi.fn(async () => {});
    await expect(saveTunerState({ ...seed, enabled: false }, publish)).rejects.toThrow("unavailable");
    expect(publish).not.toHaveBeenCalled();
    expect(state.row).toEqual(seed);
  });
  it("rolls DB state back when file publication fails", async () => {
    await loadTunerState(seed);
    await expect(saveTunerState({ ...seed, enabled: false }, async () => { throw new Error("disk full"); })).rejects.toThrow("disk full");
    expect(state.row).toEqual(seed);
    expect(query).toHaveBeenCalledWith("ROLLBACK");
  });
});