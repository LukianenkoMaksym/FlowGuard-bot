/**
 * Centralized external-endpoint configuration.
 *
 * Single source of truth for every hardcoded upstream URL, host, and User-Agent
 * used by the scanner. When NowGoal (or any upstream) moves domains, swaps a
 * mirror, or we want to A/B a different UA pool, this is the only file to touch.
 *
 * Design notes
 * ------------
 * - Values that were already arrays (NowGoal mirrors, UA pool) stay arrays so
 *   downstream rotation/probe logic is unchanged.
 * - Values that were per-file singletons (excapper UA, vcbet UA) are exported
 *   as named constants so we preserve exact current behavior — each upstream
 *   may fingerprint a specific UA, and consolidating them into one would
 *   change the request signature.
 * - Telegram + Sofascore endpoints are exposed as builder functions because
 *   they take dynamic path params (bot token, event id, query string).
 * - Env-var overrides are intentionally NOT added here. Every upstream domain
 *   below was verified-live by hand; we don't want a typo in an env var to
 *   silently rotate us to a dead mirror. If overrides are ever needed, add
 *   them with a startup probe that refuses to boot on a bad value.
 */

function envInt(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number.parseInt(raw, 10);
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

// ---------- NowGoal ecosystem ----------

/**
 * Verified-live NowGoal mirrors for the goal*.xml + Ajax/SoccerAjax endpoints.
 * Order matters: index 0 is the default primary; the rest are tried in order
 * during failover (see `tryFailover` in upstream.ts). Cross-verification picks
 * at random from indexes ≥ 1.
 */
export const NOWGOAL_HOSTS: string[] = [
  "https://live11.nowgoal26.com", // primary canonical live mirror
  "https://www.nowgoal26.com", // canonical www mirror
  "https://www.nowgoal28.com", // canonical sister-domain mirror
];

/** Automatic mirror switches are globally serialized and may not occur more
 * frequently than every ten minutes, regardless of which watchdog requested
 * the switch.  The floor is deliberate: an environment override may lengthen
 * this window, but can never re-enable rapid mirror bouncing. */
export const NOWGOAL_AUTO_SWITCH_COOLDOWN_MS = Math.max(
  10 * 60 * 1000,
  envInt("NOWGOAL_AUTO_SWITCH_COOLDOWN_MS", 10 * 60 * 1000),
);

/** Telegram is diagnostic-only and has its own cooldown. Manual failover may
 * bypass the switch cooldown, but it must not bypass notification suppression. */
export const NOWGOAL_TECHNICAL_NOTIFICATION_COOLDOWN_MS = 10 * 60 * 1000;

/** A parseable odds snapshot must remain unchanged for both this wall-clock
 * duration and this many successful, active-data samples before it is stale. */
export const NOWGOAL_VOLATILITY_STALE_WINDOW_MS = Math.max(
  5 * 60 * 1000,
  envInt("NOWGOAL_VOLATILITY_STALE_WINDOW_MS", 5 * 60 * 1000),
);
export const NOWGOAL_VOLATILITY_MIN_SUCCESSFUL_SAMPLES = Math.max(
  5,
  envInt("NOWGOAL_VOLATILITY_MIN_SUCCESSFUL_SAMPLES", 5),
);

/**
 * Referer pool rotated on every NowGoal goal*.xml request. Mixing referers
 * across the NowGoal family of hostnames lowers our fingerprint footprint.
 */
export const NOWGOAL_REFERERS: string[] = [
  "https://live11.nowgoal26.com/",
  "https://www.nowgoal26.com/",
  "https://www.nowgoal28.com/",
];

/**
 * Per-match Vcbet (company 14) oddscomp Ajax endpoint host. NowGoal rotates
 * this mirror over time (live9 → live10 observed 2026-08); stale mirrors
 * reply with an HTML "Document Moved" redirect page pointing at the current
 * one. `vcbetPerMatch.ts` detects that redirect and hot-swaps to the new
 * host at runtime, so this constant only needs to be a reasonable seed.
 * Verified working 2026-08-17: live11. This host is intentionally NOT part
 * of NOWGOAL_HOSTS because the failover pool targets goal*.xml batch feeds,
 * not oddscomp.
 */
export const NOWGOAL_VCBET_HOST = "https://live11.nowgoal26.com";

/** Public match-detail page link used in Telegram alerts and the dashboard. */
export function nowgoalMatchUrl(matchId: string): string {
  // The localized football route is currently edge-blocked (HTTP 442). The
  // canonical match page is served from the live mirror and redirects from
  // the historical .html suffix to this suffixless path.
  return `https://www.nowgoal26.com/match/live-${encodeURIComponent(matchId)}`;
}

// ---------- User-Agents ----------

/**
 * UA pool rotated on every NowGoal request (see scanner.ts `buildHeaders`).
 * Five different browser/OS combos so consecutive requests don't share a
 * fingerprint. Keep this pool >= 3 entries.
 */
export const USER_AGENT_POOL: string[] = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
];

/**
 * Single UA pinned for the Vcbet curl subprocess. The upstream's TLS/HTTP
 * fingerprint check appears to also consider the UA — this is the exact
 * string verified to work end-to-end. Do NOT rotate this without re-probing.
 */
export const USER_AGENT_VCBET =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36";

/**
 * UA pool rotated per Excapper request (see `pickUserAgent` in
 * excapperBackoff.ts). Deliberately a DIFFERENT set of vintages from
 * `USER_AGENT_POOL` so Excapper's fingerprint surface stays decoupled from
 * NowGoal's — if NowGoal ever bans one of its UAs, Excapper traffic is
 * unaffected and vice versa.
 */
export const USER_AGENT_POOL_EXCAPPER: string[] = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
];

/**
 * Single UA pinned for Sofascore's public JSON API. Sofascore doesn't
 * fingerprint heavily here — one stable UA keeps logs predictable.
 */
export const USER_AGENT_SOFASCORE =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

// ---------- Excapper ----------

export const EXCAPPER_BASE_URL = "https://www.excapper.com";

// ---------- Sofascore (live-score watchdog) ----------

export const SOFASCORE_API_BASE = "https://api.sofascore.com/api/v1";

/**
 * Optional upstream calls are explicitly disabled after repeated HTTP 403s
 * from the production runtime. The score-watchdog subsystem remains enabled:
 * it simply performs no Sofascore HTTP work, while NowGoal score ingestion and
 * the independent NowGoal score-refresh/watchdog paths continue unchanged.
 */
export const SOFASCORE_UPSTREAM_ENABLED = false;

/** Valid empty searches are retried periodically instead of cached forever. */
export const SOFASCORE_RESOLVER_NEGATIVE_TTL_MS = 15 * 60 * 1000;
export const SOFASCORE_403_BACKOFF_INITIAL_MS = 60 * 1000;
export const SOFASCORE_403_BACKOFF_MAX_MS = 15 * 60 * 1000;

/** Exponential 403 backoff with a bounded ceiling; zero starts a new block. */
export function nextSofascore403BackoffMs(previousMs: number): number {
  return previousMs === 0
    ? SOFASCORE_403_BACKOFF_INITIAL_MS
    : Math.min(SOFASCORE_403_BACKOFF_MAX_MS, previousMs * 2);
}

/** Event-suggester search by team-pair query. `q` is URL-encoded by the caller. */
export function sofascoreEventSuggesterUrl(qEncoded: string): string {
  return `${SOFASCORE_API_BASE}/search/event-suggester?q=${qEncoded}&sport=football`;
}

/** Live event detail (includes homeScore.current / awayScore.current). */
export function sofascoreEventUrl(eventId: number): string {
  return `${SOFASCORE_API_BASE}/event/${eventId}`;
}

// ---------- Telegram Bot API ----------

export const TELEGRAM_API_BASE = "https://api.telegram.org";

export function telegramGetMeUrl(token: string): string {
  return `${TELEGRAM_API_BASE}/bot${token}/getMe`;
}

export function telegramGetChatUrl(token: string): string {
  return `${TELEGRAM_API_BASE}/bot${token}/getChat`;
}

export function telegramSendMessageUrl(token: string): string {
  return `${TELEGRAM_API_BASE}/bot${token}/sendMessage`;
}

export function telegramGetUpdatesUrl(token: string): string {
  return `${TELEGRAM_API_BASE}/bot${token}/getUpdates`;
}
