import { describe, expect, it } from "vitest";
import { fixedBetTime, parseExcapperBetTime, PrebetAnalysis } from "./prebetAnalysis";
import type { ExcapperTransaction, ParsedGameDetail } from "./excapper";

const betTime = new Date(2026, 8, 21, 12, 30).getTime();
const tx = (summ: number, change: number, t: number | null): ExcapperTransaction => ({
  line: 2.5, side: "Over", summ, change, rawChange: `${change} €`,
  date: t === null ? "" : `${String(new Date(t).getHours()).padStart(2, "0")}:${String(new Date(t).getMinutes()).padStart(2, "0")} ${String(new Date(t).getDate()).padStart(2, "0")}.${String(new Date(t).getMonth() + 1).padStart(2, "0")}`,
  matchMinute: "54", sourceType: "live",
});
const detail = (at: number, odds: number, transactions: ExcapperTransaction[] = []): ParsedGameDetail => ({
  gameId: "1", observedAt: at, live: {} as ParsedGameDetail["live"],
  samples: [{ line: 2.5, over: 1, under: 1.1, overOdds: odds, underOdds: 2.1, collectedAt: at }],
  transactions,
});

describe("bounded pre-bet analysis", () => {
  it("cuts off post-bet 1.30 and anchors the five-minute drop on the bet", () => {
    const store = new PrebetAnalysis();
    store.observeDirectory(["1"], betTime - 4 * 60_000);
    store.observeDetail("1", detail(betTime - 4 * 60_000, 1.80));
    store.observeDetail("1", detail(betTime - 2 * 60_000, 1.65));
    store.observeDetail("1", detail(betTime, 1.48));
    store.observeDetail("1", detail(betTime + 60_000, 1.30));
    expect(PrebetAnalysis.window(store.timeline("1", 2.5, "Over", betTime), betTime)
      .map((point) => point.odds)).toEqual([1.8, 1.65, 1.48]);
    expect((1.8 - 1.48) / 1.8 * 100).toBeCloseTo(17.7777778);
    expect(store.timeline("1", 2.5, "Under", betTime).every((point) => point.odds === 2.1)).toBe(true);
  });

  it("deduplicates cached fetches and genuine rows, counting trigger in both windows", () => {
    const store = new PrebetAnalysis();
    store.observeDirectory(["1"], betTime);
    const rows = [tx(100, 10, betTime - 61 * 60_000), tx(200, 20, betTime - 30 * 60_000),
      tx(300, 30, betTime - 15 * 60_000), tx(400, 40, betTime - 5 * 60_000),
      tx(500, 50, null), tx(600, 60, betTime + 60_000)];
    store.observeDetail("1", detail(betTime, 1.48, rows));
    store.observeDetail("1", detail(betTime, 1.48, rows));
    expect(store.timeline("1", 2.5, "Over", betTime)).toHaveLength(1);
    expect(store.money("1", rows[4]!, betTime)).toEqual({
      inflow15m: 120, inflow60m: 140, betCount15m: 3,
    });
  });

  it("retains only two hours/200 observations, caps keys and prunes absent fixtures", () => {
    const store = new PrebetAnalysis();
    store.observeDirectory(["1"], betTime);
    for (let i = 0; i < 220; i++) store.observeDetail("1", detail(betTime - 219_000 + i * 1000, 1.8));
    expect(store.timeline("1", 2.5, "Over", betTime)).toHaveLength(200);
    store.observeDirectory(Array.from({ length: 2_050 }, (_, i) => String(i + 2)), betTime);
    for (let i = 0; i < 2_050; i++) store.observeDetail(String(i + 2), detail(betTime, 1.8));
    expect(store.timeline("1", 2.5, "Over", betTime)).toHaveLength(0);
    store.observeDirectory([], betTime + 2 * 60 * 60_000 + 1);
    expect(store.timeline("2051", 2.5, "Over", betTime + 2 * 60 * 60_000 + 1)).toHaveLength(0);
  });

  it("refreshes presence for listed games but never extends an absent game's TTL on detail reads", () => {
    const store = new PrebetAnalysis();
    const minute = 60_000;
    store.observeDirectory(["1"], betTime);
    store.observeDetail("1", detail(betTime, 1.8));
    store.observeDirectory(["1"], betTime + 119 * minute);
    store.observeDirectory([], betTime + 121 * minute);
    store.observeDetail("1", detail(betTime + 121 * minute, 1.65));
    expect(store.timeline("1", 2.5, "Over", betTime + 121 * minute)).toHaveLength(1);
    // The detail fetch is new, but the last directory sighting was at +119m.
    store.observeDetail("1", detail(betTime + 239 * minute, 1.48));
    expect(store.timeline("1", 2.5, "Over", betTime + 239 * minute)).toHaveLength(2);
    store.observeDirectory([], betTime + 239 * minute + 1);
    expect(store.timeline("1", 2.5, "Over", betTime + 239 * minute + 1)).toHaveLength(0);
    store.observeDetail("1", detail(betTime + 240 * minute, 1.3));
    expect(store.timeline("1", 2.5, "Over", betTime + 240 * minute)).toHaveLength(0);
  });

  it("parses calendar dates conservatively and fixes fallback once", () => {
    expect(parseExcapperBetTime(tx(1, 1, betTime).date, betTime)).toBe(betTime);
    expect(parseExcapperBetTime("12:30 31.02", betTime)).toBeNull();
    expect(parseExcapperBetTime("12:30 01.01", betTime)).toBeNull();
    expect(fixedBetTime(tx(1, 1, null), betTime)).toBe(betTime);
    expect(fixedBetTime({ ...tx(1, 1, null), betTime }, betTime + 60_000)).toBe(betTime);
  });
});