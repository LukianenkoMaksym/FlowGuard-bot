import { logger } from "./logger";
import { USER_AGENT_POOL_EXCAPPER } from "./config";

const BASE_DELAY_MS = 25_000;
const MAX_DELAY_MS = 10 * 60_000;
const JITTER_RATIO = 0.2;

export type ExcapperHealth = {
  state: "healthy" | "backoff" | "recovering";
  retryAt: number | null;
  lastErrorStatus: number | null;
  lastSuccessAt: number | null;
};

export interface ExcapperBrowserProfile {
  family: "chrome" | "firefox" | "safari";
  userAgent: string;
  headers: Record<string, string>;
}

const BROWSER_PROFILES: readonly ExcapperBrowserProfile[] = [
  {
    family: "chrome",
    userAgent: USER_AGENT_POOL_EXCAPPER[0]!,
    headers: {
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
      "Sec-CH-UA": '"Google Chrome";v="121", "Chromium";v="121", "Not_A Brand";v="24"',
      "Sec-CH-UA-Mobile": "?0",
      "Sec-CH-UA-Platform": '"Windows"',
    },
  },
  {
    family: "firefox",
    userAgent: USER_AGENT_POOL_EXCAPPER[3]!,
    headers: {
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
    },
  },
  {
    family: "safari",
    userAgent: USER_AGENT_POOL_EXCAPPER[4]!,
    headers: {
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
    },
  },
  {
    family: "safari",
    userAgent:
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
    headers: {
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
    },
  },
];

let consecutiveFailures = 0;
let retryAt = 0;
let lastErrorStatus: number | null = null;
let lastSuccessAt: number | null = null;
let recovering = false;

export class ExcapperCooldownError extends Error {
  readonly retryAt: number;

  constructor(until: number) {
    super(`Excapper cooldown is active until ${new Date(until).toISOString()}`);
    this.name = "ExcapperCooldownError";
    this.retryAt = until;
  }
}

export function parseRetryAfter(value: string | null, now = Date.now()): number | null {
  if (!value) return null;
  const seconds = Number(value.trim());
  if (Number.isFinite(seconds) && seconds >= 0) return Math.ceil(seconds * 1_000);
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - now) : null;
}

export function recordExcapperFailure(
  status: number,
  retryAfterMs: number | null = null,
  reason = `HTTP ${status}`,
  now = Date.now(),
  random = Math.random,
): void {
  consecutiveFailures++;
  const exponential = Math.min(
    MAX_DELAY_MS,
    BASE_DELAY_MS * 2 ** Math.min(consecutiveFailures - 1, 8),
  );
  // Jitter only extends the minimum cooldown. It must never turn the requested
  // 25-second first backoff into a shorter retry window.
  const jittered = Math.min(
    MAX_DELAY_MS,
    Math.round(exponential * (1 + random() * JITTER_RATIO)),
  );
  // Retry-After is authoritative when it is longer. It is intentionally not
  // capped: a server-requested cooldown must never be shortened locally.
  const delayMs = Math.max(jittered, retryAfterMs ?? 0);
  retryAt = Math.max(retryAt, now + delayMs);
  lastErrorStatus = status;
  recovering = false;
  logger.warn(
    { reason, status, failures: consecutiveFailures, retryAt, delayMs, retryAfterMs },
    "[EXCAPPER-BACKOFF] Upstream unavailable; shared cooldown scheduled",
  );
}

/** Compatibility entry point for older call sites. Prefer recordExcapperFailure. */
export function tripExcapperBreaker(reason: string): void {
  recordExcapperFailure(reason.includes("429") ? 429 : 503, null, reason);
}

export function assertExcapperRequestAllowed(options?: { recoveryProbe?: boolean }): void {
  const now = Date.now();
  if (now < retryAt) throw new ExcapperCooldownError(retryAt);
  if (consecutiveFailures > 0 && !options?.recoveryProbe) {
    throw new ExcapperCooldownError(retryAt || now);
  }
}

export function setExcapperRecovering(value: boolean): void {
  recovering = value;
}

export function recordAuthenticExcapperSuccess(): void {
  consecutiveFailures = 0;
  retryAt = 0;
  lastErrorStatus = null;
  lastSuccessAt = Date.now();
  recovering = false;
  // The successful batch request itself is the recovery hydration. Do not
  // notify listeners here: historical listeners started a second immediate
  // request and defeated the single-batch cadence after every cooldown.
}

export function onExcapperRecovery(listener: () => void): () => void {
  // Kept as a compatibility no-op. Recovery is consumed by the successful
  // scheduled batch itself; invoking callbacks would create a second request.
  void listener;
  return () => undefined;
}

export function isExcapperBreakerOpen(): boolean {
  return Date.now() < retryAt || recovering;
}

export function excapperBreakerRemainingMs(): number {
  return Math.max(0, retryAt - Date.now());
}

export function getExcapperHealth(): ExcapperHealth {
  return {
    state: recovering ? "recovering" : consecutiveFailures > 0 ? "backoff" : "healthy",
    retryAt: retryAt || null,
    lastErrorStatus,
    lastSuccessAt,
  };
}

export function pickUserAgent(): string {
  return pickExcapperBrowserProfile().userAgent;
}

/**
 * Selects an internally coherent set of ordinary browser HTTP headers. This
 * does not claim to reproduce a browser TLS/network fingerprint.
 */
export function pickExcapperBrowserProfile(
  random = Math.random,
): ExcapperBrowserProfile {
  const index = Math.min(
    BROWSER_PROFILES.length - 1,
    Math.floor(random() * BROWSER_PROFILES.length),
  );
  const profile = BROWSER_PROFILES[index]!;
  return { ...profile, headers: { ...profile.headers } };
}

export function __testOnlyResetExcapperBackoff(): void {
  consecutiveFailures = 0;
  retryAt = 0;
  lastErrorStatus = null;
  lastSuccessAt = null;
  recovering = false;
}