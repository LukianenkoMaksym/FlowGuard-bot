import { beforeEach, describe, expect, it, vi } from "vitest";

const runtime = vi.hoisted(() => ({
  muted: false,
  audienceOk: true,
  baselines: new Map<string, number>(),
  triggerBaselines: new Map<string, number>(),
  outbox: new Map<string, {
    event_key: string;
    message: string;
    parse_mode?: "MarkdownV2" | "plain";
    recipient_state: Array<{ id: string; primary: boolean; state: string }>;
    attempts: number;
    completed: boolean;
    createdAt: number;
    volumeObservedAt?: number;
    evidence?: unknown;
  }>(),
  snapshot: null as Map<string, number> | null,
  triggerSnapshot: null as Map<string, number> | null,
  sends: [] as string[],
  parseModes: [] as Array<"MarkdownV2" | "plain" | undefined>,
  sendResults: [] as Array<"ok" | "failed" | "blocked">,
  freshScore: { homeScore: 0, awayScore: 0, isLive: true } as {
    homeScore: number;
    awayScore: number;
    isLive: boolean;
  } | null,
}));

const query = vi.hoisted(() => vi.fn(async (sqlRaw: string, args: unknown[] = []) => {
  const sql = sqlRaw.replace(/\s+/g, " ").trim();
  if (sql === "BEGIN") {
    runtime.snapshot = new Map(runtime.baselines);
    runtime.triggerSnapshot = new Map(runtime.triggerBaselines);
    return { rows: [] };
  }
  if (sql === "COMMIT") {
    runtime.snapshot = null;
    runtime.triggerSnapshot = null;
    return { rows: [] };
  }
  if (sql === "ROLLBACK") {
    runtime.baselines = new Map(runtime.snapshot ?? []);
    runtime.triggerBaselines = new Map(runtime.triggerSnapshot ?? []);
    runtime.snapshot = null;
    runtime.triggerSnapshot = null;
    return { rows: [] };
  }
  if (sql.includes("pg_try_advisory_lock")) return { rows: [{ locked: true }] };
  if (sql.includes("pg_advisory")) return { rows: [] };
  if (sql.startsWith("CREATE TABLE")) return { rows: [] };
  if (sql.startsWith("SELECT cumulative_eur")) {
    const value = runtime.baselines.get(String(args[0]));
    return { rows: value === undefined ? [] : [{
      cumulative_eur: value,
      trigger_baseline_eur: runtime.triggerBaselines.get(String(args[0])) ?? value,
    }] };
  }
  if (sql.startsWith("INSERT INTO manual_watchlist_volume_baseline")) {
    if (!runtime.baselines.has(String(args[0]))) {
      runtime.baselines.set(String(args[0]), Number(args[1]));
      runtime.triggerBaselines.set(String(args[0]), Number(args[1]));
    }
    return { rows: [] };
  }
  if (sql.startsWith("UPDATE manual_watchlist_volume_baseline")) {
    runtime.baselines.set(String(args[0]), Number(args[1]));
    if (Boolean(args[2])) runtime.triggerBaselines.set(String(args[0]), Number(args[1]));
    return { rows: [] };
  }
  if (sql.startsWith("INSERT INTO manual_watchlist_telegram_outbox")) {
    const key = String(args[0]);
    if (!runtime.outbox.has(key)) {
      runtime.outbox.set(key, {
        event_key: key,
        message: String(args[1]),
        parse_mode: "MarkdownV2",
        recipient_state: JSON.parse(String(args[2])),
        attempts: 0,
        completed: false,
        createdAt: Date.now(),
        volumeObservedAt: Number(args[3]),
        evidence: JSON.parse(String(args[4])),
      });
    }
    return { rows: [] };
  }
  if (sql.startsWith("SELECT event_key, message")) {
    return { rows: [...runtime.outbox.values()].filter((row) => !row.completed) };
  }
  if (sql.startsWith("UPDATE manual_watchlist_telegram_outbox") && sql.includes("recipient_state =")) {
    const row = runtime.outbox.get(String(args[0]));
    if (row) {
      row.recipient_state = JSON.parse(String(args[1]));
      row.attempts++;
      row.completed = (Boolean(args[3]) && Boolean(args[4])) || Boolean(args[5]);
    }
    return { rows: [] };
  }
  if (sql.startsWith("UPDATE manual_watchlist_telegram_outbox")) {
    const maxAgeMs = Number(args[0]) * 1_000;
    for (const row of runtime.outbox.values()) {
      if (
        Date.now() - row.createdAt >= maxAgeMs ||
        row.evidence === undefined ||
        !Number.isFinite(row.volumeObservedAt) ||
        (Number.isFinite(row.volumeObservedAt) &&
          Date.now() - row.volumeObservedAt! >= maxAgeMs)
      ) row.completed = true;
    }
    return { rows: [] };
  }
  throw new Error(`Unhandled SQL in test: ${sql}`);
}));

vi.mock("@workspace/db", () => ({
  pool: {
    query,
    connect: vi.fn(async () => ({ query, release: vi.fn() })),
  },
}));
vi.mock("./controls", () => ({
  getControls: () => ({ alertsMuted: runtime.muted }),
}));
vi.mock("./logger", () => ({
  logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn(), debug: vi.fn() },
}));
vi.mock("./telegram", () => ({
  escapeMdV2: (value: string | number) =>
    String(value).replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, "\\$1"),
  snapshotTelegramRecipients: vi.fn(async () =>
    runtime.audienceOk
      ? {
          ok: true,
          recipients: [
            { id: "primary", primary: true },
            { id: "subscriber", primary: false },
          ],
        }
      : { ok: false, reason: "token_missing" },
  ),
  sendTelegramOutboxRecipient: vi.fn(async (
    recipient: { id: string },
    _message: string,
    opts?: { parseMode?: "MarkdownV2" | "plain" },
  ) => {
    runtime.sends.push(recipient.id);
    runtime.parseModes.push(opts?.parseMode);
    return runtime.sendResults.shift() ?? "ok";
  }),
}));

import {
  collectManualVolumeDeltas,
  drainManualWatchlistVolumeOutbox,
  formatManualVolumeDigest,
  MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS,
  queueManualWatchlistVolumeDigest,
  registerManualVolumeFreshScoreValidator,
  type ManualVolumeObservation,
} from "./manualWatchlistVolumeAlerts";

const sample = (
  total: number,
  side: "OVER" | "UNDER" = "OVER",
  line = 2.5,
): ManualVolumeObservation => {
  const now = Date.now();
  return {
    gameId: "live-1",
    matchLabel: "Alpha vs Beta",
    league: "Test League",
    line,
    side,
    total,
    observedAt: now,
    alertContext: {
      matchId: "match-1",
      league: "Test League",
      home: "Alpha",
      away: "Beta",
      isLive: true,
      homeScore: 0,
      awayScore: 0,
      minute: "20",
      line,
      side,
      timeline: [
        { ts: now - 60_000, line, odds: 2 },
        { ts: now, line, odds: 1.8 },
      ],
      link: null,
    },
  };
};

function evidenceFor(observation: ManualVolumeObservation, delta = 500): unknown {
  return {
    version: 1,
    events: [{ ...observation, delta, accumulatedDelta: delta }],
  };
}

describe("manual Priority Watchlist cumulative volume matcher", () => {
  it("baselines the initial sample without replaying historical money", () => {
    const baseline = new Map();
    expect(collectManualVolumeDeltas(baseline, [sample(10_000)])).toEqual([]);
    expect(baseline.get("live-1:2.5:OVER")).toEqual({
      lastObserved: 10_000,
      lastTrigger: 10_000,
    });
  });

  it("requires an inclusive positive EUR delta of 500", () => {
    const baseline499 = new Map([["live-1:2.5:OVER", {
      lastObserved: 1_000,
      lastTrigger: 1_000,
    }]]);
    expect(collectManualVolumeDeltas(baseline499, [sample(1_499)])).toEqual([]);
    const baseline500 = new Map([["live-1:2.5:OVER", {
      lastObserved: 1_000,
      lastTrigger: 1_000,
    }]]);
    expect(collectManualVolumeDeltas(baseline500, [sample(1_500)]))
      .toMatchObject([{ delta: 500, total: 1_500 }]);
  });

  it("collects all eligible lines and sides for one cycle", () => {
    const baseline = new Map([
      ["live-1:2.5:OVER", { lastObserved: 1_000, lastTrigger: 1_000 }],
      ["live-1:2.5:UNDER", { lastObserved: 2_000, lastTrigger: 2_000 }],
      ["live-1:3.5:OVER", { lastObserved: 3_000, lastTrigger: 3_000 }],
    ]);
    const events = collectManualVolumeDeltas(baseline, [
      sample(1_500, "OVER", 2.5),
      sample(2_700, "UNDER", 2.5),
      sample(3_900, "OVER", 3.5),
    ]);
    expect(events.map((event) => event.delta)).toEqual([500, 700, 900]);
  });

  it("does not replay identical or regressed stale samples", () => {
    const baseline = new Map([["live-1:2.5:OVER", {
      lastObserved: 2_000,
      lastTrigger: 2_000,
    }]]);
    expect(collectManualVolumeDeltas(baseline, [sample(2_000), sample(1_000)]))
      .toEqual([]);
    expect(baseline.get("live-1:2.5:OVER")?.lastObserved).toBe(2_000);
  });

  it("triggers when sub-500 increases accumulate to 2,000, then resets", () => {
    const baseline = new Map([["live-1:2.5:UNDER", {
      lastObserved: 1_000,
      lastTrigger: 1_000,
    }]]);
    for (const total of [1_400, 1_800, 2_200, 2_600]) {
      expect(collectManualVolumeDeltas(baseline, [sample(total, "UNDER")])).toEqual([]);
    }
    expect(collectManualVolumeDeltas(baseline, [sample(3_000, "UNDER")]))
      .toMatchObject([{ delta: 400, accumulatedDelta: 2_000 }]);
    expect(collectManualVolumeDeltas(baseline, [sample(3_400, "UNDER")])).toEqual([]);
    expect(baseline.get("live-1:2.5:UNDER")?.lastTrigger).toBe(3_000);
  });

  it("summarizes oversized consolidated digests below Telegram's hard limit", () => {
    const events = Array.from({ length: 100 }, (_, index) => ({
      ...sample(2_000 + index, index % 2 ? "UNDER" : "OVER", 2.5 + index),
      alertContext: null,
      matchLabel: `Match ${index} ${"⚽".repeat(100)}`,
      delta: 500,
      accumulatedDelta: 500,
    }));
    const digest = formatManualVolumeDigest(events);
    expect(Array.from(digest).length).toBeLessThanOrEqual(3_800);
    expect(digest).toMatch(/additional complete alert blocks omitted/);
    expect(digest).not.toContain("PRIORITY WATCHLIST VOLUME");
    expect((digest.match(/🔴 SMART MONEY/g) ?? []).length).toBeGreaterThan(1);
  });

  it("limits the escaped multi-block Telegram payload without partial blocks", () => {
    const events = Array.from({ length: 80 }, (_, index) => ({
      ...sample(2_000 + index, index % 2 ? "UNDER" : "OVER", 2.5 + index),
      alertContext: null,
      matchLabel: `Bad_[Home ${index}] vs Away *${index}* ${"⚽".repeat(20)}`,
      league: "League | hostile",
      delta: 500,
      accumulatedDelta: 500,
    }));
    const digest = formatManualVolumeDigest(events);
    const starts = digest.match(/🔴 SMART MONEY/g) ?? [];
    const ends = digest.match(/🔗 Match Details: N\/A/g) ?? [];
    expect(digest.length).toBeLessThanOrEqual(3_800);
    expect(starts.length).toBeGreaterThan(1);
    expect(ends.length).toBe(starts.length);
    expect(digest).toMatch(/additional complete alert blocks omitted$/);
    expect(digest).toContain("Bad\\_\\[Home");
  });
});

describe("durable manual-volume admission and delivery", () => {
  beforeEach(() => {
    runtime.muted = false;
    runtime.audienceOk = true;
    runtime.baselines.clear();
    runtime.triggerBaselines.clear();
    runtime.outbox.clear();
    runtime.snapshot = null;
    runtime.triggerSnapshot = null;
    runtime.sends.length = 0;
    runtime.parseModes.length = 0;
    runtime.sendResults.length = 0;
    runtime.freshScore = { homeScore: 0, awayScore: 0, isLive: true };
    registerManualVolumeFreshScoreValidator(async () => runtime.freshScore);
    query.mockClear();
  });

  it.each([
    ["missing", undefined],
    ["flat", [
      { ts: Date.now() - 60_000, line: 2.5, odds: 1.8 },
      { ts: Date.now(), line: 2.5, odds: 1.8 },
    ]],
    ["rising", [
      { ts: Date.now() - 60_000, line: 2.5, odds: 1.8 },
      { ts: Date.now(), line: 2.5, odds: 2 },
    ]],
    ["cross-line", [
      { ts: Date.now() - 60_000, line: 3.5, odds: 2 },
      { ts: Date.now(), line: 3.5, odds: 1.8 },
    ]],
  ] as const)("queues a volume spike with %s odds metadata", async (_label, timeline) => {
    await queueManualWatchlistVolumeDigest([sample(1_000)]);
    const next = sample(1_500);
    next.alertContext = timeline === undefined
      ? { ...next.alertContext!, timeline: [] }
      : { ...next.alertContext!, timeline: [...timeline] };
    await expect(queueManualWatchlistVolumeDigest([next])).resolves.toMatchObject({
      eligible: 1,
      queued: true,
    });
    expect(runtime.outbox.size).toBe(1);
  });

  it("baselines first runtime sample, ignores unchanged polls, then queues one multi-event digest", async () => {
    await expect(queueManualWatchlistVolumeDigest([sample(1_000)])).resolves
      .toMatchObject({ eligible: 0, queued: false });
    await expect(queueManualWatchlistVolumeDigest([sample(1_000)])).resolves
      .toMatchObject({ eligible: 0, queued: false });
    const result = await queueManualWatchlistVolumeDigest([
      sample(1_500),
      sample(700, "UNDER", 3.5),
    ]);
    // UNDER is first-seen baseline; only inclusive +500 OVER is admitted.
    expect(result).toMatchObject({ eligible: 1, queued: true });
    expect(runtime.outbox.size).toBe(1);
  });

  it("does not let a stale volume observation seed or advance durable state", async () => {
    const stale = sample(10_000);
    stale.observedAt = Date.now() - MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS - 1;
    await expect(queueManualWatchlistVolumeDigest([stale])).resolves
      .toMatchObject({ eligible: 0, queued: false });
    expect(runtime.baselines.size).toBe(0);

    await expect(queueManualWatchlistVolumeDigest([sample(10_500)])).resolves
      .toMatchObject({ eligible: 0, queued: false });
    expect(runtime.baselines.get("live-1:2.5:OVER")).toBe(10_500);
  });

  it("advances the baseline while muted without creating a backlog", async () => {
    await queueManualWatchlistVolumeDigest([sample(1_000)]);
    runtime.muted = true;
    await expect(queueManualWatchlistVolumeDigest([sample(1_500)])).resolves
      .toMatchObject({ eligible: 1, queued: false, reason: "alerts_muted" });
    expect(runtime.baselines.get("live-1:2.5:OVER")).toBe(1_500);
    expect(runtime.outbox.size).toBe(0);
    runtime.muted = false;
    await expect(queueManualWatchlistVolumeDigest([sample(1_500)])).resolves
      .toMatchObject({ eligible: 0, queued: false });
  });

  it("durably accumulates small increases and resets the threshold after mute", async () => {
    await queueManualWatchlistVolumeDigest([sample(1_000, "UNDER")]);
    for (const total of [1_400, 1_800, 2_200, 2_600]) {
      await expect(queueManualWatchlistVolumeDigest([sample(total, "UNDER")]))
        .resolves.toMatchObject({ eligible: 0, queued: false });
    }
    runtime.muted = true;
    await expect(queueManualWatchlistVolumeDigest([sample(3_000, "UNDER")]))
      .resolves.toMatchObject({ eligible: 1, queued: false, reason: "alerts_muted" });
    expect(runtime.triggerBaselines.get("live-1:2.5:UNDER")).toBe(3_000);
    runtime.muted = false;
    await expect(queueManualWatchlistVolumeDigest([sample(3_400, "UNDER")]))
      .resolves.toMatchObject({ eligible: 0, queued: false });
    expect(runtime.outbox.size).toBe(0);
  });

  it("rolls back eligible high-water when audience credentials are missing", async () => {
    await queueManualWatchlistVolumeDigest([sample(1_000)]);
    runtime.audienceOk = false;
    await expect(queueManualWatchlistVolumeDigest([sample(1_500)])).resolves
      .toMatchObject({ queued: false, reason: "token_missing" });
    expect(runtime.baselines.get("live-1:2.5:OVER")).toBe(1_000);
    expect(runtime.outbox.size).toBe(0);
  });

  it("retries a failed primary without resending an acknowledged subscriber", async () => {
    await queueManualWatchlistVolumeDigest([sample(1_000)]);
    runtime.sendResults.push("failed", "ok");
    await queueManualWatchlistVolumeDigest([sample(1_500)]);
    await vi.waitFor(() => expect(runtime.sends).toEqual(["primary", "subscriber"]));
    expect(runtime.parseModes).toEqual(["MarkdownV2", "MarkdownV2"]);
    runtime.sends.length = 0;
    runtime.parseModes.length = 0;
    runtime.sendResults.push("ok");
    await drainManualWatchlistVolumeOutbox();
    expect(runtime.sends).toEqual(["primary"]);
    expect([...runtime.outbox.values()][0]?.completed).toBe(true);
  });

  it("expires a pending digest after ten minutes instead of flooding stale alerts", async () => {
    runtime.outbox.set("stale", {
      event_key: "stale",
      message: "stale",
      parse_mode: "plain",
      recipient_state: [{ id: "primary", primary: true, state: "pending" }],
      attempts: 3,
      completed: false,
      createdAt: Date.now() - MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS - 1,
    });
    await drainManualWatchlistVolumeOutbox();
    expect(runtime.sends).toEqual([]);
    expect(runtime.outbox.get("stale")?.completed).toBe(true);
  });

  it("does not recover an outbox alert whose volume observation is stale", async () => {
    const stale = sample(1_500);
    const oldNow = Date.now() - MANUAL_WATCHLIST_OUTBOX_MAX_AGE_MS - 1;
    stale.observedAt = oldNow;
    stale.alertContext = {
      ...stale.alertContext!,
      timeline: [
        { ts: oldNow - 60_000, line: 2.5, odds: 2 },
        { ts: oldNow, line: 2.5, odds: 1.8 },
      ],
      currentQuote: { ts: oldNow, line: 2.5, odds: 1.8 },
    };
    runtime.outbox.set("stale-odds", {
      event_key: "stale-odds",
      message: "must not send",
      parse_mode: "MarkdownV2",
      recipient_state: [{ id: "primary", primary: true, state: "pending" }],
      attempts: 1,
      completed: false,
      createdAt: Date.now(),
      volumeObservedAt: oldNow,
      evidence: evidenceFor(stale),
    });
    await drainManualWatchlistVolumeOutbox();
    expect(runtime.sends).toEqual([]);
    expect(runtime.outbox.get("stale-odds")?.completed).toBe(true);
  });

  it("retries fresh volume even when odds metadata is stale", async () => {
    const event = sample(1_500);
    const oldOddsAt = Date.now() - 3 * 60_000;
    event.alertContext = {
      ...event.alertContext!,
      timeline: [
        { ts: oldOddsAt - 60_000, line: 2.5, odds: 2 },
        { ts: oldOddsAt, line: 2.5, odds: 1.8 },
      ],
      currentQuote: { ts: oldOddsAt, line: 2.5, odds: 1.8 },
    };
    runtime.outbox.set("stale-odds-fresh-volume", {
      event_key: "stale-odds-fresh-volume",
      message: "regenerated from evidence",
      parse_mode: "MarkdownV2",
      recipient_state: [{ id: "primary", primary: true, state: "pending" }],
      attempts: 1,
      completed: false,
      createdAt: Date.now(),
      volumeObservedAt: event.observedAt,
      evidence: evidenceFor(event),
    });

    await drainManualWatchlistVolumeOutbox();

    expect(runtime.sends).toEqual(["primary"]);
    expect(runtime.outbox.get("stale-odds-fresh-volume")?.completed).toBe(true);
  });

  it("suppresses a queued 2.5 line when a fresh goal makes the score 3-0", async () => {
    const event = sample(1_500, "OVER", 2.5);
    runtime.outbox.set("closed-after-queue", {
      event_key: "closed-after-queue",
      message: "must be regenerated, not reused",
      parse_mode: "MarkdownV2",
      recipient_state: [{ id: "primary", primary: true, state: "pending" }],
      attempts: 0,
      completed: false,
      createdAt: Date.now(),
      volumeObservedAt: Date.now(),
      evidence: evidenceFor(event),
    });
    runtime.freshScore = { homeScore: 3, awayScore: 0, isLive: true };

    await drainManualWatchlistVolumeOutbox();

    expect(runtime.sends).toEqual([]);
    expect(runtime.outbox.get("closed-after-queue")?.completed).toBe(true);
  });

  it("sends fresh volume only while the authoritative line remains active", async () => {
    const event = sample(1_500, "UNDER", 2.5);
    runtime.outbox.set("fresh-active", {
      event_key: "fresh-active",
      message: "old rendered score must not be reused",
      parse_mode: "MarkdownV2",
      recipient_state: [{ id: "primary", primary: true, state: "pending" }],
      attempts: 0,
      completed: false,
      createdAt: Date.now(),
      volumeObservedAt: Date.now(),
      evidence: evidenceFor(event),
    });
    runtime.freshScore = { homeScore: 1, awayScore: 0, isLive: true };

    await drainManualWatchlistVolumeOutbox();

    expect(runtime.sends).toEqual(["primary"]);
    expect(runtime.outbox.get("fresh-active")?.completed).toBe(true);
  });

  it("fails closed when the live-score validator is unavailable", async () => {
    const event = sample(1_500);
    runtime.outbox.set("no-validator", {
      event_key: "no-validator",
      message: "must not send",
      parse_mode: "MarkdownV2",
      recipient_state: [{ id: "primary", primary: true, state: "pending" }],
      attempts: 0,
      completed: false,
      createdAt: Date.now(),
      volumeObservedAt: Date.now(),
      evidence: evidenceFor(event),
    });
    registerManualVolumeFreshScoreValidator(null);

    await drainManualWatchlistVolumeOutbox();

    expect(runtime.sends).toEqual([]);
    expect(runtime.outbox.get("no-validator")?.completed).toBe(true);
  });

  it("suppresses legacy payloads without structured odds and score evidence", async () => {
    runtime.outbox.set("legacy", {
      event_key: "legacy",
      message: "legacy_plain_[payload]",
      recipient_state: [{ id: "primary", primary: true, state: "pending" }],
      attempts: 0,
      completed: false,
      createdAt: Date.now(),
    });
    await drainManualWatchlistVolumeOutbox();
    expect(runtime.sends).toEqual([]);
    expect(runtime.outbox.get("legacy")?.completed).toBe(true);
  });
});