import { beforeEach, describe, expect, it, vi } from "vitest";

const telegramMocks = vi.hoisted(() => ({
  sendTelegram: vi.fn(async () => {}),
  isTelegramConfigured: vi.fn(() => false),
}));

vi.mock("./telegram", () => ({
  sendTelegram: telegramMocks.sendTelegram,
  isTelegramConfigured: telegramMocks.isTelegramConfigured,
  escapeMdV2: (value: string) => value,
}));
import {
  NOWGOAL_HOSTS,
  NOWGOAL_AUTO_SWITCH_COOLDOWN_MS,
  NOWGOAL_TECHNICAL_NOTIFICATION_COOLDOWN_MS,
  NOWGOAL_VCBET_HOST,
  nowgoalMatchUrl,
  SOFASCORE_403_BACKOFF_MAX_MS,
  SOFASCORE_403_BACKOFF_INITIAL_MS,
  SOFASCORE_RESOLVER_NEGATIVE_TTL_MS,
  SOFASCORE_UPSTREAM_ENABLED,
  nextSofascore403BackoffMs,
} from "./config";
import {
  __upstreamTestOnly,
  currentBaseUrl,
  endpointsFor,
  probeHost,
  tryFailover,
  type UpstreamFetchDetails,
} from "./upstream";

const healthyXml = "<m>1^2^3</m>".repeat(6);
const healthyMeta = JSON.stringify({
  ErrCode: 0,
  Data: Array.from({ length: 10 }, (_, i) => `${i}^x^x^2026,7,1,12,0`).join("!"),
});

function healthyResponse(url: string, finalOrigin?: string): UpstreamFetchDetails {
  const parsed = new URL(url);
  return {
    body: parsed.pathname.includes("SoccerAjax") ? healthyMeta : healthyXml,
    status: 200,
    finalUrl: finalOrigin ? `${finalOrigin}${parsed.pathname}${parsed.search}` : url,
    redirected: Boolean(finalOrigin && finalOrigin !== parsed.origin),
  };
}

beforeEach(() => {
  __upstreamTestOnly.reset();
  telegramMocks.sendTelegram.mockClear();
  telegramMocks.isTelegramConfigured.mockReset();
  telegramMocks.isTelegramConfigured.mockReturnValue(false);
  vi.useRealTimers();
});

describe("canonical upstream registry", () => {
  it("keeps only the three currently healthy canonical mirrors", () => {
    expect(NOWGOAL_HOSTS).toEqual([
      "https://live11.nowgoal26.com",
      "https://www.nowgoal26.com",
      "https://www.nowgoal28.com",
    ]);
    expect(NOWGOAL_VCBET_HOST).toBe("https://live11.nowgoal26.com");
  });

  it("enforces the ten-minute global automatic switch floor", () => {
    expect(NOWGOAL_AUTO_SWITCH_COOLDOWN_MS).toBeGreaterThanOrEqual(600_000);
  });

  it("keeps a separate ten-minute technical notification cooldown", () => {
    expect(NOWGOAL_TECHNICAL_NOTIFICATION_COOLDOWN_MS).toBe(600_000);
  });

  it("uses the suffixless canonical match-detail route", () => {
    expect(nowgoalMatchUrl("2926327")).toBe(
      "https://www.nowgoal26.com/match/live-2926327",
    );
    expect(nowgoalMatchUrl("match/2926327")).toBe(
      "https://www.nowgoal26.com/match/live-match%2F2926327",
    );
  });
});

describe("automatic failover stability", () => {
  it("singleflights concurrent callers into one probe cascade", async () => {
    let calls = 0;
    let release!: () => void;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    const fetcher = async (url: string) => {
      calls++;
      await gate;
      return healthyResponse(url);
    };

    const first = tryFailover(fetcher, "volatility_stale", { force: true });
    const second = tryFailover(fetcher, "scanner_consecutive_failures", { force: true });
    release();
    const [a, b] = await Promise.all([first, second]);

    expect(a.switched).toBe(true);
    expect(b).toMatchObject({ switched: true, coalesced: true, from: a.from, to: a.to });
    expect(calls).toBe(3);
  });

  it("suppresses rapid repeated automatic attempts and does not oscillate", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T00:00:00Z"));
    const fetcher = async (url: string) => healthyResponse(url);

    const first = await tryFailover(fetcher, "volatility_stale", { force: true });
    expect(first).toMatchObject({ switched: true, to: NOWGOAL_HOSTS[1] });

    const repeat = await tryFailover(fetcher, "watchdog_stuck_live", { force: true });
    expect(repeat).toMatchObject({
      switched: false,
      to: NOWGOAL_HOSTS[1],
      suppressed: "switch_cooldown",
    });
    expect(currentBaseUrl()).toBe(NOWGOAL_HOSTS[1]);

    vi.advanceTimersByTime(NOWGOAL_AUTO_SWITCH_COOLDOWN_MS - 1);
    const stillCooling = await tryFailover(fetcher, "scanner_consecutive_failures", {
      force: true,
    });
    expect(stillCooling.suppressed).toBe("switch_cooldown");
    expect(currentBaseUrl()).toBe(NOWGOAL_HOSTS[1]);
  });

  it("treats a healthy current host as a same-host no-op", async () => {
    const result = await tryFailover(async (url) => healthyResponse(url), "preflight");
    expect(result).toMatchObject({
      switched: false,
      from: NOWGOAL_HOSTS[0],
      to: NOWGOAL_HOSTS[0],
    });
  });

  it("never switches to a candidate that redirects back to the current origin", async () => {
    const fetcher = async (url: string) => {
      const origin = new URL(url).origin;
      if (origin === NOWGOAL_HOSTS[1]) return healthyResponse(url, NOWGOAL_HOSTS[0]);
      return healthyResponse(url);
    };

    const result = await tryFailover(fetcher, "volatility_stale", { force: true });
    expect(result.switched).toBe(true);
    expect(result.to).toBe(NOWGOAL_HOSTS[2]);
    expect(result.report).toContainEqual(
      expect.objectContaining({ host: NOWGOAL_HOSTS[1], reason: "same_effective_origin" }),
    );
  });

  it("does not accept a redirecting current alias as an independently healthy source", async () => {
    const fetcher = async (url: string) => {
      const origin = new URL(url).origin;
      if (origin === NOWGOAL_HOSTS[0]) return healthyResponse(url, NOWGOAL_HOSTS[1]);
      return healthyResponse(url);
    };

    const result = await tryFailover(fetcher, "redirected_current");
    expect(result).toMatchObject({ switched: true, to: NOWGOAL_HOSTS[1] });
    expect(result.report).toContainEqual(
      expect.objectContaining({ host: NOWGOAL_HOSTS[0], ok: false, reason: "redirected_origin" }),
    );
  });

  it("fails over on genuine failure and recovers gracefully after cooldown", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T00:00:00Z"));
    let failedOrigin = NOWGOAL_HOSTS[0];
    const fetcher = async (url: string) => {
      if (new URL(url).origin === failedOrigin) throw new Error("genuine outage");
      return healthyResponse(url);
    };

    const fallback = await tryFailover(fetcher, "scanner_consecutive_failures");
    expect(fallback).toMatchObject({ switched: true, to: NOWGOAL_HOSTS[1] });

    vi.advanceTimersByTime(NOWGOAL_AUTO_SWITCH_COOLDOWN_MS);
    failedOrigin = NOWGOAL_HOSTS[1];
    const recovered = await tryFailover(fetcher, "scanner_consecutive_failures");
    expect(recovered).toMatchObject({ switched: true, to: NOWGOAL_HOSTS[0] });
  });

  it("temporarily quarantines invalid schema and permits recovery", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T00:00:00Z"));
    let invalid = true;
    const calls: string[] = [];
    const fetcher = async (url: string) => {
      calls.push(url);
      if (invalid && new URL(url).origin === NOWGOAL_HOSTS[0]) return { body: "<html>not a feed</html>", status: 200, finalUrl: url };
      return healthyResponse(url);
    };

    const fallback = await tryFailover(fetcher, "invalid_schema");
    expect(fallback).toMatchObject({ switched: true, to: NOWGOAL_HOSTS[1] });
    expect(__upstreamTestOnly.hostHealth.get(NOWGOAL_HOSTS[0])?.kind).toBe("invalid");

    __upstreamTestOnly.setCurrentBase(NOWGOAL_HOSTS[0]!);
    calls.length = 0;
    await tryFailover(fetcher, "rapid_repeat");
    expect(calls.every((url) => new URL(url).origin !== NOWGOAL_HOSTS[0])).toBe(true);

    vi.advanceTimersByTime(10 * 60 * 1000);
    invalid = false;
    __upstreamTestOnly.setCurrentBase(NOWGOAL_HOSTS[0]!);
    const recovered = await tryFailover(fetcher, "quarantine_expired");
    expect(recovered.switched).toBe(false);
    expect(__upstreamTestOnly.hostHealth.has(NOWGOAL_HOSTS[0]!)).toBe(false);
  });

  it("backs off transient 5xx probes without permanently blacklisting the host", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T00:00:00Z"));
    let failing = true;
    const fetcher = async (url: string) => {
      if (failing && new URL(url).origin === NOWGOAL_HOSTS[0]) {
        throw new Error(`HTTP 503 from ${url}`);
      }
      return healthyResponse(url);
    };

    await tryFailover(fetcher, "transient_5xx");
    const health = __upstreamTestOnly.hostHealth.get(NOWGOAL_HOSTS[0]!);
    expect(health).toMatchObject({ kind: "transient", transientBackoffMs: 30_000 });

    // The host-level transient delay is only 30s, while the independent
    // global switch cooldown remains 10m. Once both have elapsed the host is
    // eligible and a successful probe clears its transient state.
    vi.advanceTimersByTime(NOWGOAL_AUTO_SWITCH_COOLDOWN_MS);
    failing = false;
    __upstreamTestOnly.setCurrentBase(NOWGOAL_HOSTS[0]!);
    const recovered = await tryFailover(fetcher, "transient_recovered");
    expect(recovered.switched).toBe(false);
    expect(__upstreamTestOnly.hostHealth.has(NOWGOAL_HOSTS[0]!)).toBe(false);
  });

  it("rate-limits Telegram diagnostics even when manual switches bypass switch cooldown", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T00:00:00Z"));
    telegramMocks.isTelegramConfigured.mockReturnValue(true);
    let failedOrigin = NOWGOAL_HOSTS[0];
    const fetcher = async (url: string) => {
      if (new URL(url).origin === failedOrigin) throw new Error("genuine outage");
      return healthyResponse(url);
    };

    const first = await tryFailover(fetcher, "automatic_failure");
    expect(first).toMatchObject({ switched: true, to: NOWGOAL_HOSTS[1] });
    expect(telegramMocks.sendTelegram).toHaveBeenCalledTimes(1);

    failedOrigin = NOWGOAL_HOSTS[1];
    const manualBypass = await tryFailover(fetcher, "manual_trigger", {
      bypassCooldown: true,
    });
    expect(manualBypass).toMatchObject({ switched: true, to: NOWGOAL_HOSTS[2] });
    expect(telegramMocks.sendTelegram).toHaveBeenCalledTimes(1);

    vi.advanceTimersByTime(NOWGOAL_TECHNICAL_NOTIFICATION_COOLDOWN_MS);
    failedOrigin = NOWGOAL_HOSTS[2];
    const afterNotificationCooldown = await tryFailover(fetcher, "manual_trigger", {
      bypassCooldown: true,
    });
    expect(afterNotificationCooldown.switched).toBe(true);
    expect(telegramMocks.sendTelegram).toHaveBeenCalledTimes(2);
  });
});

describe("upstream probe transport metadata", () => {
  it("preserves status and redirect details when a transport adapter supplies them", async () => {
    const base = "https://live11.nowgoal26.com";
    const endpoints = endpointsFor(base);
    const xml = "<m>1^2^3</m>".repeat(6);
    const meta = JSON.stringify({
      ErrCode: 0,
      Data: Array.from({ length: 10 }, (_, i) => `${i}^x^x^2026,7,1,12,0`).join("!"),
    });
    const result = await probeHost(base, async (url) => {
      if (url === endpoints.meta) {
        return {
          body: meta,
          status: 200,
          finalUrl: `${base}/Ajax/SoccerAjax?type=12`,
          redirected: true,
          redirectCount: 1,
        };
      }
      if (url === endpoints.primaryOu) return { body: xml, status: 200 };
      return { body: xml, status: 200 };
    });

    expect(result.ok).toBe(true);
    expect(result.endpointStatus).toEqual({
      meta: 200,
      primaryOu: 200,
      benchmarkOu: 200,
    });
    expect(result.finalUrls?.meta).toContain("type=12");
    expect(result.redirected).toBe(true);
    expect(result.redirectCount).toBe(1);
  });
});

describe("Sofascore retry policy", () => {
  it("defaults the repeatedly blocked optional upstream to disabled", () => {
    expect(SOFASCORE_UPSTREAM_ENABLED).toBe(false);
  });

  it("expires negative resolution entries and caps 403 backoff", () => {
    expect(SOFASCORE_RESOLVER_NEGATIVE_TTL_MS).toBe(15 * 60 * 1000);
    expect(nextSofascore403BackoffMs(0)).toBe(SOFASCORE_403_BACKOFF_INITIAL_MS);
    expect(nextSofascore403BackoffMs(SOFASCORE_403_BACKOFF_INITIAL_MS)).toBe(120_000);
    expect(nextSofascore403BackoffMs(SOFASCORE_403_BACKOFF_MAX_MS)).toBe(
      SOFASCORE_403_BACKOFF_MAX_MS,
    );
  });
});