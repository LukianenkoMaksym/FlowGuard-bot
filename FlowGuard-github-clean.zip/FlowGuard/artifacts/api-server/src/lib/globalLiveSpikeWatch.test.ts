import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { UnifiedAlertInput } from "./unifiedAlert";

const mocks = vi.hoisted(() => ({
  directory: vi.fn(),
  detail: vi.fn(),
  process: vi.fn(),
  listener: null as null | ((event: { gameId: string; tx: any; league: string }) => void),
  send: vi.fn(async (_message: string): Promise<{ status: string }> => ({ status: "delivered" })),
  configured: vi.fn(() => true),
  muted: false,
  breaker: false,
  context: vi.fn(() => null),
  movements: vi.fn(() => [] as Record<string, unknown>[]),
  formatted: vi.fn((_input: UnifiedAlertInput) => undefined),
  binding: vi.fn(() => null),
  pending: new Map<string, { gameId: string; tx: any }>(),
  completed: new Set<string>(),
  admission: vi.fn(async () => true),
  builder: null as null | ((gameId: string, tx: any) => Promise<string | null | "closed">),
}));
vi.mock("./excapper", () => ({
  bindAutomaticExcapperRows: vi.fn(async () => undefined),
  loadLiveExcapperDirectory: mocks.directory,
  loadParsedGameDetail: mocks.detail,
  processTransactions: mocks.process,
  setNewExcapperTransactionListener: (fn: typeof mocks.listener) => { mocks.listener = fn; },
  getVerifiedExcapperBinding: mocks.binding,
}));
vi.mock("./excapperBackoff", () => ({
  isExcapperBreakerOpen: () => mocks.breaker,
}));
vi.mock("./controls", () => ({
  getControls: () => ({ alertsMuted: mocks.muted }),
}));
vi.mock("./telegram", () => ({
  isTelegramConfigured: mocks.configured,
  sendTelegram: mocks.send,
  escapeMdV2: (s: string) => s,
}));
vi.mock("./scanner", () => ({ getScannerAlertContext: mocks.context }));
vi.mock("./radarBookMarkets", () => ({ getCachedBookMovements: mocks.movements }));
vi.mock("./unifiedAlert", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./unifiedAlert")>();
  return {
    ...actual,
    formatUnifiedAlert: (input: UnifiedAlertInput) => {
      mocks.formatted(input);
      return actual.formatUnifiedAlert(input);
    },
  };
});
vi.mock("./globalSpikeOutbox", () => ({
  admitGlobalSpike: async (gameId: string, tx: any) => {
    const admitted = await mocks.admission();
    const key = `${gameId}:${tx.line}:${tx.side}:${tx.summ}`;
    if (admitted && !mocks.completed.has(key)) mocks.pending.set(key, { gameId, tx });
    return admitted;
  },
  drainGlobalSpikeOutbox: async (build: (gameId: string, tx: any) => Promise<string | null | "closed">) => {
    mocks.builder = build;
    if (mocks.muted) return;
    for (const [key, value] of mocks.pending) {
      const message = await build(value.gameId, value.tx);
      if (message === "closed") { mocks.pending.delete(key); mocks.completed.add(key); continue; }
      if (!message) continue;
      const result = await mocks.send(message);
      if (result?.status === "delivered") { mocks.pending.delete(key); mocks.completed.add(key); }
    }
  },
}));
vi.mock("./targetLeagues", () => ({
  matchTargetLeague: (league: string) => league === "Target League" ? league : null,
}));

import { runGlobalLiveSpikeCycle, startGlobalLiveSpikeWatch, stopGlobalLiveSpikeWatch } from "./globalLiveSpikeWatch";

const row = (gameId: string, overrides: Record<string, unknown> = {}) => ({
  gameId, team1: "Home", team2: "Away", league: "Target League", activity: "live",
  isLive: true, totalVolume: 1000, ...overrides,
});
const tx = (summ: number, change: number) => ({
  line: 2.5, side: "Over", summ, change, rawChange: String(change),
  date: "", matchMinute: "54", sourceType: "live",
});
const detail = {
  observedAt: Date.now(), live: { liveScore: { home: 1, away: 0 }, liveMinute: 54 },
  samples: [{ line: 2.5, overOdds: 1.8, underOdds: 2.05, collectedAt: Date.now() }],
  transactions: [],
};
async function flush() {
  await vi.waitFor(() => expect(mocks.detail).toHaveBeenCalled());
  await new Promise((resolve) => setTimeout(resolve, 0));
}

describe("global live spike watch", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.muted = false;
    mocks.breaker = false;
    mocks.configured.mockReturnValue(true);
    mocks.binding.mockReturnValue(null);
    mocks.context.mockReturnValue(null);
    mocks.movements.mockReturnValue([]);
    mocks.pending.clear();
    mocks.completed.clear();
    mocks.builder = null;
    mocks.admission.mockResolvedValue(true);
    mocks.send.mockResolvedValue({ status: "delivered" } as any);
    mocks.directory.mockResolvedValue({ rows: [row("101")], stale: false });
    mocks.detail.mockResolvedValue(detail);
  });
  afterEach(() => stopGlobalLiveSpikeWatch());

  it("delivers original evidence when fresh enrichment never resolves", async () => {
    process.env["EXCAPPER_ENRICHMENT_TIMEOUT_MS"] = "10";
    try {
      startGlobalLiveSpikeWatch();
      await flush();
      mocks.directory.mockImplementation(() => new Promise(() => {}));
      await mocks.listener!({ gameId: "101", tx: tx(1500, 500), league: "Target League" });
      await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(1));
      expect(mocks.pending.size).toBe(0);
    } finally { delete process.env["EXCAPPER_ENRICHMENT_TIMEOUT_MS"]; }
  });

  it("delivers without a binding when candidates remain ambiguous", async () => {
    mocks.binding.mockReturnValue(null);
    startGlobalLiveSpikeWatch();
    await flush();
    await mocks.listener!({ gameId: "101", tx: tx(1500, 500), league: "Target League" });
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(1));
    expect(mocks.pending.size).toBe(0);
    expect(mocks.context).not.toHaveBeenCalled();
  });

  it("leaves the current card minute unknown when only the transaction has a minute", async () => {
    startGlobalLiveSpikeWatch();
    await flush();
    mocks.detail.mockResolvedValueOnce({
      ...detail, live: { liveScore: { home: 1, away: 0 }, liveMinute: null },
    });
    await mocks.builder?.("101", tx(1500, 500));
    expect(mocks.formatted.mock.calls.at(-1)?.[0]).toMatchObject({
      minute: null,
      inflow: { minute: "54" },
    });
  });

  it("dispatches each new bet once, suppresses 499, mute, settled totals and missing evidence", async () => {
    startGlobalLiveSpikeWatch();
    await flush();
    const fire = (summ: number, change: number) =>
      mocks.listener?.({ gameId: "101", tx: tx(summ, change), league: "Target League" });
    fire(1500, 500);
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(1));
    expect(mocks.send.mock.calls[0]![0]).toContain("💎 SMART EXCAPPER");
    expect(mocks.send.mock.calls[0]![0]).toContain("excapper.com/");
    fire(1500, 500);
    await flush();
    expect(mocks.send).toHaveBeenCalledTimes(1);
    mocks.muted = true;
    fire(2200, 700);
    await flush();
    expect(mocks.send).toHaveBeenCalledTimes(1);
    mocks.muted = false;
    // Isolate the later closed-line checks from the muted pending delivery.
    mocks.pending.clear();
    mocks.detail.mockResolvedValueOnce({
      ...detail, live: { liveScore: { home: 2, away: 1 }, liveMinute: 56 },
    });
    fire(3000, 800);
    await flush();
    expect(mocks.send).toHaveBeenCalledTimes(1);
    mocks.detail.mockResolvedValueOnce({ ...detail, samples: [], live: { liveScore: null, liveMinute: null } });
    fire(4000, 900);
    await flush();
    expect(mocks.send).toHaveBeenCalledTimes(1);
  });

  it("rotates at a hard cap of eight, rejects non-live and non-target, and honors breaker", async () => {
    mocks.directory.mockResolvedValue({ rows: [
      ...Array.from({ length: 11 }, (_, i) => row(String(101 + i))),
      row("999", { activity: "scheduled", isLive: false }),
      row("998", { league: "Unknown" }),
    ], stale: false });
    startGlobalLiveSpikeWatch();
    // The cycle uses jitter between detail fetches; wait until all eight complete.
    await vi.waitFor(() => expect(mocks.process).toHaveBeenCalledTimes(8), { timeout: 10_000 });
    expect(mocks.process.mock.calls.map((call) => call[1])).toEqual(
      Array.from({ length: 8 }, (_, i) => String(101 + i)));
    mocks.process.mockClear();
    await runGlobalLiveSpikeCycle();
    expect(mocks.process.mock.calls.map((call) => call[1])).toEqual(
      ["109", "110", "111", "101", "102", "103", "104", "105"]);
    mocks.breaker = true;
    mocks.process.mockClear();
    await runGlobalLiveSpikeCycle();
    expect(mocks.process).not.toHaveBeenCalled();
  }, 20_000);

  it("does not start without Telegram", () => {
    mocks.configured.mockReturnValue(false);
    startGlobalLiveSpikeWatch();
    expect(mocks.directory).not.toHaveBeenCalled();
    expect(mocks.listener).toBeNull();
  });

  it("does not overlap cycles while the directory request is in flight", async () => {
    let release!: (snapshot: unknown) => void;
    mocks.directory.mockReturnValueOnce(new Promise((resolve) => { release = resolve; }));
    startGlobalLiveSpikeWatch();
    await runGlobalLiveSpikeCycle();
    expect(mocks.directory).toHaveBeenCalledTimes(1);
    release({ rows: [row("101")], stale: false });
    await vi.waitFor(() => expect(mocks.process).toHaveBeenCalledTimes(1));
  });

  it("does not invent a NowGoal identity for unknown fixtures", async () => {
    startGlobalLiveSpikeWatch();
    await flush();
    mocks.listener?.({ gameId: "101", tx: tx(9500, 500), league: "Target League" });
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(1));
    expect(mocks.context).not.toHaveBeenCalled();
    expect(mocks.send.mock.calls[0]![0]).not.toContain("nowgoal");
  });

  it("prefers same-line scanner history only for a verified binding", async () => {
    mocks.binding.mockReturnValue({ matchId: "nowgoal-501" } as any);
    mocks.context.mockReturnValue({
      matchId: "nowgoal-501", league: "Target League", home: "Home", away: "Away",
      isLive: true, homeScore: 1, awayScore: 0, minute: "54",
      side: "OVER", line: 2.5,
       timeline: [
         { ts: Date.now() - 120_000, line: 2.5, odds: 2.5 },
         { ts: Date.now() - 60_000, line: 2.5, odds: 1.8 },
       ],
       currentQuote: { ts: Date.now() - 60_000, line: 2.5, odds: 1.8 },
      link: "https://nowgoal.example/501",
    } as any);
    startGlobalLiveSpikeWatch();
    await flush();
    mocks.listener?.({ gameId: "101", tx: tx(12345, 500), league: "Target League" });
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledOnce());
    expect(mocks.context).toHaveBeenCalledWith("nowgoal-501", 2.5, "OVER");
    expect(mocks.send.mock.calls[0]![0]).toContain("nowgoal.example/501");
    expect(mocks.send.mock.calls[0]![0]).toContain("Тотал больше 2.5 · Bet365: 2.50 → 1.80 (-28.0%)");
  });

  it("displays cached moving books only on a verified exact-market binding without moving the bet cutoff", async () => {
    const betTime = Date.now() - 15_000;
    mocks.binding.mockReturnValue({ matchId: "501" } as any);
    mocks.context.mockReturnValue({
      matchId: "501", isLive: true, homeScore: 1, awayScore: 0, minute: "54",
      side: "OVER", line: 2.5, link: "https://nowgoal.example/501",
      timeline: [
        { ts: betTime - 90_000, line: 2.5, odds: 2.50 },
        { ts: betTime - 30_000, line: 2.5, odds: 1.80 },
      ],
      currentQuote: { ts: betTime - 30_000, line: 2.5, odds: 1.80 },
    } as any);
    mocks.movements.mockReturnValue([{
      cid: "50", bookmaker: "1xBet", type: "drop",
      from: 2.40, to: 2.00, percent: -16.7, quoteAt: betTime - 20_000,
      history: [{ ts: betTime - 100_000, odds: 2.40 }, { ts: betTime - 20_000, odds: 2.00 }],
    }]);
    startGlobalLiveSpikeWatch();
    await flush();
    mocks.listener?.({ gameId: "101", tx: { ...tx(12346, 501), betTime }, league: "Target League" });
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledOnce());
    expect(mocks.movements).toHaveBeenCalledWith("501", "OVER", 2.5, betTime);
    const card = mocks.send.mock.calls[0]![0];
    expect(card).toContain("Bet365: 2.50 → 1.80");
    expect(card).toContain("1xBet: 2.40 → 2.00");
    expect(card).not.toContain("за 5 мин");
  });

  it("keeps a fixed bet cutoff on retries despite a newer detail repricing", async () => {
    const cutoff = Date.now() - 20_000;
    const observed = (at: number, odds: number) => ({
      ...detail, observedAt: at,
      samples: [{ ...detail.samples[0], collectedAt: at, overOdds: odds }],
    });
    mocks.detail.mockResolvedValueOnce(observed(cutoff - 4 * 60_000, 1.8));
    startGlobalLiveSpikeWatch();
    await flush();
    mocks.detail.mockResolvedValueOnce(observed(cutoff - 2 * 60_000, 1.65));
    await mocks.builder?.("101", { ...tx(1_500, 500), betTime: cutoff });
    mocks.detail.mockResolvedValueOnce(observed(cutoff, 1.48));
    mocks.send.mockResolvedValueOnce({ status: "failed" } as any);
    mocks.listener?.({ gameId: "101", tx: { ...tx(1_500, 500), betTime: cutoff }, league: "Target League" });
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(1));
    const first = mocks.send.mock.calls[0]![0];
    const firstInput = mocks.formatted.mock.calls.at(-1)![0];
    expect(firstInput.prebet?.betTime).toBe(cutoff);
    expect(firstInput.timeline.map((point) => point.odds)).toEqual(
      expect.arrayContaining([1.80, 1.48]));
    expect(firstInput.currentQuote?.odds).toBe(1.48);
    expect(firstInput.timeline.every((point) => point.ts <= cutoff)).toBe(true);
    // Excapper samples do not identify a bookmaker: don't invent one just
    // because the source has a real pre-bet price movement.
    expect(firstInput.bookmaker).toBeUndefined();
    expect(firstInput.radarBooks).toEqual([]);
    expect(first).toContain("Рынок: Тотал больше 2.5");
    expect(first).not.toContain("букмекер неизвестен: 1.80");
    mocks.detail.mockResolvedValueOnce(observed(cutoff + 60_000, 1.3));
    const retry = await mocks.builder?.("101", { ...tx(1_500, 500), betTime: cutoff });
    const retryInput = mocks.formatted.mock.calls.at(-1)![0];
    expect(retryInput.prebet?.betTime).toBe(cutoff);
    expect(retryInput.timeline).toEqual(firstInput.timeline);
    expect(retryInput.currentQuote).toEqual(firstInput.currentQuote);
    expect(retryInput.bookmaker).toBeUndefined();
    expect(retryInput.radarBooks).toEqual([]);
    expect(retry).toContain("Рынок: Тотал больше 2.5");
    expect(retry).not.toContain("1.30");
  });

  it("retries a resolved failed broadcast and a failed context build without losing the bet", async () => {
    startGlobalLiveSpikeWatch();
    await flush();
    mocks.send.mockResolvedValueOnce({ status: "failed" } as any);
    mocks.listener?.({ gameId: "101", tx: tx(10500, 500), league: "Target League" });
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(1));
    expect(mocks.pending.size).toBe(1);
    await runGlobalLiveSpikeCycle();
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(2));
    expect(mocks.pending.size).toBe(0);

    mocks.detail.mockResolvedValueOnce({ ...detail, samples: [], live: { liveScore: null, liveMinute: null } });
    mocks.listener?.({ gameId: "101", tx: tx(11000, 500), league: "Target League" });
    await vi.waitFor(() => expect(mocks.pending.size).toBe(1));
    await runGlobalLiveSpikeCycle();
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(3));
    expect(mocks.pending.size).toBe(0);
  });

  it("keeps a persisted bet pending while Telegram is unconfigured or the watcher is stopped", async () => {
    startGlobalLiveSpikeWatch();
    await flush();
    mocks.send.mockResolvedValueOnce({ status: "failed" } as any);
    mocks.listener?.({ gameId: "101", tx: tx(12500, 500), league: "Target League" });
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledOnce());
    expect(mocks.pending.size).toBe(1);

    mocks.configured.mockReturnValue(false);
    expect(await mocks.builder?.("101", tx(12500, 500))).toBeNull();
    await runGlobalLiveSpikeCycle();
    expect(mocks.pending.size).toBe(1);
    expect(mocks.send).toHaveBeenCalledOnce();

    stopGlobalLiveSpikeWatch();
    expect(await mocks.builder?.("101", tx(12500, 500))).toBeNull();
    mocks.configured.mockReturnValue(true);
    expect(mocks.pending.size).toBe(1);
    startGlobalLiveSpikeWatch();
    await vi.waitFor(() => expect(mocks.send).toHaveBeenCalledTimes(2));
    expect(mocks.pending.size).toBe(0);
  });
});