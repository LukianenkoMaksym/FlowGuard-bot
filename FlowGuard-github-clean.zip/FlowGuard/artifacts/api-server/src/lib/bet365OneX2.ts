import { USER_AGENT_POOL } from "./config";
import { withCacheBuster } from "./upstream";

/** NowGoal match page's 1X2 history popup:
 * /Ajax/SoccerAjax?type=14&id={match}&t=20&cid=8&h=0&r1=0&r2=0&r3=0
 * cid=8 is Bet365; Data.op lists newest-first observations with Unix mt.
 * odds.u = home, odds.g = draw, odds.d = away (the website's OP column).
 * Never infer these prices from OU, another bookmaker, or a failed response.
 */
export interface OneX2Point {
  ts: number;
  home: number | null;
  away: number | null;
}
export interface Bet365OneX2 {
  bookmaker: "Bet365";
  /** Time the verified remote response was obtained, not a fabricated quote timestamp. */
  observedAt: number;
  history: OneX2Point[];
  current: OneX2Point;
}

export function parseBet365OneX2(body: string, observedAt = Date.now()): Bet365OneX2 | null {
  let payload: unknown;
  try { payload = JSON.parse(body); } catch { return null; }
  if (!payload || typeof payload !== "object") return null;
  const response = payload as { ErrCode?: unknown; Data?: { op?: unknown } };
  if (response.ErrCode !== 0 || !Array.isArray(response.Data?.op)) return null;
  // In-play and pre-match observations are distinct segments. Only real live
  // Bet365 entries with a recorded source timestamp can trigger live RADAR.
  const history: OneX2Point[] = [];
  let newestTs = Infinity;
  for (const item of response.Data.op) {
    if (!item || typeof item !== "object") break;
    const row = item as { close?: unknown; type?: unknown; mt?: unknown; odds?: { u?: unknown; g?: unknown; d?: unknown } };
    if (row.close === true || row.type !== 0) break;
    const ts = Number(row.mt) * 1_000;
    const rawHome = Number(row.odds?.u);
    const rawAway = Number(row.odds?.d);
    const home = Number.isFinite(rawHome) && rawHome > 1 ? rawHome : null;
    const away = Number.isFinite(rawAway) && rawAway > 1 ? rawAway : null;
    if (!Number.isSafeInteger(ts) || ts <= 0 || ts > observedAt + 5_000 ||
        ts >= newestTs || (home === null && away === null)) break;
    newestTs = ts;
    history.push({ ts, home, away });
  }
  if (!history.length) return null;
  history.reverse();
  return { bookmaker: "Bet365", observedAt, history, current: history[history.length - 1]! };
}

export async function fetchBet365OneX2(matchId: string, signal?: AbortSignal): Promise<Bet365OneX2 | null> {
  if (!/^\d+$/.test(matchId)) return null;
  // This Ajax endpoint is verified on the canonical www host; the normal
  // scanner's primary live11 host currently replies with {code:1002}.
  const url = `https://www.nowgoal26.com/Ajax/SoccerAjax?type=14&id=${matchId}&t=20&cid=8&h=0&r1=0&r2=0&r3=0`;
  // Do not use scanner.fetchRaw: it randomly selects a referer from three
  // mirrors. This per-match www endpoint returns {code:1002} unless its
  // Referer is www.nowgoal26.com (verified against the live source).
  const response = await fetch(withCacheBuster(url), {
    headers: {
      "User-Agent": USER_AGENT_POOL[0]!,
      Referer: "https://www.nowgoal26.com/",
      "X-Requested-With": "XMLHttpRequest",
      Accept: "application/json, text/javascript, */*; q=0.01",
    },
    signal: AbortSignal.any([AbortSignal.timeout(5_000), ...(signal ? [signal] : [])]),
  });
  if (!response.ok) throw new Error(`Bet365 1X2 HTTP ${response.status}`);
  const body = await response.text();
  let payload: unknown;
  try { payload = JSON.parse(body); }
  catch { throw new Error("Invalid Bet365 1X2 Ajax response: not JSON"); }
  if (!payload || typeof payload !== "object" ||
      (payload as { ErrCode?: unknown }).ErrCode !== 0 ||
      !Array.isArray((payload as { Data?: { op?: unknown } }).Data?.op)) {
    throw new Error("Invalid Bet365 1X2 Ajax response: bookmaker data unavailable");
  }
  return parseBet365OneX2(body);
}