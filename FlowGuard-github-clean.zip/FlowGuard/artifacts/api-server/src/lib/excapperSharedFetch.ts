import {
  assertExcapperRequestAllowed,
  getExcapperHealth,
  parseRetryAfter,
  pickExcapperBrowserProfile,
  recordAuthenticExcapperSuccess,
  recordExcapperFailure,
  setExcapperRecovering,
} from "./excapperBackoff";
import { logger } from "./logger";

export type ExcapperRequestTier =
  | "manual"
  | "live"
  | "directory"
  | "prematch"
  | "background";

export interface ExcapperRequestOptions {
  tier?: ExcapperRequestTier;
  /** Retained for caller compatibility. Raw responses are never cached after
   * completion, so this no longer permits serving a previous response. */
  maxAgeMs?: number;
  /** Retained for caller compatibility. Every completed request is already
   * discarded; an already-running request for the same URL is still joined. */
  bypassCache?: boolean;
}

interface QueueEntry {
  url: string;
  kind: "directory" | "game";
  tier: ExcapperRequestTier;
  queuedAt: number;
  timeoutMs: number;
  controller: AbortController;
  activeConsumers: number;
  started: boolean;
  resolve: (html: string) => void;
  reject: (error: unknown) => void;
  promise: Promise<string>;
}

const pendingByUrl = new Map<string, QueueEntry>();
// Response provenance is needed by quote consumers, but retaining the raw HTML
// here caused process memory to grow with every distinct game. Keep only small,
// bounded completion timestamps. Raw bodies live solely in the in-flight
// promise and become collectible as soon as its consumers finish.
const completedAtByUrl = new Map<string, number>();
const MAX_COMPLETION_TIMESTAMPS = 2_048;
const MAX_PENDING_REQUESTS = 8;
const queues: Record<0 | 1 | 2, QueueEntry[]> = { 0: [], 1: [], 2: [] };
let running: QueueEntry | null = null;
let pumpTimer: ReturnType<typeof setTimeout> | null = null;
let lastCompletedAt = 0;
let consecutiveUrgent = 0;

const statusCounts: Record<string, number> = {};
const tierCounts: Record<ExcapperRequestTier, { submitted: number; started: number; completed: number }> = {
  manual: { submitted: 0, started: 0, completed: 0 },
  live: { submitted: 0, started: 0, completed: 0 },
  directory: { submitted: 0, started: 0, completed: 0 },
  prematch: { submitted: 0, started: 0, completed: 0 },
  background: { submitted: 0, started: 0, completed: 0 },
};
let lastNetworkSuccessAt: number | null = null;

// Excapper may issue an ordinary session cookie on the directory response.
// Keep only a small name/value jar in process memory. It is never logged,
// persisted, or sent anywhere except the canonical HTTPS Excapper origin.
const sessionCookies = new Map<string, string>();
const MAX_SESSION_COOKIES = 20;
const MAX_COOKIE_BYTES = 4_096;

/**
 * Minimum completion-to-start spacing shared by every Excapper request.
 * Directory, automatic live hydration and explicit/manual callers all pass
 * through this same queue; priority changes ordering, never the rate budget.
 *
 * The coordinator owns the 12-second directory cadence (including its
 * discovery jitter). This transport-level floor protects targeted detail
 * hydration while still serializing directory requests through the same
 * single-active-request queue.
 */
export function queueMicrodelayMs(_random = Math.random): number {
  return 1_500;
}

/** @deprecated Use the one shared request-spacing budget. */
export function liveGameDelayMs(random = Math.random): number {
  return queueMicrodelayMs(random);
}

function priority(tier: ExcapperRequestTier): 0 | 1 | 2 {
  if (tier === "manual") return 0;
  if (tier === "live" || tier === "directory") return 1;
  return 2;
}

function takeNext(): QueueEntry | undefined {
  // Urgent work changes only queue order. It never bypasses the shared
  // 1.5-second completion spacing enforced by schedulePump().
  if (consecutiveUrgent >= 4 && queues[2].length) {
    consecutiveUrgent = 0;
    return queues[2].shift();
  }
  const urgent = queues[0].shift() ?? queues[1].shift();
  if (urgent) {
    consecutiveUrgent++;
    return urgent;
  }
  consecutiveUrgent = 0;
  return queues[2].shift();
}

function removeQueuedEntry(entry: QueueEntry): void {
  for (const queue of Object.values(queues)) {
    const index = queue.indexOf(entry);
    if (index >= 0) queue.splice(index, 1);
  }
  if (pendingByUrl.get(entry.url) === entry) pendingByUrl.delete(entry.url);
}

function recordCompletedAt(url: string, completedAt: number): void {
  // Refresh insertion order so active URLs survive bounded eviction.
  completedAtByUrl.delete(url);
  completedAtByUrl.set(url, completedAt);
  while (completedAtByUrl.size > MAX_COMPLETION_TIMESTAMPS) {
    const oldest = completedAtByUrl.keys().next().value as string | undefined;
    if (oldest === undefined) break;
    completedAtByUrl.delete(oldest);
  }
}

function schedulePump(): void {
  if (running || pumpTimer) return;
  const elapsed = Date.now() - lastCompletedAt;
  const jitter = queueMicrodelayMs();
  const cooldownDelay = Math.max(0, (getExcapperHealth().retryAt ?? 0) - Date.now());
  const spacingDelay = lastCompletedAt === 0 ? 0 : Math.max(0, jitter - elapsed);
  const delay = Math.max(cooldownDelay, spacingDelay);
  if (delay === 0) {
    void pump();
    return;
  }
  pumpTimer = setTimeout(() => {
    pumpTimer = null;
    void pump();
  }, delay);
}

class RetryableExcapperResponseError extends Error {
  constructor(readonly status: number) {
    super(`HTTP ${status} from Excapper`);
    this.name = "RetryableExcapperResponseError";
  }
}

function classifyChallengeEvidence(sample: string): string {
  const lower = sample.toLowerCase();
  if (/cf-chl-|checking your browser|just a moment|cloudflare/.test(lower)) {
    return "browser-challenge";
  }
  if (/captcha/.test(lower)) return "captcha";
  if (/access denied|forbidden/.test(lower)) return "access-denied";
  if (/<html|<!doctype/.test(lower)) return "html-other";
  return sample.trim() ? "non-html" : "empty";
}

async function inspectBoundedErrorResponse(response: Response): Promise<string> {
  const reader = response.body?.getReader();
  if (!reader) return "empty";
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (total < 8_192) {
      const { done, value } = await reader.read();
      if (done) break;
      const remaining = 8_192 - total;
      chunks.push(value.subarray(0, remaining));
      total += Math.min(value.length, remaining);
      if (value.length > remaining) break;
    }
  } finally {
    await reader.cancel().catch(() => undefined);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return classifyChallengeEvidence(new TextDecoder().decode(bytes));
}

async function execute(entry: QueueEntry): Promise<string> {
  const recoveryProbe = true;
  assertExcapperRequestAllowed({ recoveryProbe });
  if (recoveryProbe) setExcapperRecovering(true);
  const timeout = setTimeout(() => entry.controller.abort(), entry.timeoutMs);
  try {
    const profile = pickExcapperBrowserProfile();
    const cookie = [...sessionCookies].map(([name, value]) => `${name}=${value}`).join("; ");
    const response = await fetch(entry.url, {
      headers: {
        "User-Agent": profile.userAgent,
        ...profile.headers,
        "Cache-Control": "no-cache",
        Pragma: "no-cache",
        Referer: "https://excapper.com/",
        "Upgrade-Insecure-Requests": "1",
        ...(cookie ? { Cookie: cookie } : {}),
      },
      redirect: "manual",
      signal: entry.controller.signal,
    });
    statusCounts[String(response.status)] = (statusCounts[String(response.status)] ?? 0) + 1;
    retainSessionCookies(response.headers);
    if (!response.ok) {
      if (response.status === 429 || response.status === 503 || response.status === 403) {
        const bodyClass = await inspectBoundedErrorResponse(response);
        const retryable = response.status === 429 || response.status === 503 ||
          bodyClass === "browser-challenge" || bodyClass === "captcha" ||
          bodyClass === "access-denied";
        const evidenceHeaders = Object.fromEntries(
          ["content-type", "retry-after", "server", "cf-mitigated"]
            .map((name) => [name, response.headers.get(name)])
            .filter(([, value]) => value !== null),
        );
        logger.warn(
          { status: response.status, bodyClass, headers: evidenceHeaders },
          "[EXCAPPER] Bounded upstream error response inspection",
        );
        if (retryable) {
          recordExcapperFailure(
            response.status,
            parseRetryAfter(response.headers.get("retry-after")),
            `HTTP ${response.status} (${bodyClass}) for Excapper request`,
          );
          throw new RetryableExcapperResponseError(response.status);
        }
      }
      throw new Error(`HTTP ${response.status} for ${entry.url}`);
    }
    const html = await response.text();
    if (!isAuthenticExcapperPayload(html, entry.kind)) {
      recordExcapperFailure(200, null, `Invalid 200 ${entry.kind} payload from ${entry.url}`);
      throw new InvalidExcapperPayloadError(entry.kind);
    }
    if (recoveryProbe) recordAuthenticExcapperSuccess();
    lastNetworkSuccessAt = Date.now();
    return html;
  } catch (error) {
    if (
      !(error instanceof RetryableExcapperResponseError) &&
      !(error instanceof InvalidExcapperPayloadError) &&
      (!(error instanceof DOMException && error.name === "AbortError") ||
        entry.activeConsumers > 0)
    ) {
      recordExcapperFailure(0, null, "Excapper network failure");
    }
    throw error;
  } finally {
    clearTimeout(timeout);
    if (recoveryProbe) setExcapperRecovering(false);
  }
}

async function pump(): Promise<void> {
  if (running) return;
  let entry = takeNext();
  while (entry && entry.activeConsumers === 0) {
    pendingByUrl.delete(entry.url);
    entry.reject(new DOMException("Aborted", "AbortError"));
    entry = takeNext();
  }
  if (!entry) return;
  running = entry;
  entry.started = true;
  tierCounts[entry.tier].started++;
  try {
    const html = await execute(entry);
    const completedAt = Date.now();
    recordCompletedAt(entry.url, completedAt);
    entry.resolve(html);
  } catch (error) {
    entry.reject(error);
    if (pendingByUrl.get(entry.url) === entry) pendingByUrl.delete(entry.url);
  } finally {
    tierCounts[entry.tier].completed++;
    if (entry.started && pendingByUrl.get(entry.url) === entry) {
      pendingByUrl.delete(entry.url);
    }
    running = null;
    lastCompletedAt = Date.now();
    schedulePump();
  }
}

function subscribe(entry: QueueEntry, signal: AbortSignal): Promise<string> {
  entry.activeConsumers++;
  return new Promise<string>((resolve, reject) => {
    let settled = false;
    const detach = () => signal.removeEventListener("abort", onAbort);
    const onAbort = () => {
      if (settled) return;
      settled = true;
      detach();
      entry.activeConsumers--;
      if (entry.activeConsumers === 0) {
        if (entry.started) {
          entry.controller.abort();
        } else {
          removeQueuedEntry(entry);
          entry.reject(new DOMException("Aborted", "AbortError"));
        }
      }
      reject(new DOMException("Aborted", "AbortError"));
    };
    if (signal.aborted) {
      onAbort();
      return;
    }
    signal.addEventListener("abort", onAbort, { once: true });
    entry.promise.then(
      (html) => {
        if (settled) return;
        settled = true;
        detach();
        entry.activeConsumers--;
        resolve(html);
      },
      (error) => {
        if (settled) return;
        settled = true;
        detach();
        entry.activeConsumers--;
        reject(error);
      },
    );
  });
}

export class InvalidExcapperPayloadError extends Error {
  readonly status = 200;
  constructor(kind: "directory" | "game") {
    super(`Invalid Excapper ${kind} payload (possible HTML challenge)`);
    this.name = "InvalidExcapperPayloadError";
  }
}

export class ExcapperBatchOnlyError extends Error {
  constructor() {
    super("Only the Excapper directory or a numeric game page may be requested");
    this.name = "ExcapperBatchOnlyError";
  }
}

function canonicalExcapperUrl(
  rawUrl: string,
  kind: "directory" | "game",
): string | null {
  try {
    const url = new URL(rawUrl);
    if (
      url.protocol !== "https:" ||
      (url.hostname !== "excapper.com" && url.hostname !== "www.excapper.com") ||
      url.port !== "" ||
      url.pathname !== "/" ||
      url.hash !== "" ||
      url.username !== "" ||
      url.password !== ""
    ) return null;
    if (kind === "directory") {
      return url.search === "" ? "https://www.excapper.com/" : null;
    }
    if (
      url.searchParams.size !== 2 ||
      url.searchParams.getAll("action").length !== 1 ||
      url.searchParams.get("action") !== "game" ||
      url.searchParams.getAll("id").length !== 1
    ) return null;
    const gameId = url.searchParams.get("id");
    if (!gameId || !/^\d{1,20}$/.test(gameId)) return null;
    return `https://www.excapper.com/?action=game&id=${gameId}`;
  } catch {
    return null;
  }
}

function retainSessionCookies(headers: Headers): void {
  const getSetCookie = (headers as Headers & { getSetCookie?: () => string[] }).getSetCookie;
  const values = typeof getSetCookie === "function" ? getSetCookie.call(headers) : [];
  for (const raw of values) {
    if (raw.length > MAX_COOKIE_BYTES) continue;
    const pair = raw.split(";", 1)[0] ?? "";
    const separator = pair.indexOf("=");
    if (separator <= 0) continue;
    const name = pair.slice(0, separator).trim();
    const value = pair.slice(separator + 1).trim();
    if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name) || /[\r\n;]/.test(value)) continue;
    if (/(?:^|;)\s*max-age=0(?:;|$)/i.test(raw) || value === "") {
      sessionCookies.delete(name);
      continue;
    }
    sessionCookies.delete(name);
    sessionCookies.set(name, value);
    while (sessionCookies.size > MAX_SESSION_COOKIES) {
      const oldest = sessionCookies.keys().next().value as string | undefined;
      if (oldest === undefined) break;
      sessionCookies.delete(oldest);
    }
  }
}

function isAuthenticBatchJson(raw: string): boolean {
  if (!raw.trimStart().startsWith("{") && !raw.trimStart().startsWith("[")) return false;
  try {
    const parsed: unknown = JSON.parse(raw);
    const containers: unknown[] = parsed && typeof parsed === "object" && !Array.isArray(parsed)
        ? ["events", "matches", "liveMatches", "fixtures"]
            .map((key) => (parsed as Record<string, unknown>)[key])
            .filter(Array.isArray)
        : [];
    return containers.some((container) =>
      (container as unknown[]).length > 0 &&
      (container as unknown[]).every((item) => {
        if (!item || typeof item !== "object" || Array.isArray(item)) return false;
        const row = item as Record<string, unknown>;
        const id = row.id ?? row.gameId ?? row.game_id ?? row.matchId;
        const home = row.home ?? row.homeTeam ?? row.team1;
        const away = row.away ?? row.awayTeam ?? row.team2;
        return (typeof id === "string" || typeof id === "number") &&
          typeof home === "string" && home.trim() !== "" &&
          typeof away === "string" && away.trim() !== "";
      }),
    );
  } catch {
    return false;
  }
}

export function isAuthenticExcapperPayload(
  html: string,
  kind: "directory" | "game",
): boolean {
  if (isAuthenticBatchJson(html)) return kind === "directory";
  if (html.length < 1_000) return false;
  const lower = html.toLowerCase();
  if (
    /captcha|cf-chl-|cloudflare ray id|checking your browser|just a moment|access denied/.test(
      lower,
    )
  ) return false;
  if (kind === "directory") {
    return (
      /<tr\b[^>]*\bclass=["'][^"']*\ba_link\b[^"']*["'][^>]*\bgame_id=["']\d+["']/i.test(
        html,
      ) ||
      (lower.includes("excapper") && /<table\b/i.test(html))
    );
  }
  return (
    /tab_content_\d+/i.test(html) &&
    /over\/under\s+\d+(?:\.\d+)?\s+goals/i.test(html) &&
    /(?:\bodds?\b|(?:^|>)\s*over\s*(?:<|$)|(?:^|>)\s*under\s*(?:<|$))/i.test(html)
  );
}

/** Compatibility coalescing helpers; the network owner also dedupes by URL. */
const inFlight = new Map<string, Promise<string>>();
function shared(key: string, fetcher: () => Promise<string>): Promise<string> {
  const existing = inFlight.get(key);
  if (existing) return existing;
  const request = fetcher().finally(() => {
    if (inFlight.get(key) === request) inFlight.delete(key);
  });
  inFlight.set(key, request);
  return request;
}

export function fetchSharedExcapperGamePage(
  gameId: string,
  fetcher: () => Promise<string>,
): Promise<string> {
  if (!/^\d{1,20}$/.test(gameId)) return Promise.reject(new ExcapperBatchOnlyError());
  return shared(`game:${gameId}`, fetcher);
}

export function fetchSharedExcapperDirectory(fetcher: () => Promise<string>): Promise<string> {
  return shared("directory", fetcher);
}

export function fetchExcapperText(
  url: string,
  signal: AbortSignal,
  kind: "directory" | "game",
  timeoutMs = 20_000,
  options: ExcapperRequestOptions = {},
): Promise<string> {
  const canonicalUrl = canonicalExcapperUrl(url, kind);
  if (!canonicalUrl) {
    return Promise.reject(new ExcapperBatchOnlyError());
  }
  // Both accepted host spellings represent one origin. Canonicalizing before
  // queue lookup prevents duplicate requests and keeps the memory-only cookie
  // jar same-origin. redirect:"manual" prevents arbitrary redirect fetching.
  url = canonicalUrl;
  const tier = options.tier ?? (kind === "directory" ? "directory" : "background");
  tierCounts[tier].submitted++;
  const existing = pendingByUrl.get(url);
  if (existing) return subscribe(existing, signal);
  // Fail closed immediately during shared cooldown rather than occupying the
  // serialized queue. A same-URL recovery probe above still coalesces.
  try {
    assertExcapperRequestAllowed({ recoveryProbe: true });
  } catch (error) {
    return Promise.reject(error);
  }
  if (pendingByUrl.size >= MAX_PENDING_REQUESTS) {
    return Promise.reject(
      new Error(`Excapper request queue is full (${MAX_PENDING_REQUESTS} pending requests)`),
    );
  }

  let resolve!: (html: string) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<string>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  // Prevent a queued request whose only subscriber cancels from producing an
  // unhandled rejection before another observer can attach.
  void promise.catch(() => undefined);
  const entry: QueueEntry = {
    url,
    kind,
    tier,
    queuedAt: Date.now(),
    timeoutMs,
    controller: new AbortController(),
    activeConsumers: 0,
    started: false,
    resolve,
    reject,
    promise,
  };
  pendingByUrl.set(url, entry);
  queues[priority(tier)].push(entry);
  const subscription = subscribe(entry, signal);
  schedulePump();
  return subscription;
}

export function getExcapperQueueStats() {
  const now = Date.now();
  const pending = [...pendingByUrl.values()].filter((entry) => !entry.started);
  return {
    pending: pending.length,
    running: running ? 1 : 0,
    oldestPendingAgeMs: pending.length
      ? Math.max(...pending.map((entry) => now - entry.queuedAt))
      : 0,
    runningAgeMs: running ? now - running.queuedAt : 0,
    retainedCompletedBodies: 0,
    retainedCompletionTimestamps: completedAtByUrl.size,
    maxPending: MAX_PENDING_REQUESTS,
    lastNetworkSuccessAt,
    statusCounts: { ...statusCounts },
    tiers: Object.fromEntries(
      Object.entries(tierCounts).map(([tier, counts]) => [
        tier,
        {
          ...counts,
          pending: pending.filter((entry) => entry.tier === tier).length,
          targetCadenceMs:
            tier === "manual" || tier === "live"
              ? 1_500
              : tier === "prematch" || tier === "background"
                ? 60_000
                : 12_000,
        },
      ]),
    ),
  };
}

/**
 * Timestamp at which the shared network owner completed this exact response.
 * Quote consumers use this instead of stamping parsed evidence with a later
 * Date.now(). Only this bounded provenance metadata survives completion.
 */
export function getExcapperResponseObservedAt(url: string): number | null {
  return completedAtByUrl.get(url) ?? null;
}

export function __testOnlyClearSharedExcapperFetches(): void {
  inFlight.clear();
  sessionCookies.clear();
  completedAtByUrl.clear();
  for (const queue of Object.values(queues)) queue.length = 0;
  pendingByUrl.clear();
  running?.controller.abort();
  running = null;
  if (pumpTimer) clearTimeout(pumpTimer);
  pumpTimer = null;
  lastCompletedAt = 0;
  consecutiveUrgent = 0;
  lastNetworkSuccessAt = null;
  for (const key of Object.keys(statusCounts)) delete statusCounts[key];
  for (const counts of Object.values(tierCounts)) {
    counts.submitted = 0;
    counts.started = 0;
    counts.completed = 0;
  }
}