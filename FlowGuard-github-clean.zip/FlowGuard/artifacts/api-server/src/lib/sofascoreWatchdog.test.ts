import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./logger", () => {
  const noop = () => {};
  return {
    logger: {
      debug: noop,
      info: noop,
      warn: noop,
      error: noop,
    },
  };
});

const scannerMocks = vi.hoisted(() => ({
  getWatchlistMatchesForVolume: vi.fn(() => [
    { matchId: "12345", team1: "Home", team2: "Away" },
  ]),
}));

vi.mock("./scanner", () => ({
  getWatchlistMatchesForVolume: scannerMocks.getWatchlistMatchesForVolume,
  setExternalScore: vi.fn(),
  _internalGetMatchStates: vi.fn(() => new Map()),
}));
vi.mock("./controls", () => ({
  getControls: () => ({ scoreWatchdogEnabled: true }),
}));

import {
  getScoreWatchdogStats,
  runScoreWatchdogCycle,
  startScoreWatchdog,
  stopScoreWatchdog,
} from "./sofascoreWatchdog";

describe("Sofascore source disable", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.stubGlobal("fetch", vi.fn());
  });

  afterEach(() => {
    stopScoreWatchdog();
    vi.unstubAllGlobals();
    vi.useRealTimers();
  });

  it("runs only when the coordinator invokes the adapter", async () => {
    const ticksBefore = getScoreWatchdogStats().ticks;

    startScoreWatchdog();
    await vi.advanceTimersByTimeAsync(60_000);
    expect(getScoreWatchdogStats().ticks).toBe(ticksBefore);
    await runScoreWatchdogCycle();

    expect(getScoreWatchdogStats()).toMatchObject({
      upstreamEnabled: false,
      disabledReason: "Disabled by config after repeated HTTP 403 responses",
      ticks: ticksBefore + 1,
    });
    expect(scannerMocks.getWatchlistMatchesForVolume).not.toHaveBeenCalled();
    expect(fetch).not.toHaveBeenCalled();

    await runScoreWatchdogCycle();
    expect(getScoreWatchdogStats().ticks).toBe(ticksBefore + 2);
  });
});