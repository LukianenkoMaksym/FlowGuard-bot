/**
 * Normalized live-state evidence from an Excapper event payload or page.
 *
 * Missing evidence stays null. In particular, this parser never turns an
 * absent score into 0-0 and never marks an event live merely because a payload
 * exists.
 */
export type ExcapperLivePeriod =
  | "first-half"
  | "half-time"
  | "second-half"
  | "extra-time"
  | "penalties"
  | "finished";

export interface ExcapperParsedData {
  score: { home: number; away: number } | null;
  period: ExcapperLivePeriod | null;
  minute: number | null;
  isLive: boolean;
  /** At least one explicit score, period, minute, live, or terminal marker was found. */
  rawFound: boolean;
}

const MAX_DEPTH = 8;
const MAX_NODES = 500;
const MAX_TEXT_BYTES = 200_000;
const IGNORED_BRANCH = /^(?:odds?|markets?|prices?|transactions?|bets?|history|results?)$/i;
const SCORE_KEYS = ["score", "currentScore", "liveScore"] as const;
const PERIOD_KEYS = ["period", "matchPeriod", "matchTime", "status", "state", "phase"] as const;
const MINUTE_KEYS = ["elapsed", "minute", "matchMinute", "matchTime", "clock"] as const;

/** Disabled HTML markup (including script assignments) is not live evidence. */
export function stripExcapperHtmlComments(html: string): string {
  return html.replace(/<!--[\s\S]*?(?:-->|$)/g, "");
}

interface Evidence {
  score: ExcapperParsedData["score"];
  period: ExcapperLivePeriod | null;
  minute: number | null;
  explicitLive: boolean;
  rawFound: boolean;
  quality: number;
}

const emptyEvidence = (): Evidence => ({
  score: null,
  period: null,
  minute: null,
  explicitLive: false,
  rawFound: false,
  quality: 0,
});

function safeNumber(value: unknown): number | null {
  const parsed = typeof value === "number"
    ? value
    : typeof value === "string" && /^\s*\d{1,3}\s*$/.test(value)
      ? Number(value.trim())
      : NaN;
  return Number.isInteger(parsed) && parsed >= 0 && parsed <= 999 ? parsed : null;
}

function parseScoreString(value: unknown): ExcapperParsedData["score"] {
  if (typeof value !== "string") return null;
  const match = /^\s*(\d{1,3})\s*[-:]\s*(\d{1,3})\s*$/.exec(value);
  if (!match) return null;
  return { home: Number(match[1]), away: Number(match[2]) };
}

function parseScore(value: unknown): ExcapperParsedData["score"] {
  const textScore = parseScoreString(value);
  if (textScore) return textScore;
  if (!value || typeof value !== "object") return null;
  const source = value as Record<string, unknown>;
  const home = safeNumber(source.home ?? source.h ?? source.homeScore ?? source[0]);
  const away = safeNumber(source.away ?? source.a ?? source.awayScore ?? source[1]);
  return home !== null && away !== null ? { home, away } : null;
}

function parseMinute(value: unknown): number | null {
  if (typeof value !== "number" && typeof value !== "string") return null;
  const match = /^\s*(\d{1,3})(?:\s*\+\s*(\d{1,2}))?\s*(?:'|min|mins|minute|мин(?:ута|уты|ут)?)?\s*$/iu
    .exec(String(value));
  if (!match) return null;
  const minute = Number(match[1]) + Number(match[2] ?? 0);
  return minute >= 0 && minute <= 130 ? minute : null;
}

function parsePeriod(value: unknown): ExcapperLivePeriod | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const raw = String(value).trim().toLocaleLowerCase();
  if (!raw) return null;
  const normalized = raw.replace(/[_–—]+/g, "-").replace(/\s+/g, " ");
  if (/(?:\b(?:finished|final|ended|full[- ]?time|ft)\b|заверш[её]н|окончен)/iu.test(normalized)) {
    return "finished";
  }
  if (/(?:\b(?:penalties|penalty|pens)\b|пенальти)/iu.test(normalized)) return "penalties";
  if (/(?:\b(?:extra[- ]?time|aet|et)\b|дополнительн)/iu.test(normalized)) return "extra-time";
  if (/(?:\b(?:half[- ]?time|halftime|ht|break|interval)\b|перерыв)/iu.test(normalized)) {
    return "half-time";
  }
  if (/(?:\b(?:second[- ]?half|2nd[- ]?half|2h)\b|2-й тайм|второй тайм)/iu.test(normalized)) {
    return "second-half";
  }
  if (/^(?:2nd|second)$/iu.test(normalized)) return "second-half";
  if (/(?:\b(?:first[- ]?half|1st[- ]?half|1h)\b|1-й тайм|первый тайм)/iu.test(normalized)) {
    return "first-half";
  }
  if (/^(?:1st|first)$/iu.test(normalized)) return "first-half";
  return null;
}

function isExplicitLive(value: unknown): boolean {
  return (typeof value === "string" || typeof value === "boolean") &&
    (value === true || /^(?:live|in[- ]?play|playing|в эфире|идет|идёт)$/iu.test(String(value).trim()));
}

function ownEvidence(value: Record<string, unknown>): Evidence {
  const evidence = emptyEvidence();
  const directHome = safeNumber(value.homeScore);
  const directAway = safeNumber(value.awayScore);
  if (directHome !== null && directAway !== null) {
    evidence.score = { home: directHome, away: directAway };
    evidence.quality += 5;
  } else {
    for (const key of SCORE_KEYS) {
      const parsed = parseScore(value[key]);
      if (parsed) {
        evidence.score = parsed;
        evidence.quality += key === "score" ? 4 : 5;
        break;
      }
    }
    if (!evidence.score) evidence.score = parseScore(value.scores);
  }
  for (const key of PERIOD_KEYS) {
    const period = parsePeriod(value[key]);
    if (period) {
      evidence.period = period;
      evidence.quality += 3;
      break;
    }
  }
  for (const key of MINUTE_KEYS) {
    const minute = parseMinute(value[key]);
    if (minute !== null) {
      evidence.minute = minute;
      evidence.quality += 3;
      break;
    }
  }
  evidence.explicitLive = Object.entries(value)
    .some(([key, candidate]) => /^(?:isLive|live|activity|status|state)$/i.test(key) && isExplicitLive(candidate));
  if (evidence.explicitLive) evidence.quality += 3;
  evidence.rawFound = Boolean(
    evidence.score || evidence.period || evidence.minute !== null || evidence.explicitLive,
  );
  return evidence;
}

function embeddedEvidence(text: string): Evidence {
  const evidence = emptyEvidence();
  const bounded = text.slice(0, MAX_TEXT_BYTES);
  const scoreMatch =
    /(?:data-(?:current-)?score|class=["'][^"']*\bscore\b[^"']*["'])\s*(?:=|>)\s*["']?\s*(\d{1,3})\s*[-:]\s*(\d{1,3})/iu.exec(bounded);
  if (scoreMatch) {
    evidence.score = { home: Number(scoreMatch[1]), away: Number(scoreMatch[2]) };
    evidence.quality += 4;
  }
  const periodMatch =
    /data-(?:period|status)\s*=\s*["']([^"']{1,40})["']/iu.exec(bounded);
  if (periodMatch) {
    evidence.period = parsePeriod(periodMatch[1]);
    if (evidence.period) evidence.quality += 3;
  }
  const minuteMatch =
    /data-(?:elapsed|minute)\s*=\s*["'](\d{1,3}(?:\s*\+\s*\d{1,2})?)["']/iu.exec(bounded);
  if (minuteMatch) {
    evidence.minute = parseMinute(minuteMatch[1]);
    if (evidence.minute !== null) evidence.quality += 3;
  }
  evidence.explicitLive =
    /data-(?:live|status)\s*=\s*["'](?:true|live|in[- ]?play|playing)["']/iu.test(bounded);
  if (evidence.explicitLive) evidence.quality += 3;
  evidence.rawFound = Boolean(
    evidence.score || evidence.period || evidence.minute !== null || evidence.explicitLive,
  );
  return evidence;
}

/** Extract bounded JSON object literals from script-backed dynamic pages. */
function embeddedJsonValues(text: string): unknown[] {
  const bounded = text.slice(0, MAX_TEXT_BYTES);
  const values: unknown[] = [];
  try {
    values.push(JSON.parse(bounded));
    return values;
  } catch {
    // HTML and script assignments are expected to need object extraction.
  }
  let start = -1;
  let depth = 0;
  let quote = "";
  let escaped = false;
  for (let index = 0; index < bounded.length && values.length < 20; index++) {
    const char = bounded[index]!;
    if (quote) {
      if (escaped) escaped = false;
      else if (char === "\\") escaped = true;
      else if (char === quote) quote = "";
      continue;
    }
    if (char === `"` || char === `'`) {
      quote = char;
      continue;
    }
    if (char === "{") {
      if (depth === 0) start = index;
      depth++;
    } else if (char === "}" && depth > 0) {
      depth--;
      if (depth === 0 && start >= 0) {
        try {
          values.push(JSON.parse(bounded.slice(start, index + 1)));
        } catch {
          // Not every JavaScript object literal is valid JSON.
        }
        start = -1;
      }
    }
  }
  return values;
}

function better(left: Evidence, right: Evidence): Evidence {
  if (!left.rawFound) return right;
  if (!right.rawFound) return left;
  const leftComplete = Number(Boolean(left.score)) + Number(Boolean(left.period)) +
    Number(left.minute !== null) + Number(left.explicitLive);
  const rightComplete = Number(Boolean(right.score)) + Number(Boolean(right.period)) +
    Number(right.minute !== null) + Number(right.explicitLive);
  return rightComplete > leftComplete ||
    (rightComplete === leftComplete && right.quality > left.quality) ? right : left;
}

export function parseExcapperLiveState(rawData: unknown): ExcapperParsedData {
  if (rawData === null || rawData === undefined) {
    return { score: null, period: null, minute: null, isLive: false, rawFound: false };
  }
  // Strip before *both* attribute matching and JSON extraction: a commented
  // script must not become an explicit period/clock via embeddedJsonValues.
  const text = typeof rawData === "string" ? stripExcapperHtmlComments(rawData) : null;
  let best = text !== null ? embeddedEvidence(text) : emptyEvidence();
  const seen = new WeakSet<object>();
  let visited = 0;
  let terminalFound = false;
  const hasPotentialEvidence = (
    value: unknown,
    depth = 0,
    localSeen = new WeakSet<object>(),
  ): boolean => {
    if (!value || typeof value !== "object" || depth > 4 || localSeen.has(value)) return false;
    localSeen.add(value);
    if (Array.isArray(value)) return value.some((item) => hasPotentialEvidence(item, depth + 1, localSeen));
    const record = value as Record<string, unknown>;
    if (ownEvidence(record).rawFound) return true;
    return Object.entries(record).some(([key, child]) =>
      !IGNORED_BRANCH.test(key) && hasPotentialEvidence(child, depth + 1, localSeen)
    );
  };
  const visit = (value: unknown, depth: number): void => {
    if (!value || typeof value !== "object" || depth > MAX_DEPTH || visited >= MAX_NODES) return;
    if (seen.has(value)) return;
    seen.add(value);
    visited++;
    if (Array.isArray(value)) {
      // A payload can contain a directory of several fixtures. Without a
      // requested fixture identity, selecting the first/richest one would bind
      // another match. A single evidence-bearing item remains unambiguous.
      if (value.filter((item) => hasPotentialEvidence(item)).length > 1) return;
      for (const item of value) visit(item, depth + 1);
      return;
    }
    const record = value as Record<string, unknown>;
    const own = ownEvidence(record);
    if (own.period === "finished") terminalFound = true;
    best = better(best, own);
    for (const [key, child] of Object.entries(record)) {
      if (!IGNORED_BRANCH.test(key)) visit(child, depth + 1);
    }
  };
  visit(rawData, 0);
  if (text !== null) {
    for (const embedded of embeddedJsonValues(text)) visit(embedded, 0);
  }

  if (terminalFound) {
    best = { ...best, period: "finished", rawFound: true };
  }
  const terminal = best.period === "finished";
  const periodLive = best.period !== null && !terminal;
  const isLive = !terminal && (best.explicitLive || periodLive || best.minute !== null);
  return {
    score: best.score,
    period: best.period,
    minute: best.minute,
    isLive,
    rawFound: best.rawFound,
  };
}