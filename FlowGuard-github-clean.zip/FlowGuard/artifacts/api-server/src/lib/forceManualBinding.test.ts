import { mkdir as fsMkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const audit = vi.hoisted(() => vi.fn());
vi.mock("./bindingDecisionAudit", async (importOriginal) => ({
  ...await importOriginal<typeof import("./bindingDecisionAudit")>(),
  recordBindingDecision: audit,
}));

import {
  __testOnlyGetManualExcapperBindingCache,
  __testOnlyGetManualBindingEpoch,
  __testOnlyResetExcapperBindingDiagnostics,
  __testOnlyResetManualExcapperBindingCache,
  __testOnlyRecordExcapperBindingDiagnostic,
  __testOnlySetBindingBlockDependencies,
  forceManualExcapperBinding,
  getExcapperBindingDiagnostic,
  initManualExcapperBindingBlocks,
  resetManualExcapperBinding,
  withExcapperBindingDiagnostics,
} from "./excapper";
import { getRuntimeAudit } from "./runtimeAudit";
import {
  __testOnlySetManualBindingsFile,
  __testOnlySetManualBindingsPaths,
  getPersistedManualBindings,
  initManualBindingsStore,
  savePersistedManualBinding,
} from "./manualBindingsStore";

describe("force manual binding persistence", () => {
  let dir: string;
  let storePath: string;

  beforeEach(async () => {
    dir = await mkdtemp(path.join(os.tmpdir(), "force-binding-"));
    storePath = path.join(dir, "manual-bindings.json");
    __testOnlySetManualBindingsFile(storePath);
    __testOnlyResetManualExcapperBindingCache();
    __testOnlyResetExcapperBindingDiagnostics();
    __testOnlySetBindingBlockDependencies({
      load: async () => [],
      reset: async () => undefined,
      remove: async () => undefined,
    });
    audit.mockReset();
  });

  afterEach(async () => {
    __testOnlySetBindingBlockDependencies();
    await rm(dir, { recursive: true, force: true });
  });

  it("binds a stale displayed source id without a discovery candidate and reloads it", async () => {
    const binding = await forceManualExcapperBinding({
      nowgoalId: "710001",
      excapperId: "91001",
      candidateId: "obsolete-opaque-review-handle",
      force: true,
      source: { team1: "Alpha", team2: "Beta", league: "League" },
    } as Parameters<typeof forceManualExcapperBinding>[0] & { force: true });

    expect(binding).toMatchObject({
      nowgoalId: "710001", excapperId: "91001", status: "Verified", autoBound: false,
    });
    expect(audit).toHaveBeenCalledWith("710001", expect.objectContaining({
      action: "bind", mode: "manual_override",
    }));
    expect(JSON.parse(await readFile(storePath, "utf8")).bindings).toHaveLength(1);

    __testOnlyResetManualExcapperBindingCache();
    __testOnlyResetExcapperBindingDiagnostics();
    __testOnlySetManualBindingsFile(storePath);
    await initManualExcapperBindingBlocks();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: "710001", gameId: "91001" }),
    ]);
    expect(getExcapperBindingDiagnostic("710001")).toMatchObject({
      status: "bound_pending",
      candidateExcapperId: "91001",
      bindingMode: "manual_override",
    });
  });

  it("persists FORCE_MANUAL verification without treating an opaque ref as a game id", async () => {
    const binding = await forceManualExcapperBinding({
      nowgoalId: "710002",
      candidateId: "opaque_candidate_reference_not_a_game_id",
      source: { team1: "Shown Home", team2: "Shown Away", league: "Shown League" },
    });
    expect(binding.excapperId).toBe("FORCE_MANUAL");
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
    expect(getExcapperBindingDiagnostic("710002")).toMatchObject({
      status: "identity_only",
      candidateExcapperId: null,
      bindingMode: "manual_override",
    });
    __testOnlyResetManualExcapperBindingCache();
    __testOnlyResetExcapperBindingDiagnostics();
    __testOnlySetManualBindingsFile(storePath);
    await initManualExcapperBindingBlocks();
    expect(getExcapperBindingDiagnostic("710002")).toMatchObject({
      status: "identity_only", candidateExcapperId: null,
      bindingDecision: { status: "manual", chosenId: null },
    });
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
    const reset = vi.fn(async () => undefined);
    __testOnlySetBindingBlockDependencies({ reset });
    await resetManualExcapperBinding("710002");
    expect(reset).toHaveBeenCalledWith([{ diagnosticId: "710002", gameId: "*" }], expect.any(Array), "710002");
    expect(reset).toHaveBeenCalledWith(
      [{ diagnosticId: "710002", gameId: "*" }],
      expect.arrayContaining([expect.objectContaining({
        decision: expect.objectContaining({ source: expect.objectContaining({ id: null }) }),
      })]),
      "710002",
    );
    __testOnlyResetManualExcapperBindingCache();
    __testOnlySetManualBindingsFile(storePath);
    await initManualExcapperBindingBlocks();
    expect(getExcapperBindingDiagnostic("710002").status).not.toBe("bound_verified");
  });

  it("accepts numeric ids and clears a prior fetchable binding on FORCE_MANUAL replacement", async () => {
    await forceManualExcapperBinding({
      nowgoalId: 710005,
      excapperId: 91005,
      source: { team1: "Old Home", team2: "Old Away", league: "Old League" },
    });
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([
      expect.objectContaining({ matchId: "710005", gameId: "91005" }),
    ]);

    const replacement = await forceManualExcapperBinding({
      nowgoalId: 710005,
      candidateId: "stale-opaque-ref",
      source: { team1: "New Home", team2: "New Away", league: "New League" },
    });
    expect(replacement.excapperId).toBe("FORCE_MANUAL");
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
    expect(__testOnlyGetManualBindingEpoch("710005")).toBeGreaterThanOrEqual(2);
  });

  it("rejects nonnumeric source IDs and duplicate ownership without replacing the accepted pair", async () => {
    await expect(forceManualExcapperBinding({
      nowgoalId: "710021", excapperId: "opaque-candidate-ref",
    })).rejects.toThrow("numeric Excapper game ID");
    await forceManualExcapperBinding({
      nowgoalId: "710021", excapperId: "91021",
      source: { team1: "Alpha", team2: "Beta", league: "League" },
    });
    await expect(forceManualExcapperBinding({
      nowgoalId: "710022", excapperId: "91021",
    })).rejects.toThrow("already bound to another NowGoal fixture");
    expect(getPersistedManualBindings()).toEqual([
      expect.objectContaining({ nowgoalId: "710021", excapperId: "91021" }),
    ]);
    expect(audit).toHaveBeenCalledTimes(1);
  });

  it.each(["36109446", "FORCE_MANUAL"])(
    "keeps durable manual decision authoritative after runtime retirement and hydration overlay (%s)",
    async (excapperId) => {
      await forceManualExcapperBinding({
        nowgoalId: "3094867",
        ...(excapperId === "FORCE_MANUAL" ? {} : { excapperId }),
        source: { team1: "AD Picuiense", team2: "AD Guarabira", league: "Brazilian Paraibano Matches" },
      });
      __testOnlyResetManualExcapperBindingCache();
      __testOnlyResetExcapperBindingDiagnostics();
      __testOnlyRecordExcapperBindingDiagnostic("3094867", "hydrated");
      const chosenId = excapperId === "FORCE_MANUAL" ? null : excapperId;
      expect(getExcapperBindingDiagnostic("3094867")).toMatchObject({
        status: excapperId === "FORCE_MANUAL" ? "identity_only" : "bound_pending",
        bindingMode: "manual_override", candidateExcapperId: chosenId,
        bindingDecision: {
          status: "manual", chosenId,
          candidateAttempt: { status: "unbound", reason: "hydrated", chosenId: null },
        },
      });
      const watchlist = withExcapperBindingDiagnostics({
        entries: [{ matchId: "3094867", signature: "id:3094867" }],
      });
      const runtime = getRuntimeAudit({
        watchlist: [],
        scanner: [{ nowGoalMatchId: "3094867", hasMeta: true, matchName: "Picuiense vs Desportiva Guarabira PB",
          leagueName: "Brazil Campeonato Paraibano 2", score: null, elapsedTime: null,
          matchPhase: "Live", excapperMatchId: null }],
      });
      expect(runtime.matches[0]?.status).toBe("Verified");
      expect(runtime.matches[0]?.bindingDecision).toEqual(watchlist.entries[0]?.excapperBinding.bindingDecision);
      __testOnlyRecordExcapperBindingDiagnostic("3094867", "score_period_conflict");
      expect(getExcapperBindingDiagnostic("3094867").bindingDecision).toMatchObject({
        status: "manual", chosenId,
      });
    },
  );

  it("a wildcard reset suppresses a stale FORCE_MANUAL file until explicit confirmation", async () => {
    await forceManualExcapperBinding({ nowgoalId: "710012" });
    __testOnlySetBindingBlockDependencies({
      load: async () => [{ diagnosticId: "710012", gameId: "*" }],
    });
    // Even initialization in an already-populated process must obey the reset.
    await initManualExcapperBindingBlocks();
    expect(getExcapperBindingDiagnostic("710012").status).not.toBe("bound_verified");
    const remove = vi.fn(async () => undefined);
    __testOnlySetBindingBlockDependencies({ remove });
    await forceManualExcapperBinding({ nowgoalId: "710012" });
    expect(remove).toHaveBeenCalledWith("710012", "*");
    expect(getExcapperBindingDiagnostic("710012").status).toBe("identity_only");
  });

  it("durably unblocks an explicitly rebound pair and restores the block if audit fails", async () => {
    const removeBlock = vi.fn(async () => undefined);
    const restoreBlock = vi.fn(async () => undefined);
    __testOnlySetBindingBlockDependencies({
      load: async () => [{ diagnosticId: "710009", gameId: "91009" }],
      remove: removeBlock,
      persist: restoreBlock,
    });
    __testOnlyResetManualExcapperBindingCache();
    await initManualExcapperBindingBlocks();

    await forceManualExcapperBinding({
      nowgoalId: "710009", excapperId: "91009",
    });
    expect(removeBlock).toHaveBeenCalledWith("710009", "91009");
    expect(restoreBlock).not.toHaveBeenCalled();

    // Recreate the reset state, then prove a failed rebind cannot silently
    // remove its durable protection.
    __testOnlySetBindingBlockDependencies({
      load: async () => [{ diagnosticId: "710009", gameId: "91009" }],
      remove: removeBlock,
      persist: restoreBlock,
    });
    __testOnlyResetManualExcapperBindingCache();
    await initManualExcapperBindingBlocks();
    audit.mockImplementationOnce(() => { throw new Error("audit failed"); });
    await expect(forceManualExcapperBinding({
      nowgoalId: "710009", excapperId: "91009",
    })).rejects.toThrow("audit failed");
    expect(restoreBlock).toHaveBeenCalledWith("710009", "91009");
  });

  it("does not change runtime or audit when the disk save fails", async () => {
    const obstruction = path.join(dir, "not-a-directory");
    await writeFile(obstruction, "x");
    __testOnlySetManualBindingsFile(path.join(obstruction, "manual-bindings.json"));
    await expect(forceManualExcapperBinding({
      nowgoalId: "710003", excapperId: "91003",
    })).rejects.toThrow();
    expect(audit).not.toHaveBeenCalled();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });

  it("rolls back the durable override when audit admission fails", async () => {
    audit.mockImplementationOnce(() => { throw new Error("audit disk unavailable"); });
    await expect(forceManualExcapperBinding({
      nowgoalId: "710004", excapperId: "91004",
    })).rejects.toThrow("audit disk unavailable");
    expect(getPersistedManualBindings()).toEqual([]);
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
    expect(JSON.parse(await readFile(storePath, "utf8")).bindings).toEqual([]);
  });

  it("serializes duplicate submits so a failed first rollback cannot erase the second", async () => {
    audit.mockImplementationOnce(() => { throw new Error("first audit failed"); });
    const first = forceManualExcapperBinding({
      nowgoalId: "710006", excapperId: "91006",
    });
    const second = forceManualExcapperBinding({
      nowgoalId: "710006", excapperId: "91007",
    });
    await expect(first).rejects.toThrow("first audit failed");
    await expect(second).resolves.toMatchObject({ excapperId: "91007" });
    expect(getPersistedManualBindings()).toEqual([
      expect.objectContaining({ nowgoalId: "710006", excapperId: "91007" }),
    ]);
  });

  it("keeps a durable reset authoritative when positive JSON cleanup fails", async () => {
    await forceManualExcapperBinding({
      nowgoalId: "710008", excapperId: "91008",
    });
    await rm(dir, { recursive: true, force: true });
    await writeFile(dir, "obstruction");

    await expect(resetManualExcapperBinding("710008")).rejects.toThrow();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);

    await rm(dir, { force: true });
    await writeFile(storePath, JSON.stringify({ bindings: [{
      nowgoalId: "710008", excapperId: "91008", boundAt: new Date().toISOString(),
      status: "Verified", autoBound: false,
    }] }), { flag: "w" }).catch(async () => {
      const { mkdir } = await import("node:fs/promises");
      await mkdir(dir, { recursive: true });
      await writeFile(storePath, JSON.stringify({ bindings: [{
        nowgoalId: "710008", excapperId: "91008", boundAt: new Date().toISOString(),
        status: "Verified", autoBound: false,
      }] }));
    });
    __testOnlyResetManualExcapperBindingCache();
    __testOnlySetManualBindingsFile(storePath);
    __testOnlySetBindingBlockDependencies({
      load: async () => [{ diagnosticId: "710008", gameId: "91008" }],
    });
    await initManualExcapperBindingBlocks();
    expect(__testOnlyGetManualExcapperBindingCache()).toEqual([]);
  });

  it("loads only valid durable records", async () => {
    await writeFile(storePath, JSON.stringify({
      bindings: [
        { nowgoalId: "1", excapperId: "2", boundAt: new Date().toISOString(),
          status: "Verified", autoBound: false },
        { nowgoalId: "bad" },
      ],
    }));
    await initManualBindingsStore();
    expect(getPersistedManualBindings()).toHaveLength(1);
    await savePersistedManualBinding({
      nowgoalId: "3", excapperId: "4", boundAt: new Date().toISOString(),
      status: "Verified", autoBound: true,
    });
    expect(JSON.parse(await readFile(storePath, "utf8")).bindings)
      .toEqual(expect.arrayContaining([
        expect.objectContaining({ nowgoalId: "1" }),
        { nowgoalId: "bad" },
        expect.objectContaining({ nowgoalId: "3", autoBound: true }),
      ]));
  });

  it("migrates legacy records once and preserves automatic records and extra fields", async () => {
    const canonical = path.join(dir, "data", "active_bindings.json");
    const legacy = path.join(dir, "config", "manual-bindings.json");
    await fsMkdir(path.dirname(legacy), { recursive: true });
    await writeFile(legacy, JSON.stringify({ bindings: [{
      nowgoalId: "1", excapperId: "2", boundAt: new Date().toISOString(),
      status: "Verified", autoBound: true, signature: "id:1", confidence: 0.75,
    }] }));
    __testOnlySetManualBindingsPaths(canonical, legacy);

    await initManualBindingsStore();

    expect(getPersistedManualBindings()).toEqual([
      expect.objectContaining({ nowgoalId: "1", autoBound: true, confidence: 0.75 }),
    ]);
    expect(JSON.parse(await readFile(canonical, "utf8")).bindings[0])
      .toMatchObject({ autoBound: true, confidence: 0.75 });
    expect(JSON.parse(await readFile(legacy, "utf8")).bindings).toHaveLength(1);

    await rm(legacy);
    __testOnlySetManualBindingsPaths(canonical, legacy);
    await initManualBindingsStore();
    expect(getPersistedManualBindings()).toEqual([
      expect.objectContaining({ nowgoalId: "1", autoBound: true, confidence: 0.75 }),
    ]);
  });

  it("gives the canonical store precedence over a different legacy file", async () => {
    const canonical = path.join(dir, "data", "active_bindings.json");
    const legacy = path.join(dir, "config", "manual-bindings.json");
    await fsMkdir(path.dirname(canonical), { recursive: true });
    await fsMkdir(path.dirname(legacy), { recursive: true });
    const record = (nowgoalId: string, excapperId: string) => ({
      nowgoalId, excapperId, boundAt: new Date().toISOString(),
      status: "Verified", autoBound: false,
    });
    await writeFile(canonical, JSON.stringify({ bindings: [record("canonical", "10")] }));
    await writeFile(legacy, JSON.stringify({ bindings: [record("legacy", "20")] }));
    __testOnlySetManualBindingsPaths(canonical, legacy);

    await initManualBindingsStore();

    expect(getPersistedManualBindings()).toEqual([
      expect.objectContaining({ nowgoalId: "canonical", excapperId: "10" }),
    ]);
  });

  it("serializes initialization with concurrent saves without losing either record", async () => {
    const canonical = path.join(dir, "data", "active_bindings.json");
    const legacy = path.join(dir, "config", "manual-bindings.json");
    await fsMkdir(path.dirname(legacy), { recursive: true });
    await writeFile(legacy, JSON.stringify({ bindings: [{
      nowgoalId: "legacy", excapperId: "1", boundAt: new Date().toISOString(),
      status: "Verified", autoBound: false,
    }] }));
    __testOnlySetManualBindingsPaths(canonical, legacy);
    const init = initManualBindingsStore();
    const save = savePersistedManualBinding({
      nowgoalId: "new", excapperId: "2", boundAt: new Date().toISOString(),
      status: "Verified", autoBound: true,
    });

    await Promise.all([init, save]);

    expect(JSON.parse(await readFile(canonical, "utf8")).bindings)
      .toEqual(expect.arrayContaining([
        expect.objectContaining({ nowgoalId: "legacy" }),
        expect.objectContaining({ nowgoalId: "new", autoBound: true }),
      ]));
  });

  it("does not replace in-memory records when canonical initialization fails", async () => {
    const canonical = path.join(dir, "data", "active_bindings.json");
    __testOnlySetManualBindingsFile(canonical);
    await savePersistedManualBinding({
      nowgoalId: "kept", excapperId: "1", boundAt: new Date().toISOString(),
      status: "Verified", autoBound: false,
    });
    await writeFile(canonical, "{broken json");

    await expect(initManualBindingsStore()).rejects.toThrow();
    expect(getPersistedManualBindings()).toEqual([
      expect.objectContaining({ nowgoalId: "kept" }),
    ]);
  });
});