import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { PgDialect } from "drizzle-orm/pg-core";

const store = vi.hoisted(() => ({
  rows: [] as Record<string, any>[], writes: 0, failWrite: false, primaryOk: true, sends: 0,
  legacy: [] as Record<string, any>[],
  subscriber: false, subscriberOk: true, primarySends: 0,
  final: null as null | { state: number | null; homeScore: number; awayScore: number; isLive: boolean; clockLabel: null },
}));
vi.mock("@workspace/db", async () => {
  const schema = await import("../../../../lib/db/src/schema");
  return {
    ...schema,
    db: {
      insert: () => ({
        values: (row: Record<string, any>) => ({
          onConflictDoNothing: async () => {
            store.writes++;
            if (store.failWrite) throw new Error("db unavailable");
            if (!store.rows.some((r) => r.deliveryKey === row.deliveryKey)) {
              store.rows.push({ ...row, id: store.rows.length + 1, createdAt: new Date() });
            }
          },
        }),
      }),
      select: () => ({ from: (table: unknown) => ({
        where: (condition: unknown) => ({
          then: (yes: (rows: Record<string, any>[]) => unknown) =>
            Promise.resolve(table === schema.signalHistoryEntriesTable
              ? store.rows.filter((r) => r.status === "PENDING") : []).then(yes),
          orderBy: async () => {
            if (table !== schema.anomaliesTable) return [];
            const params = condition
              ? new PgDialect().sqlToQuery(condition as Parameters<PgDialect["sqlToQuery"]>[0]).params
              : [];
            return store.legacy.filter((row) => !params.some((p) => p === "ODDS_DROP" || p === "SMART_MONEY") ||
              params.includes(row.anomalyType));
          },
        }),
        orderBy: async () => table === schema.signalHistoryEntriesTable ? [...store.rows] : [],
      }) }),
      update: () => ({ set: (values: Record<string, any>) => ({
        where: async () => {
          if (store.failWrite) throw new Error("db unavailable");
          const row = store.rows.find((r) => r.status === (values.status === "PENDING" ? "AWAITING_ACK" : "PENDING"));
          if (row) Object.assign(row, values);
        },
      }) }),
    },
  };
});
vi.mock("./scanner", () => ({ fetchFreshScoreNow: async () => store.final }));
vi.mock("./targetLeagues", () => ({ matchTargetLeague: () => true }));
vi.mock("./controls", () => ({ getControls: () => ({ alertsMuted: false }) }));
vi.mock("./telegramBroadcastRecipients.json", () => ({ default: { chatIds: [] } }));
vi.mock("./telegramSubscribers", () => ({
  ensureSubscribersLoaded: async () => {}, listSubscriberChatIds: () => store.subscriber ? ["subscriber"] : [], removeSubscriber: async () => true,
}));
vi.mock("./logger", () => ({ logger: { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() } }));

let sendTelegram: typeof import("./telegram").sendTelegram;
let resolveDeliveredSignals: typeof import("./deliveredSignals").resolveDeliveredSignals;
let getAnomalyHistory: typeof import("./winRate").getAnomalyHistory;
let formatUnifiedAlert: typeof import("./unifiedAlert").formatUnifiedAlert;
const card = (side: "OVER" | "UNDER") => formatUnifiedAlert({
  source: "odds-radar", radarMovement: { type: "drop", from: 2, to: 1.8, percent: 10 },
  matchId: "123456", home: "Home FC", away: "Away FC", league: "Any League",
  isLive: true, homeScore: 1, awayScore: 0, minute: "35", side, line: 2.5,
  timeline: [], link: "https://www.nowgoal26.com/match/live-123456",
});
const oneX2Card = (outcome: "HOME" | "AWAY", type: "drop" | "rise" | "revert" = "drop") => formatUnifiedAlert({
  source: "odds-radar", market: { kind: "1X2", outcome },
  radarMovement: { type, from: type === "rise" ? 1.8 : 2, to: type === "rise" ? 2 : 1.8 },
  ...(type === "revert" ? { radarBooks: [{
    cid: "8", bookmaker: "Bet365", type: "revert" as const,
    baseline: 1.8, peak: 2.2, from: 2, to: 1.8, percent: -10,
    durationMs: 60_000, quoteAt: Date.parse("2026-09-25T12:32:00Z"),
    history: [
      { ts: Date.parse("2026-09-25T12:30:00Z"), odds: 1.8 },
      { ts: Date.parse("2026-09-25T12:31:00Z"), odds: 2.2 },
      { ts: Date.parse("2026-09-25T12:32:00Z"), odds: 1.8 },
    ],
  }] } : {}),
  matchId: "654321", home: "Hosts FC", away: "Visitors FC", league: "Any League",
  isLive: true, homeScore: 0, awayScore: 0, minute: "67", side: "OVER", line: 2.5,
  bookmaker: "Bet365", isRepeat: true, alertAt: Date.parse("2026-09-25T12:34:00Z"),
  timeline: [], oneX2Timeline: [
    { ts: Date.parse("2026-09-25T12:31:00Z"), odds: 2 },
    { ts: Date.parse("2026-09-25T12:32:00Z"), odds: 1.8 },
  ], link: "https://www.nowgoal26.com/match/live-654321",
});

beforeAll(async () => {
  vi.stubEnv("TELEGRAM_TOKEN", "test-token");
  vi.stubEnv("TELEGRAM_CHAT_ID", "primary");
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("REPLIT_DEPLOYMENT", "1");
  ({ sendTelegram } = await import("./telegram"));
  ({ resolveDeliveredSignals } = await import("./deliveredSignals"));
  ({ getAnomalyHistory } = await import("./winRate"));
  ({ formatUnifiedAlert } = await import("./unifiedAlert"));
});
beforeEach(() => {
  store.rows = []; store.writes = 0; store.failWrite = false; store.primaryOk = true;
  store.sends = 0; store.final = null; store.legacy = [];
  store.subscriber = false; store.subscriberOk = true; store.primarySends = 0;
  vi.stubGlobal("fetch", vi.fn(async (_url: unknown, init?: RequestInit) => {
    store.sends++;
    const chatId = JSON.parse(String(init?.body)).chat_id;
    if (chatId === "primary") store.primarySends++;
    return new Response("{}", { status: chatId === "primary"
      ? store.primaryOk ? 200 : 403 : store.subscriberOk ? 200 : 500 });
  }));
});

describe("confirmed Telegram signal history", () => {
  it("records a multi-book market using the strongest real movement, then settles HOME", async () => {
    const rendered = formatUnifiedAlert({
      source: "odds-radar", market: { kind: "1X2", outcome: "HOME" },
      radarMovement: { type: "drop", from: 2.5, to: 2.2 },
      radarBooks: [
        { cid: "31", bookmaker: "Sbobet", type: "rise", from: 2.4, to: 2.5,
          quoteAt: Date.parse("2026-09-25T12:31:00Z"), percent: 4.2, history: [] },
        { cid: "8", bookmaker: "Bet365", type: "drop", from: 2.5, to: 2.2,
          quoteAt: Date.parse("2026-09-25T12:31:00Z"), percent: -12, history: [] },
      ],
      matchId: "654321", home: "Hosts FC", away: "Visitors FC", league: "Any League",
      isLive: true, homeScore: 0, awayScore: 0, minute: "67",
      side: "OVER", line: 0, timeline: [], alertAt: Date.parse("2026-09-25T12:32:00Z"),
      link: "https://www.nowgoal26.com/match/live-654321",
    });
    const { parseDeliveredSignal } = await import("./deliveredSignals");
    expect(parseDeliveredSignal(rendered)).toMatchObject({
      targetSide: "HOME", line: null, anomalyType: "RADAR_DROP",
    });
    expect(parseDeliveredSignal(rendered)?.oddsAtFire).toBeCloseTo(1.2);
    expect((await sendTelegram(rendered, { deliveryKey: "multibook-home" })).primaryDelivered).toBe(true);
    expect(store.rows[0]?.status).toBe("PENDING");
    store.final = { state: -1, homeScore: 2, awayScore: 1, isLive: false, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]).toMatchObject({ status: "WIN", targetSide: "HOME", finalTotal: 3 });
  });

  it("keeps the new Excapper volume-only card and old header detectable without inventing odds", async () => {
    const input = {
      matchId: "654321", home: "Hosts FC", away: "Visitors FC", league: "Any League",
      isLive: true, homeScore: 0, awayScore: 0, minute: "12", side: "OVER" as const,
      line: 2.5, timeline: [], link: "https://www.nowgoal26.com/match/live-654321",
      source: "excapper-global" as const, alertAt: Date.parse("2026-09-25T12:32:00Z"),
      inflow: { matchId: "654321", line: 2.5, side: "OVER" as const,
        single: 1200, total: 5400, minute: "12", observedAt: Date.parse("2026-09-25T12:30:00Z") },
    };
    const rendered = formatUnifiedAlert(input);
    const { parseDeliveredSignal } = await import("./deliveredSignals");
    expect(rendered.indexOf("💰 Вливание:")).toBeLessThan(rendered.indexOf("📊 Рынок:"));
    expect(parseDeliveredSignal(rendered)).toMatchObject({
      anomalyType: "EXCAPPER", targetSide: "OVER", line: 2.5, oddsAtFire: null,
    });
    expect(parseDeliveredSignal(rendered.replace("💎 SMART EXCAPPER", "⚡ SMART EXCAPPER")))
      .toMatchObject({ anomalyType: "EXCAPPER", targetSide: "OVER" });
  });

  it("only writes after primary confirmation and retries without duplicate delivery", async () => {
    store.primaryOk = false;
    expect((await sendTelegram(card("OVER"), { deliveryKey: "e2e-over" })).primaryDelivered).toBe(false);
    expect(store.rows).toHaveLength(1);
    expect(store.rows[0]?.status).toBe("AWAITING_ACK");
    expect((await getAnomalyHistory()).rows).toHaveLength(0);
    store.primaryOk = true;
    store.failWrite = true;
    await expect(sendTelegram(card("OVER"), { deliveryKey: "e2e-over" })).resolves.toMatchObject({ primaryDelivered: true });
    const sent = store.sends;
    store.failWrite = false;
    // Same event may retry transport for failed subscribers, but never needs
    // a second primary ack just to repair a history DB failure.
    const { retryAcknowledgedSignals } = await import("./deliveredSignals");
    await retryAcknowledgedSignals();
    expect(store.sends).toBe(sent);
    expect(store.rows).toHaveLength(1);
    expect(store.rows[0]?.status).toBe("PENDING");
    expect((await getAnomalyHistory()).rows[0]).toMatchObject({
      source: "RADAR", anomalyType: "RADAR_DROP", status: "PENDING", targetSide: "OVER",
    });
    await resolveDeliveredSignals();
    expect(store.rows[0]?.status).toBe("PENDING");
    store.final = { state: 3, homeScore: 2, awayScore: 1, isLive: true, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]?.status).toBe("PENDING");
    store.final = { state: 0, homeScore: 0, awayScore: 0, isLive: false, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]?.status).toBe("PENDING");
    store.final = { state: -1, homeScore: NaN, awayScore: 1, isLive: false, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]?.status).toBe("PENDING");
    store.final = { state: -1, homeScore: 2, awayScore: 1, isLive: false, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]).toMatchObject({ status: "WIN", finalHomeScore: 2, finalAwayScore: 1, finalTotal: 3 });
    expect((await getAnomalyHistory()).rows[0]).toMatchObject({ status: "WIN", finalTotal: 3 });
    await resolveDeliveredSignals();
    expect(store.rows).toHaveLength(1);
  });

  it("retains UNDER, only settling with finished authoritative scores", async () => {
    await sendTelegram(card("UNDER"), { deliveryKey: "e2e-under" });
    store.final = { state: null, homeScore: 0, awayScore: 0, isLive: false, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]?.status).toBe("PENDING");
    store.final.state = -1;
    await resolveDeliveredSignals();
    expect(store.rows[0]).toMatchObject({ targetSide: "UNDER", status: "WIN", finalTotal: 0 });
    expect((await getAnomalyHistory({ targetSide: "UNDER" })).rows[0]).toMatchObject({ status: "WIN", targetSide: "UNDER" });
  });
  it.each([
    ["HOME", "drop", 2, 1, "WIN", "RADAR_DROP"],
    ["AWAY", "rise", 1, 2, "WIN", "RADAR_RISE"],
    ["HOME", "revert", 1, 1, "LOSS", "RADAR_REVERT"],
  ] as const)("records %s %s as PENDING and settles only on finished %i:%i", async (side, movement, homeScore, awayScore, status, anomalyType) => {
    const rendered = oneX2Card(side, movement);
    expect(rendered).toContain(side === "HOME" ? "Победа хозяев" : "Победа гостей");
    expect(rendered).toContain("повторный сигнал");
    expect(rendered).toContain(movement === "rise" ? "\\+11\\.1%" : movement === "drop" ? "\\-10\\.0%" : "⚡");
    const { parseDeliveredSignal } = await import("./deliveredSignals");
    expect(parseDeliveredSignal(rendered)).toMatchObject({
      matchId: "654321", targetSide: side, line: null, anomalyType, oddsAtFire: movement === "rise" ? 1 : 0.8,
    });
    expect((await sendTelegram(rendered, { deliveryKey: `1x2-${side}-${movement}` })).primaryDelivered).toBe(true);
    expect(store.rows[0]).toMatchObject({ status: "PENDING", targetSide: side, line: null });
    store.final = { state: 3, homeScore, awayScore, isLive: true, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]?.status).toBe("PENDING");
    store.final.state = -1;
    await resolveDeliveredSignals();
    expect((await getAnomalyHistory({ targetSide: side })).rows[0])
      .toMatchObject({ source: "RADAR", targetSide: side, status, anomalyType });
    expect((await getAnomalyHistory({ targetSide: "UNDER" })).rows).toHaveLength(0);
  });

  it("parses both historical English and new Russian cards, without turning a partial card into a settled row", async () => {
    const { parseDeliveredSignal } = await import("./deliveredSignals");
    expect(parseDeliveredSignal([
      "👁 ODDS RADAR", "🏆 League", "⚽️ Home vs Away", "📊 Live Score: 0:0 | 30'",
      "🎯 Market: Over 2.5", "📡 Drop 10.0% [2.00 -> 1.80]",
      "🔗 [Match Details](https://www.nowgoal26.com/match/live-123456)",
    ].join("\n"))).toMatchObject({
      targetSide: "OVER", anomalyType: "RADAR_DROP", line: 2.5, oddsAtFire: 0.8,
    });
    expect(parseDeliveredSignal([
      "🔴 SMART MONEY", "🏆 League", "⚽️ Home vs Away", "📊 Live Score: 0:0 | 30'",
      "🎯 Market: Under 4.5", "📉 Drop: 12.0% [2.00 ➡️ 1.76]",
      "07:02 | 4.5 | 🔴 2.00", "07:05 | 4.5 | 🟢 1.76",
      "🔗 [Match Details](https://www.nowgoal26.com/match/live-123456)",
    ].join("\n"))).toMatchObject({
      targetSide: "UNDER", anomalyType: "SMART_MONEY", line: 4.5, oddsAtFire: 0.76,
    });
    const incomplete = oneX2Card("HOME").replace("live-654321", "missing-fixture");
    expect((await sendTelegram(incomplete, { deliveryKey: "missing-1x2-fixture" })).primaryDelivered).toBe(true);
    store.final = { state: -1, homeScore: 2, awayScore: 0, isLive: false, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]).toMatchObject({ targetSide: "HOME", status: "PENDING", matchId: null });
    expect(store.rows[0]).toMatchObject({ team1: "Hosts FC", team2: "Visitors FC" });
  });

  it("keeps unknown score and malformed fixture as pending diagnostics, without changing delivery result", async () => {
    const malformed = card("OVER").replace("1:0", "N/A").replace("live-123456", "missing-fixture");
    expect((await sendTelegram(malformed, { deliveryKey: "partial" })).primaryDelivered).toBe(true);
    expect((await getAnomalyHistory()).rows[0]).toMatchObject({
      status: "PENDING", homeScoreAtFire: null, awayScoreAtFire: null, matchId: "",
    });
    store.final = { state: -1, homeScore: 3, awayScore: 0, isLive: false, clockLabel: null };
    await resolveDeliveredSignals();
    expect(store.rows[0]?.status).toBe("PENDING");
  });

  it("DB failure never causes primary re-send or skips pending subscriber retry", async () => {
    store.subscriber = true;
    store.subscriberOk = false;
    store.failWrite = true;
    const first = await sendTelegram(card("UNDER"), { deliveryKey: "subscriber-retry" });
    expect(first).toMatchObject({ status: "delivered", primaryDelivered: true, failed: 1 });
    expect(store.primarySends).toBe(1);
    store.failWrite = false;
    store.subscriberOk = true;
    const next = await sendTelegram(card("UNDER"), { deliveryKey: "subscriber-retry" });
    expect(next).toMatchObject({ primaryDelivered: true, skippedAlreadyDelivered: 1, delivered: 1 });
    expect(store.primarySends).toBe(1);
    expect((await getAnomalyHistory()).rows).toHaveLength(1);
  });

  it("does not hide an ODDS_DROP legacy row when the SMART_MONEY ledger type is filtered out", async () => {
    const now = new Date();
    store.legacy.push({
      id: 22, matchId: "123456", league: "Any League", team1: "Home FC", team2: "Away FC",
      anomalyType: "ODDS_DROP", targetSide: "OVER", line: 2.5,
      minuteBucket: "mid", matchMinute: 35, homeScoreAtFire: 1, awayScoreAtFire: 0,
      oddsAtFire: null, status: "PENDING", finalHomeScore: null, finalAwayScore: null,
      finalTotal: null, createdAt: now, resolvedAt: null,
    });
    const smart = card("OVER").replace("👁 ODDS RADAR", "🔴 SMART MONEY");
    await sendTelegram(smart, { deliveryKey: "smart-history" });
    expect((await getAnomalyHistory({ anomalyType: "ODDS_DROP" })).rows.map((r) => r.anomalyType))
      .toEqual(["ODDS_DROP"]);
    expect((await getAnomalyHistory({ anomalyType: "SMART_MONEY" as "ODDS_DROP" })).rows.map((r) => r.anomalyType))
      .toEqual(["SMART_MONEY"]);
    expect((await getAnomalyHistory()).rows).toHaveLength(1);
  });
});