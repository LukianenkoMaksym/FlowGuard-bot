import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  __testOnlyClearSharedExcapperFetches,
  ExcapperBatchOnlyError,
  fetchExcapperText,
  fetchSharedExcapperGamePage,
  getExcapperQueueStats,
  isAuthenticExcapperPayload,
  queueMicrodelayMs,
} from "./excapperSharedFetch";
import {
  __testOnlyResetExcapperBackoff,
  getExcapperHealth,
  pickExcapperBrowserProfile,
} from "./excapperBackoff";

const authenticDirectory =
  `<html><head><title>Excapper</title></head><body><table>` +
  `<tr class="a_link" game_id="42"><td>x</td></tr></table>` +
  "x".repeat(1_100) +
  `</body></html>`;

const authenticGame =
  `<html><head><title>Excapper game</title></head><body>` +
  `<div id="tab_content_1">Over/Under 2.5 Goals<table><tr><td>Over</td>` +
  `<td>1.91</td><td>120 €</td></tr></table></div>` +
  "x".repeat(1_100) +
  `</body></html>`;

describe("serialized Excapper transport", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-09-22T12:00:00Z"));
    __testOnlyResetExcapperBackoff();
    __testOnlyClearSharedExcapperFetches();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.useRealTimers();
  });

  it("allows only canonical root and numeric game URLs", async () => {
    const network = vi.fn();
    vi.stubGlobal("fetch", network);
    const signal = new AbortController().signal;

    for (const [url, kind] of [
      ["http://www.excapper.com/?action=game&id=42", "game"],
      ["https://evil.test/?action=game&id=42", "game"],
      ["https://user:pass@www.excapper.com/?action=game&id=42", "game"],
      ["https://www.excapper.com:444/?action=game&id=42", "game"],
      ["https://www.excapper.com/live?action=game&id=42", "game"],
      ["https://www.excapper.com/?action=game&id=42&id=43", "game"],
      ["https://www.excapper.com/?id=42&action=game&extra=1", "game"],
      ["https://www.excapper.com/?action=game&id=abc", "game"],
      ["https://www.excapper.com/?action=game&id=42", "directory"],
      ["https://www.excapper.com/", "game"],
    ] as const) {
      await expect(fetchExcapperText(url, signal, kind))
        .rejects.toBeInstanceOf(ExcapperBatchOnlyError);
    }
    expect(network).not.toHaveBeenCalled();
  });

  it("coalesces a verified game loader and forgets its raw body after completion", async () => {
    const loader = vi.fn(async () => authenticGame);
    const [first, second] = await Promise.all([
      fetchSharedExcapperGamePage("42", loader),
      fetchSharedExcapperGamePage("42", loader),
    ]);
    expect(first).toBe(authenticGame);
    expect(second).toBe(authenticGame);
    expect(loader).toHaveBeenCalledTimes(1);
    await fetchSharedExcapperGamePage("42", loader);
    expect(loader).toHaveBeenCalledTimes(2);
    await expect(fetchSharedExcapperGamePage("../42", loader))
      .rejects.toBeInstanceOf(ExcapperBatchOnlyError);
  });

  it("coalesces root batch consumers into one request with safe headers", async () => {
    const network = vi.fn(async (_url: string, init: RequestInit) => {
      const headers = new Headers(init.headers);
      expect(headers.get("Accept-Language")).toBe("en-US,en;q=0.9");
      expect(headers.get("Referer")).toBe("https://excapper.com/");
      expect(headers.get("User-Agent")).toMatch(/^Mozilla\//);
      return new Response(authenticDirectory, { status: 200 });
    });
    vi.stubGlobal("fetch", network);
    const signal = new AbortController().signal;
    const first = fetchExcapperText("https://www.excapper.com/", signal, "directory");
    const second = fetchExcapperText("https://excapper.com/", signal, "directory");
    await expect(Promise.all([first, second])).resolves.toEqual([
      authenticDirectory, authenticDirectory,
    ]);
    expect(network).toHaveBeenCalledTimes(1);
    expect(network.mock.calls[0]![1]).toMatchObject({ redirect: "manual" });
    expect(getExcapperQueueStats()).toMatchObject({ pending: 0, running: 0, maxPending: 8 });
  });

  it("uses one shared 1.5s transport floor", () => {
    expect(queueMicrodelayMs(() => 0)).toBe(1_500);
    expect(queueMicrodelayMs(() => 0.999999)).toBe(1_500);
  });

  it("serializes directory and game HTTP requests with the shared floor", async () => {
    let active = 0;
    let maximumActive = 0;
    const releases: Array<() => void> = [];
    const network = vi.fn(async (url: string) => {
      active++;
      maximumActive = Math.max(maximumActive, active);
      await new Promise<void>((resolve) => releases.push(resolve));
      active--;
      return new Response(url.includes("action=game") ? authenticGame : authenticDirectory);
    });
    vi.stubGlobal("fetch", network);
    const signal = new AbortController().signal;
    const directory = fetchExcapperText("https://excapper.com/", signal, "directory");
    const game = fetchExcapperText(
      "https://excapper.com/?id=42&action=game", signal, "game",
    );
    await vi.advanceTimersByTimeAsync(0);
    expect(network).toHaveBeenCalledTimes(1);
    releases.shift()!();
    await directory;
    await vi.advanceTimersByTimeAsync(1_499);
    expect(network).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(1);
    expect(network).toHaveBeenCalledTimes(2);
    releases.shift()!();
    await game;
    expect(maximumActive).toBe(1);
  });

  it("retains issued cookies in memory and sends them only on a later Excapper request", async () => {
    const network = vi.fn()
      .mockResolvedValueOnce(new Response(authenticDirectory, {
        headers: { "Set-Cookie": "PHPSESSID=session-value; Path=/; Secure; HttpOnly" },
      }))
      .mockImplementationOnce(async (_url: string, init: RequestInit) => {
        expect(new Headers(init.headers).get("Cookie")).toBe("PHPSESSID=session-value");
        return new Response(authenticGame);
      });
    vi.stubGlobal("fetch", network);
    const signal = new AbortController().signal;
    await fetchExcapperText("https://excapper.com/", signal, "directory");
    const game = fetchExcapperText(
      "https://www.excapper.com/?action=game&id=42", signal, "game",
    );
    await vi.advanceTimersByTimeAsync(1_500);
    await expect(game).resolves.toBe(authenticGame);
    expect(JSON.stringify(getExcapperQueueStats())).not.toContain("session-value");
  });

  it("does not let a manual request bypass spacing after a directory request", async () => {
    const startedAt: number[] = [];
    const network = vi.fn(async (url: string) => {
      startedAt.push(Date.now());
      return new Response(url.includes("action=game") ? authenticGame : authenticDirectory);
    });
    vi.stubGlobal("fetch", network);
    const signal = new AbortController().signal;

    await fetchExcapperText("https://excapper.com/", signal, "directory");
    const manual = fetchExcapperText(
      "https://excapper.com/?action=game&id=42",
      signal,
      "game",
      20_000,
      { tier: "manual" },
    );
    await vi.advanceTimersByTimeAsync(1_499);
    expect(network).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(1);
    await expect(manual).resolves.toBe(authenticGame);
    expect(startedAt[1]! - startedAt[0]!).toBeGreaterThanOrEqual(1_500);
  });

  it("uses coherent browser profiles and the required language header", () => {
    for (const random of [0, 0.3, 0.6, 0.99]) {
      const profile = pickExcapperBrowserProfile(() => random);
      expect(profile.userAgent).toMatch(/^Mozilla\//);
      expect(profile.headers["Accept-Language"]).toBe("en-US,en;q=0.9");
      if (profile.family !== "chrome") expect(profile.headers["Sec-CH-UA"]).toBeUndefined();
    }
  });

  it("backs off on Cloudflare-style 403 and does not retry inside the queue", async () => {
    const network = vi.fn(async () => new Response(
      `<html><title>Just a moment</title>cf-chl-${"x".repeat(2_000)}</html>`,
      { status: 403 },
    ));
    vi.stubGlobal("fetch", network);
    await expect(fetchExcapperText(
      "https://excapper.com/", new AbortController().signal, "directory",
    )).rejects.toThrow("HTTP 403");
    expect(network).toHaveBeenCalledTimes(1);
    expect(getExcapperHealth()).toMatchObject({ state: "backoff", lastErrorStatus: 403 });
    expect(getExcapperHealth().retryAt! - Date.now()).toBeGreaterThanOrEqual(25_000);
    expect(getExcapperQueueStats()).toMatchObject({ pending: 0, running: 0 });
  });

  it("accepts only structured batch JSON with per-event identity", () => {
    expect(isAuthenticExcapperPayload(JSON.stringify({
      events: [{ id: 42, home: "Alpha", away: "Beta" }],
    }), "directory")).toBe(true);
    expect(isAuthenticExcapperPayload(JSON.stringify({
      events: [{ score: "1-0" }],
    }), "directory")).toBe(false);
    expect(isAuthenticExcapperPayload(JSON.stringify({
      status: "ok", data: [],
    }), "directory")).toBe(false);
  });

  it("accepts full game HTML but rejects summary and challenge HTML", () => {
    expect(isAuthenticExcapperPayload(authenticGame, "game")).toBe(true);
    expect(isAuthenticExcapperPayload(authenticDirectory, "game")).toBe(false);
    expect(isAuthenticExcapperPayload(
      `<html><title>Just a moment</title>cf-chl-${"x".repeat(2_000)}</html>`,
      "game",
    )).toBe(false);
  });
});