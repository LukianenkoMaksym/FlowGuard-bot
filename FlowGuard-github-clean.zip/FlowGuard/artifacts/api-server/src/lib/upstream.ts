/**
 * Upstream host pool with lazy, fallback-on-error rotation.
 *
 * The NowGoal ecosystem mirrors the same XML/Ajax data structure across
 * several domains. We pick ONE primary and stick with it indefinitely;
 * other mirrors are touched only when the primary fails or when the
 * watchdog wants a quick cross-verification. This minimizes load on
 * upstream and reduces our IP-ban surface area.
 *
 * Pool curation
 * -------------
 * The registry contains only canonical origins that currently serve the
 * feeds without an HTTP redirect. It is deliberately small so routine
 * failover does not hammer stale aliases. A future live mirror can still be
 * added after a bounded probe; this list is a routing preference, not proof
 * that an upstream will remain healthy.
 */
import { logger } from "./logger";
import {
  NOWGOAL_AUTO_SWITCH_COOLDOWN_MS,
  NOWGOAL_HOSTS,
  NOWGOAL_TECHNICAL_NOTIFICATION_COOLDOWN_MS,
} from "./config";
import { sendTelegram, escapeMdV2, isTelegramConfigured } from "./telegram";

/**
 * Local copy of `parseKickoffMs` to avoid a circular dependency with
 * `healthcheck.ts` (which imports from this file). The function is small and
 * pure; if you change one, change both. See `healthcheck.ts` for the
 * authoritative comments on the GMT+8 / 0-indexed-month quirks.
 */
function parseKickoffMsLocal(commaTime: string): number | null {
  const FEED_TZ_OFFSET_MS = 8 * 60 * 60 * 1000;
  const p = commaTime.split(",").map((x) => parseInt(x.trim(), 10));
  if (p.length < 5 || p.some((n) => Number.isNaN(n))) return null;
  const wallMs = Date.UTC(p[0], p[1], p[2], p[3], p[4], p[5] ?? 0);
  if (!Number.isFinite(wallMs)) return null;
  return wallMs - FEED_TZ_OFFSET_MS;
}

/**
 * Verified working mirrors (probed sequentially against
 * `/Ajax/SoccerAjax?type=12` + `/gf/data/odds/en/goal8.xml`).
 *
 * Order matters: index 0 is the default primary; the rest are tried in order
 * during failover. Cross-verification picks at random from indexes ≥ 1.
 */
// Mirror pool lives in `config.ts` — see that file for ordering rules and
// the rationale for keeping the Vcbet oddscomp host out of this pool.
const HOST_CANDIDATES = NOWGOAL_HOSTS;

let currentBase = HOST_CANDIDATES[0];
let lastFailoverAt: number | null = null;
let lastTechnicalNotificationAt: number | null = null;
let failoverHistory: { at: number; from: string; to: string; reason: string }[] = [];

/**
 * Singleflight guard for `tryFailover`. The scanner and the watchdog can both
 * decide to failover within the same second (e.g. scanner hits 2 consecutive
 * failures right as the watchdog ticks). Without this, two parallel probe
 * cascades would mutate `currentBase` non-deterministically and could swap
 * twice in quick succession — exactly the IP-banning thundering-herd we want
 * to avoid. Concurrent callers piggyback on the in-flight probe instead.
 */
let inflightFailover: Promise<FailoverResult> | null = null;
const failureLogAt = new Map<string, number>();
const FAILURE_LOG_THROTTLE_MS = 5 * 60 * 1000;
const INVALID_HOST_QUARANTINE_MS = 10 * 60 * 1000;
const TRANSIENT_BACKOFF_INITIAL_MS = 30 * 1000;
const TRANSIENT_BACKOFF_MAX_MS = 5 * 60 * 1000;
interface HostHealth {
  nextProbeAt: number;
  transientBackoffMs: number;
  kind: "invalid" | "transient";
  reason: string;
}
const hostHealth = new Map<string, HostHealth>();

export interface FailoverResult {
  switched: boolean;
  from: string;
  to: string;
  report: HostProbeReport[];
  coalesced?: boolean;
  suppressed?: "switch_cooldown";
  retryAfterMs?: number;
}

// Cross-verification telemetry (used by /scanner/health to surface load)
let crossVerifyCount = 0;
let crossVerifyConfirmedQuietCount = 0;
let crossVerifyMismatchCount = 0;
let lastCrossVerifyAt: number | null = null;
let lastCrossVerifyResult: {
  altHost: string;
  altLiveCount: number;
  altPreMatchCount: number;
  agreedQuiet: boolean;
  ranAt: string;
} | null = null;

export function currentBaseUrl(): string {
  return currentBase;
}

export function listCandidates(): readonly string[] {
  return HOST_CANDIDATES;
}

/**
 * Build the endpoint URLs from a base URL.
 *
 * Per-book live OU feeds are exposed at `/gf/data/odds/en/goal{companyId}.xml`
 * where the company ID comes from NowGoal's bookmaker registry (lifted out of
 * the oddscomp page's filter window). Confirmed mappings:
 *
 *   8  → Bet365   (primaryOu, baseline for line/move detection + alerts)
 *   3  → Crown    (benchmarkOu, also drives evalBenchmark()/Telegram)
 *   31 → Sbobet
 *   17 → M88
 *   24 → 12Bet
 *   42 → 18Bet
 *   14 → VSBet (Vcbet) — replaced Easybet in the 7th slot of the NOWGOAL stack.
 *
 * Easybet (id 12 in the UI filter) was previously kept in the display order as
 * a permanent "—" because goal12.xml 404s (its feed lives on a gzipped Ajax
 * type=11 transport requiring pako decoding). User swapped it for VSBet which
 * does serve goal14.xml on the same XML transport as the other extras, so the
 * row now carries live odds instead of a dash.
 *
 * `extraBooks` is a stable object so callers can iterate with predictable key
 * order — keys double as display labels in the dashboard's NOWGOAL stack.
 */
export function endpointsFor(base: string) {
  return {
    primaryOu: `${base}/gf/data/odds/en/goal8.xml`,
    benchmarkOu: `${base}/gf/data/odds/en/goal3.xml`,
    extraBooks: {
      Sbobet: `${base}/gf/data/odds/en/goal31.xml`,
      M88: `${base}/gf/data/odds/en/goal17.xml`,
      "12Bet": `${base}/gf/data/odds/en/goal24.xml`,
      "18Bet": `${base}/gf/data/odds/en/goal42.xml`,
      VSBet: `${base}/gf/data/odds/en/goal14.xml`,
    } as const,
    meta: `${base}/Ajax/SoccerAjax?type=12`,
    leagues: `${base}/Ajax/SoccerAjax?type=6`,
  };
}

/** Ordered list of extra book keys — drives parallel fetch + serialization. */
export const EXTRA_BOOK_KEYS = ["Sbobet", "M88", "12Bet", "18Bet", "VSBet"] as const;
export type ExtraBookKey = (typeof EXTRA_BOOK_KEYS)[number];

/**
 * Append a unique cache-buster querystring so any intermediary HTTP cache
 * (CDN, ISP-side proxy, browser cache) is forced to revalidate on every
 * scanner tick. The mirror itself is fine — this defends against opaque
 * upstream/edge caches that occasionally serve a stale XML and silently
 * blind us to in-play movement on regional fixtures.
 *
 * Safe to call on URLs that already have a querystring; appends with `&`.
 */
export function withCacheBuster(url: string): string {
  const sep = url.includes("?") ? "&" : "?";
  return `${url}${sep}_=${Date.now()}`;
}

export function getFailoverState() {
  return {
    currentBase,
    lastFailoverAt: lastFailoverAt ? new Date(lastFailoverAt).toISOString() : null,
    failoverHistory: failoverHistory.slice(-10),
    poolSize: HOST_CANDIDATES.length,
    crossVerify: {
      total: crossVerifyCount,
      confirmedQuiet: crossVerifyConfirmedQuietCount,
      mismatch: crossVerifyMismatchCount,
      lastRanAt: lastCrossVerifyAt ? new Date(lastCrossVerifyAt).toISOString() : null,
      lastResult: lastCrossVerifyResult,
    },
  };
}

/** Optional response metadata accepted by probes that can preserve transport details. */
export interface UpstreamFetchDetails {
  body: string;
  status?: number;
  finalUrl?: string;
  redirected?: boolean;
  redirectCount?: number;
}

/**
 * `fetchRaw` intentionally exposes only the body for the scanner hot path.
 * Health/probe callers may provide this richer shape when their transport
 * adapter can retain response metadata; the optional fields are omitted when
 * the body-only interface is used.
 */
export type UpstreamFetcher = (url: string) => Promise<string | UpstreamFetchDetails>;

export interface HostProbeReport {
  host?: string;
  ok: boolean;
  reason?: string;
  matches?: number;
  endpointStatus?: {
    meta?: number;
    primaryOu?: number;
    benchmarkOu?: number;
  };
  finalUrls?: {
    meta?: string;
    primaryOu?: string;
    benchmarkOu?: string;
  };
  redirected?: boolean;
  redirectCount?: number;
}

function originOf(value: string | undefined): string | null {
  if (!value) return null;
  try {
    return new URL(value).origin.toLowerCase();
  } catch {
    return null;
  }
}

/** A redirecting alias is not an independent mirror. Prefer the final origin
 * supplied by the transport; all three probe endpoints are expected to agree. */
function effectiveProbeOrigin(candidate: string, probe: HostProbeReport): string {
  const finals = Object.values(probe.finalUrls ?? {})
    .map(originOf)
    .filter((value): value is string => value !== null);
  return finals[0] ?? originOf(candidate) ?? candidate.toLowerCase();
}

function logFailoverFailure(reason: string, details: Record<string, unknown>): void {
  const now = Date.now();
  const key = `${currentBase}|${reason}`;
  const previous = failureLogAt.get(key) ?? 0;
  if (now - previous < FAILURE_LOG_THROTTLE_MS) {
    logger.debug({ reason, ...details }, "Upstream failover failure suppressed (duplicate)");
    return;
  }
  failureLogAt.set(key, now);
  logger.error({ reason, ...details }, "Upstream failover failed — no healthy mirror");
}

function normalizeFetchResult(value: string | UpstreamFetchDetails): UpstreamFetchDetails {
  return typeof value === "string" ? { body: value } : value;
}

function classifyProbeFailure(probe: HostProbeReport): "invalid" | "transient" {
  const statuses = Object.values(probe.endpointStatus ?? {});
  if (statuses.some((status) => status === 404) || probe.reason?.includes("HTTP 404")) return "invalid";
  if (
    probe.reason === "meta_unparseable" ||
    probe.reason === "redirected_origin" ||
    probe.reason === "meta_too_few_records" ||
    probe.reason === "primary_ou_empty" ||
    probe.reason === "bench_ou_empty" ||
    probe.reason?.startsWith("meta_errcode_")
  ) {
    return "invalid";
  }
  return "transient";
}

function recordProbeHealth(host: string, probe: HostProbeReport): void {
  if (probe.ok) {
    hostHealth.delete(host);
    return;
  }
  const now = Date.now();
  const kind = classifyProbeFailure(probe);
  if (kind === "invalid") {
    hostHealth.set(host, {
      kind,
      reason: probe.reason ?? "invalid_payload",
      nextProbeAt: now + INVALID_HOST_QUARANTINE_MS,
      transientBackoffMs: 0,
    });
    return;
  }
  const previous = hostHealth.get(host);
  const backoff =
    previous?.kind === "transient"
      ? Math.min(TRANSIENT_BACKOFF_MAX_MS, Math.max(TRANSIENT_BACKOFF_INITIAL_MS, previous.transientBackoffMs * 2))
      : TRANSIENT_BACKOFF_INITIAL_MS;
  hostHealth.set(host, {
    kind,
    reason: probe.reason ?? "transient_failure",
    nextProbeAt: now + backoff,
    transientBackoffMs: backoff,
  });
}

function deferredProbe(host: string): HostProbeReport | null {
  const health = hostHealth.get(host);
  if (!health || Date.now() >= health.nextProbeAt) return null;
  return {
    host,
    ok: false,
    reason: `${health.kind === "invalid" ? "quarantined" : "backoff"}:${health.reason}`,
  };
}

/** Full probe: META + primary OU + benchmark OU must all return parseable, non-empty
 *  bodies. We deliberately don't rely on META alone — a mirror can return a healthy
 *  schedule but a broken/empty odds feed, which would silently degrade the scanner. */
export async function probeHost(
  base: string,
  fetchFn: UpstreamFetcher,
): Promise<HostProbeReport> {
  const ep = endpointsFor(base);
  try {
    const [metaResponse, primaryResponse, benchResponse] = await Promise.all([
      fetchFn(ep.meta),
      fetchFn(ep.primaryOu),
      fetchFn(ep.benchmarkOu),
    ]);
    const meta = normalizeFetchResult(metaResponse);
    const primary = normalizeFetchResult(primaryResponse);
    const bench = normalizeFetchResult(benchResponse);
    const endpointStatus = {
      ...(meta.status !== undefined && { meta: meta.status }),
      ...(primary.status !== undefined && { primaryOu: primary.status }),
      ...(bench.status !== undefined && { benchmarkOu: bench.status }),
    };
    const finalUrls = {
      ...(meta.finalUrl !== undefined && { meta: meta.finalUrl }),
      ...(primary.finalUrl !== undefined && { primaryOu: primary.finalUrl }),
      ...(bench.finalUrl !== undefined && { benchmarkOu: bench.finalUrl }),
    };
    const redirected = Boolean(meta.redirected || primary.redirected || bench.redirected);
    const redirectCount = Math.max(
      meta.redirectCount ?? 0,
      primary.redirectCount ?? 0,
      bench.redirectCount ?? 0,
    );
    const transportDetails = {
      ...(Object.keys(endpointStatus).length > 0 && { endpointStatus }),
      ...(Object.keys(finalUrls).length > 0 && { finalUrls }),
      ...(redirected && { redirected, redirectCount }),
    };

    let json: { ErrCode: number; Data: string };
    try {
      json = JSON.parse(meta.body) as { ErrCode: number; Data: string };
    } catch {
      return { ok: false, reason: "meta_unparseable", ...transportDetails };
    }
    if (json.ErrCode !== 0 || !json.Data) {
      return { ok: false, reason: `meta_errcode_${json.ErrCode}`, ...transportDetails };
    }
    const matches = json.Data.split("!").filter(Boolean).length;
    if (matches < 10) {
      return { ok: false, reason: "meta_too_few_records", matches, ...transportDetails };
    }

    const primaryRows = (primary.body.match(/<m>[^<]+<\/m>/g) ?? []).length;
    if (primaryRows < 5) {
      return { ok: false, reason: "primary_ou_empty", matches, ...transportDetails };
    }

    const benchRows = (bench.body.match(/<m>[^<]+<\/m>/g) ?? []).length;
    if (benchRows < 5) {
      return { ok: false, reason: "bench_ou_empty", matches, ...transportDetails };
    }

    return { ok: true, matches, ...transportDetails };
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : String(err) };
  }
}

/**
 * Probe all candidates, switch to the first healthy one if our current is unhealthy.
 * Returns the chosen base URL and a per-candidate report.
 *
 * NOTE: this fans out to every mirror sequentially (not in parallel) to avoid
 * the "thundering herd" load pattern that gets us IP-banned. The trade-off is
 * latency — worst case we probe N hosts before finding a healthy one.
 */
export async function tryFailover(
  fetchFn: UpstreamFetcher,
  reason: string,
  opts: { force?: boolean; bypassCooldown?: boolean } = {},
): Promise<FailoverResult> {
  // Singleflight: if a probe cascade is already running, await its result
  // instead of starting a parallel one. Marked `coalesced` so callers can log
  // that they piggybacked rather than initiated the switch.
  if (inflightFailover) {
    const result = await inflightFailover;
    return { ...result, coalesced: true };
  }

  const force = Boolean(opts.force);

  inflightFailover = (async (): Promise<FailoverResult> => {
    const from = currentBase;
    const report: { host: string; ok: boolean; reason?: string; matches?: number }[] = [];
    const sinceLastSwitch = lastFailoverAt === null ? Infinity : Date.now() - lastFailoverAt;
    if (!opts.bypassCooldown && sinceLastSwitch < NOWGOAL_AUTO_SWITCH_COOLDOWN_MS) {
      const retryAfterMs = NOWGOAL_AUTO_SWITCH_COOLDOWN_MS - sinceLastSwitch;
      logger.debug(
        { from, reason, retryAfterMs },
        "Automatic upstream switch suppressed by global cooldown",
      );
      return {
        switched: false,
        from,
        to: from,
        report,
        suppressed: "switch_cooldown",
        retryAfterMs,
      };
    }

    // Probe current first — if it's healthy we don't need to swap.
    // EXCEPTION: `force=true` callers (e.g. odds-volatility staleness) need to
    // rotate AWAY from a mirror that's HTTP-healthy but serving frozen data.
    // For them, we skip the current-probe early return and go straight to
    // probing alternates so we can actually switch off the dead mirror.
    if (!force) {
      const deferred = deferredProbe(currentBase);
      const rawCurrentProbe = deferred ?? await probeHost(currentBase, fetchFn);
      const currentProbe =
        rawCurrentProbe.ok &&
        effectiveProbeOrigin(currentBase, rawCurrentProbe) !== originOf(currentBase)
          ? { ...rawCurrentProbe, ok: false, reason: "redirected_origin" }
          : rawCurrentProbe;
      if (!deferred) {
        recordProbeHealth(currentBase, currentProbe);
      }
      report.push({ host: currentBase, ...currentProbe });
      if (currentProbe.ok) {
        return { switched: false, from, to: currentBase, report };
      }
    } else {
      report.push({ host: currentBase, ok: false, reason: `force_rotation:${reason}` });
    }

    // Sequential probe (NOT parallel) — see comment on tryFailover above.
    const currentOrigin = originOf(currentBase);
    const probedEffectiveOrigins = new Set<string>();
    for (const candidate of HOST_CANDIDATES) {
      if (originOf(candidate) === currentOrigin) continue;
      const deferred = deferredProbe(candidate);
      const probe = deferred ?? await probeHost(candidate, fetchFn);
      if (!deferred) recordProbeHealth(candidate, probe);
      const effectiveOrigin = effectiveProbeOrigin(candidate, probe);
      if (effectiveOrigin === currentOrigin) {
        report.push({ host: candidate, ...probe, ok: false, reason: "same_effective_origin" });
        continue;
      }
      if (probedEffectiveOrigins.has(effectiveOrigin)) {
        report.push({ host: candidate, ...probe, ok: false, reason: "duplicate_effective_origin" });
        continue;
      }
      probedEffectiveOrigins.add(effectiveOrigin);
      report.push({ host: candidate, ...probe });
      if (probe.ok) {
        if (candidate === currentBase) {
          return { switched: false, from, to: currentBase, report };
        }
        currentBase = candidate;
        const switchedAt = Date.now();
        lastFailoverAt = switchedAt;
        failoverHistory.push({ at: switchedAt, from, to: candidate, reason });
        if (failoverHistory.length > 50) failoverHistory = failoverHistory.slice(-50);
        logger.warn({ from, to: candidate, reason, force }, "Upstream failover");
        // Fire-and-forget admin alert. We don't await this — it must not block
        // the scanner tick, and the failover decision is already final at this
        // point regardless of whether the Telegram dispatch succeeds.
        const notificationCooledDown =
          lastTechnicalNotificationAt === null ||
          switchedAt - lastTechnicalNotificationAt >=
            NOWGOAL_TECHNICAL_NOTIFICATION_COOLDOWN_MS;
        if (isTelegramConfigured() && notificationCooledDown) {
          // Claim the cooldown before the fire-and-forget dispatch so parallel
          // or manual bypass switches cannot enqueue duplicate diagnostics.
          lastTechnicalNotificationAt = switchedAt;
          const text =
            `⚠️ *Upstream failover*\n` +
            `From: \`${escapeMdV2(from)}\`\n` +
            `To: \`${escapeMdV2(candidate)}\`\n` +
            `Reason: ${escapeMdV2(reason)}` +
            (force ? ` _\\(forced\\)_` : "");
          sendTelegram(text).catch((err) => {
            logger.warn(
              { err: err instanceof Error ? err.message : String(err) },
              "[FAILOVER-ALERT] Telegram dispatch failed",
            );
          });
        } else if (isTelegramConfigured()) {
          logger.debug(
            {
              from,
              to: candidate,
              reason,
              retryAfterMs:
                NOWGOAL_TECHNICAL_NOTIFICATION_COOLDOWN_MS -
                (switchedAt - (lastTechnicalNotificationAt ?? switchedAt)),
            },
            "Upstream failover Telegram notification suppressed by technical cooldown",
          );
        }
        return { switched: true, from, to: candidate, report };
      }
    }

    // No healthy candidate found — keep current and let next watchdog tick retry.
    logFailoverFailure(reason, { report, force });
    return { switched: false, from, to: currentBase, report };
  })();

  try {
    return await inflightFailover;
  } finally {
    inflightFailover = null;
  }
}

/** Deterministic state seam for unit tests only. */
export const __upstreamTestOnly = {
  reset(): void {
    currentBase = HOST_CANDIDATES[0];
    lastFailoverAt = null;
    lastTechnicalNotificationAt = null;
    failoverHistory = [];
    inflightFailover = null;
    failureLogAt.clear();
    hostHealth.clear();
  },
  setCurrentBase(base: string): void {
    currentBase = base;
  },
  hostHealth,
};

/**
 * Cross-verify: when our primary mirror reports zero live matches but plenty
 * of pre-match data, ask exactly ONE alternative mirror "are you also seeing
 * zero live?" before alarming. If both agree it's quiet → genuine quiet hour.
 * If the alt sees lots of live matches → we're being silently blocked /
 * served stale data and the watchdog should escalate (failover + alarm).
 *
 * Cheap by design: only fetches META from a single alternate host (the
 * lightest endpoint), not the full odds + benchmark feeds. We pick a random
 * non-current host so that load is spread across the pool over time rather
 * than always hammering the same secondary.
 */
export async function crossVerifyLiveCount(
  fetchFn: (url: string) => Promise<string>,
): Promise<{
  ok: boolean;
  altHost: string | null;
  altLiveCount: number;
  altPreMatchCount: number;
  agreedQuiet: boolean;
  reason?: string;
}> {
  const alts = HOST_CANDIDATES.filter((h) => h !== currentBase);
  if (alts.length === 0) {
    return {
      ok: false,
      altHost: null,
      altLiveCount: 0,
      altPreMatchCount: 0,
      agreedQuiet: false,
      reason: "no_alt_hosts",
    };
  }

  // Pick a random alt so load is spread over time.
  const altHost = alts[Math.floor(Math.random() * alts.length)];
  const ep = endpointsFor(altHost);

  let metaText: string;
  try {
    metaText = await fetchFn(ep.meta);
  } catch (err) {
    crossVerifyCount++;
    lastCrossVerifyAt = Date.now();
    return {
      ok: false,
      altHost,
      altLiveCount: 0,
      altPreMatchCount: 0,
      agreedQuiet: false,
      reason: err instanceof Error ? err.message : String(err),
    };
  }

  let json: { ErrCode: number; Data: string };
  try {
    json = JSON.parse(metaText) as { ErrCode: number; Data: string };
  } catch {
    crossVerifyCount++;
    lastCrossVerifyAt = Date.now();
    return {
      ok: false,
      altHost,
      altLiveCount: 0,
      altPreMatchCount: 0,
      agreedQuiet: false,
      reason: "meta_unparseable",
    };
  }
  if (json.ErrCode !== 0 || !json.Data) {
    crossVerifyCount++;
    lastCrossVerifyAt = Date.now();
    return {
      ok: false,
      altHost,
      altLiveCount: 0,
      altPreMatchCount: 0,
      agreedQuiet: false,
      reason: `meta_errcode_${json.ErrCode}`,
    };
  }

  // Coarse "live now" count: kickoff is in the past but within the live window
  // (2.5h covers regulation + ET + penalties). Same window the scanner uses.
  const LIVE_WINDOW_MS = 150 * 60 * 1000;
  const now = Date.now();
  let altLive = 0;
  let altPreMatch = 0;
  for (const record of json.Data.split("!").filter(Boolean)) {
    const f = record.split("^");
    const ms = parseKickoffMsLocal(f[3] ?? "");
    if (ms === null) continue;
    if (ms <= now && ms + LIVE_WINDOW_MS > now) altLive++;
    else if (ms > now) altPreMatch++;
  }

  const agreedQuiet = altLive === 0;
  crossVerifyCount++;
  if (agreedQuiet) crossVerifyConfirmedQuietCount++;
  else crossVerifyMismatchCount++;
  lastCrossVerifyAt = Date.now();
  lastCrossVerifyResult = {
    altHost,
    altLiveCount: altLive,
    altPreMatchCount: altPreMatch,
    agreedQuiet,
    ranAt: new Date().toISOString(),
  };

  logger.info(
    { altHost, altLive, altPreMatch, agreedQuiet },
    agreedQuiet
      ? "Cross-verify: alt mirror also sees 0 live — genuine quiet hour"
      : "Cross-verify: alt mirror sees live matches — primary likely silently blocked",
  );

  return {
    ok: true,
    altHost,
    altLiveCount: altLive,
    altPreMatchCount: altPreMatch,
    agreedQuiet,
  };
}
