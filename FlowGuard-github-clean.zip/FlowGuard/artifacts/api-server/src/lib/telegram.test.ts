import { afterEach, describe, expect, it, vi } from "vitest";
import {
  getTelegramConfigurationStatus,
  TELEGRAM_SYSTEM_CHECK_MESSAGE,
} from "./telegram";
import { resolveTelegramOutboundMode } from "./telegramOutboundPolicy";

describe("Telegram delivery configuration reasons", () => {
  it("fails closed with an explicit missing-token reason", () => {
    expect(getTelegramConfigurationStatus({ TELEGRAM_CHAT_ID: "configured" })).toEqual({
      configured: false,
      reason: "token_missing",
    });
  });

  it("does not use a hidden fallback destination when chat is missing", () => {
    expect(getTelegramConfigurationStatus({ TELEGRAM_TOKEN: "configured" })).toEqual({
      configured: false,
      reason: "chat_missing",
    });
  });

  it("reports configured only when both metadata fields are present", () => {
    expect(getTelegramConfigurationStatus({
      TELEGRAM_TOKEN: "configured",
      TELEGRAM_CHAT_ID: "configured",
    })).toEqual({ configured: true });
  });

  it("keeps the authorized primary diagnostic text exact and startup-neutral", () => {
    expect(TELEGRAM_SYSTEM_CHECK_MESSAGE).toBe(
      "🤖 [SYSTEM CHECK] Telegram Alert Pipeline Active & Connected",
    );
  });
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("Telegram production transport isolation", () => {
  it("requires both production NODE_ENV and the deployed runtime marker", () => {
    for (const NODE_ENV of [undefined, "development", "test"]) {
      expect(resolveTelegramOutboundMode({ NODE_ENV, REPLIT_DEPLOYMENT: "1", TELEGRAM_POLLING: "enabled" }).allowed).toBe(false);
    }
    expect(resolveTelegramOutboundMode({ NODE_ENV: "production" }).allowed).toBe(false);
    expect(resolveTelegramOutboundMode({ NODE_ENV: "production", REPLIT_DEPLOYMENT: "1" }).allowed).toBe(true);
  });

  it("never fetches or acknowledges suppressed broadcasts, direct replies, or bot diagnostics", async () => {
    vi.resetModules();
    vi.stubEnv("TELEGRAM_TOKEN", "test-token");
    vi.stubEnv("TELEGRAM_CHAT_ID", "primary");
    vi.stubEnv("REPLIT_DEPLOYMENT", "1");
    const fetchMock = vi.fn(async () => new Response("{}", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const telegram = await import("./telegram");

    for (const env of ["development", "test", ""]) {
      vi.stubEnv("NODE_ENV", env);
      expect(await telegram.sendTelegram("suppressed")).toMatchObject({
        status: "failed", reason: "non_production", primaryDelivered: false, attempted: 0,
      });
      expect(await telegram.sendTelegramTo("primary", "bot reply")).toBe("failed");
      expect(await telegram.sendTelegramOutboxRecipient({ id: "primary", primary: true }, "outbox")).toBe("failed");
      expect(await telegram.sendPrimaryTelegramSystemCheck()).toBe("failed");
      expect((await telegram.probeTelegramSilent()).ok).toBe(false);
    }
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("allows real transport paths only in a production deployment", async () => {
    vi.resetModules();
    vi.stubEnv("TELEGRAM_TOKEN", "test-token");
    vi.stubEnv("TELEGRAM_CHAT_ID", "primary");
    vi.stubEnv("NODE_ENV", "production");
    vi.stubEnv("REPLIT_DEPLOYMENT", "1");
    const fetchMock = vi.fn(async () => new Response("{}", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const telegram = await import("./telegram");
    expect(await telegram.sendTelegramTo("primary", "allowed")).toBe("ok");
    expect(await telegram.sendPrimaryTelegramSystemCheck()).toBe("ok");
    expect(fetchMock).toHaveBeenCalledTimes(2);
    vi.stubEnv("NODE_ENV", "development");
    expect(await telegram.sendTelegramTo("primary", "no longer allowed")).toBe("failed");
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });
});