import { describe, expect, it, vi } from "vitest";

// These rule assertions exercise a fixed approved policy snapshot, not the
// operator-editable config/target-leagues.json. Never write the live config in
// a test: concurrent operator edits must not change the expected rule set.
const approvedNames = vi.hoisted(() => `Finland Kakkonen D3
Singapore S-League
Peruvian Segunda Division
Liga Super Malaysia
FA Cup Malaysia
Malaysia
Indian I-League 2nd Division
Indian Mumbai Super Division
Indian Shillong Premier League
Hong Kong 1st Division League
Hong Kong 2nd Division League
German 3.Liga
Costa Rican Liga de Ascenso
Colombian Primera B
Bolivian Liga de Futbol Profesional
Bhutan Premier
Armenian Premier
Argentinian Primera B Metropolitana
Myanmar U21 League
Puerto Rico League
Paraguay Reserve Team League
Bangladesh Premier League
Bolivian Copa Simon Bolivar
Argentinian Primera C Metropolitana
Argentinian Primera D
Argentinian Torneo Federal A
Brazilian Paulista A3
Brazilian Paulista A4
Brazilian Carioca B1
Brazilian Carioca B2
Brazilian State Cups
Vietnam V-League 2
Vietnam U19 Championship
Vietnam U21 Championship
Indonesia Liga 2
Indonesia Liga 3
Philippines National/Premier League
Australia NPL Victoria
Australia NPL New South Wales
Australia NPL Queensland
Greece Super League 2
Serbia Prva Liga
North Macedonia Prva Liga
Bulgaria Second League
Czech 3 Liga
Czech MSFL
Czech CFL
Slovakia 3 Liga
Czech Winter Cup
Slovakia Winter Cup
International Club Friendlies
U19 League
U21 League
U23 League
Ecuadorian Serie B`.split("\n"));

vi.mock("node:fs", async (importOriginal) => {
  const fs = await importOriginal<typeof import("node:fs")>();
  return {
    ...fs,
    readFileSync: (filePath: Parameters<typeof fs.readFileSync>[0], options?: Parameters<typeof fs.readFileSync>[1]) =>
      String(filePath).endsWith("/config/target-leagues.json")
        ? JSON.stringify(approvedNames.map((name) => ({ name, aliases: [] })))
        : fs.readFileSync(filePath, options),
  };
});
import {
  TARGET_LEAGUES,
  getLeaguePolicy,
  isTargetLeague,
  matchTargetLeague,
} from "./targetLeagues";

describe("canonical target league allowlist", () => {
  it("contains exactly the configured approved labels", () => {
    const diagnostic = getLeaguePolicy();
    // Production policy can vary; this suite deliberately loads the fixed fixture.
    expect(TARGET_LEAGUES.map((target) => target.label)).toEqual(
      diagnostic.entries.map((entry) => entry.name),
    );
    expect(TARGET_LEAGUES).toHaveLength(diagnostic.total);
    expect(new Set(TARGET_LEAGUES.map((target) => target.label)).size).toBe(diagnostic.total);
    expect(diagnostic.entries.filter((entry) => !entry.custom)
      .every((entry) => entry.displayNameRu !== entry.name)).toBe(true);
    expect(diagnostic.rulesRu.every((rule) => /[А-Яа-яЁё]/u.test(rule))).toBe(true);
  });

  it("accepts named target leagues and rejects missing/country-only values", () => {
    expect(matchTargetLeague("Finland Kakkonen")).toBe("Finland Kakkonen D3");
    expect(matchTargetLeague("Singapore S-League")).toBe("Singapore S-League");
    expect(matchTargetLeague("Bangladesh Premier League")).toBe("Bangladesh Premier League");
    expect(matchTargetLeague("")).toBeNull();
    expect(matchTargetLeague(undefined)).toBeNull();
    expect(matchTargetLeague("Bhutan")).toBeNull();
    expect(matchTargetLeague("India")).toBeNull();
    expect(matchTargetLeague("Puerto Rico")).toBeNull();
    expect(isTargetLeague(null)).toBe(false);
  });

  it("does not broaden country/league patterns into women, youth, reserve, cups or siblings", () => {
    expect(matchTargetLeague("Finland Kakkonen Women")).toBeNull();
    expect(matchTargetLeague("Singapore Premier League")).toBe("Singapore S-League");
    expect(matchTargetLeague("Premier League Singapore")).toBe("Singapore S-League");
    expect(matchTargetLeague("S-League")).toBeNull();
    expect(matchTargetLeague("India Sikkim S-League")).toBeNull();
    expect(matchTargetLeague("Myanmar U19 League")).toBeNull();
    expect(matchTargetLeague("Paraguay Primera Division")).toBeNull();
    expect(matchTargetLeague("Bangladesh Premier League 2")).toBeNull();
    expect(matchTargetLeague("Bhutan Thimphu League")).toBeNull();
    expect(matchTargetLeague("India Shillong Women Premier League")).toBeNull();
  });

  it("allows only the explicitly named youth, reserve and cup exceptions", () => {
    expect(matchTargetLeague("Myanmar U21 League")).toBe("Myanmar U21 League");
    expect(matchTargetLeague("Paraguay Reserve Team League")).toBe("Paraguay Reserve Team League");
    expect(matchTargetLeague("FA Cup Malaysia")).toBe("FA Cup Malaysia");
    expect(matchTargetLeague("Malaysia")).toBe("Malaysia");
    expect(matchTargetLeague("Malaysia Cup")).toBe("Malaysia");
    expect(matchTargetLeague("Malaysia Premier League")).toBe("Malaysia");
    expect(matchTargetLeague("Malaysia Women Premier League")).toBe("Malaysia");
    expect(matchTargetLeague("Malaysia Liga M3")).toBe("Malaysia");
    expect(matchTargetLeague("Malaysia FA Cup Women")).toBe("FA Cup Malaysia");
    expect(matchTargetLeague("Paraguay Reserve Team Women")).toBeNull();
  });

  it("requires the named Bhutan, Shillong and Puerto Rico competitions", () => {
    expect(matchTargetLeague("Bhutan Premier League")).toBe("Bhutan Premier");
    expect(matchTargetLeague("Indian Shillong Premier League")).toBe("Indian Shillong Premier League");
    expect(matchTargetLeague("Puerto Rico League")).toBe("Puerto Rico League");
    expect(matchTargetLeague("Hong Kong Division 1")).toBe("Hong Kong 1st Division League");
    expect(matchTargetLeague("Hong Kong Division 2")).toBe("Hong Kong 2nd Division League");
    expect(matchTargetLeague("India I-League 2")).toBe("Indian I-League 2nd Division");
    expect(matchTargetLeague("Peru Liga 2")).toBe("Peruvian Segunda Division");
    expect(matchTargetLeague("Liga 2 Peru")).toBe("Peruvian Segunda Division");
    expect(matchTargetLeague("Bhutan Thimphu League")).toBeNull();
    expect(matchTargetLeague("Puerto Rico U21")).toBeNull();
    expect(matchTargetLeague("Puerto Rico Premier League")).toBeNull();
  });

  it("accepts the requested South American lower and state competitions", () => {
    expect(matchTargetLeague("Bolivia División Profesional")).toBe("Bolivian Liga de Futbol Profesional");
    expect(matchTargetLeague("Bolivia Copa Simón Bolívar")).toBe("Bolivian Copa Simon Bolivar");
    expect(matchTargetLeague("Brazil Campeonato Paulista Série A3")).toBe("Brazilian Paulista A3");
    expect(matchTargetLeague("Brasil Paulista A4")).toBe("Brazilian Paulista A4");
    expect(matchTargetLeague("Brazil Campeonato Carioca B1")).toBe("Brazilian Carioca B1");
    expect(matchTargetLeague("Brasil Carioca Série B2")).toBe("Brazilian Carioca B2");
    expect(matchTargetLeague("Brazil Copa Paulista")).toBe("Brazilian State Cups");
    expect(matchTargetLeague("Argentina Primera C Metropolitana")).toBe("Argentinian Primera C Metropolitana");
    expect(matchTargetLeague("Argentina Primera D")).toBe("Argentinian Primera D");
    expect(matchTargetLeague("Argentina Torneo Federal A")).toBe("Argentinian Torneo Federal A");
    expect(matchTargetLeague("Colombia Primera B")).toBe("Colombian Primera B");

    expect(matchTargetLeague("Bolivia Primera Division")).toBeNull();
    expect(matchTargetLeague("Brazil Campeonato Paulista A2")).toBeNull();
    expect(matchTargetLeague("Brazil Campeonato Carioca A1")).toBeNull();
    expect(matchTargetLeague("Brazil Copa do Brasil")).toBeNull();
    expect(matchTargetLeague("Argentina Primera Division")).toBeNull();
    expect(matchTargetLeague("Colombia Primera A")).toBeNull();
  });

  it("accepts the requested Southeast Asian competitions without admitting top-tier siblings", () => {
    expect(matchTargetLeague("Vietnam V-League 2")).toBe("Vietnam V-League 2");
    expect(matchTargetLeague("Vietnam U19 National Championship")).toBe("Vietnam U19 Championship");
    expect(matchTargetLeague("Vietnam U21 Championship")).toBe("Vietnam U21 Championship");
    expect(matchTargetLeague("Indonesia Liga 2")).toBe("Indonesia Liga 2");
    expect(matchTargetLeague("Liga 3 Indonesia")).toBe("Indonesia Liga 3");
    expect(matchTargetLeague("Philippines Football League")).toBe("Philippines National/Premier League");
    expect(matchTargetLeague("Philippines Premier League")).toBe("Philippines National/Premier League");

    // Malaysia remains the deliberate all-competitions country exception.
    expect(matchTargetLeague("Malaysia National Premier League")).toBe("Malaysia");
    expect(matchTargetLeague("Vietnam V-League 1")).toBeNull();
    expect(matchTargetLeague("Vietnam U17 Championship")).toBeNull();
    expect(matchTargetLeague("Indonesia Liga 1")).toBeNull();
    expect(matchTargetLeague("Philippines Women's Premier League")).toBeNull();
  });

  it("accepts only the named Australian NPL states", () => {
    expect(matchTargetLeague("Australia NPL Victoria")).toBe("Australia NPL Victoria");
    expect(matchTargetLeague("Australia NPL NSW")).toBe("Australia NPL New South Wales");
    expect(matchTargetLeague("Australia Queensland Premier League")).toBe("Australia NPL Queensland");
    expect(matchTargetLeague("Australia A-League")).toBeNull();
    expect(matchTargetLeague("Australia NPL Western Australia")).toBeNull();
    expect(matchTargetLeague("Australia NPL Victoria Women")).toBeNull();
    expect(matchTargetLeague("NPL Queensland")).toBeNull();
  });

  it("accepts requested European lower leagues, subdivisions and winter cups", () => {
    expect(matchTargetLeague("Greece Super League 2")).toBe("Greece Super League 2");
    expect(matchTargetLeague("Serbia Prva Liga")).toBe("Serbia Prva Liga");
    expect(matchTargetLeague("North Macedonia Prva Liga")).toBe("North Macedonia Prva Liga");
    expect(matchTargetLeague("Bulgaria Vtora Liga")).toBe("Bulgaria Second League");
    expect(matchTargetLeague("България Втора лига")).toBe("Bulgaria Second League");
    expect(matchTargetLeague("Czech Republic 3. Liga")).toBe("Czech 3 Liga");
    expect(matchTargetLeague("Czechia Moravskoslezská fotbalová liga")).toBe("Czech MSFL");
    expect(matchTargetLeague("Czech Republic ČFL")).toBe("Czech CFL");
    expect(matchTargetLeague("Slovakia 3 Liga")).toBe("Slovakia 3 Liga");
    expect(matchTargetLeague("Czechia Tipsport Liga")).toBe("Czech Winter Cup");
    expect(matchTargetLeague("Slovakia Winter Cup")).toBe("Slovakia Winter Cup");

    expect(matchTargetLeague("Greece Super League 1")).toBeNull();
    expect(matchTargetLeague("Serbia Super Liga")).toBeNull();
    expect(matchTargetLeague("North Macedonia Second League")).toBeNull();
    expect(matchTargetLeague("Bulgaria First League")).toBeNull();
    expect(matchTargetLeague("Czech Republic 2 Liga")).toBeNull();
    expect(matchTargetLeague("Slovakia Super Liga")).toBeNull();
    expect(matchTargetLeague("Tipsport Liga")).toBeNull();
  });

  it("accepts anchored international friendlies and age-league names", () => {
    expect(matchTargetLeague("International Club Friendlies")).toBe("International Club Friendlies");
    expect(matchTargetLeague("Club Friendly")).toBe("International Club Friendlies");
    expect(matchTargetLeague("International U19 League")).toBe("U19 League");
    expect(matchTargetLeague("U21 Football League")).toBe("U21 League");
    expect(matchTargetLeague("U-23 League")).toBe("U23 League");

    expect(matchTargetLeague("International Friendly")).toBeNull();
    expect(matchTargetLeague("International Women Club Friendlies")).toBeNull();
    expect(matchTargetLeague("U17 League")).toBeNull();
    expect(matchTargetLeague("England U21 Premier League")).toBeNull();
    expect(matchTargetLeague("U23 League Cup")).toBeNull();
  });
});