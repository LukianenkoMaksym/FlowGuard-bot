import { describe, expect, it } from "vitest";
import { getRuntimeAudit, type RuntimeAuditScannerRow } from "./runtimeAudit";
import type { NormalizedEntry } from "./watchlist";

const watch = (
  signature: string,
  matchId?: string,
  league?: string,
): NormalizedEntry => ({
  label: matchId ? `Watch ${matchId}` : `Text ${signature}`,
  fragments: ["team"],
  matchId,
  league,
  origin: "manual",
  signature,
});

const tracked = (
  nowGoalMatchId: string,
  overrides: Partial<RuntimeAuditScannerRow> = {},
): RuntimeAuditScannerRow => ({
  nowGoalMatchId,
  hasMeta: true,
  matchName: `Home ${nowGoalMatchId} vs Away`,
  leagueName: "Any league",
  score: "1-0",
  elapsedTime: "55'",
  matchPhase: "Live",
  excapperMatchId: null,
  ...overrides,
});

it("honors durable manual verification without inventing an Excapper id or live facts", () => {
  const result = getRuntimeAudit({
    watchlist: [watch("id:3094867", "3094867")],
    scanner: [tracked("3094867", { score: null, elapsedTime: null })],
    diagnosticStatus: () => "bound_verified",
  });
  expect(result.matches[0]).toMatchObject({
    status: "Verified", excapperMatchId: null, score: null, elapsedTime: null,
  });
});

describe("runtime audit", () => {
  it("unions only current live rows and retains configured counts separately", () => {
    const result = getRuntimeAudit({
      watchlist: [watch("id:1", "1"), watch("txt:hidden", undefined, undefined)],
      scanner: [
        tracked("1"),
        tracked("2", {
          hasMeta: false,
          matchName: null,
          leagueName: null,
          score: null,
          elapsedTime: null,
          matchPhase: "Unknown",
        }),
      ],
      diagnosticStatus: () => "pending",
      generatedAt: "2026-01-01T00:00:00.000Z",
    });

    expect(result.watchlistTotal).toBe(1);
    expect(result.configuredWatchlistTotal).toBe(2);
    expect(result.total).toBe(1);
    expect(result.matches.find((row) => row.nowGoalMatchId === "2")).toBeUndefined();
    expect(result.matches.some((row) => row.key === "watchlist:txt:hidden")).toBe(false);
  });

  it("deduplicates only accepted actual ids and reports verified/review status", () => {
    const result = getRuntimeAudit({
      watchlist: [
        watch("id:10", "10"),
        watch("txt:bound"),
        watch("txt:same-name"),
        watch("txt:review"),
      ],
      scanner: [
        tracked("10", { excapperMatchId: "ex-10" }),
        tracked("20", { matchName: "Text txt:same-name" }),
      ],
      textBinding: (signature) => signature === "txt:bound" ? "ex-10" : null,
      diagnosticStatus: (id) =>
        id === "manual-text:txt:review" ? "ambiguous_identity" : "pending",
    });

    // id:10 and txt:bound collapse through the actual Excapper id. The
    // same-name text row remains independent because names are never fuzzy keys.
    expect(result.total).toBe(2);
    expect(result.matches.filter((row) => row.excapperMatchId === "ex-10")).toHaveLength(1);
    expect(result.matches.find((row) => row.excapperMatchId === "ex-10")?.status).toBe("Verified");
    expect(result.matches.find((row) => row.key === "watchlist:txt:review")?.status)
      .toBeUndefined();
    expect(result.matches.some((row) => row.key === "watchlist:txt:same-name")).toBe(false);
  });

  it("excludes unresolved configuration and metadata-less states from active counts", () => {
    const reviewStatuses = [
      "source_unavailable",
      "no_directory_match",
      "non_live_candidate",
      "empty_market",
      "fetch_failed",
      "bound_pending",
    ];
    for (const diagnostic of reviewStatuses) {
      const result = getRuntimeAudit({
        watchlist: [watch("id:31", "31")],
        scanner: [],
        diagnosticStatus: () => diagnostic,
      });
      expect(result.matches, diagnostic).toHaveLength(0);
      expect(result.configuredWatchlistTotal).toBe(1);
    }
    const noMeta = getRuntimeAudit({
      scanner: [tracked("32", { hasMeta: false, matchName: null })],
      diagnosticStatus: () => "fetch_failed",
    });
    expect(noMeta.matches).toHaveLength(0);
  });

  it("never merges two different NowGoal ids through a shared Excapper id", () => {
    const result = getRuntimeAudit({
      scanner: [
        tracked("41", { excapperMatchId: "shared-binding" }),
        tracked("42", { excapperMatchId: "shared-binding" }),
      ],
      diagnosticStatus: () => "hydrated",
    });
    expect(result.total).toBe(2);
    expect(result.matches.map((row) => row.nowGoalMatchId).sort()).toEqual(["41", "42"]);
  });
});