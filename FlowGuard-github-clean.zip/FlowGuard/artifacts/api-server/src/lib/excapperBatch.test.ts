import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  __testOnlyResetExcapperBatchCache,
  getExcapperBatchStatus,
  loadExcapperBatchSnapshot,
  parseExcapperBatchDetails,
  parseExcapperStructuredRows,
} from "./excapperBatch";

beforeEach(() => {
  __testOnlyResetExcapperBatchCache();
  vi.useRealTimers();
});

const batch = JSON.stringify({
  events: [
    {
      gameId: "101", homeTeam: "Alpha", awayTeam: "Beta", league: "League",
      isLive: true, score: "2-1", period: "2nd", elapsed: 67,
      markets: [{ line: 2.5, over: 1200, under: 800 }],
    },
    {
      gameId: "102", homeTeam: "Gamma", awayTeam: "Delta", league: "League",
      status: "scheduled",
    },
  ],
});

describe("Excapper root batch", () => {
  it("parses raw JSON identities and game-scoped detail without HTML", () => {
    expect(parseExcapperStructuredRows(batch)).toEqual([
      expect.objectContaining({ gameId: "101", team1: "Alpha", activity: "live" }),
      expect.objectContaining({ gameId: "102", team1: "Gamma", activity: "scheduled" }),
    ]);
    expect(parseExcapperBatchDetails(batch, 123).get("101")).toEqual({
      gameId: "101",
      score: { home: 2, away: 1 },
      period: "second-half",
      minute: 67,
      markets: [{ line: 2.5, over: 1200, under: 800, collectedAt: 123 }],
    });
  });

  it("coalesces manual and coordinator consumers into one root request", async () => {
    let release!: (value: string) => void;
    const load = vi.fn(() => new Promise<string>((resolve) => { release = resolve; }));
    const first = loadExcapperBatchSnapshot(load, parseExcapperStructuredRows);
    const second = loadExcapperBatchSnapshot(load, parseExcapperStructuredRows);
    expect(load).toHaveBeenCalledOnce();
    release(batch);
    const [a, b] = await Promise.all([first, second]);
    expect(a.observedAt).toBe(b.observedAt);
    expect(a.rows).toHaveLength(2);
  });

  it("schedules the next shared root fetch at 12 seconds plus 300-800ms jitter", async () => {
    const random = vi.spyOn(Math, "random")
      .mockReturnValueOnce(0)
      .mockReturnValueOnce(500 / 501);
    const first = await loadExcapperBatchSnapshot(
      async () => batch,
      parseExcapperStructuredRows,
    );
    expect(getExcapperBatchStatus().nextFetchAt! - first.observedAt).toBe(12_300);
    __testOnlyResetExcapperBatchCache();
    const second = await loadExcapperBatchSnapshot(
      async () => batch,
      parseExcapperStructuredRows,
    );
    expect(getExcapperBatchStatus().nextFetchAt! - second.observedAt).toBe(12_800);
    random.mockRestore();
  });

  it("returns the same observed snapshot inside the cadence and marks fallback stale", async () => {
    const load = vi.fn()
      .mockResolvedValueOnce(batch)
      .mockRejectedValueOnce(new Error("429"));
    const first = await loadExcapperBatchSnapshot(load, parseExcapperStructuredRows);
    const repeated = await loadExcapperBatchSnapshot(load, parseExcapperStructuredRows);
    expect(repeated.observedAt).toBe(first.observedAt);
    expect(load).toHaveBeenCalledOnce();

    vi.useFakeTimers();
    vi.setSystemTime(first.observedAt + 13_000);
    const stalePromise = loadExcapperBatchSnapshot(load, parseExcapperStructuredRows);
    await vi.runAllTimersAsync();
    const stale = await stalePromise;
    expect(stale.stale).toBe(true);
    expect(stale.observedAt).toBe(first.observedAt);
    expect(getExcapperBatchStatus()).toMatchObject({
      stale: true, observedAt: first.observedAt, detailCapable: true,
    });
  });

  it("does not infer detail capability from identity-only root HTML", async () => {
    const root = `<div id="live"><table><tr class="a_link" game_id="77">
      <td>12:00</td><td>TH</td><td>League</td><td>Home - Away</td><td>10 €</td>
    </tr></table></div>`;
    const snapshot = await loadExcapperBatchSnapshot(
      async () => root,
      () => [{ gameId: "77" }],
    );
    expect(snapshot.detailCapable).toBe(false);
    expect(snapshot.details.size).toBe(0);
  });
});