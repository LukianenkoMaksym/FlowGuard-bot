import { matchTargetLeague } from "./targetLeagues";

export const TUNER_DAY_MS = 24 * 60 * 60 * 1000;
export interface TunerAdjustment {
  at: string;
  oldThreshold: number;
  newThreshold: number;
  winRatePct: number;
  sampleSize: number;
}
export interface TunerMetadata {
  enabled: boolean;
  pausedUntil: string | null;
  lastAdjustment: TunerAdjustment | null;
}
export const defaultTunerMetadata = (): TunerMetadata => ({
  enabled: false, pausedUntil: null, lastAdjustment: null,
});

export interface TrainingRow {
  id: number;
  matchId: string;
  team1: string;
  team2: string;
  league: string;
  anomalyType: string;
  targetSide: string;
  line: number;
  status: string;
  createdAt: Date;
  resolvedAt: Date | null;
}

/** Exact fixture pair and explicit marker tokens, not arbitrary name substrings. */
export function isTestOrigin(row: TrainingRow): boolean {
  const teams = [row.team1.trim().toLowerCase(), row.team2.trim().toLowerCase()].sort();
  if (teams[0] === "alpha" && teams[1] === "beta") return true;
  return [row.matchId, row.team1, row.team2, row.league].some(
    (value) => /(?:^|[\s:_|/-])(?:test(?:\d+)?|fixture(?:\d+)?|synthetic|mock)(?:$|[\s:_|/-])/i.test(value),
  );
}

/** Same legacy 15-minute display buckets as history; collapse BEFORE last 60. */
export function selectTunerSample(rows: TrainingRow[], now: number): TrainingRow[] {
  const buckets = new Map<string, TrainingRow>();
  for (const row of rows) {
    const created = row.createdAt?.getTime();
    const resolved = row.resolvedAt?.getTime();
    if (row.anomalyType !== "ODDS_DROP" || !["WIN", "LOSS"].includes(row.status) ||
        !Number.isFinite(created) || resolved == null || !Number.isFinite(resolved) ||
        resolved > now || resolved < created || isTestOrigin(row) || !matchTargetLeague(row.league)) continue;
    const key = JSON.stringify([row.matchId, row.anomalyType, row.targetSide, row.line, Math.floor(created / 900_000)]);
    const old = buckets.get(key);
    if (!old || created < old.createdAt.getTime() || (created === old.createdAt.getTime() && row.id < old.id)) {
      buckets.set(key, row);
    }
  }
  return [...buckets.values()].sort((a, b) =>
    b.resolvedAt!.getTime() - a.resolvedAt!.getTime() || b.id - a.id,
  ).slice(0, 60);
}

export function tunerDecision(threshold: number, sampleSize: number, winRatePct: number | null) {
  if (sampleSize < 40 || winRatePct === null) return { next: threshold, reason: "Collecting settled signals." };
  if (!Number.isFinite(threshold) || threshold < 0.15 || threshold > 1) {
    return { next: threshold, reason: "Manual dropThreshold is outside tuner bounds (0.15–1.00); holding." };
  }
  const delta = winRatePct >= 60 ? -0.05 : winRatePct < 45 ? 0.05 : 0;
  const next = Math.round(Math.max(0.15, Math.min(1, threshold + delta)) * 1000000) / 1000000;
  // Rounding must never turn an arbitrary manual precision into a >0.05 step.
  if (Math.abs(next - threshold) > 0.050000000001) return { next: threshold, reason: "Step would exceed 0.05; holding." };
  return { next, reason: next === threshold ? "Win rate is neutral or threshold is at its bound; holding." : null };
}