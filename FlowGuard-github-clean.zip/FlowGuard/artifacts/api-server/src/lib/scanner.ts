import { logger } from "./logger";
import { normalizedTeamName } from "./teamIdentity";
import { sendTelegram, isTelegramConfigured, escapeMdV2 } from "./telegram";
import { isMajorLeague, isLowLiquidityLeague } from "./leagues";
import { endpointsFor, currentBaseUrl, tryFailover, getFailoverState, withCacheBuster, EXTRA_BOOK_KEYS, type ExtraBookKey, type UpstreamFetchDetails } from "./upstream";
import { fetchVcbetBatch, probeVcbet } from "./vcbetPerMatch";
import {
  USER_AGENT_POOL,
  NOWGOAL_REFERERS,
  NOWGOAL_VOLATILITY_MIN_SUCCESSFUL_SAMPLES,
  NOWGOAL_VOLATILITY_STALE_WINDOW_MS,
  NOWGOAL_AUTO_SWITCH_COOLDOWN_MS,
  nowgoalMatchUrl,
} from "./config";
import {
  startWatchdog,
  stopWatchdog,
  validateUpstream,
  noteLiveCount,
  getLastValidation,
  getWatchdogState,
} from "./healthcheck";
import { initWatchlist, matchesWatchlist, getWatchlistSnapshot, getNormalizedEntries } from "./watchlist";
import { getVolumeConfig } from "./volumeConfig";
import { computeSignal } from "./signalScore";
import {
  recordAnomaly,
  computeWinRateForMatch,
  parseMatchMinute,
  passesValueGuards,
} from "./winRate";
import { getControls } from "./controls";
import { getTelegramPollingMode } from "./telegramBot";
import { matchTargetLeague, getLeaguePolicy } from "./targetLeagues";
import { parseLiveDirectory, type DiscoveryCandidate } from "./liveDiscovery";
import { selectLiveVerificationIds } from "./liveVerification";
import {
  claimUnifiedAlertEvent,
  releaseUnifiedAlertEvent,
  formatUnifiedAlert,
  getRecentUnifiedInflow,
  recordUnifiedInflow,
  ODDS_DROP_WINDOW_MS,
  resolvePositiveOddsDrop,
  resolveUnifiedAlertMinute,
  normalizeFixtureClock,
  resetUnifiedAlertStateForTests,
  type UnifiedAlertInput,
  type UnifiedOddsPoint,
} from "./unifiedAlert";
import { getCachedBookMovements } from "./radarBookMarkets";

/**
 * Exact user-pasted numeric ids are the only watchlist entries allowed to
 * bypass the automated target-league gate. Existing test/config entries that
 * predate provenance have no origin field and are treated as manual by
 * watchlist.ts for backwards compatibility.
 */
function isManualWatchlistId(matchId: string): boolean {
  return getNormalizedEntries().some(
    (entry) =>
      entry.matchId === matchId &&
      (entry.origin === undefined || entry.origin === "manual"),
  );
}

// ----- Endpoints (resolved per-tick from current base URL via upstream.ts) -----
const BENCHMARK_NAME = "Crown";
const CORNER_XML_URL: string | null = null; // not available on this mirror

// ----- Timings -----
// Priority-pool cadence: every tick is a "priority pass" for watchlist
// matches. Non-watchlist matches piggyback but are throttled (see
// GLOBAL_POOL_INTERVAL_MS) so we don't melt the CPU at 400+ concurrent games.
export const POLL_INTERVAL_MS = 12_000;
export const POLL_JITTER_MS = 2_000;
// HYBRID ARCHITECTURE:
// When the user has matches in the watchlist, the tick scheduler compresses
// to this interval so watchlist matches refresh every ~12s. The
// global non-priority pool stays gated by GLOBAL_POOL_INTERVAL_MS (50s), so
// 24/7 discovery scanning is NOT accelerated — only watchlist analysis is.
// This gives the user instant volatility tracking on their picks without
// melting upstream with 5× the global match analysis load.
// Empty watchlist ⇒ tick falls back to POLL_INTERVAL_MS (no need to hammer
// the source when no one is watching anything specific).
export const WATCHLIST_FAST_POLL_INTERVAL_MS = 12_000;
// HYPER-FOCUS cadence — only used when the user has paused the global
// background scanner via POST /api/scanner/toggle. With the global pool
// disabled we skip bench + meta bulk fetches and ALL non-watchlist
// processing, so the upstream cost-per-tick drops dramatically and we can
// safely poll the single remaining primaryOu endpoint every ~12s without
// risking rate limits.
export const WATCHLIST_HYPER_POLL_INTERVAL_MS = 12_000;
// Global pool: each non-priority live match gets re-analyzed at most every
// ~50s. Catches massive anomalies without per-tick processing of every game.
const GLOBAL_POOL_INTERVAL_MS = 50_000;
// Hard cap on non-priority matches analyzed per tick. Priority (watchlist)
// matches bypass this cap entirely. Protects the Reserved VM from drowning
// when the feed swells past 400+ concurrent live games.
const MAX_CONCURRENT_LIVE_MATCHES = 60;
// Pre-match loop runs at this cadence — much slower than the live loop.
// Refreshes the league-name cache + meta-only sanity probe.
const PREMATCH_TICK_MS = 5 * 60 * 1000;
// Per-match data-recency tracker. A live match should see odds movement well
// within this window; if >STALE_RATIO_TRIGGER of live matches go silent for
// longer than this, the mirror is almost certainly serving stale cached data
// and we trigger an immediate force-failover (independent of the per-tick
// volatility signature check, which only catches whole-feed freezes).
const MATCH_STALE_AFTER_MS = 5 * 60 * 1000;
const STALE_RATIO_TRIGGER = 0.20;     // 20% of live matches stale → rotate
const STALE_RATIO_MIN_SAMPLE = 25;    // require at least this many live matches before the ratio check arms
// Per-attempt HTTP timeout. The old 3.5s budget was short enough to turn normal
// NowGoal edge/CDN jitter into a fetch AbortError on an otherwise healthy
// mirror. Keep the timeout bounded, but give the upstream enough time to serve
// the six-book snapshot during a busy in-play window.
export const HTTP_REQUEST_TIMEOUT_MS = 6_000;
// A 429/5xx response may be retried twice. Bound the complete fetchRaw call as
// well as each individual attempt so retries cannot turn one tick into an
// unbounded wait. The tick scheduler remains independent of this deadline.
export const HTTP_REQUEST_TOTAL_TIMEOUT_MS = 12_000;
// Optional books are deliberately shorter than the core feeds and are
// all-settled: a slow Sbobet/M88/12Bet/18Bet/VSBet must never discard a healthy
// Bet365 primary snapshot.
export const EXTRA_BOOK_TIMEOUT_MS = 7_000;
const LEAGUE_REFRESH_MS = 60 * 1000;
const ALERT_COOLDOWN_MS = 2 * 60 * 1000;
/** Suppress odds-drop alerts for this long after a goal is detected.
 * Goal-driven repricing inside the 5-min drop window looks exactly like
 * smart-money inflow -- this blackout lets the market settle first. */
export const GOAL_BLACKOUT_MS = 90 * 1000;
const HISTORY_WINDOW_MS = 4 * 60 * 1000;  // pressure + benchmark lookback
const HISTORY_RETENTION_MS = 6 * 60 * 1000;

// ----- Resilience: UA & Referer rotation -----
// Pools live in `config.ts`; local aliases keep the rest of this file unchanged.
const USER_AGENTS = USER_AGENT_POOL;
const REFERERS = NOWGOAL_REFERERS;

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function buildHeaders(): Record<string, string> {
  return {
    "User-Agent": pick(USER_AGENTS),
    Referer: pick(REFERERS),
    "X-Requested-With": "XMLHttpRequest",
    "Accept-Encoding": "gzip",
    Accept: "application/json, text/javascript, */*; q=0.01",
    // Realistic browser fingerprint to reduce bot-detection. UA + Referer are
    // already rotated above; these two round out a typical Chrome request.
    // NOTE: undici (Node's fetch) manages keep-alive itself and may drop the
    // Connection header — it's set for parity/log realism, not to force pooling.
    "Accept-Language": "en-US,en;q=0.9",
    Connection: "keep-alive",
  };
}

// ----- Config -----
export interface ScannerConfig {
  /** Minimum primary Over-odds drop between consecutive ticks to consider an alert. */
  dropThreshold: number;
  /** Hard discard: |Over - Under| > this means low liquidity, alert dropped. */
  maxSpread: number;
  /** Spread must be ≤ this for "tight density" confidence bonus. */
  tightSpread: number;
  /** Benchmark Over decimal must drop ≥ this within window to count as "dropping". */
  benchmarkConfirmDrop: number;
  /** Reject alerts whose computed confidence score is below this (1..10). */
  minConfidence: number;
  /** Apply the market-density (max spread) gate. When false, only the absurd-spread cap applies. */
  requireDensity: boolean;
  /** League IDs to always track even if classified as a major league. */
  priorityLeagueIds: string[];
  /** Relaxed max spread for low-liquidity regions (S. America lower / C. America / Africa). */
  lowLiqMaxSpread: number;
  /** Drop magnitude that bypasses the spread gate entirely (used for fixed-match-style moves). */
  bypassSpreadOnBigDrop: number;
  /** Hard ceiling: spread above this is always rejected (likely broken / data error). */
  absurdSpreadCap: number;
  /**
   * HYBRID LIQUIDITY GATE (operator-controlled, default off).
   * When true, the per-match drop+alert pipeline is short-circuited for any
   * match whose latest Excapper volume sample fails the `minCumulativeEur`
   * threshold — UNLESS the match is on the watchlist (priority matches
   * always run full evaluation). When false, odds-drop and volume alerts
   * stay independent (legacy behaviour — no alerts go silent).
   * Saves the cost of evalBenchmark + computeConfidence + alert emission
   * on dead markets when on.
   */
  requireLiquidityConfirmation: boolean;
}

export const config: ScannerConfig = {
  dropThreshold: 0.40,
  maxSpread: 0.50,
  tightSpread: 0.15,
  benchmarkConfirmDrop: 0.05,
  minConfidence: 5, // 5/10 = early-bird threshold
  requireDensity: true,
  requireLiquidityConfirmation: false,
  // User-requested 24/7 priority targets (2026-05-16). Three of these
  // (MLS=21, Liga MX=140, J1=18) are classified as MAJOR leagues and would
  // normally be filtered out; listing them here forces the scanner to track
  // them anyway. The others (Chinese Super League, Allsvenskan, Eliteserien,
  // Brazil Serie B, Colombia Primera A) are already tracked globally — being
  // here just marks them as user-prioritized for telemetry / future tiering.
  priorityLeagueIds: [
    "21",   // USA MLS
    "140",  // Mexico Liga MX
    "18",   // Japan J1 League
    "60",   // China Super League (off-season at probe time; speculative ID kept for when feed re-includes it)
    "26",   // Sweden Allsvenskan
    "22",   // Norway Eliteserien
    "358",  // Brazil Serie B
    "250",  // Colombia Primera A
  ],
  lowLiqMaxSpread: 1.00,        // ~2× normal cap for regional volatile markets
  bypassSpreadOnBigDrop: 0.80,  // 2× the default drop threshold
  absurdSpreadCap: 1.50,        // anything wider is almost certainly a broken quote
};

/** Keep the exported config object's identity stable for existing scanner readers. */
export function getScannerConfig(): ScannerConfig {
  return { ...config, priorityLeagueIds: [...config.priorityLeagueIds] };
}

export function setScannerConfig(next: ScannerConfig): void {
  Object.assign(config, next, { priorityLeagueIds: [...next.priorityLeagueIds] });
}

// ----- Internal state -----
interface MatchMeta {
  evidenceVersion?: number;
  team1: string;
  team2: string;
  leagueId: string;
  /** Optional source-resolved league label for alternate/test feeds. */
  leagueName?: string;
  homeScore: number;
  awayScore: number;
  isLive: boolean;
  /** Explicit type=11 state when available; absent for kickoff-window inference. */
  state?: number | null;
  /** Absolute kickoff epoch ms (GMT+8→UTC normalized); null when unparseable. */
  kickoffMs: number | null;
  /** Literal clock/phase observed in the fixture header; never estimated. */
  clockLabel?: string | null;
}

interface OUSnapshot {
  ts: number;
  overDecimal: number;
  underDecimal: number;
  line: number;
}

interface BenchmarkSnapshot {
  ts: number;
  overDecimal: number;
  underDecimal: number;
  line: number;
}

/**
 * Per-Excapper-line volume sample. We track one entry per OU line (0.5,
 * 1.5, 2.5, ...) so a single match can carry parallel smart-money signals
 * on multiple totals markets simultaneously (e.g. spike on Over 2.5 AND
 * Over 3.5 at the same time).
 */
interface VolumeSample {
  over: number;
  under: number;
  overPrev?: number;
  underPrev?: number;
  updatedAt: number;
  prevAt?: number;
  // Spike = native-feed EUR delta > 2,000 within ~60s while Bet365 hasn't
  // moved. Auto-clears in buildLive when odds catch up or after 90s.
  overSpikeAt?: number;
  underSpikeAt?: number;
}

/**
 * Source attribution + override telemetry per match. NONE of these fields
 * accumulate arrays — they are scalar timestamps / counters, capped O(1)
 * per match. Used by Branch B (alt-mirror stream) and the Sofascore score
 * watchdog to surface what touched the row last without growing memory.
 */
interface SourceAttribution {
  /** Last time the alt-mirror branch refreshed odds for this match. */
  lastAltOddsAt: number | null;
  /** Last time the Sofascore watchdog reconciled the score. */
  lastScoreCheckAt: number | null;
  /** Last time the Sofascore watchdog actively overrode a frozen score. */
  lastScoreOverrideAt: number | null;
  /** Cumulative override count for telemetry. */
  scoreOverrides: number;
}

interface MatchState {
  history: OUSnapshot[];
  benchmarkHistory: BenchmarkSnapshot[];
  /**
   * Per-book OU history for the static NOWGOAL stack books beyond Bet365
   * (primary) and Crown (benchmark). Lazy-initialized on first push so the
   * existing MatchState init sites stay untouched. Each book tracks its OWN
   * line + odds independently — books often quote different handicaps in
   * live, and we want to surface that divergence in the UI rather than
   * gate everything to Bet365's line.
   *
   * Reused `BenchmarkSnapshot` shape (ts/line/overDecimal/underDecimal)
   * so the existing `pruneHistory()` helper works without changes.
   */
  bookHistory?: Map<ExtraBookKey, BenchmarkSnapshot[]>;
  /**
   * Last time the PRIMARY tick loop actually visited this match (regardless
   * of whether odds changed). This is the authoritative freshness signal
   * the alt-mirror branch uses to decide whether to overwrite — anchoring
   * on `lastOddsChangeAt` would incorrectly treat a quiet but freshly-
   * ticked match as stale during low-volatility windows.
   */
  lastPrimaryTickAt?: number;
  /** Optional per-source attribution (lazy-initialized on first cross-stream touch). */
  attribution?: SourceAttribution;
  // ----- EXCAPPER VOLUME (Betfair-exchange smart-money flow) -----
  // Populated by lib/excapper.ts every ~35s for watchlist matches that we
  // can fuzzy-map to an Excapper game_id. Keyed by Excapper integer .5
  // line. Multi-line: lets us surface a Over-2.5 spike independently from
  // a concurrent Over-3.5 spike on the same match.
  volumes?: Map<number, VolumeSample>;
  excapperGameId?: string;
  lastAlertAt: number;
  /** Match-wide SMART MONEY admission; independent of Excapper money events. */
  oddsDropAlertInFlight?: boolean;
  // When the primary OU snapshot last actually moved (line or odds value
  // changed). Used by the stale-ratio watchdog to detect mirrors that are
  // serving cached data per-match instead of whole-feed.
  lastOddsChangeAt: number;
  /** When the live score last changed (goal detected on the tick meta).
   * Used by the goal-blackout gate in evaluateOddsDropAlert. */
  lastScoreChangeAt?: number;
  // When this match was last fully analyzed (drop math + alert pipeline).
  // Used to throttle the global pool — non-priority matches are skipped if
  // analyzed within GLOBAL_POOL_INTERVAL_MS.
  lastAnalyzedAt: number;
  // Most recent meta we saw for this match. Stored so the dashboard's
  // watchlist endpoint can render team names + scores + league without
  // re-fetching, and so URL "match #12345" lookups can resolve to teams.
  lastMeta?: {
    team1: string;
    team2: string;
    leagueId: string;
    leagueName: string;
    homeScore: number;
    awayScore: number;
    isLive: boolean;
    /** Raw authoritative type=11 state, or null when live status is inferred. */
    state?: number | null;
    liveStateSource?: "explicit" | "inferred";
    /** Absolute kickoff epoch ms; null when the feed didn't expose one. */
    kickoffMs: number | null;
    clockLabel?: string | null;
    updatedAt: number;
  };
}

const matchStates = new Map<string, MatchState>();
// Discovery-only metadata for RADAR 1X2 fixtures absent from the OU feed.
// The radar must verify the actual type=11 live state before any 1X2 alert;
// these candidates never feed SMART MONEY, tuner, or scanner odds history.
const radarOneX2Candidates = new Map<string, {
  meta: NonNullable<MatchState["lastMeta"]>;
  lastScoreChangeAt: number | null;
}>();
/** Detached, authentic primary-feed observations for the read-only radar.
 * No caller can modify scanner history or metadata through this snapshot. */
export function getOddsRadarSnapshot(): Array<{
  matchId: string;
  meta: NonNullable<MatchState["lastMeta"]>;
  current: OUSnapshot;
  history: OUSnapshot[];
  lastScoreChangeAt: number | null;
}> {
  const result: Array<{
    matchId: string;
    meta: NonNullable<MatchState["lastMeta"]>;
    current: OUSnapshot;
    history: OUSnapshot[];
    lastScoreChangeAt: number | null;
  }> = [];
  for (const [matchId, state] of matchStates) {
    const current = state.history[state.history.length - 1];
    if (current && state.lastMeta) result.push({
      matchId, meta: { ...state.lastMeta }, current: { ...current },
      history: state.history.map((point) => ({ ...point })),
      lastScoreChangeAt: state.lastScoreChangeAt ?? null,
    });
  }
  return result;
}
/** Independent read-only fixture list for Bet365 1X2 RADAR. An active
 * fixture may have no Bet365 totals market; never require OU for 1X2. */
export function getOddsRadarFixtureSnapshot(): Array<{
  matchId: string;
  meta: NonNullable<MatchState["lastMeta"]>;
  lastScoreChangeAt: number | null;
  needsVerification?: boolean;
}> {
  const result: Array<{
    matchId: string;
    meta: NonNullable<MatchState["lastMeta"]>;
    lastScoreChangeAt: number | null;
    needsVerification?: boolean;
  }> = [];
  for (const [matchId, state] of matchStates) {
    if (state.lastMeta) result.push({
      matchId, meta: { ...state.lastMeta },
      lastScoreChangeAt: state.lastScoreChangeAt ?? null,
    });
  }
  for (const [matchId, candidate] of radarOneX2Candidates) {
    if (!matchStates.has(matchId) && Date.now() - candidate.meta.updatedAt <= 2 * 60_000) {
      result.push({
        matchId, meta: { ...candidate.meta },
        lastScoreChangeAt: candidate.lastScoreChangeAt,
        needsVerification: true,
      });
    }
  }
  return result;
}
/** Every metadata writer (including score-only corrections) goes through this
 * gate so a newly observed goal cannot miss the odds-drop blackout. */
function updateLastMetaWithScoreTracking(
  state: MatchState,
  meta: NonNullable<MatchState["lastMeta"]>,
  now: number,
): void {
  const previous = state.lastMeta;
  if (
    previous &&
    Number.isFinite(previous.homeScore) && Number.isFinite(previous.awayScore) &&
    Number.isFinite(meta.homeScore) && Number.isFinite(meta.awayScore) &&
    (previous.homeScore !== meta.homeScore || previous.awayScore !== meta.awayScore)
  ) state.lastScoreChangeAt = now;
  state.lastMeta = meta;
}
const leagueNames = new Map<string, string>();
let liveDiscoveryCandidates = new Map<string, DiscoveryCandidate>();
let liveDiscoveryFetchedAt = 0;
let liveDiscoveryError: string | null = null;
const liveVerificationCursors = { manual: 0, discovery: 0, other: 0 };
const LIVE_VERIFICATION_BUDGET = Math.min(10, MAX_CONCURRENT_LIVE_MATCHES);
const LIVE_CONFIRMATION_TTL_MS = 2 * LEAGUE_REFRESH_MS;
const recentLiveConfirmations = new Map<string, {
  verifiedAt: number;
  evidence: NonNullable<Awaited<ReturnType<typeof fetchFreshScoreNow>>>;
}>();
export const liveDiscoveryDiagnostics = {
  get snapshot() {
    return {
      fetchedAt: liveDiscoveryFetchedAt ? new Date(liveDiscoveryFetchedAt).toISOString() : null,
      ageMs: liveDiscoveryFetchedAt ? Math.max(0, Date.now() - liveDiscoveryFetchedAt) : null,
      stale: !liveDiscoveryFetchedAt || Date.now() - liveDiscoveryFetchedAt >= 2 * LEAGUE_REFRESH_MS,
      candidateCount: liveDiscoveryCandidates.size,
      error: liveDiscoveryError,
      eligibleCount: scannerStats.liveVerificationEligible,
      selectedCount: scannerStats.liveVerificationSelected,
      confirmedCount: scannerStats.liveMatchesConfirmed,
    };
  },
};

export const RUNTIME_ARCHIVE_CAP = 500;
export const RUNTIME_ARCHIVE_TTL_MS = 30 * 60_000;
const runtimeArchive = new Map<string, {
  nowGoalMatchId: string; matchName: string | null; leagueName: string | null;
  matchPhase: string; score: string | null; archivedAt: number;
}>();
const rejectedLiveIds = new Map<string, number>();
let runtimeEvidenceVersion = 0;
function isLiveMeta(meta: { state?: number | null; isLive: boolean } | undefined): boolean {
  return !!meta && (meta.state != null ? meta.state >= 1 : meta.isLive === true);
}
export function getRuntimeArchiveRows() {
  const now = Date.now();
  for (const [id, row] of runtimeArchive) {
    if (now - row.archivedAt >= RUNTIME_ARCHIVE_TTL_MS) runtimeArchive.delete(id);
  }
  return [...runtimeArchive.values()];
}
function retireRuntimeMatch(id: string, meta = matchStates.get(id)?.lastMeta): void {
  runtimeEvidenceVersion++;
  const removed = matchStates.delete(id);
  if (removed) logger.info({ matchId: id, state: meta?.state ?? null }, "Матч исключён из активной памяти; сохранённая подписка не изменена");
  rejectedLiveIds.set(id, runtimeEvidenceVersion);
  if (rejectedLiveIds.size > 10_000) rejectedLiveIds.delete(rejectedLiveIds.keys().next().value!);
  runtimeArchive.delete(id);
  runtimeArchive.set(id, {
    nowGoalMatchId: id, matchName: meta ? `${meta.team1} vs ${meta.team2}` : null,
    leagueName: meta?.leagueName ?? null,
    matchPhase: !meta ? "Unknown" : meta.state != null
      ? meta.state < 0 ? "Finished" : meta.state === 0 ? "Scheduled" : "Cached" : "Cached",
    score: meta ? `${meta.homeScore}-${meta.awayScore}` : null, archivedAt: Date.now(),
  });
  getRuntimeArchiveRows();
  while (runtimeArchive.size > RUNTIME_ARCHIVE_CAP) runtimeArchive.delete(runtimeArchive.keys().next().value!);
  // A fixture-lifetime manual binding survives feed loss. Release cross-source
  // references only on an explicit authoritative non-live state.
  if (meta?.state != null && meta.state < 1) {
    void import("./excapper").then((m) => m.releaseManualExcapperBinding(id));
  }
}
function acceptRuntimeMeta(id: string, meta: MatchMeta, authoritative = false): boolean {
  if (!isLiveMeta(meta)) {
    retireRuntimeMatch(id, { ...meta, leagueName: meta.leagueName ?? leagueNames.get(meta.leagueId) ?? "", updatedAt: Date.now() });
    return false;
  }
  if (rejectedLiveIds.has(id)) {
    if (!authoritative || meta.state == null || meta.state < 1) return false;
    if ((meta.evidenceVersion ?? -1) < rejectedLiveIds.get(id)!) return false;
    rejectedLiveIds.delete(id);
  }
  return true;
}

/**
 * Read-only, filterless scanner inventory for operator diagnostics. This must
 * not be reused for alert/watchlist admission: unlike the public live snapshot
 * it deliberately includes non-target, finished, cached, and metadata-less
 * states.
 */
export function getRuntimeAuditScannerRows(): Array<{
  userWatchlist: boolean;
  nowGoalMatchId: string;
  hasMeta: boolean;
  matchName: string | null;
  leagueName: string | null;
  score: string | null;
  elapsedTime: string | null;
  matchPhase: string;
  excapperMatchId: string | null;
}> {
  return [...matchStates.entries()].map(([nowGoalMatchId, state]) => {
    const meta = state.lastMeta;
    const matchPhase = !meta
      ? "Unknown"
      : meta.state != null
        ? meta.state < 0
          ? "Finished"
          : meta.state === 0
            ? "Scheduled"
            : "Live"
        : meta.isLive
          ? "Live"
          : "Cached";
    return {
      userWatchlist: !!meta && matchesWatchlist(meta.team1, meta.team2, nowGoalMatchId) !== null,
      nowGoalMatchId,
      hasMeta: meta != null,
      matchName: meta ? `${meta.team1} vs ${meta.team2}` : null,
      leagueName: meta?.leagueName ?? null,
      score: meta ? `${meta.homeScore}-${meta.awayScore}` : null,
      elapsedTime: meta?.clockLabel ?? null,
      matchPhase,
      excapperMatchId: state.excapperGameId ?? null,
    };
  });
}

function resolveLiveState(
  incoming: MatchMeta,
  previous?: MatchState["lastMeta"],
): Pick<NonNullable<MatchState["lastMeta"]>, "isLive" | "state" | "liveStateSource"> {
  if (incoming.state !== undefined && incoming.state !== null) {
    return {
      isLive: incoming.state >= 1,
      state: incoming.state,
      liveStateSource: "explicit",
    };
  }
  // A bulk/meta score fallback may infer "live" from kickoff time. It must
  // never resurrect a match that the per-match state endpoint explicitly
  // marked scheduled/finished/abnormal.
  if (
    previous?.liveStateSource === "explicit" &&
    previous.state !== undefined &&
    previous.state !== null &&
    previous.state < 1
  ) {
    return {
      isLive: false,
      state: previous.state,
      liveStateSource: "explicit",
    };
  }
  return { isLive: incoming.isLive, state: null, liveStateSource: "inferred" };
}

/**
 * Live match-state events (cards + penalties) decoded from the per-match
 * `SoccerAjax?type=15` incident list (`d_f`). Cards/penalties live ONLY in
 * that per-match feed — the bulk goal8.xml feed drops a match the instant it
 * kicks off, and the `tT_f` stats block carries shots/corners/attacks only.
 * Counts are per side; reds include second-yellow send-offs (kind 9).
 * Populated for manual watchlist and resolved Excapper-master matches by
 * injectMissingWatchlistMeta, read by buildLive (dashboard) and
 * the consolidated smart-money alert formatter.
 */
interface LiveMatchEvents {
  yellowHome: number;
  yellowAway: number;
  redHome: number;
  redAway: number;
  penalty: boolean;
  /** Minute of the FIRST penalty seen (d_f[1]); null if none. */
  penaltyMinute: number | null;
  penaltySide: "home" | "away" | null;
  updatedAt: number;
}
// Keyed by matchId. Holds the bounded manual watchlist + resolved master set;
// GC'd alongside lastDirectFetchAt when an id is removed.
const liveEventsCache = new Map<string, LiveMatchEvents>();

// Global Live-transition tracker. Holds matchIds that were live on the
// previous tick across the ENTIRE feed (all 252+ leagues, including majors
// that the main alert loop skips). When a matchId appears here for the first
// time we fire a "match went live" Telegram card.
//
// `liveSeeded` guards against an alert storm on scanner startup: the very
// first tick after boot just seeds the set without firing anything, since
// every currently-live match would otherwise look like a fresh transition.
const liveMatchIds = new Set<string>();
let liveSeeded = false;

let scannerTimer: ReturnType<typeof setTimeout> | null = null;
// Tick wall-time telemetry — see the comment block at the top of tick().
let __lastTickAt = 0;
let leagueTimer: ReturnType<typeof setTimeout> | null = null;
let prematchTimer: ReturnType<typeof setTimeout> | null = null;
let consecutiveFailures = 0;

// Generation counter: prevents an in-flight tick from resurrecting the timer
// chain after stopScanner() or a startScanner() restart. Every start/stop
// bumps the generation; tick() captures it at entry and skips re-arming if
// the generation changed underneath it. Mirrors the pattern used in
// healthcheck.ts:55 for the watchdog loop.
let scannerGeneration = 0;

// ----- FREEZE-RECOVERY / WATCHDOG -----
// The tick loop occasionally hangs on an awaited helper that — unlike every
// fetchRaw, which is hard-capped at HTTP_REQUEST_TIMEOUT_MS — has no firm
// deadline, leaving "Last move" climbing to 500s+ before it self-heals. These
// module-level handles let a manual Force-Restart (UI) or the auto-watchdog
// (a) name the blocking phase, (b) cancel its in-flight network work, and
// (c) start a fresh generation immediately instead of waiting it out.
//
// Per-tick AbortController, wired into the core OU/bench/meta fetches via
// fetchRaw's EXISTING extSignal param (no change to fetchRaw internals). When
// aborted, any in-flight core fetch for the current tick tears down at once.
let __currentTickAbort: AbortController | null = null;
// Human-readable label of the phase the current tick is in. This is the
// "Culprit/Blocked by" name surfaced in the watchdog Telegram alert and the
// /api/scanner/loop-diagnostic payload.
let __tickPhase: { label: string; startedAt: number } | null = null;
// True from tick entry until the tick settles (reaches scheduleNextTick for
// its own generation). Lets the watchdog tell a genuinely hung in-flight tick
// apart from a healthy idle gap between ticks.
let __tickInFlight = false;
// Wall-clock of the last tick that fully SETTLED, and the time the next tick
// is expected to fire (set by scheduleNextTick). The watchdog uses the latter
// to detect a timer chain that died without re-arming, with grace that scales
// to whatever backoff cadence is currently scheduled.
let __lastTickCompletedAt = 0;
let __nextTickExpectedAt = 0;
// Independent watchdog interval. It must live OFF the tick's setTimeout chain
// (that chain is dead while a tick is hung), so it's a standalone setInterval.
let watchdogTimer: ReturnType<typeof setInterval> | null = null;

/** Stall threshold: a tick in-flight (or a timer overdue) longer than this is
 *  considered frozen and force-restarted. The user asked for 45s — we cannot
 *  wait out the 500s natural timeout. */
export const SCANNER_STALL_THRESHOLD_MS = 45_000;
/** Slow-cycle TRACE threshold. A tick whose in-flight time (or overdue timer
 *  gap) crosses this — but has not yet hit SCANNER_STALL_THRESHOLD_MS — is not
 *  restarted; instead the watchdog emits a loud, detailed trace naming the exact
 *  phase the loop is wedged on. This is the "where is it stuck" signal; recovery
 *  still only happens at the 45s stall threshold. */
export const SCANNER_SLOW_CYCLE_THRESHOLD_MS = 15_000;
const WATCHDOG_POLL_MS = 5_000;

function setTickPhase(label: string): void {
  __tickPhase = { label, startedAt: Date.now() };
}

// ----- PRE-FLIGHT VALIDATION GATE -----
// Before the live tick loop starts — at boot AND after every watchdog/manual
// force-restart — we validate that upstream routing is actually live and
// retry every PREFLIGHT_RETRY_MS until it is, instead of letting the loop spin
// against a dead/hanging upstream. This is the ROOT-CAUSE guard requested by
// the user.
//
// IMPORTANT (empirically verified): the NowGoal/Vcbet endpoints are STATELESS
// GETs — no session tokens, cookies, or CSRF to "handshake". The only genuinely
// dynamic routing is the MAIN host mirror pool (upstream.ts), so the gate:
//   1. MAIN host (HARD gate): validateUpstream() → tryFailover() to pick a live
//      mirror. The loop will NOT start until a healthy mirror is found.
//   2. VCBET (SOFT gate): probeVcbet() confirms the fallback Ajax host is
//      reachable. Because vcbet is only a per-match FALLBACK feed (a persistent
//      vcbet outage must never permanently black out Bet365/Crown alerts on the
//      main pipeline), it hard-blocks for the first VCBET_PREFLIGHT_HARD_ATTEMPTS
//      retries, then proceeds "degraded" with vcbet flagged.
const PREFLIGHT_RETRY_MS = 10_000;
const VCBET_PREFLIGHT_HARD_ATTEMPTS = 3;

// True while the gate is running (boot or post-restart). The auto-watchdog must
// stand down while this is set — there is no tick to be "stalled" yet, and the
// gate manages its own retry cadence.
let __preflightInProgress = false;
// True only after startScanner() has finished wiring all post-gate runtime
// (leagues, watchlist, altStream, score/freeze watchdogs, prematch loop). A
// restart requested before this is set must NOT supersede the in-progress
// startup — otherwise the gate would preempt startScanner() (skipping init)
// while the resume path schedules ticks against a half-built runtime.
let __runtimeInitialized = false;
let __lastPreflightOkAt = 0;
let __preflightConsecutiveFailures = 0;
let __lastPreflight:
  | {
      ok: boolean;
      reason: string;
      mainHost: string;
      mainOk: boolean;
      vcbetOk: boolean;
      vcbetReason: string;
      vcbetDegraded: boolean;
      attempt: number;
      context: string;
      ranAt: string;
    }
  | null = null;

export function getPreflightState() {
  return {
    inProgress: __preflightInProgress,
    lastOkAt: __lastPreflightOkAt > 0 ? new Date(__lastPreflightOkAt).toISOString() : null,
    consecutiveFailures: __preflightConsecutiveFailures,
    last: __lastPreflight,
  };
}

/** Sleep that wakes early if the scanner is stopped or this generation is
 *  superseded, so a stop/restart during the 10s retry gap stays responsive. */
async function preflightSleep(totalMs: number, gen: number): Promise<void> {
  const step = 500;
  let waited = 0;
  while (waited < totalMs && scannerRunning && gen === scannerGeneration) {
    await new Promise((r) => setTimeout(r, Math.min(step, totalMs - waited)));
    waited += step;
  }
}

/** One pass of pre-flight validation. Validates the main mirror (hard) and
 *  vcbet reachability (soft after the hard-retry window). Never throws. */
async function runPreflightOnce(attempt: number): Promise<{
  ok: boolean;
  reason: string;
  mainHost: string;
  mainOk: boolean;
  vcbetOk: boolean;
  vcbetReason: string;
  vcbetDegraded: boolean;
}> {
  // 1. MAIN HOST — validate the current mirror; if unhealthy, fail over to a
  //    live one and re-validate against the chosen base.
  let mainHost = currentBaseUrl();
  let mainOk = false;
  try {
    const v = await validateUpstream(fetchRawDetails);
    mainHost = v.base;
    mainOk = v.ok;
    if (!mainOk) {
      const fo = await tryFailover(fetchRawDetails, "preflight");
      mainHost = fo.to;
      const v2 = await validateUpstream(fetchRawDetails);
      mainOk = v2.ok;
      mainHost = v2.base;
    }
  } catch (err) {
    return {
      ok: false,
      reason: `main_error:${err instanceof Error ? err.message : String(err)}`,
      mainHost,
      mainOk: false,
      vcbetOk: false,
      vcbetReason: "skipped_main_failed",
      vcbetDegraded: false,
    };
  }
  if (!mainOk) {
    return {
      ok: false,
      reason: "no_healthy_mirror",
      mainHost,
      mainOk: false,
      vcbetOk: false,
      vcbetReason: "skipped_main_failed",
      vcbetDegraded: false,
    };
  }

  // 2. VCBET — sample a currently-live match id from the validated META feed so
  //    the probe is meaningful, then confirm the vcbet Ajax host is reachable.
  let sampleId: string | null = null;
  try {
    const metaText = await fetchRaw(withCacheBuster(endpointsFor(mainHost).meta));
    const meta = parseMatchMeta(metaText);
    for (const [id, m] of meta) {
      if (m.isLive) {
        sampleId = id;
        break;
      }
    }
    if (!sampleId) {
      const first = meta.keys().next();
      if (!first.done) sampleId = first.value;
    }
  } catch {
    // Non-fatal — probeVcbet falls back to a placeholder id.
  }

  const vc = await probeVcbet(sampleId);
  if (vc.ok) {
    return {
      ok: true,
      reason: "ok",
      mainHost,
      mainOk: true,
      vcbetOk: true,
      vcbetReason: vc.reason,
      vcbetDegraded: false,
    };
  }
  // vcbet unreachable: hard-block for the first few attempts, then proceed
  // degraded so a vcbet-only outage can't permanently gate the main scanner.
  // <= so VCBET_PREFLIGHT_HARD_ATTEMPTS=3 hard-blocks attempts 1–3 and degrades
  // from attempt 4 onward (matches the documented "hard-block N attempts").
  if (attempt <= VCBET_PREFLIGHT_HARD_ATTEMPTS) {
    return {
      ok: false,
      reason: `vcbet_${vc.reason}`,
      mainHost,
      mainOk: true,
      vcbetOk: false,
      vcbetReason: vc.reason,
      vcbetDegraded: false,
    };
  }
  logger.warn(
    { attempt, vcbetReason: vc.reason },
    "[PREFLIGHT] vcbet still unreachable after hard-retry window — proceeding with vcbet fallback DEGRADED",
  );
  return {
    ok: true,
    reason: "ok_vcbet_degraded",
    mainHost,
    mainOk: true,
    vcbetOk: false,
    vcbetReason: vc.reason,
    vcbetDegraded: true,
  };
}

/** Run the pre-flight gate: loop runPreflightOnce() every PREFLIGHT_RETRY_MS
 *  until it passes. Returns true when validated, or false if the scanner was
 *  stopped / this generation was superseded mid-gate. */
async function runPreflightGate(gen: number, context: string): Promise<boolean> {
  let attempt = 0;
  while (scannerRunning && gen === scannerGeneration) {
    attempt++;
    const res = await runPreflightOnce(attempt);
    __lastPreflight = { ...res, attempt, context, ranAt: new Date().toISOString() };
    if (res.ok) {
      __lastPreflightOkAt = Date.now();
      __preflightConsecutiveFailures = 0;
      logger.info(
        { context, attempt, base: res.mainHost, vcbet: res.vcbetReason, vcbetDegraded: res.vcbetDegraded },
        "[PREFLIGHT] validation passed — starting loop",
      );
      return true;
    }
    __preflightConsecutiveFailures++;
    logger.error(
      { context, attempt, reason: res.reason, base: res.mainHost, retryMs: PREFLIGHT_RETRY_MS },
      "[PREFLIGHT] validation FAILED — main loop blocked, retrying",
    );
    await preflightSleep(PREFLIGHT_RETRY_MS, gen);
  }
  return false;
}

/** Resume the tick loop after a watchdog/manual restart, gating on pre-flight
 *  validation first. Scheduled (not awaited) by abortAndRestartLoop. */
async function resumeAfterPreflight(gen: number, context: string): Promise<void> {
  const ok = await runPreflightGate(gen, context);
  // If a newer start/stop/restart superseded us, the new owner manages state.
  if (gen !== scannerGeneration || !scannerRunning) return;
  __preflightInProgress = false;
  if (!ok) return;
  __nextTickExpectedAt = Date.now();
  scannerTimer = setTimeout(() => {
    scannerTimer = null;
    if (!scannerRunning || gen !== scannerGeneration) return;
    void tick(gen);
  }, 0);
}

// ----- HYPER-FOCUS MODE -----
// When true, tick() short-circuits the heavy global pipeline (no bench fetch,
// no meta fetch, no live-transition tracker, no stale-ratio watchdog, no
// volatility ring, no global-pool alerts, no matchStates prune across
// non-watchlist matches). Only primaryOu is fetched, and processing is
// restricted to matches whose IDs appear in the watchlist. Re-arm cadence
// uses WATCHLIST_HYPER_POLL_INTERVAL_MS (~12s). Volatile — not persisted
// across restarts.
//
// ALWAYS-ON MODEL (user directive 2026-08-17, revised same day): the global
// scanner boots UNPAUSED and NOTHING pauses it automatically — no fallback,
// watchdog, or recovery path may call this with paused=true. The ONLY
// legitimate pause caller is the manual dashboard toggle (user's explicit
// choice), which is why the API route below remains enabled. The `opts`
// parameter is retained for signature compatibility with tests.
let isGlobalScannerPaused = false;
export function getGlobalScannerPaused(): boolean {
  return isGlobalScannerPaused;
}
export function setGlobalScannerPaused(
  paused: boolean,
  _opts?: { force?: boolean },
): boolean {
  const prev = isGlobalScannerPaused;
  isGlobalScannerPaused = !!paused;
  if (prev !== isGlobalScannerPaused) {
    logger.warn(
      { paused: isGlobalScannerPaused, prev },
      isGlobalScannerPaused
        ? "[HYPER-FOCUS] Global background scanner PAUSED — watchlist-only mode, ~12s cadence"
        : "[HYPER-FOCUS] Global background scanner RESUMED — full pipeline restored",
    );
    // RESUME RECONCILIATION (surgical):
    // - WATCHLIST matches: leave history INTACT. Hyper-focus tick has been
    //   refreshing their OU snapshots every ~12s during pause, so `prev` is
    //   fresh and delta math is valid. Clearing would cost one cycle of
    //   visibility for no safety benefit.
    // - NON-WATCHLIST matches: their `prev` snapshot is potentially HOURS
    //   stale. Without reseeding, the next normal tick would compute
    //   drop = current − prev against ancient prices and spuriously trip
    //   the alert pipeline (often early-bird with no benchmark guard).
    //   Clear history so the next tick rebuilds baseline from now.
    //
    // Preserved across resume in BOTH cases (never reset by this path):
    //   lastMeta, lastAlertAt cooldowns, lastOddsChangeAt, lastAnalyzedAt,
    //   watchlist.json, scannerStats counters, mirror state.
    if (!isGlobalScannerPaused) {
      const wl = getWatchlistSnapshot();
      const pinnedIds = new Set<string>();
      for (const e of wl.entries) {
        if (e.matchId) pinnedIds.add(e.matchId);
      }
      let reseeded = 0;
      let preserved = 0;
      for (const [id, st] of matchStates) {
        // Text-only watchlist entries (no matchId) match on team names — we
        // don't know their matchId here, so we conservatively check ANY
        // current matchesWatchlist() hit on the cached lastMeta to keep
        // their history intact too.
        const isWatchlist =
          pinnedIds.has(id) ||
          (st.lastMeta != null &&
            matchTargetLeague(st.lastMeta.leagueName) !== null &&
            matchesWatchlist(st.lastMeta.team1, st.lastMeta.team2, id) !== null);
        if (isWatchlist) {
          preserved++;
          continue;
        }
        if (st.history.length > 0) {
          st.history = [];
          reseeded++;
        }
        // Bench history was NOT updated during pause (no bench fetch), so
        // it's safe but stale — drop it so confirmation gates use only
        // post-resume samples.
        st.benchmarkHistory = [];
      }
      logger.warn(
        { reseeded, preserved, total: matchStates.size },
        "[HYPER-FOCUS] Resume reconciliation — watchlist history preserved, non-watchlist baselines cleared",
      );
    }
  }
  return isGlobalScannerPaused;
}

export const scannerStats: {
  lastCheckAt: Date | null;
  /** Last time a tick FULLY completed its write phase (scheduleNextTick reached
   *  for the current generation). Unlike lastCheckAt — which is stamped right
   *  after the upstream fetch succeeds, BEFORE the per-match processing/write
   *  loop — this only advances once the scanner has actually finished writing
   *  state for the cycle. If the loop freezes mid-tick (or a zombie generation
   *  is fenced off) this stops entirely, so it is the true "is the whole
   *  scanner alive" heartbeat rather than "did one bookmaker's price move". */
  lastGlobalUpdateAt: Date | null;
  checksTotal: number;
  anomaliesFound: number;
  alertsSuppressedBySpread: number;
  alertsSuppressedByConfidence: number;
  alertsSuppressedByGoalBlackout: number;
  /** Anomalies dropped by the upstream value guards (odds floor / score buffer). */
  alertsSuppressedByValueGuard: number;
  benchmarkConfirmedAlerts: number;
  earlyBirdAlerts: number;
  lastError: string | null;
  leaguesLoaded: number;
  scheduleMatchesSeen: number;
  liveMatchesConfirmed: number;
  liveVerificationEligible: number;
  liveVerificationSelected: number;
  liveMatchesTracked: number;
  minorMatchesTracked: number;
  majorMatchesSkipped: number;
  lowLiquidityMatchesTracked: number;
  lowLiquidityAlerts: number;
  benchmarkCoverage: number;
  primaryFetchFailures: number;
  benchmarkFetchFailures: number;
  /** Per-book OU fetch tally — visible at /api/scanner/status to spot
   *  silent dashing of the Sbobet/M88/12Bet/18Bet/VSBet stack.
   *  `lastParsedRows` is the row count from the most recent successful
   *  parse, so an operator can compare it against primaryMap size and
   *  see at-a-glance which books legitimately cover few fixtures vs.
   *  which ones have gone silently empty. */
  perBookFetch: Record<
    ExtraBookKey,
    { ok: number; fail: number; lastError: string | null; lastParsedRows: number; lastParsedAt: Date | null }
  >;
  consecutiveFailures: number;
  benchmarkName: string;
  lastTickMapSizes: { primary: number; bench: number; meta: number; capturedAt: Date | null };
  dataVolatility: {
    isStale: boolean;
    consecutiveIdenticalTicks: number;
    successfulUnchangedSamples: number;
    lastSignature: string | null;
    lastChangedAt: Date | null;
    unchangedSince: Date | null;
    lastStaleRotationAt: Date | null;
    rotationsForStaleness: number;
  };
  pool: {
    priorityWatchlistMatches: number;
    globalPoolAnalyzed: number;
    globalPoolSkippedByThrottle: number;
    globalPoolSkippedByCap: number;
    lowLiqPrematchSkipped: number;
    maxConcurrentLiveMatches: number;
    globalPoolIntervalSec: number;
  };
  /** Freeze-recovery watchdog telemetry — surfaced at /api/scanner/status and
   *  /api/scanner/loop-diagnostic so the dashboard can show how often the loop
   *  has auto-recovered and what was blocking it. */
  autoWatchdog: {
    triggers: number;
    lastTriggeredAt: Date | null;
    lastCulprit: string | null;
    lastStalledMs: number | null;
  };
} = {
  lastCheckAt: null as Date | null,
  lastGlobalUpdateAt: null as Date | null,
  checksTotal: 0,
  anomaliesFound: 0,
  alertsSuppressedBySpread: 0,
  alertsSuppressedByConfidence: 0,
  alertsSuppressedByGoalBlackout: 0,
  alertsSuppressedByValueGuard: 0,
  benchmarkConfirmedAlerts: 0,
  earlyBirdAlerts: 0,
  lastError: null as string | null,
  leaguesLoaded: 0,
  scheduleMatchesSeen: 0,
  liveMatchesConfirmed: 0,
  liveVerificationEligible: 0,
  liveVerificationSelected: 0,
  liveMatchesTracked: 0,
  minorMatchesTracked: 0,
  majorMatchesSkipped: 0,
  lowLiquidityMatchesTracked: 0,
  lowLiquidityAlerts: 0,
  benchmarkCoverage: 0, // # matches with benchmark data on last tick
  primaryFetchFailures: 0,
  benchmarkFetchFailures: 0,
  perBookFetch: {
    Sbobet: { ok: 0, fail: 0, lastError: null, lastParsedRows: 0, lastParsedAt: null },
    M88: { ok: 0, fail: 0, lastError: null, lastParsedRows: 0, lastParsedAt: null },
    "12Bet": { ok: 0, fail: 0, lastError: null, lastParsedRows: 0, lastParsedAt: null },
    "18Bet": { ok: 0, fail: 0, lastError: null, lastParsedRows: 0, lastParsedAt: null },
    VSBet: { ok: 0, fail: 0, lastError: null, lastParsedRows: 0, lastParsedAt: null },
  },
  consecutiveFailures: 0,
  benchmarkName: BENCHMARK_NAME,
  // Per-tick parse-map sizes (primary OU, benchmark OU, META). Used by the
  // self-analysis endpoint to verify each map is being rebuilt every tick
  // rather than silently frozen at the last successful values.
  lastTickMapSizes: {
    primary: 0,
    bench: 0,
    meta: 0,
    capturedAt: null as Date | null,
  },
  // Odds Volatility tracker. A mirror can return HTTP 200 with parseable data
  // every tick, yet still be FROZEN (every tick returns the identical XML).
  // We hash the primary OU snapshot per tick and rotate if N consecutive ticks
  // produce the same signature. See VOLATILITY_* constants and tick() body.
  dataVolatility: {
    isStale: false,                              // true while we're locked on a frozen mirror
    consecutiveIdenticalTicks: 0,                // how many ticks in a row had identical signatures
    successfulUnchangedSamples: 0,
    lastSignature: null as string | null,        // most recent odds hash
    lastChangedAt: null as Date | null,          // when the signature last actually moved
    unchangedSince: null as Date | null,
    lastStaleRotationAt: null as Date | null,    // last time we forced a failover for staleness
    rotationsForStaleness: 0,                    // cumulative count for telemetry
  },
  pool: {
    priorityWatchlistMatches: 0,
    globalPoolAnalyzed: 0,
    globalPoolSkippedByThrottle: 0,
    globalPoolSkippedByCap: 0,
    lowLiqPrematchSkipped: 0,
    maxConcurrentLiveMatches: 60,
    globalPoolIntervalSec: 50,
  },
  autoWatchdog: {
    triggers: 0,
    lastTriggeredAt: null as Date | null,
    lastCulprit: null as string | null,
    lastStalledMs: null as number | null,
  },
};

/** Public read-only watchlist snapshot (re-exported for the dashboard). */
export function getWatchlist() {
  return getWatchlistSnapshot();
}

/**
 * Look up the most recent meta we've seen for a given matchId. Used by the
 * watchlist POST route to resolve a NowGoal26 URL containing only a numeric
 * id into actual team names that the fuzzy matcher can use.
 */
export function lookupMatchMetaById(matchId: string): MatchState["lastMeta"] | null {
  const st = matchStates.get(matchId);
  return st?.lastMeta ?? null;
}

/**
 * Snapshot of watchlist matches eligible for Excapper volume sampling.
 *
 * Excapper's scraper (lib/excapper.ts) calls this every ~35s to know which
 * Bet365 matches to look up. We only return matches that:
 *   - are currently in Excapper's explicit auto-promotion registry,
 *   - have a target-whitelist league,
 *   - have lastMeta (so we have team names to fuzzy-match), AND
 *   - have at least one OU history snapshot (so we know the current line).
 *
 * Excluding matches without `lastMeta` or history avoids burning Excapper
 * bandwidth on watchlist entries that haven't been picked up by the scanner
 * yet (e.g. text-only entries awaiting kickoff).
 */
export function getWatchlistMatchesForVolume(): Array<{
  matchId: string;
  team1: string;
  team2: string;
  line: number;
  isLive: boolean;
}> {
  const out: Array<{
    matchId: string;
    team1: string;
    team2: string;
    line: number;
    isLive: boolean;
  }> = [];
  for (const [id, st] of matchStates) {
    if (!st.lastMeta) continue;
    if (!isManualExcapperHydrationState(id)) continue;
    const last = st.history[st.history.length - 1];
    if (!last) continue;
    out.push({
      matchId: id,
      team1: st.lastMeta.team1,
      team2: st.lastMeta.team2,
      line: last.line,
      isLive: st.lastMeta.isLive,
    });
  }
  return out;
}

export interface ManualExcapperHydrationCandidate {
  kickoffMs?: number | null;
  /** Scanner state id used only for writing accepted volume samples. */
  matchId: string;
  /**
   * Stable watchlist-row identity used by API diagnostics. Text-only entries
   * retain manual-text:<signature> even after resolving to a numeric state.
   */
  diagnosticId?: string;
  /** More than one strict scanner state matched this text-only row. */
  identityAmbiguous?: boolean;
  team1: string;
  team2: string;
  league: string;
  /** NowGoal/Bet365 line, when that separate odds feed currently has one. */
  nowGoalLine: number | null;
  /** Authoritative type=11 state. Null means live corroboration is unavailable. */
  state?: number | null;
  homeScore?: number | null;
  awayScore?: number | null;
  /** Literal NowGoal fixture-header minute. Null means unavailable, never zero-filled. */
  liveMinute?: number | null;
}

const manualTextVolumes = new Map<string, {
  gameId: string;
  samples: Map<number, VolumeSample>;
}>();

/** Actual accepted binding only; candidate ids are intentionally inaccessible. */
export function getRuntimeAuditTextExcapperBinding(signature: string): string | null {
  return manualTextVolumes.get(signature)?.gameId ?? null;
}

function isManualExcapperHydrationState(matchId: string): boolean {
  if (isManualWatchlistId(matchId)) return true;
  const state = matchStates.get(matchId);
  if (!state?.lastMeta) return false;
  return getNormalizedEntries().some(
    (entry) =>
      entry.origin === "manual" &&
      entry.matchId === undefined &&
      entry.fragments.length === 2 &&
      strictTeamPairMatches(
        entry.fragments[0]!,
        entry.fragments[1]!,
        state.lastMeta!.team1,
        state.lastMeta!.team2,
      ),
  );
}

/** Membership-only check used by the fixture-lifetime direct-fetch cache. */
export function hasManualExcapperHydrationMembership(matchId: string): boolean {
  if (matchId.startsWith("manual-text:")) {
    const signature = matchId.slice("manual-text:".length);
    return getNormalizedEntries().some(
      (entry) =>
        entry.origin === "manual" &&
        entry.signature === signature &&
        entry.matchId === undefined,
    );
  }
  return isManualExcapperHydrationState(matchId);
}

/**
 * Manual pins are eligible for silent Excapper volume hydration, but never for
 * Excapper promotion/transaction dispatch merely because they were pinned.
 * Complete NowGoal metadata, including the upstream league label, is required.
 * Manual hydration deliberately does not consult the automated target-league
 * allowlist: identity safety is enforced later by the complete-pair + strict
 * league-equivalence binder.
 */
export function getManualWatchlistMatchesForExcapper(
  onlyIds?: ReadonlySet<string>,
): ManualExcapperHydrationCandidate[] {
  const candidates: ManualExcapperHydrationCandidate[] = [];
  const manualEntries = getNormalizedEntries().filter(
    (entry) => {
      if (!onlyIds) return true;
      const selector = entry.matchId ?? `manual-text:${entry.signature}`;
      return onlyIds.has(selector);
    },
  );
  for (const entry of manualEntries) {
    let id = entry.matchId;
    if (!id) {
      // Text-only pins are real Priority Watchlist entries. They may use the
      // volume-only path once their two complete team identities resolve to
      // exactly one tracked state. This does not mutate the entry into a
      // numeric pin and grants no odds/alert eligibility.
      if (entry.fragments.length !== 2) continue;
      const stateMatches = [...matchStates.entries()].filter(([, state]) =>
        state.lastMeta &&
        strictTeamPairMatches(
          entry.fragments[0]!,
          entry.fragments[1]!,
          state.lastMeta.team1,
          state.lastMeta.team2,
        ),
      );
      if (stateMatches.length === 0) {
        // No NowGoal identity is required for volume-only enrichment. The
        // Excapper binder may resolve this synthetic key only from an exact
        // two-team pair that is globally unique in the current directory.
        candidates.push({
          matchId: `manual-text:${entry.signature}`,
          diagnosticId: `manual-text:${entry.signature}`,
          team1: entry.fragments[0]!,
          team2: entry.fragments[1]!,
          league: "",
          nowGoalLine: null,
        });
        continue;
      }
      if (stateMatches.length !== 1) {
        candidates.push({
          matchId: `manual-text:${entry.signature}`,
          diagnosticId: `manual-text:${entry.signature}`,
          identityAmbiguous: true,
          team1: entry.fragments[0]!,
          team2: entry.fragments[1]!,
          league: "",
          nowGoalLine: null,
        });
        continue;
      }
      id = stateMatches[0]![0];
    }
    const state = matchStates.get(id);
    const meta = state?.lastMeta;
    const league = meta?.leagueName.trim();
    if (!state || !meta || !league) continue;
    candidates.push({
      matchId: id,
      diagnosticId: entry.matchId ? id : `manual-text:${entry.signature}`,
      team1: meta.team1,
      team2: meta.team2,
      league,
      kickoffMs: meta.kickoffMs,
      nowGoalLine: state.history[state.history.length - 1]?.line ?? null,
      state: meta.liveStateSource === "explicit" ? (meta.state ?? null) : null,
      homeScore: meta.homeScore,
      awayScore: meta.awayScore,
      liveMinute: (() => {
        const match = /^(\d{1,3})(?:\s*\+\s*(\d{1,2}))?/.exec(meta.clockLabel ?? "");
        return match ? Number(match[1]) + Number(match[2] ?? 0) : null;
      })(),
    });
  }
  return candidates;
}

/**
 * Normalize the complete team identity, not individual tokens. Common names
 * such as "United" are not sufficient evidence for a match: punctuation,
 * accents and the common "Football Club"/"Club" spelling are the only
 * tolerated differences.
 */
const normalizedTeamIdentity = normalizedTeamName;

/** Identity-only candidates; this grants neither alert nor manual hydration eligibility. */
export function getAutomaticExcapperCandidates(): ManualExcapperHydrationCandidate[] {
  return [...matchStates.entries()].flatMap(([matchId, state]) => {
    const meta = state.lastMeta;
    if (!meta?.isLive || !matchTargetLeague(meta.leagueName)) return [];
    return [{ matchId, team1: meta.team1, team2: meta.team2, league: meta.leagueName,
      kickoffMs: meta.kickoffMs, nowGoalLine: null,
      state: meta.liveStateSource === "explicit" ? meta.state : null,
      homeScore: meta.homeScore, awayScore: meta.awayScore }];
  });
}

const manualExactOddsHistory = new Map<string, UnifiedOddsPoint[]>();
const MAX_MANUAL_EXACT_ODDS_MARKETS = 2_000;

function recordManualExactQuote(
  matchId: string,
  line: number,
  side: "OVER" | "UNDER",
  quote: { odds: number; collectedAt: number },
): UnifiedOddsPoint[] {
  const key = `${matchId}:${line}:${side}`;
  const cutoff = quote.collectedAt - ODDS_DROP_WINDOW_MS;
  const history = (manualExactOddsHistory.get(key) ?? []).filter(
    (point) => point.ts >= cutoff && point.ts <= quote.collectedAt,
  );
  const last = history[history.length - 1];
  if (!last || quote.collectedAt > last.ts) {
    history.push({ ts: quote.collectedAt, line, odds: quote.odds });
  } else if (quote.collectedAt === last.ts && quote.odds !== last.odds) {
    history[history.length - 1] = { ts: quote.collectedAt, line, odds: quote.odds };
  }
  manualExactOddsHistory.delete(key);
  manualExactOddsHistory.set(key, history);
  while (manualExactOddsHistory.size > MAX_MANUAL_EXACT_ODDS_MARKETS) {
    const oldest = manualExactOddsHistory.keys().next().value as string | undefined;
    if (!oldest) break;
    manualExactOddsHistory.delete(oldest);
  }
  return history;
}

function strictTeamPairMatches(
  a1: string,
  a2: string,
  b1: string,
  b2: string,
): boolean {
  return (
    (normalizedTeamIdentity(a1) === normalizedTeamIdentity(b1) &&
      normalizedTeamIdentity(a2) === normalizedTeamIdentity(b2)) ||
    (normalizedTeamIdentity(a1) === normalizedTeamIdentity(b2) &&
      normalizedTeamIdentity(a2) === normalizedTeamIdentity(b1))
  );
}

/** Context seam used while Excapper hydrates manual fixtures (no reverse import). */
export function getManualVolumeAlertContext(
  matchId: string,
  line: number,
  side: "OVER" | "UNDER",
  currentQuote?: { odds: number; collectedAt: number } | null,
): Omit<UnifiedAlertInput, "inflow"> | null {
  const state = matchStates.get(matchId);
  const meta = state?.lastMeta;
  if (!state || !meta) return null;
  const validCurrentQuote =
    currentQuote &&
    Number.isFinite(currentQuote.odds) &&
    currentQuote.odds > 1 &&
    Number.isFinite(currentQuote.collectedAt)
      ? currentQuote
      : null;
  // Volume-spike odds evidence is retained per exact Excapper market. Do not
  // substitute the primary NowGoal handicap, another line, or the opposite
  // side. The first observation remains the baseline until it leaves the
  // bounded event window.
  const exactTimeline = validCurrentQuote
    ? recordManualExactQuote(matchId, line, side, validCurrentQuote)
    : [];
  return {
    matchId,
    league: meta.leagueName || `League #${meta.leagueId}`,
    home: meta.team1,
    away: meta.team2,
    isLive: meta.isLive,
    homeScore: meta.homeScore,
    awayScore: meta.awayScore,
    minute: resolveUnifiedAlertMinute(meta, null),
    side,
    line,
    timeline: exactTimeline,
    currentQuote:
      validCurrentQuote
        ? { ts: validCurrentQuote.collectedAt, line, odds: validCurrentQuote.odds }
        : null,
    link: matchLink(matchId),
  };
}

/** Primary NowGoal evidence for a verified NowGoal match identity. The caller
 * must resolve Excapper ids through a verified binding before invoking this.
 * Never combine this timeline with a quote from another source. */
export function getScannerAlertContext(
  matchId: string,
  line: number,
  side: "OVER" | "UNDER",
): Omit<UnifiedAlertInput, "inflow"> | null {
  const state = matchStates.get(matchId);
  const meta = state?.lastMeta;
  const latest = state?.history[state.history.length - 1];
  const now = Date.now();
  if (
    !state || !meta || !isLiveMeta(meta) || !Number.isFinite(line) ||
    latest?.line !== line || latest.ts > now ||
    now - latest.ts > HISTORY_WINDOW_MS ||
    meta.updatedAt > now || now - meta.updatedAt > HISTORY_WINDOW_MS
  ) return null;
  const timeline = state.history
    .filter((point) => point.line === line)
    .map((point) => ({
      ts: point.ts,
      line: point.line,
      odds: side === "OVER" ? point.overDecimal : point.underDecimal,
    }));
  if (!timeline.length) return null;
  const currentQuote = timeline[timeline.length - 1]!;
  return {
    matchId,
    league: meta.leagueName || `League #${meta.leagueId}`,
    home: meta.team1,
    away: meta.team2,
    isLive: meta.isLive,
    homeScore: meta.homeScore,
    awayScore: meta.awayScore,
    minute: resolveUnifiedAlertMinute(meta, null),
    side,
    line,
    timeline,
    currentQuote,
    link: matchLink(matchId),
  };
}

/**
 * Write a fresh multi-line Excapper sample for a match. Each line slot
 * tracks its own prev/spike state, so concurrent spikes on different
 * totals markets (e.g. Over 2.5 AND Over 3.5) are surfaced independently.
 *
 * Spike rule per (line, side):
 *   - native-feed EUR delta > 2,000 between consecutive samples for the SAME line
 *   - sample gap ≤ 60s (filters out resumed-after-pause stale comparisons)
 *   - Bet365 odds haven't moved in the last 30s (state.lastOddsChangeAt is
 *     older than now − 30s). If the bookmaker has already caught up, the
 *     volume swing isn't "smart money in front of the price" — it's noise
 *     trailing a known move.
 *
 * Because each line has its own slot, we no longer need the prior "line
 * shifted → reset" guard: the 2.5 slot is naturally untouched when only
 * 3.5 receives new flow.
 *
 * Lines absent from `samples` but present in prior state are left alone —
 * Excapper sometimes drops a line briefly mid-match. We don't want to
 * clear our history on a transient parse miss.
 *
 * No-op if the matchId isn't in matchStates (race: scanner dropped the
 * match between excapper's directory scan and per-game fetch).
 */
function formatEurAmount(n: number): string {
  return `€${Math.round(n).toLocaleString("en-US")}`;
}

/**
 * [MONEY SPIKE] alerting — TRANSACTION-LEVEL.
 *
 * Telegram fire is keyed off Excapper's literal per-bet "Change" cell
 * (parsed in lib/excapper.ts), NOT cycle-to-cycle running-total deltas
 * (the v3 method which conflated multiple small concurrent bets into one
 * apparent "spike"). Each call here corresponds to ONE row in Excapper's
 * transaction table whose Change cell was at least 500 native-feed EUR.
 *
 * Dedupe key is `(matchId, line, side, summ)`. Excapper's `Summ` column
 * is the running cumulative total AFTER the bet, so it is monotonically
 * increasing per (line, side) and therefore unique per transaction —
 * perfect natural dedup ID across cycles.
 */
/**
 * Per-match cache-bypass score fetch. Hits the per-match scoreboard
 * endpoint (`type=11&id={matchId}`) with `withCacheBuster()` so any
 * intermediary cache is forced to revalidate. Used to refresh the score
 * the user sees in a Telegram alert at the exact moment of send — the
 * cached st.lastMeta can be up to one tick stale (~10s), and on a
 * just-scored event that staleness reads as "wrong score" to the user.
 *
 * Returns null on any failure (timeout, parse error, missing match) so
 * the caller can fall back to st.lastMeta. Hard 2.5s timeout — we never
 * want the alert path to block on a single sluggish fetch.
 */
export async function fetchFreshScoreNow(
  matchId: string,
): Promise<{ homeScore: number; awayScore: number; isLive: boolean; state: number | null; clockLabel: string | null } | null> {
  const url = withCacheBuster(`${currentBaseUrl()}/Ajax/SoccerAjax?type=11&id=${matchId}`);
  const ctl = new AbortController();
  const timeoutId = setTimeout(() => ctl.abort(), 2500);
  try {
    // Bypass fetchRaw — its 5xx/429 retry adds 500ms + 1500ms backoff sleeps
    // that aren't abort-aware during the sleep, so wall time could exceed our
    // 2.5s hard cap. The alert path prefers a clean fallback to cached meta
    // over a 4-second delay.
    const res = await fetch(url, { headers: buildHeaders(), signal: ctl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return parsePerMatchScore(await res.text());
  } catch (err) {
    logger.debug(
      { matchId, err: err instanceof Error ? err.message : err },
      "[TG-ALERT] fresh score fetch failed — falling back to cached meta",
    );
    return null;
  } finally {
    clearTimeout(timeoutId);
  }
}

// ----- WATCHLIST LIVE-SCORE FAST-REFRESH LOOP -----
//
// Independent timer that re-fetches the per-match cache-bypass score
// endpoint (`type=11`) for every watchlist match on the same cadence as
// the fast watchlist OU poll (WATCHLIST_FAST_POLL_INTERVAL_MS, ~12s).
//
// Why this exists: NowGoal's bulk goal8.xml feed (which the main scanner
// tick parses for score in row indices [11]/[12]) is throttled upstream
// — score events take 10-20s to surface in that bulk feed. The per-match
// type=11 endpoint (the same one their own UI polls for live updates)
// reflects a goal within ~2s. Without this loop the watchlist Score
// column can sit on "0-0" for 20+ seconds after a goal even while OU
// odds (which are not throttled in goal8.xml) already show the market
// reacting.
//
// Scope guarantee: this loop touches ONLY st.lastMeta score/live-state fields
// plus updatedAt. The type=11 state is authoritative, so a finished transition
// must be committed even when the numeric score did not change. It does not touch:
//   - st.history (OU odds tick ring)
//   - the bulk goal8.xml feed or any other odds path
//   - the alt-mirror stream
//   - any alert/Telegram path
//   - the Sofascore watchdog (which remains the freeze-detector
//     override at 25s cadence)
// The odds tracking + curl architecture from baseline f55cac2 is
// strictly preserved.
//
// Concurrency safety: max 3 fetches in flight per tick (modest enough
// to not move the upstream load needle), each hard-capped at 2.5s by
// fetchFreshScoreNow itself. Tick generation guard mirrors the scanner
// pattern so stop()/restart() can't leave a zombie loop ticking.
let scoreRefreshTimer: ReturnType<typeof setTimeout> | null = null;
let scoreRefreshGeneration = 0;
const SCORE_REFRESH_MAX_CONCURRENT = 1;
const directScoreIdsFetchedThisCycle = new Set<string>();

async function watchlistScoreRefreshTick(myGen: number): Promise<void> {
  if (myGen !== scoreRefreshGeneration) return;
  const snap = getWatchlistSnapshot();
  if (snap.count === 0) return;

  // Collect distinct matchIds we have state for. Entries without a
  // resolved matchId (text-only fragments still awaiting first feed hit)
  // are skipped — we can't address them at the per-match endpoint.
  const ids = new Set<string>();
  for (const e of getNormalizedEntries()) {
    if (
      e.matchId &&
      matchStates.has(e.matchId) &&
      !directScoreIdsFetchedThisCycle.has(e.matchId)
    ) ids.add(e.matchId);
  }
  if (ids.size === 0) return;

  const queue = [...ids];
  let inFlight = 0;
  await new Promise<void>((resolve) => {
    let completed = 0;
    const total = queue.length;
    const pump = (): void => {
      while (inFlight < SCORE_REFRESH_MAX_CONCURRENT && queue.length > 0) {
        const id = queue.shift()!;
        inFlight++;
        void (async () => {
          try {
            const stBefore = matchStates.get(id);
            if (!stBefore || !stBefore.lastMeta) return;
            // Existing watchlist entries/states are retained for history.
            // Automated score refresh stays target-only, except for an exact
            // manual numeric pin whose out-of-allowlist state is explicitly
            // visible in the dashboard.
            if (
              !matchTargetLeague(stBefore.lastMeta.leagueName) &&
              !isManualWatchlistId(id)
            ) return;
            // Capture the updatedAt before we await — see write-guard
            // comment below.
            const beforeUpdatedAt = stBefore.lastMeta.updatedAt;
            const fresh = await fetchFreshScoreNow(id);
            // WRITE GUARD #1 — generation: a stop/restart that bumped
            // scoreRefreshGeneration while we were awaiting must not let
            // a stale in-flight worker mutate state under the new loop.
            if (myGen !== scoreRefreshGeneration) return;
            if (!fresh) return;
            const stNow = matchStates.get(id);
            const metaNow = stNow?.lastMeta;
            if (!stNow || !metaNow) return;
            // WRITE GUARD #2 — race vs setExternalScore / main scanner
            // tick: if anyone (Sofascore watchdog freeze-override, or the
            // 12s bulk-feed merge) wrote lastMeta while we were awaiting,
            // their write is by definition more recent than our fetch.
            // Skip rather than risk clobbering a newer correction with a
            // slower stale response. The next tick (~12s) will reconcile.
            if (metaNow.updatedAt !== beforeUpdatedAt) return;
            const liveChanged =
              metaNow.isLive !== fresh.isLive ||
              metaNow.state !== fresh.state ||
              metaNow.liveStateSource !== "explicit";
            if (
              metaNow.homeScore === fresh.homeScore &&
              metaNow.awayScore === fresh.awayScore &&
              !liveChanged
            ) return;
            const previous = {
              home: metaNow.homeScore,
              away: metaNow.awayScore,
            };
            const st = stNow;
            updateLastMetaWithScoreTracking(st, {
              ...metaNow, homeScore: fresh.homeScore, awayScore: fresh.awayScore,
              isLive: fresh.isLive, state: fresh.state, clockLabel: fresh.clockLabel,
              liveStateSource: "explicit", updatedAt: Date.now(),
            }, Date.now());
            if (!isLiveMeta(st.lastMeta)) {
              retireRuntimeMatch(id, st.lastMeta);
              return;
            }
            if (!st.attribution) {
              st.attribution = {
                lastAltOddsAt: null,
                lastScoreCheckAt: null,
                lastScoreOverrideAt: null,
                scoreOverrides: 0,
              };
            }
            // Track the check time so operators can see the loop is alive,
            // but deliberately do NOT bump scoreOverrides / lastScoreOverrideAt
            // here — those exist for the Sofascore watchdog's freeze-correction
            // path, and we don't want the UI's amber "score corrected" badge
            // to flash on every routine 12s refresh.
            st.attribution.lastScoreCheckAt = Date.now();
            logger.info(
              {
                matchId: id,
                previous,
                corrected: { home: fresh.homeScore, away: fresh.awayScore },
              },
              "[SCORE-REFRESH] Watchlist score updated via cache-bypass per-match fetch",
            );
          } catch (err) {
            logger.debug(
              { matchId: id, err: err instanceof Error ? err.message : err },
              "[SCORE-REFRESH] per-match fetch failed",
            );
          } finally {
            inFlight--;
            completed++;
            if (completed >= total) resolve();
            else pump();
          }
        })();
      }
    };
    pump();
  });
}

export function startWatchlistScoreRefresh(): void {
  scoreRefreshGeneration++;
  const myGen = scoreRefreshGeneration;
  const loop = async (): Promise<void> => {
    if (myGen !== scoreRefreshGeneration) return;
    try {
      await watchlistScoreRefreshTick(myGen);
    } catch (err) {
      logger.warn({ err }, "[SCORE-REFRESH] tick crashed");
    } finally {
      if (myGen === scoreRefreshGeneration) {
        scoreRefreshTimer = setTimeout(
          () => { void loop(); },
          WATCHLIST_FAST_POLL_INTERVAL_MS,
        );
      }
    }
  };
  scoreRefreshTimer = setTimeout(
    () => { void loop(); },
    WATCHLIST_FAST_POLL_INTERVAL_MS,
  );
  logger.info(
    {
      intervalMs: WATCHLIST_FAST_POLL_INTERVAL_MS,
      maxConcurrent: SCORE_REFRESH_MAX_CONCURRENT,
    },
    "[SCORE-REFRESH] Watchlist score refresh loop started",
  );
}

export function stopWatchlistScoreRefresh(): void {
  scoreRefreshGeneration++;
  if (scoreRefreshTimer !== null) {
    clearTimeout(scoreRefreshTimer);
    scoreRefreshTimer = null;
  }
}

export async function runWatchlistScoreRefreshCycle(): Promise<void> {
  await watchlistScoreRefreshTick(scoreRefreshGeneration);
}

/**
 * Legacy volume-card builder retained temporarily for win-rate compatibility.
 * This scanner-side hydration only updates state; the separate global
 * Excapper watcher may dispatch standalone volume alerts.
 *
 * Does a cache-bypass fetch of the live score immediately before send so
 * the score the user reads is the freshest available — not whatever the
 * scanner had in its 10s-old tick cache. Falls back to cached meta if
 * the fresh fetch fails (timeout, parse error, network blip).
 */
async function buildLegacyVolumeSnapshotWithoutDispatch(args: {
  provider: "Xcaper" | "Betfair";
  matchId: string;
  line: number;
  side: "Over" | "Under";
  /** Native-feed EUR amount that triggered the alert. */
  volDelta?: number;
  /**
   * Cumulative native-feed EUR total on this (line, side) after the triggering
   * bet — i.e. Excapper's "Summ" column. Rendered next to volDelta in
   * parens so the operator sees both the incoming spike and the running
   * tally without flipping screens.
   */
  volTotal?: number;
  matchMinute: string;
  /** Xcaper line / pivot value for audit context (typically same as `line`). */
  xcaperLine: number;
}): Promise<void> {
  const st = matchStates.get(args.matchId);
  if (!st) return;
  const cachedMeta = st.lastMeta;
  if (!cachedMeta) return;
  if (!matchTargetLeague(cachedMeta.leagueName)) return;

  // Cache-bypass score fetch RIGHT BEFORE evaluation. Live alerts fail closed
  // when this authoritative score is unavailable; prematch formatting may
  // still use the cached score because no live total has settled yet.
  const fresh = await fetchFreshScoreNow(args.matchId);
  if (cachedMeta.isLive && (!fresh || !fresh.isLive)) {
    scannerStats.alertsSuppressedByValueGuard++;
    logger.info(
      { matchId: args.matchId, side: args.side, line: args.line, reason: "live-score-unavailable" },
      "[MONEY SPIKE] alert suppressed by value guard",
    );
    return;
  }
  const homeScore = fresh?.homeScore ?? cachedMeta.homeScore;
  const awayScore = fresh?.awayScore ?? cachedMeta.awayScore;

  // Pull the current live Bet365 entry odds on the relevant side from
  // the last OU snapshot. This is the price the bot would tag for entry.
  const last = st.history[st.history.length - 1];
  const liveOdds =
    last != null
      ? (args.side === "Over" ? last.overDecimal : last.underDecimal).toFixed(2)
      : "—";

  // ----- UPSTREAM VALUE GUARD -----
  // Same protection as the odds-drop path: drop micro-odds parking and
  // "guaranteed clear" unders before recording or alerting. Excapper gives us a
  // live minute ("Time" cell) here, so the late-game score-buffer rule applies.
  const guardDecimalOdds =
    last != null ? (args.side === "Over" ? last.overDecimal : last.underDecimal) : null;
  const valueGuard = passesValueGuards({
    decimalOdds: guardDecimalOdds,
    targetSide: args.side === "Over" ? "OVER" : "UNDER",
    line: args.line,
    totalGoals: homeScore + awayScore,
    isLive: cachedMeta.isLive,
    minute: parseMatchMinute(args.matchMinute),
  });
  if (!valueGuard.ok) {
    scannerStats.alertsSuppressedByValueGuard++;
    logger.info(
      { matchId: args.matchId, side: args.side, line: args.line, reason: valueGuard.reason },
      "[MONEY SPIKE] alert suppressed by value guard",
    );
    return;
  }

  const e = escapeMdV2;
  const market = `${args.side} ${formatLine(args.line)}`;
  const minute = args.matchMinute || "—";
  // League shown on its own bold line above the fixture so the operator can
  // locate the match at a glance (same field the watchlist UI renders). Fall
  // back to the numeric league id when the name cache hasn't resolved yet.
  const displayLeague = cachedMeta.leagueName || `League #${cachedMeta.leagueId}`;

  // Amount Matched — Excapper's native EUR values, with no FX conversion.
  // Format: "€<spike> (€<cumulative> total)". The cumulative figure comes
  // from Excapper's "Summ" column (running per-(line,side) total AFTER
  // this bet), so it monotonically grows across the match rather than
  // resetting per tick. Falls back to just the spike if no total is
  // available (defensive — caller currently always passes one for Xcaper).
  const volStr = formatEurAmount(args.volDelta ?? 0);
  const totalStr =
    args.volTotal != null && args.volTotal > 0
      ? formatEurAmount(args.volTotal)
      : null;
  const amountLine =
    totalStr != null
      ? `💰 Amount Matched: ${e(volStr)} \\(${e(totalStr)} total\\)`
      : `💰 Amount Matched: ${e(volStr)}`;

  // VERBATIM TEMPLATE (user-approved). All dynamic values escaped for
  // MarkdownV2; literal "[", "]", "(", ")", ".", "'" in static text are
  // pre-escaped inline. The PROVIDER tag is bold + in parens so it reads
  // as a structured label, not body copy.
  // Match State line — live cards + penalties on a dedicated line below the
  // score. OMITTED ENTIRELY when there are zero cards AND no penalty (no point
  // showing "0-0 | 0-0"). Format: "🟨 YC: 2-1 | 🟥 RC: 0-1 | 🥅 Penalty: Yes (75')".
  // The whole content is passed through e() so the MarkdownV2 specials it
  // contains (-, |, (, )) are escaped in one pass; emojis are untouched.
  const evState = liveEventsCache.get(args.matchId);
  const matchStateLines: string[] = [];
  if (
    evState &&
    (evState.yellowHome > 0 ||
      evState.yellowAway > 0 ||
      evState.redHome > 0 ||
      evState.redAway > 0 ||
      evState.penalty)
  ) {
    const segs = [
      `🟨 YC: ${evState.yellowHome}-${evState.yellowAway}`,
      `🟥 RC: ${evState.redHome}-${evState.redAway}`,
    ];
    if (evState.penalty) {
      segs.push(
        `🥅 Penalty: Yes${
          evState.penaltyMinute != null ? ` (${evState.penaltyMinute}')` : ""
        }`,
      );
    }
    matchStateLines.push(`🎯 ${e(`Match State: ${segs.join(" | ")}`)}`);
  }

  const msg = [
    `*${e("SMART MONEY")}* \\(${e(args.provider)}\\)`,
    `🏆 *${e(displayLeague)}*`,
    `⚽️ ${e(cachedMeta.team1)} vs ${e(cachedMeta.team2)}`,
    `📊 Live Score: ${e(`${homeScore}:${awayScore}`)} \\(${e(minute)}'\\)`,
    ...matchStateLines,
    ``,
    `📉 Market: ${e(market)}`,
    `📈 Entry Odds: ${e(liveOdds)}`,
    amountLine,
    `📋 Xcaper Line: ${e(formatLine(args.xcaperLine))}`,
  ].join("\n");

  // ----- WIN-RATE TRACKER: persist anomaly snapshot -----
  // Money-spike alerts are watchlist-only by construction (setMatchVolume is
  // fed exclusively by the deep-fetch of watchlist matches), so no gate is
  // needed. The targeted side + line come straight from the Excapper Change
  // row, and matchMinute is parsed from the live-minute string.
  {
    const lastSnap = st.history[st.history.length - 1];
    const oddsAtFire = lastSnap
      ? (args.side === "Over" ? lastSnap.overDecimal : lastSnap.underDecimal) - 1
      : null;
    recordAnomaly({
      matchId: args.matchId,
      team1: cachedMeta.team1,
      team2: cachedMeta.team2,
      league: displayLeague,
      anomalyType: "MONEY_SPIKE",
      targetSide: args.side === "Over" ? "OVER" : "UNDER",
      line: args.line,
      matchMinute: parseMatchMinute(args.matchMinute),
      isLive: true,
      homeScore,
      awayScore,
      oddsAtFire,
      kickoffAtMs: st.lastMeta?.kickoffMs ?? null,
    });
  }

  // Intentionally no Telegram dispatch. Kept only as a legacy formatter seam
  // while old callers drain; reportTransactionSpike now records authentic
  // inflow for the next consolidated odds-drop alert instead.
  void msg;
}

function writeHydratedExcapperVolume(
  st: MatchState,
  samples: ReadonlyArray<{ line: number; over: number; under: number }>,
  excapperGameId: string,
): void {
  const now = Date.now();
  if (!st.volumes) st.volumes = new Map();
  for (const sample of samples) {
    const prev = st.volumes.get(sample.line);
    st.volumes.set(sample.line, {
      over: sample.over,
      under: sample.under,
      updatedAt: now,
      ...(prev
        ? {
            overPrev: prev.over,
            underPrev: prev.under,
            prevAt: prev.updatedAt,
          }
        : {}),
    });
  }
  st.excapperGameId = excapperGameId;
}

/**
 * Store Excapper money totals for an explicitly manual row. Unlike
 * setMatchVolume(), this is hydration only: it does not create spike flags,
 * touch auto-promotion TTL, or enter the transaction/Telegram pipeline.
 */
/** Side-effect-free preflight used before durable binding audit admission. */
export function canHydrateManualMatchVolume(matchId: string): boolean {
  if (matchId.startsWith("manual-text:")) {
    const signature = matchId.slice("manual-text:".length);
    return getNormalizedEntries().some((entry) =>
      entry.signature === signature && entry.origin === "manual" &&
      entry.matchId === undefined && entry.fragments.length === 2);
  }
  return !!matchStates.get(matchId)?.lastMeta && isManualExcapperHydrationState(matchId);
}
export function hydrateManualMatchVolume(
  matchId: string,
  samples: ReadonlyArray<{ line: number; over: number; under: number }>,
  excapperGameId: string,
): boolean {
  if (matchId.startsWith("manual-text:")) {
    const signature = matchId.slice("manual-text:".length);
    const entry = getNormalizedEntries().find(
      (candidate) =>
        candidate.signature === signature &&
        candidate.origin === "manual" &&
        candidate.matchId === undefined &&
        candidate.fragments.length === 2,
    );
    if (!entry) return false;
    const now = Date.now();
    manualTextVolumes.set(signature, {
      gameId: excapperGameId,
      samples: new Map(
        samples.map((sample) => [
          sample.line,
          { over: sample.over, under: sample.under, updatedAt: now },
        ]),
      ),
    });
    return true;
  }
  const st = matchStates.get(matchId);
  if (
    !st?.lastMeta ||
    !isManualExcapperHydrationState(matchId)
  ) {
    return false;
  }
  writeHydratedExcapperVolume(st, samples, excapperGameId);
  return true;
}

/** Detach a no-longer-valid manual-only Excapper association. */
export function clearManualMatchVolumeBinding(matchId: string): boolean {
  if (matchId.startsWith("manual-text:")) {
    return manualTextVolumes.delete(matchId.slice("manual-text:".length));
  }
  const st = matchStates.get(matchId);
  if (
    !st ||
    !isManualExcapperHydrationState(matchId)
  ) {
    return false;
  }
  st.volumes?.clear();
  st.excapperGameId = undefined;
  return true;
}

/** Detach volume state for a text-only entry before it is deleted. */
export function clearManualTextMatchVolumeBinding(
  fragments: readonly string[],
): boolean {
  const direct = getNormalizedEntries().find(
    (entry) =>
      entry.origin === "manual" &&
      entry.matchId === undefined &&
      entry.fragments.length === fragments.length &&
      entry.fragments.every((fragment, index) => fragment === fragments[index]),
  );
  const directRemoved = direct
    ? manualTextVolumes.delete(direct.signature)
    : false;
  if (fragments.length !== 2) return false;
  const matches = [...matchStates.entries()].filter(([, state]) =>
    state.lastMeta &&
    strictTeamPairMatches(
      fragments[0]!,
      fragments[1]!,
      state.lastMeta.team1,
      state.lastMeta.team2,
    ),
  );
  if (matches.length !== 1) return directRemoved;
  const [matchId, state] = matches[0]!;
  state.volumes?.clear();
  state.excapperGameId = undefined;
  return true;
}

/**
 * Per-watchlist-entry throttle so the "no live match found" debug dump
 * fires at most once per minute for any given fragment set. Without this,
 * a text-only entry that doesn't match anything would log the entire live
 * board every 5 seconds (every dashboard poll), drowning the journal.
 */
const lastMissedLogAt = new Map<string, number>();
const MISSED_LOG_THROTTLE_MS = 60_000;

function maybeLogLiveTitlesMissed(entrySignature: string, fragments: string[]): void {
  const now = Date.now();
  const last = lastMissedLogAt.get(entrySignature) ?? 0;
  if (now - last < MISSED_LOG_THROTTLE_MS) return;
  lastMissedLogAt.set(entrySignature, now);

  const liveTitles: string[] = [];
  for (const [id, st] of matchStates) {
    if (!st.lastMeta) continue;
    if (!st.lastMeta.isLive) continue;
    liveTitles.push(`${id}: ${st.lastMeta.team1} vs ${st.lastMeta.team2}`);
  }
  liveTitles.sort();
  // Structured logger only — they can grep `[WATCHLIST-MISS]` to see WHY
  // their text fragments didn't catch (e.g. "unsw fc (w)" vs "UNSW Women's FC").
  logger.info(
    { fragments, liveCount: liveTitles.length, sample: liveTitles.slice(0, 20) },
    "Watchlist text entry has no live match — dumping current live titles for diagnosis",
  );
}

/**
 * Alt-mirror branch: ingest an OU snapshot fetched from a sibling NowGoal
 * mirror by lib/altStream.ts. Used as a SUPPLEMENT, never as a primary:
 *
 *   - For matches the primary already has: only refresh if the primary
 *     hasn't seen an odds change in `altStaleAfterMs` (default 60s). This
 *     prevents the alt branch from clobbering fresh primary ticks with
 *     potentially-older data (the alt mirror polls less often than the
 *     primary tick loop).
 *   - For matches the primary DOESN'T have yet (e.g. the primary mirror
 *     missed a regional fixture): seed minimal state immediately so the
 *     dashboard can show the row.
 *
 * Pure data merge — does NOT run the alert pipeline. Alerts continue to
 * fire exclusively from the primary tick path (single source of truth for
 * Telegram), so the alt stream can never produce duplicate alerts.
 *
 * Returns counters for telemetry. Never throws.
 */
export function mergeAltOddsSnapshot(
  altPrimaryMap: Map<string, OUEntry>,
  altMetaMap: Map<string, MatchMeta>,
  opts: { altStaleAfterMs?: number; source: string } = { source: "alt" },
): { seeded: number; refreshed: number; skippedFresh: number } {
  const staleAfter = opts.altStaleAfterMs ?? 60_000;
  const now = Date.now();
  let seeded = 0;
  let refreshed = 0;
  let skippedFresh = 0;

  for (const [matchId, ou] of altPrimaryMap) {
    let state = matchStates.get(matchId);
    const altMeta = altMetaMap.get(matchId);
    if (!altMeta || !acceptRuntimeMeta(matchId, altMeta)) continue;
    const altLeagueName = altMeta
      ? altMeta.leagueName ?? leagueNames.get(altMeta.leagueId) ?? ""
      : "";
    // Alt odds are allowed to seed a row only when the alt stream also has a
    // resolved target league.  Existing target state may continue receiving
    // alt odds while the current alt tick omits its metadata; an unknown row
    // is never made eligible merely because it is pinned/priority.
    const altLeague = matchTargetLeague(altLeagueName);
    const manualOverride = isManualWatchlistId(matchId);
    const stateLeague = matchTargetLeague(state?.lastMeta?.leagueName);
    if (altMeta && !altLeague && !manualOverride) continue;
    if (!state && !altLeague && !manualOverride) continue;
    if (state && !stateLeague && !altLeague && !manualOverride) continue;
    if (!state) {
      // Primary missed this match entirely — seed from alt so it's visible.
      // We deliberately use a minimal init (no benchmark history etc.) so the
      // primary tick can fill in the rest on its next sweep.
      state = {
        history: [],
        benchmarkHistory: [],
        lastAlertAt: 0,
        lastOddsChangeAt: now,
        lastAnalyzedAt: 0,
      };
      seeded++;
    } else if (
      state.lastPrimaryTickAt != null &&
      now - state.lastPrimaryTickAt < staleAfter
    ) {
      // Primary has actually visited this match recently (regardless of
      // whether odds moved) — do not overwrite its fresh ODDS. This is the
      // strict "alt never clobbers a fresh primary tick" guarantee.
      //
      // BUT we still backfill MISSING meta here: team/league/score seeding is
      // independent of odds freshness and never overrides primary-authoritative
      // meta (guarded by !state.lastMeta). This matters in global-paused
      // (hyper-focus) mode — that tick stamps lastPrimaryTickAt WITHOUT ever
      // fetching the meta feed, so without this backfill a pinned watchlist
      // match would be perpetually "fresh primary" yet never gain lastMeta,
      // leaving its Pro Alert eval (evaluateOddsDropAlert is gated on lastMeta)
      // and smart-money eval (getWatchlistMatchesForVolume requires lastMeta)
      // suppressed indefinitely. The alt feed is the only meta source while
      // paused, so seed from it here.
      const freshMeta = altMeta;
      if (freshMeta && (!state.lastMeta || !matchTargetLeague(state.lastMeta.leagueName))) {
        const leagueName = freshMeta.leagueName ?? leagueNames.get(freshMeta.leagueId) ?? "";
        if (!matchTargetLeague(leagueName) && !manualOverride) {
          skippedFresh++;
          continue;
        }
        const liveState = resolveLiveState(freshMeta, state.lastMeta);
        updateLastMetaWithScoreTracking(state, {
          team1: freshMeta.team1,
          team2: freshMeta.team2,
          leagueId: freshMeta.leagueId,
          leagueName,
          homeScore: freshMeta.homeScore,
          awayScore: freshMeta.awayScore,
          ...liveState,
          kickoffMs: freshMeta.kickoffMs,
          clockLabel: freshMeta.clockLabel ?? null,
          updatedAt: now,
        }, now);
      }
      skippedFresh++;
      continue;
    } else {
      refreshed++;
    }

    const prev = state.history[state.history.length - 1];
    const current: OUSnapshot = {
      ts: now,
      overDecimal: ou.overDecimal,
      underDecimal: ou.underDecimal,
      line: ou.line,
    };
    if (
      !prev ||
      prev.line !== ou.line ||
      prev.overDecimal !== ou.overDecimal ||
      prev.underDecimal !== ou.underDecimal
    ) {
      state.lastOddsChangeAt = now;
    }
    state.history.push(current);
    state.history = pruneHistory(state.history, now);

    const meta = altMeta;
    if (meta && (!state.lastMeta || !matchTargetLeague(state.lastMeta.leagueName))) {
      // Only seed lastMeta when primary hasn't set it yet — never override
      // primary's authoritative team names / league.
      const leagueName = meta.leagueName ?? leagueNames.get(meta.leagueId) ?? "";
      if (!matchTargetLeague(leagueName) && !manualOverride) continue;
      const liveState = resolveLiveState(meta, state.lastMeta);
      updateLastMetaWithScoreTracking(state, {
        team1: meta.team1,
        team2: meta.team2,
        leagueId: meta.leagueId,
        leagueName,
        homeScore: meta.homeScore,
        awayScore: meta.awayScore,
        ...liveState,
        kickoffMs: meta.kickoffMs,
        clockLabel: meta.clockLabel ?? null,
        updatedAt: now,
      }, now);
    } else if (state.lastMeta) {
      // Alt stream just committed a fresh OU sample for an already-tracked row
      // (we only reach here when primary did NOT visit recently — see the
      // skippedFresh guard above). Bump the per-match "last successful write"
      // stamp so the dashboard "Last update" column reflects alt-mirror
      // activity too; without this an alt-only row looks stale while its odds
      // are actively refreshing. Team/league/score stay primary-authoritative.
      state.lastMeta.updatedAt = now;
    }

    if (isLiveMeta(state.lastMeta)) matchStates.set(matchId, state);
    if (!state.attribution) {
      state.attribution = {
        lastAltOddsAt: null,
        lastScoreCheckAt: null,
        lastScoreOverrideAt: null,
        scoreOverrides: 0,
      };
    }
    state.attribution.lastAltOddsAt = now;
  }

  return { seeded, refreshed, skippedFresh };
}

/**
 * Score watchdog override surface. Called by lib/sofascoreWatchdog.ts when
 * an alternate live-score feed disagrees with the primary feed AND we have
 * reason to believe the primary is frozen (odds moving while score sits
 * still for > N minutes).
 *
 * Pure mutation — no history, no array growth, just overwrites lastMeta
 * score fields and bumps the override counter. Returns whether anything
 * actually changed (so the caller can log a one-shot reconciliation line
 * without spamming on "in sync" ticks).
 */
export function setExternalScore(
  matchId: string,
  homeScore: number,
  awayScore: number,
  source: string,
): { changed: boolean; previous?: { home: number; away: number } } {
  const st = matchStates.get(matchId);
  if (!st || !st.lastMeta) return { changed: false };
  const now = Date.now();

  if (!st.attribution) {
    st.attribution = {
      lastAltOddsAt: null,
      lastScoreCheckAt: null,
      lastScoreOverrideAt: null,
      scoreOverrides: 0,
    };
  }
  st.attribution.lastScoreCheckAt = now;

  if (st.lastMeta.homeScore === homeScore && st.lastMeta.awayScore === awayScore) {
    return { changed: false };
  }
  const previous = { home: st.lastMeta.homeScore, away: st.lastMeta.awayScore };
  updateLastMetaWithScoreTracking(st, {
    ...st.lastMeta, homeScore, awayScore, updatedAt: now,
  }, now);
  st.attribution.lastScoreOverrideAt = now;
  st.attribution.scoreOverrides++;

  logger.warn(
    {
      matchId,
      source,
      previous,
      corrected: { home: homeScore, away: awayScore },
      totalOverrides: st.attribution.scoreOverrides,
    },
    "[SCORE-WATCHDOG] 🔧 Forced score correction from external feed",
  );
  return { changed: true, previous };
}

/**
 * Read-only access for cross-stream modules (altStream, sofascoreWatchdog)
 * that need to enumerate matches without copying state. Returns the live
 * Map — callers MUST treat it as read-only. Exposing the Map directly
 * (instead of an array copy) is intentional for V8 escape-analysis perf
 * on the ~600-match feed.
 */
export function _internalGetMatchStates(): ReadonlyMap<string, Readonly<MatchState>> {
  return matchStates;
}

// NOTE: A previous multi-book drift stream was removed because Cloudflare
// hard-blocks its upstream from this server's egress (every endpoint
// returned HTTP 403), making the merge surface, in-memory sample state,
// dedicated Telegram provider branch, and matching dashboard column
// permanently inert. All of those were deleted to keep the data layer
// honest. Re-introduce when/if a reachable per-book odds source is wired in.
// TEMPORARY DIAGNOSTIC (remove after the "identical OU across matches" report
// is resolved): throttle for the per-row matchId → OU audit log emitted by
// getWatchlistLiveSnapshot(). The dashboard polls on a few-second cadence, so
// we cap the audit to once per interval to avoid flooding the log.
const WATCHLIST_AUDIT_INTERVAL_MS = 15_000;
let lastWatchlistAuditAt = 0;
// TEMPORARY DIAGNOSTIC (remove with the bulk-feed audit block in the main
// tick): throttle for the [BULK-FEED-AUDIT] log that confirms the scraper sees
// the full upstream match list each tick.
const BULK_FEED_AUDIT_INTERVAL_MS = 15_000;
let lastBulkFeedAuditAt = 0;

/**
 * Returns the current set of watchlist entries paired with their live
 * tracked match (if any). The dashboard renders this so the user can
 * visually compare bot odds against the official site.
 */
export function getWatchlistLiveSnapshot() {
  const snap = getWatchlistSnapshot();
  // Index normalized entries by signature so we can recover matchId + fragments
  // (the public snapshot intentionally exposes only display-safe fields).
  // Signatures are namespaced (`id:` vs `txt:`) so collisions are structurally
  // impossible — but if a duplicate ever shows up it indicates corruption;
  // log it so we don't silently mis-associate live data to the wrong entry.
  const normIndex = new Map<string, ReturnType<typeof getNormalizedEntries>[number]>();
  for (const e of getNormalizedEntries()) {
    if (normIndex.has(e.signature)) {
      logger.error(
        { signature: e.signature },
        "Duplicate watchlist signature detected — entry identities have collided",
      );
    }
    normIndex.set(e.signature, e);
  }
  // Garbage-collect throttle entries for signatures that no longer exist so
  // the map can't grow unbounded over a long-lived process with high churn.
  const liveSigs = new Set(normIndex.keys());
  for (const sig of lastMissedLogAt.keys()) {
    if (!liveSigs.has(sig)) lastMissedLogAt.delete(sig);
  }
  const now = Date.now();
  const out = snap.entries.map((entry) => {
    const norm = normIndex.get(entry.signature);
    const matchId = norm?.matchId;
    const fragments = norm?.fragments ?? [];

    let live: {
      matchId: string;
      team1: string;
      team2: string;
      league: string;
      isLive: boolean;
      /** Authoritative NowGoal phase: live, scheduled, finished, or unknown. */
      matchStatus: "live" | "scheduled" | "finished" | "unknown";
      homeScore: number;
      awayScore: number;
      line: number | null;
      // HONG KONG ODDS — the EXACT format Bet365 publishes on NowGoal26's live
      // page (always positive, e.g. 0.85, 0.97, 1.05). Computed as decimal-1
      // from our internal decimal store. NO sign flipping, NO Malay conversion,
      // NO formula tricks — pure subtraction so the dashboard is a 1:1 mirror
      // of the bookmaker line.
      overHk: number | null;
      underHk: number | null;
      prevLine: number | null;
      prevOverHk: number | null;
      prevUnderHk: number | null;
      overTrend: "up" | "down" | "flat";
      underTrend: "up" | "down" | "flat";
      lineChanged: boolean;
      lastChangeAgoSec: number | null;
      lastSeenAgoSec: number;
      historyPoints: number;
      volumes: Array<{
        line: number;
        over: number;
        under: number;
        totalVolume: number;
        overSharePct: number | null;
        underSharePct: number | null;
        overDelta: number | null;
        underDelta: number | null;
        overSpike: boolean;
        underSpike: boolean;
        updatedAgoSec: number;
      }>;
    } | null = null;

    // ID-FAST-PATH: if the entry has a numeric matchId from a pasted URL,
    // look it up directly in matchStates. This bypasses ALL fuzzy text
    // matching — bulletproof for regional leagues whose team-name strings
    // on the site (e.g. "UNSW FC (W)") don't match the feed strings
    // ("UNSW Football Club Women").
    const buildLive = (id: string, st: MatchState) => {
      if (!st.lastMeta) return null;
      // Automated output remains target-league-only. A user-pasted numeric
      // id is an explicit exception so an out-of-allowlist fixture still
      // renders its stored row and any deep-enriched odds/book history.
      if (!matchTargetLeague(st.lastMeta.leagueName) && !isManualWatchlistId(id)) return null;
      const last = st.history[st.history.length - 1];
      // prev = the second-to-last history snapshot. We compare tick-over-
      // tick rather than against an absolute baseline so the dashboard can
      // flash arrows on EVERY Bet365 odds move, matching the per-tick rhythm
      // of the "Bet365 Odds Change" history popup on the site.
      const prev = st.history.length >= 2 ? st.history[st.history.length - 2] : null;

      // direction helper: "down" when the decimal odds FELL (money pouring
      // in on that side); "up" when they ROSE (money leaving); "flat" when
      // no change OR no previous snapshot exists.
      const dir = (curr: number, p: number | undefined): "up" | "down" | "flat" => {
        if (p === undefined || p === null) return "flat";
        if (curr < p) return "down";
        if (curr > p) return "up";
        return "flat";
      };

      // HK = decimal − 1. Single, deterministic, always-positive subtraction.
      // No sign branches, no Malay inversion, no |x| tricks — that's the
      // whole point of the 1:1 rule. Trend is still computed on the raw
      // decimal store (which is the same as HK + 1, so direction is identical
      // to comparing HK values): lower = price shortened = market pressure.
      const overHk = last ? last.overDecimal - 1 : null;
      const underHk = last ? last.underDecimal - 1 : null;
      const prevOverHk = prev ? prev.overDecimal - 1 : null;
      const prevUnderHk = prev ? prev.underDecimal - 1 : null;

      // Signed delta = current − previous. Positive ⇒ odds ROSE (money
      // leaving that side, red). Negative ⇒ odds FELL (money pouring in,
      // green). null when we have no previous snapshot yet OR when the
      // handicap line itself moved (different market — comparing across a
      // line shift would produce a misleading delta number). The fast
      // watchlist poll (~12s, see WATCHLIST_FAST_POLL_INTERVAL_MS) rewrites
      // st.history every tick, so this delta refreshes on the ultra-loop
      // cadence without depending on the 12s global scanner.
      const lineChanged = last !== null && prev !== null && prev.line !== last.line;
      const overDeltaHk =
        last && prev && !lineChanged ? overHk! - (prev.overDecimal - 1) : null;
      const underDeltaHk =
        last && prev && !lineChanged ? underHk! - (prev.underDecimal - 1) : null;

      // Crown odds (benchmark book) — sourced from the same NowGoal
      // `goal3.xml` upstream we already poll, so zero extra network cost.
      // PER-BOOK LINE INDEPENDENCE: we emit Crown's OWN active handicap
      // even when it differs from Bet365's (operators want to see e.g.
      // Bet365 @ 2/2.5 next to Crown @ 2.5 side-by-side, with each row's
      // line label making the difference explicit). Trends are gated on
      // Crown's own line continuity (prev sample must be same Crown line)
      // so a Crown line shift doesn't render as a fake price swing.
      const benchLast =
        st.benchmarkHistory.length > 0
          ? st.benchmarkHistory[st.benchmarkHistory.length - 1]
          : null;
      const benchPrev =
        st.benchmarkHistory.length >= 2
          ? st.benchmarkHistory[st.benchmarkHistory.length - 2]
          : null;
      const crownLine = benchLast ? benchLast.line : null;
      const crownOverDecimal = benchLast ? benchLast.overDecimal : null;
      const crownUnderDecimal = benchLast ? benchLast.underDecimal : null;
      const crownPrevAlignedOver =
        benchPrev && benchLast && benchPrev.line === benchLast.line
          ? benchPrev.overDecimal
          : undefined;
      const crownPrevAlignedUnder =
        benchPrev && benchLast && benchPrev.line === benchLast.line
          ? benchPrev.underDecimal
          : undefined;
      const crownOverTrend: "up" | "down" | "flat" = benchLast
        ? dir(benchLast.overDecimal, crownPrevAlignedOver)
        : "flat";
      const crownUnderTrend: "up" | "down" | "flat" = benchLast
        ? dir(benchLast.underDecimal, crownPrevAlignedUnder)
        : "flat";
      // Tick-over-tick HK delta for Crown — null when no aligned prev sample
      // (either no history yet OR a line shift broke comparability). HK delta
      // equals decimal delta since HK = decimal − 1 (the offset cancels).
      const crownOverDeltaHk =
        benchLast && crownPrevAlignedOver != null
          ? benchLast.overDecimal - crownPrevAlignedOver
          : null;
      const crownUnderDeltaHk =
        benchLast && crownPrevAlignedUnder != null
          ? benchLast.underDecimal - crownPrevAlignedUnder
          : null;

      // Per-book independent line/odds payload for the extra NOWGOAL stack
      // books (Sbobet, M88, 12Bet, 18Bet). Each book reports its OWN active
      // handicap — the UI badges them in yellow alongside Bet365/Crown so
      // operators can see when books quote different lines on the same match.
      // Trends gate on same-line continuity (mirrors the Crown logic) so a
      // line shift never renders as a fake price swing. null entry means
      // no sample has landed for that book yet (renders "—").
      const books: Record<
        ExtraBookKey,
        {
          line: number;
          overDecimal: number;
          underDecimal: number;
          overTrend: "up" | "down" | "flat";
          underTrend: "up" | "down" | "flat";
          // Tick-over-tick HK delta (same units as the displayed value).
          // null when the line just shifted or there's no prev sample —
          // mirrors the Bet365/Crown delta semantics.
          overDeltaHk: number | null;
          underDeltaHk: number | null;
        } | null
      > = { Sbobet: null, M88: null, "12Bet": null, "18Bet": null, VSBet: null };
      if (st.bookHistory) {
        for (const book of EXTRA_BOOK_KEYS) {
          const hist = st.bookHistory.get(book);
          if (!hist || hist.length === 0) continue;
          const bLast = hist[hist.length - 1]!;
          const bPrev = hist.length >= 2 ? hist[hist.length - 2]! : null;
          const sameLine = bPrev != null && bPrev.line === bLast.line;
          books[book] = {
            line: bLast.line,
            overDecimal: bLast.overDecimal,
            underDecimal: bLast.underDecimal,
            overTrend: sameLine ? dir(bLast.overDecimal, bPrev!.overDecimal) : "flat",
            underTrend: sameLine ? dir(bLast.underDecimal, bPrev!.underDecimal) : "flat",
            overDeltaHk: sameLine ? bLast.overDecimal - bPrev!.overDecimal : null,
            underDeltaHk: sameLine ? bLast.underDecimal - bPrev!.underDecimal : null,
          };
        }
      }

      return {
        matchId: id,
        team1: st.lastMeta.team1,
        team2: st.lastMeta.team2,
        league: st.lastMeta.leagueName,
        isLive: st.lastMeta.isLive,
        matchStatus: (
          st.lastMeta.state != null
            ? st.lastMeta.state >= 1
              ? "live"
              : st.lastMeta.state < 0
                ? "finished"
                : "scheduled"
            : st.lastMeta.isLive
              ? "live"
              : "unknown"
        ) as "live" | "scheduled" | "finished" | "unknown",
        homeScore: st.lastMeta.homeScore,
        awayScore: st.lastMeta.awayScore,
        // Estimated live match minute, derived from kickoff time. NowGoal's
        // bulk feed carries no live clock, so this is elapsed wall time since
        // kickoff (includes the HT break — treat as an estimate, capped at
        // 120'). null when not live or kickoff unknown.
        minute:
          st.lastMeta.isLive && st.lastMeta.kickoffMs !== null
            ? Math.min(Math.max(Math.floor((now - st.lastMeta.kickoffMs) / 60_000) + 1, 1), 120)
            : null,
        // Live match-state badges (cards + penalties), team-specific. home maps
        // to team1, away to team2 (the per-match title is "Home VS Away"). null
        // until the type=15 incident feed has been decoded for this match.
        events: (() => {
          const ev = liveEventsCache.get(id);
          if (!ev) return null;
          return {
            yc: { home: ev.yellowHome, away: ev.yellowAway },
            rc: { home: ev.redHome, away: ev.redAway },
            penalty: { present: ev.penalty, minute: ev.penaltyMinute },
          };
        })(),
        line: last?.line ?? null,
        // Hong Kong odds (e.g. 0.85, 0.97). Mirror of the site value.
        overHk,
        underHk,
        prevLine: prev?.line ?? null,
        prevOverHk,
        prevUnderHk,
        // Signed tick-over-tick movement in HK odds units. The dashboard
        // renders these directly as "+0.10" / "-0.15" next to the arrow.
        overDeltaHk,
        underDeltaHk,
        overTrend: last ? dir(last.overDecimal, prev?.overDecimal) : "flat",
        underTrend: last ? dir(last.underDecimal, prev?.underDecimal) : "flat",
        lineChanged,
        lastChangeAgoSec: st.lastOddsChangeAt
          ? Math.round((now - st.lastOddsChangeAt) / 1000)
          : null,
        lastSeenAgoSec: Math.round((now - st.lastMeta.updatedAt) / 1000),
        historyPoints: st.history.length,
        // Crown (benchmark book) decimal odds — same NowGoal feed, no
        // extra fetch. Crown's OWN active line is published alongside so
        // the UI can render an independent per-book line label. null
        // only when no Crown sample has landed yet for this match.
        crownLine,
        crownOverDecimal,
        crownUnderDecimal,
        crownOverTrend,
        crownUnderTrend,
        crownOverDeltaHk,
        crownUnderDeltaHk,
        // Per-book payload for Sbobet/M88/12Bet/18Bet (each book's OWN line + odds).
        // Backend value is European decimal — frontend renders (dec − 1) to stay
        // on the HK scale used by NowGoal's own matrix and the Bet365 column.
        books,
        // ----- Excapper multi-line volume snapshot -----
        // One row per OU line that currently has any liquidity. Each row
        // exposes the per-window DELTA (not the running total) plus a
        // spike flag that's "active" only while:
        //   (a) the spike timestamp is within the last 90s, AND
        //   (b) Bet365 odds haven't moved since the spike was registered.
        // Once the bookmaker catches up (lastOddsChangeAt advances past
        // the spike timestamp) the highlight clears on the next snapshot.
        volumes: st.volumes
          ? [...st.volumes.entries()]
              .sort(([a], [b]) => a - b)
              .map(([line, v]) => ({
                line,
                over: v.over,
                under: v.under,
                totalVolume: v.over + v.under,
                overSharePct:
                  v.over + v.under > 0 ? (v.over / (v.over + v.under)) * 100 : null,
                underSharePct:
                  v.over + v.under > 0 ? (v.under / (v.over + v.under)) * 100 : null,
                // Δ = current − prev. null on first sample for this line.
                overDelta: typeof v.overPrev === "number" ? v.over - v.overPrev : null,
                underDelta:
                  typeof v.underPrev === "number" ? v.under - v.underPrev : null,
                overSpike:
                  typeof v.overSpikeAt === "number" &&
                  now - v.overSpikeAt < 90_000 &&
                  st.lastOddsChangeAt < v.overSpikeAt,
                underSpike:
                  typeof v.underSpikeAt === "number" &&
                  now - v.underSpikeAt < 90_000 &&
                  st.lastOddsChangeAt < v.underSpikeAt,
                updatedAgoSec: Math.round((now - v.updatedAt) / 1000),
              }))
          : [],
        // ----- Signal score (pure, on-the-fly, no history buffers) -----
        // Pick the volume row whose Excapper line is closest to the current
        // Bet365 handicap line — that's the market the bookmaker price
        // belongs to, so it's the only one we can fairly blend with
        // bookmaker-implied probability. Skip entirely if no volume row
        // has crossed the MIN_VOLUME_EUR floor (CPU + noise saver).
        signal: (() => {
          if (!st.volumes || st.volumes.size === 0) return null;
          let bestRow: VolumeSample | null = null;
          let bestDelta = Infinity;
           if (!last) return null;
           for (const [vLine, v] of st.volumes) {
             const d = Math.abs(vLine - last.line);
            if (d < bestDelta) {
              bestDelta = d;
              bestRow = v;
            }
          }
          if (!bestRow) return null;
          const overSpikeActive =
            typeof bestRow.overSpikeAt === "number" &&
            now - bestRow.overSpikeAt < 90_000 &&
            st.lastOddsChangeAt < bestRow.overSpikeAt;
          const underSpikeActive =
            typeof bestRow.underSpikeAt === "number" &&
            now - bestRow.underSpikeAt < 90_000 &&
            st.lastOddsChangeAt < bestRow.underSpikeAt;
          return computeSignal({
            overDecimal: last.overDecimal,
            underDecimal: last.underDecimal,
            volumeOver: bestRow.over,
            volumeUnder: bestRow.under,
            overSpike: overSpikeActive,
            underSpike: underSpikeActive,
            overTrend: dir(last.overDecimal, prev?.overDecimal),
            underTrend: dir(last.underDecimal, prev?.underDecimal),
          });
        })(),
        // ----- Cross-stream provenance badges -----
        // Surface (a) when the alt-mirror branch last touched this row and
        // (b) when the Sofascore watchdog last corrected a frozen score, so
        // the dashboard can show a small badge. Null when the feature has
        // never fired for this match.
        altOddsAgoSec:
          st.attribution?.lastAltOddsAt != null
            ? Math.round((now - st.attribution.lastAltOddsAt) / 1000)
            : null,
        scoreOverrideAgoSec:
          st.attribution?.lastScoreOverrideAt != null
            ? Math.round((now - st.attribution.lastScoreOverrideAt) / 1000)
            : null,
        scoreOverrideCount: st.attribution?.scoreOverrides ?? 0,
        // ----- Dynamic win-rate (live probability engine) -----
        // Historical resolved win-rate for the anomaly pattern currently active
        // on this match. null when no recent anomaly fired on it. The tracker
        // returns sufficient=false (and pct=null) until the chosen bucket has
        // enough resolved cases, so the UI can show a "building" state.
        winRate: computeWinRateForMatch(id),
      };
    };

    if (matchId) {
      const st = matchStates.get(matchId);
      if (st) live = buildLive(matchId, st);
    }

    if (!live && fragments.length > 0) {
      for (const [id, st] of matchStates) {
        if (!st.lastMeta) continue;
        const t1 = st.lastMeta.team1.toLowerCase();
        const t2 = st.lastMeta.team2.toLowerCase();
        const combined = `${t1} || ${t2}`;
        const allHit = fragments.every((f) => combined.includes(f));
        if (!allHit) continue;
        live = buildLive(id, st);
        if (live) break;
      }
    }

    // Debug aid: when a TEXT-only entry can't be matched against any live
    // feed title, dump the current live titles (throttled per-entry to once
    // a minute) so the user can see exactly why their fragments didn't
    // match (e.g. "UNSW FC (W)" vs "NSW W-League Womens"). Skipped for
    // id-only entries because those don't rely on fuzzy matching.
    if (!live && fragments.length > 0 && !matchId) {
      maybeLogLiveTitlesMissed(entry.signature, fragments);
    }

    const fetchState = matchId ? directFetchStatus.get(matchId) : undefined;
    const status: "ready" | "loading" | "error" = fetchState?.kind === "error"
      ? "error"
      : live && (live.historyPoints > 0 || live.matchStatus === "finished")
        ? "ready"
        : "loading";
    const statusMessage =
      fetchState?.message ??
      (live?.matchStatus === "finished" && live.historyPoints === 0
        ? "Finished match — historical score available; no current live odds"
        : status === "loading"
          ? matchId
            ? "Waiting for direct NowGoal metadata or the first odds snapshot"
            : "Waiting for a matching live fixture"
          : undefined);

    const directTextVolume = manualTextVolumes.get(entry.signature);
    const excapperVolumes = directTextVolume
      ? [...directTextVolume.samples.entries()]
          .sort(([a], [b]) => a - b)
          .map(([line, volume]) => {
            const totalVolume = volume.over + volume.under;
            return {
              line,
              over: volume.over,
              under: volume.under,
              totalVolume,
              overSharePct: totalVolume > 0 ? (volume.over / totalVolume) * 100 : null,
              underSharePct: totalVolume > 0 ? (volume.under / totalVolume) * 100 : null,
              overDelta: null,
              underDelta: null,
              overSpike: false,
              underSpike: false,
              updatedAgoSec: Math.round((now - volume.updatedAt) / 1000),
            };
          })
      : [];
    return { ...entry, live, excapperVolumes, status, statusMessage };
  });

  // ----- TEMPORARY DIAGNOSTIC: per-row matchId → Bet365 OU audit -----
  // Verifies the user's "different matches show identical Over/Under figures"
  // report against ground truth. Emits, once per WATCHLIST_AUDIT_INTERVAL_MS:
  //   1. one INFO line listing every live row's resolved matchId + OU figures
  //      so it can be confirmed each row carries independent, matchId-keyed
  //      odds (NOT one shared/cached value), and
  //   2. an ERROR if two DISTINCT watchlist rows resolve to the SAME matchId —
  //      the precise mapping-collision failure that would produce identical OU.
  // Remove this whole block once the report is resolved.
  const auditNow = Date.now();
  if (auditNow - lastWatchlistAuditAt >= WATCHLIST_AUDIT_INTERVAL_MS) {
    lastWatchlistAuditAt = auditNow;
    const rows = out
      .filter((r) => r.live && r.live.overHk !== null && r.live.underHk !== null)
      .map((r) => ({
        match: `${r.live!.team1} vs ${r.live!.team2}`,
        matchId: r.live!.matchId,
        line: r.live!.line,
        overHk: Number(r.live!.overHk!.toFixed(2)),
        underHk: Number(r.live!.underHk!.toFixed(2)),
      }));
    const byId = new Map<string, string[]>();
    for (const r of rows) {
      const labels = byId.get(r.matchId) ?? [];
      labels.push(r.match);
      byId.set(r.matchId, labels);
    }
    for (const [matchId, matches] of byId) {
      if (matches.length > 1) {
        logger.error(
          { matchId, rows: matches },
          "[WATCHLIST-AUDIT] Mapping collision — multiple watchlist rows resolved to the SAME matchId",
        );
      }
    }
    logger.info(
      { count: rows.length, rows },
      "[WATCHLIST-AUDIT] Per-row matchId → Bet365 OU mapping (each row should carry independent odds)",
    );
  }

  const entries = out.filter((row) => row.live?.isLive && row.live.matchStatus === "live")
    .map((row) => ({ ...row, matchPhase: "Live" as const }));
  return { ...snap, count: entries.length, entries, savedEntries: out };
}

// ----- Odds Volatility (frozen-mirror) detection -----
// Fast watchlist polling must not turn a quiet minute into a failover. Require
// both five minutes of wall-clock silence and multiple successful active-data
// samples before a parseable snapshot can be called frozen.
const VOLATILITY_STALE_WINDOW_MS = NOWGOAL_VOLATILITY_STALE_WINDOW_MS;
const VOLATILITY_MIN_SUCCESSFUL_SAMPLES = NOWGOAL_VOLATILITY_MIN_SUCCESSFUL_SAMPLES;
const VOLATILITY_ROTATION_COOLDOWN_MS = NOWGOAL_AUTO_SWITCH_COOLDOWN_MS;
// Last N tick signatures for telemetry / dashboard visibility.
const volatilityRing: string[] = [];
const VOLATILITY_RING_SIZE = 8;
// Guard against duplicate side effects (metric increment, log lines) if
// successive ticks both decide to rotate before the first failover resolves.
// tryFailover's own singleflight coalesces the probe cascade, but coalesced
// callers each still run their own post-result branch — without this guard
// that would mean 2× log noise per real rotation.
let staleFailoverInFlight = false;

function hasObservedOddsMovement(history: ReadonlyArray<OUSnapshot>): boolean {
  for (let i = 1; i < history.length; i++) {
    const a = history[i - 1]!;
    const b = history[i]!;
    if (
      a.line !== b.line ||
      a.overDecimal !== b.overDecimal ||
      a.underDecimal !== b.underDecimal
    ) return true;
  }
  return false;
}

// ----- Helpers -----
function malayToDecimal(malay: number): number {
  if (isNaN(malay)) return 0;
  return malay >= 0 ? malay + 1 : 1 / Math.abs(malay) + 1;
}

// Inverse of malayToDecimal — recover the raw Malaysian / In-Play number
// the source site actually publishes (e.g. 0.85, -0.95). Used by the
// watchlist snapshot so the dashboard can show identical digits to the
// NowGoal26 Bet365 column without any mathematical adjustment.
//   dec >= 2  →  positive malay = dec - 1
//   dec <  2  →  negative malay = -1 / (dec - 1)
// The boundary dec === 2 is ambiguous (both +1 and -1 map to 2); we prefer
// the positive branch because that's how Bet365 displays even money.
function decimalToMalay(decimal: number): number {
  if (!isFinite(decimal) || decimal <= 1) return 0;
  if (decimal >= 2) return +(decimal - 1).toFixed(2);
  return +(-1 / (decimal - 1)).toFixed(2);
}

/**
 * Compute a deterministic signature for the current primary OU snapshot.
 * Identical signatures across consecutive ticks ⇒ the mirror is serving
 * cached / frozen data even though HTTP 200 + parse both succeed.
 *
 * We sum every overDecimal × 1000 (rounded) across the map. A real live
 * market produces a different sum every ~12s tick; a frozen mirror produces
 * the exact same sum every tick. Cheap O(N) and collision-resistant enough
 * for staleness detection (we don't need cryptographic strength).
 */
function computeOddsSignature(primaryMap: Map<string, OUEntry>): string {
  // Collision-resistant: build a sorted-by-matchId digest of every
  // (matchId, line, over, under) tuple, then FNV-1a hash to 32 bits.
  // Sum-based hashes can hide offsetting moves (one match +0.05, another -0.05
  // = same sum), which would let a moving market look frozen. Sorting ensures
  // the same set of matches in any iteration order produces the same hash.
  const tuples: string[] = [];
  for (const [matchId, ou] of primaryMap) {
    tuples.push(`${matchId}|${ou.line}|${Math.round(ou.overDecimal * 1000)}|${Math.round(ou.underDecimal * 1000)}`);
  }
  tuples.sort();
  // FNV-1a 32-bit hash — fast, deterministic, low collision for short strings.
  let h = 0x811c9dc5;
  for (const t of tuples) {
    for (let i = 0; i < t.length; i++) {
      h ^= t.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    h ^= 0x0a; // record separator
    h = Math.imul(h, 0x01000193);
  }
  // Unsigned hex + size prefix for human-readable telemetry.
  return `${primaryMap.size}:${(h >>> 0).toString(16)}`;
}

/**
 * Push a new signature into the ring, update the consecutive-identical
 * counter, and decide whether to flag the mirror as stale. Returns true
 * if the caller should trigger a failover this tick.
 *
 * Logic:
 *  - First-ever tick: just seed, never flag.
 *  - primaryMap empty (size 0): inconclusive — don't update counter, don't flag.
 *  - Signature matches previous: increment counter; flag stale once we hit
 *    VOLATILITY_STALE_AFTER_TICKS and we're past the cooldown.
 *  - Signature changed: reset counter, clear stale flag, record movement time.
 */
function recordVolatilityAndCheckStale(
  sig: string,
  primarySize: number,
  activeSize: number,
  now = Date.now(),
): boolean {
  const vol = scannerStats.dataVolatility;

  // Empty feeds and snapshots with no active matches are valid/inconclusive.
  // In particular, pre-match-only quiet hours must never rotate mirrors.
  if (primarySize === 0 || activeSize === 0) {
    logger.debug(
      { primarySize, activeSize },
      "[VOLATILITY] No active odds data — inconclusive, not counting toward staleness",
    );
    return false;
  }

  volatilityRing.push(sig);
  if (volatilityRing.length > VOLATILITY_RING_SIZE) volatilityRing.shift();

  // First-ever tick: just seed, nothing to compare against.
  if (vol.lastSignature === null) {
    vol.lastSignature = sig;
    vol.lastChangedAt = new Date(now);
    vol.unchangedSince = new Date(now);
    vol.successfulUnchangedSamples = 1;
    return false;
  }

  if (sig === vol.lastSignature) {
    vol.consecutiveIdenticalTicks++;
    vol.successfulUnchangedSamples++;
    logger.debug(
      {
        consecutiveIdenticalTicks: vol.consecutiveIdenticalTicks,
        successfulSamples: vol.successfulUnchangedSamples,
        unchangedForMs: now - (vol.unchangedSince?.getTime() ?? now),
        staleWindowMs: VOLATILITY_STALE_WINDOW_MS,
        sig,
      },
      "[VOLATILITY] No movement",
    );

    const unchangedForMs = now - (vol.unchangedSince?.getTime() ?? now);
    if (
      unchangedForMs >= VOLATILITY_STALE_WINDOW_MS &&
      vol.successfulUnchangedSamples >= VOLATILITY_MIN_SUCCESSFUL_SAMPLES
    ) {
      // Cooldown: if we already rotated recently and the new mirror is ALSO
      // stale, don't immediately rotate again — likely an upstream-wide issue.
      const sinceLastRotation = vol.lastStaleRotationAt
        ? now - vol.lastStaleRotationAt.getTime()
        : Infinity;
      if (sinceLastRotation < VOLATILITY_ROTATION_COOLDOWN_MS) {
        if (!vol.isStale) {
          vol.isStale = true;
          logger.warn(
            { sinceLastRotationSec: Math.round(sinceLastRotation / 1000), cooldownSec: VOLATILITY_ROTATION_COOLDOWN_MS / 1000 },
            "[VOLATILITY] Mirror flagged STALE again but in cooldown — will retry after cooldown",
          );
        }
        return false;
      }
      vol.isStale = true;
      return true;
    }
    return false;
  }

  // Signature changed — mirror is live. Reset counters and flags.
  if (vol.isStale || vol.consecutiveIdenticalTicks > 0) {
    logger.info(
      { afterIdenticalTicks: vol.consecutiveIdenticalTicks, prevSig: vol.lastSignature, newSig: sig },
      "[VOLATILITY] Mirror RECOVERED — signature moved",
    );
  }
  vol.isStale = false;
  vol.consecutiveIdenticalTicks = 0;
  vol.successfulUnchangedSamples = 0;
  vol.lastSignature = null;
  vol.lastChangedAt = new Date(now);
  vol.unchangedSince = null;
  volatilityRing.length = 0;
  return false;
}

// ----- DIRECT PER-MATCH FETCH (watchlist bypass) -----
//
// Some regional/W-league fixtures appear in the bulk goal8.xml OU feed but
// NOT in the bulk type=12 meta feed (verified for match 2987515 — Waterside
// Karori vs Wellington Olympic, NZ Central League). The main tick loop iterates
// primaryMap and bails at `if (!meta) continue;` for those rows, so the
// dashboard never sees them even though OU data is right there.
//
// For any watchlist entry pinned by matchId, we fetch the per-match meta
// directly from the same mirror:
//   - GET /match/live-<id>.html       → <title>X VS Y - …</title> + leagueName='…' JS var
//   - GET /Ajax/SoccerAjax?type=11    → live score + state
// and synthesize a MatchMeta record that the main loop picks up normally.
// Watchlist priority then bypasses major-league + low-liquidity filters as
// before. (Per-match OU injection is NOT done here — the type=4 schema differs
// from goal8.xml's <m> rows in non-obvious ways, and for the actual failure
// case OU is already in the bulk feed. If OU is also missing we'll log it and
// leave the entry visible-but-empty rather than risk parsing wrong odds.)

// Long-lived cache: team names + league don't change, scrape once per id.
// Bounded LRU: cap at MAX_DIRECT_MATCH_CACHE_SIZE entries; oldest entries are
// evicted on insert when the cap is exceeded. Insertion order in a JS Map is
// preserved, so deleting the first key always drops the LRU entry. On a
// re-access we delete-then-set to move the entry to the MRU position.
const MAX_DIRECT_MATCH_CACHE_SIZE = 5000;
const directMatchTeamCache = new Map<
  string,
  {
    team1: string;
    team2: string;
    leagueId: string;
    leagueName: string;
    // Upstream numeric team ids (`_homeTeamID`/`_guestTeamID`). Used to map a
    // type=15 incident's `d_f[2]` teamId to home/away with zero ambiguity.
    // Optional because pre-existing cache entries (and pages whose markup the
    // regex can't match) may lack them — the incident parser then falls back
    // to the `d_f[5]` side flag.
    homeTeamId?: string;
    guestTeamId?: string;
  }
>();
function getDirectMatchCache(id: string) {
  const v = directMatchTeamCache.get(id);
  if (v !== undefined) {
    // Touch: move to MRU position so this entry survives future evictions.
    directMatchTeamCache.delete(id);
    directMatchTeamCache.set(id, v);
  }
  return v;
}
function setDirectMatchCache(
  id: string,
  v: {
    team1: string;
    team2: string;
    leagueId: string;
    leagueName: string;
    homeTeamId?: string;
    guestTeamId?: string;
  },
): void {
  // If key exists, delete first so the re-insert lands at MRU position.
  if (directMatchTeamCache.has(id)) directMatchTeamCache.delete(id);
  directMatchTeamCache.set(id, v);
  // Evict oldest entries until we're back under the cap. Loop (not single
  // delete) so a future cap-shrink can still GC down from any starting size.
  while (directMatchTeamCache.size > MAX_DIRECT_MATCH_CACHE_SIZE) {
    const oldest = directMatchTeamCache.keys().next().value;
    if (oldest === undefined) break;
    directMatchTeamCache.delete(oldest);
  }
}
// Per-id throttle. Failed attempts also bump this so a dead id can't be
// re-fetched every tick (12s = our nominal poll interval).
const lastDirectFetchAt = new Map<string, number>();
// Crosses the normal scanner tick and API/startup refresh control so a manual
// refresh cannot launch a second identical HTML/score/events fan-out while
// the first one is still in flight.
const directFetchInFlight = new Map<string, Promise<void>>();
const directFetchStatus = new Map<
  string,
  { kind: "loading" | "error"; message?: string; updatedAt: number }
>();
const DIRECT_FETCH_MIN_INTERVAL_MS = 12_000;
// Direct watchlist metadata is supplementary to the bulk feeds. Give a busy
// mirror a little more room than the former 4s budget, but keep the entire
// fan-out bounded so it cannot wedge the primary tick.
const DIRECT_FETCH_TICK_BUDGET_MS = 6_000;
const MANUAL_BOOK_REFRESH_BUDGET_MS = 7_000;

function parsePerMatchHtml(html: string):
  | {
      team1: string;
      team2: string;
      leagueName: string;
      homeTeamId?: string;
      guestTeamId?: string;
    }
  | null {
  // The page header has exactly: <title>Home VS Away - Live Score, …</title>
  // (verified against live9.nowgoal26.com for match 2987515.)
  const titleMatch = /<title>([^<]+?) VS ([^<]+?) - /i.exec(html);
  // …and a `leagueName = 'Foo Bar'` JS var injected into a top-level <script>.
  const leagueMatch = /leagueName\s*=\s*['"]([^'"]+)['"]/i.exec(html);
  if (!titleMatch || !leagueMatch) return null;
  const team1 = titleMatch[1].trim();
  const team2 = titleMatch[2].trim();
  const leagueName = leagueMatch[1].trim();
  if (!team1 || !team2 || !leagueName) return null;
  // Numeric team ids: `var _homeTeamID = '7879'; var _guestTeamID = '1960';`
  // (whitespace-tolerant — some mirror hosts emit slightly different spacing).
  // Verified: these equal the `d_f[2]` teamId in the type=15 incident feed, so
  // they give a bulletproof home/away side mapping for cards/penalties.
  const homeIdMatch = /_homeTeamID\s*=\s*['"](\d+)['"]/i.exec(html);
  const guestIdMatch = /_guestTeamID\s*=\s*['"](\d+)['"]/i.exec(html);
  return {
    team1,
    team2,
    leagueName,
    homeTeamId: homeIdMatch?.[1],
    guestTeamId: guestIdMatch?.[1],
  };
}

/**
 * Decode live cards + penalties from a per-match `SoccerAjax?type=15`
 * response. Its `Data` is JS source-text; we pull the `d_f[id]=[…]` incident
 * array and tally per side. We deliberately parse ONLY the leading numeric
 * fields of each row via regex (kind, minute, teamId, _, _, sideFlag) so the
 * quoted player-name fields — which can contain commas/apostrophes and would
 * break a naive JSON.parse — are never touched.
 *
 * Row schema (verified against live matches #2984355 and #2981917):
 *   [0]=kind  [1]=minute  [2]=teamId  [3]=playerId  [5]=sideFlag(1=home,2=away)
 * Kind legend (from the page's `_techWin.eventDesc`):
 *   1=Goal 2=Red 3=Yellow 7=Penalty Scored 8=Own Goal 9=Second Yellow 13=Penalty(missed)
 *
 * Side is resolved by matching `teamId` against the cached home/guest team ids
 * (bulletproof); the `d_f[5]` flag is only a fallback for rows whose team can't
 * be mapped. Returns null only when the feed is unparseable / has no `d_f`.
 */
function parseLiveEvents(
  type15Text: string,
  id: string,
  homeTeamId?: string,
  guestTeamId?: string,
): LiveMatchEvents | null {
  let data: string;
  try {
    const j = JSON.parse(type15Text) as { Data?: unknown };
    data = typeof j.Data === "string" ? j.Data : "";
  } catch {
    return null;
  }
  const key = `d_f[${id}]=`;
  const start = data.indexOf(key);
  if (start < 0) return null;
  const semi = data.indexOf(";", start);
  const seg = data.slice(start + key.length, semi >= 0 ? semi : undefined);

  let yellowHome = 0;
  let yellowAway = 0;
  let redHome = 0;
  let redAway = 0;
  let penalty = false;
  let penaltyMinute: number | null = null;
  let penaltySide: "home" | "away" | null = null;

  // Each incident row starts with six comma-separated integers.
  const rowRe = /\[(\d+),(\d+),(\d+),(\d+),(\d+),(\d+),/g;
  let m: RegExpExecArray | null;
  while ((m = rowRe.exec(seg)) !== null) {
    const kind = parseInt(m[1]!, 10);
    const minute = parseInt(m[2]!, 10);
    const teamId = m[3]!;
    const sideFlag = parseInt(m[6]!, 10);

    let side: "home" | "away" | null = null;
    if (homeTeamId && teamId === homeTeamId) side = "home";
    else if (guestTeamId && teamId === guestTeamId) side = "away";
    else if (sideFlag === 1) side = "home";
    else if (sideFlag === 2) side = "away";
    if (side === null) continue;

    switch (kind) {
      case 3: // Yellow Card
        if (side === "home") yellowHome++;
        else yellowAway++;
        break;
      case 2: // Red Card
      case 9: // Second Yellow → send-off (counts as a red)
        if (side === "home") redHome++;
        else redAway++;
        break;
      case 7: // Penalty Scored
      case 13: // Penalty (missed)
        penalty = true;
        if (penaltyMinute === null) {
          penaltyMinute = minute;
          penaltySide = side;
        }
        break;
      default:
        break;
    }
  }

  return {
    yellowHome,
    yellowAway,
    redHome,
    redAway,
    penalty,
    penaltyMinute,
    penaltySide,
    updatedAt: Date.now(),
  };
}

export function parsePerMatchScore(
  jsonText: string,
): { homeScore: number; awayScore: number; isLive: boolean; state: number | null; clockLabel: string | null } | null {
  let j: { ErrCode: number; Data?: Record<string, unknown> & { state?: number; html?: string } };
  try {
    j = JSON.parse(jsonText) as typeof j;
  } catch {
    return null;
  }
  if (j.ErrCode !== 0 || !j.Data) return null;
  const html = j.Data.html ?? "";
  // Markup: <div class='score'>0</div>…<div class='score'>1</div>
  const scores = [...html.matchAll(/<div class='score'>(\d+)<\/div>/g)].map((m) =>
    parseInt(m[1], 10),
  );
  // A missing scoreboard is not 0-0. Returning null makes every live alert
  // caller fail closed rather than treating an incomplete payload as a score.
  if (!Number.isFinite(scores[0]) || !Number.isFinite(scores[1])) return null;
  const homeScore = scores[0]!;
  const awayScore = scores[1]!;
  // state: in-play PHASE code, NOT a boolean. 1=1st half, 2=half-time,
  // 3=2nd half, 4+=extra-time/penalty shootout; 0=scheduled, negative=finished
  // or abnormal (per upstream's _matchInfo.state). A match is therefore live
  // whenever state >= 1 — the old `=== 1` check wrongly dropped every match the
  // instant it reached half-time / the 2nd half. The raw `state` is also
  // surfaced so callers (e.g. the win-rate resolver) can distinguish a
  // not-yet-started match (state 0) from a genuinely finished one (state < 0).
  const state = typeof j.Data.state === "number" ? j.Data.state : null;
  const isLive = state !== null && state >= 1;
  const normalizeClockCandidate = (value: unknown): string | null => {
    if (typeof value !== "string") return normalizeFixtureClock(value);
    return normalizeFixtureClock(
      value
        .replace(/<[^>]+>/g, " ")
        .replace(/&nbsp;/gi, " ")
        .replace(/\s+/g, " ")
        .trim(),
    );
  };
  // Numeric `period` is commonly a phase code (2 = half-time), never minute 2.
  // Prefer explicit clock fields and main-header markup before textual phase.
  const directClockKeys = ["minute", "matchMinute", "liveMinute", "time", "clock"];
  let clockLabel: string | null = null;
  for (const key of directClockKeys) {
    const normalized = normalizeClockCandidate(j.Data[key]);
    if (normalized) {
      clockLabel = normalized;
      break;
    }
  }
  if (!clockLabel) {
    // Some mirrors embed the main-header clock only in Data.html.
    const headerElement =
      /<([a-z][\w-]*)\b[^>]*class=['"][^'"]*(?:time|minute|period|status)[^'"]*['"][^>]*>([\s\S]*?)<\/\1>/i.exec(html)?.[2];
    const dataClock =
      /data-(?:minute|time)=['"]([^"']+)['"]/i.exec(html)?.[1];
    clockLabel = normalizeClockCandidate(headerElement ?? dataClock);
  }
  if (!clockLabel) {
    const period = j.Data.period;
    clockLabel = typeof period === "string" && !/^\s*\d+\s*$/.test(period)
      ? normalizeClockCandidate(period)
      : null;
  }
  return { homeScore, awayScore, isLive, state, clockLabel };
}

/**
 * For each watchlist matchId that has no entry in metaMap, fetch the per-
 * match HTML (cached) + scoreboard and synthesize a MatchMeta so the main
 * tick loop processes the row normally. Bounded by an overall 6s budget so
 * a single slow per-match endpoint can never stall the whole tick.
 */
async function injectMissingWatchlistMeta(
  primaryMap: Map<string, OUEntry>,
  metaMap: Map<string, MatchMeta>,
  opts: {
    /**
     * Explicit manual refreshes bypass the normal per-id throttle and may
     * refresh ids already present in the bulk meta map (needed for cards,
     * penalties, and score freshness).
     */
    forceIds?: ReadonlySet<string>;
    /** Ignore the per-id throttle for an explicit user/API refresh only. */
    bypassThrottle?: boolean;
    /** Restrict an API-triggered refresh to this bounded id batch. */
    onlyIds?: ReadonlySet<string>;
    /** Materialize direct metadata into matchStates for API-triggered refreshes. */
    materializeState?: boolean;
  } = {},
): Promise<void> {
  const evidenceVersion = runtimeEvidenceVersion;
  const generation = scannerGeneration;
  const forceIds = opts.forceIds ?? new Set<string>();
  const watchlistIds = new Set<string>();
  for (const e of getNormalizedEntries()) {
    if (e.matchId) watchlistIds.add(e.matchId);
  }
  // GC throttle entries for ids the user has since removed.
  for (const id of lastDirectFetchAt.keys()) {
    if (!watchlistIds.has(id)) lastDirectFetchAt.delete(id);
  }
  // GC decoded card/penalty events for ids the user has since removed so the
  // cache can't outlive the watchlist.
  for (const id of liveEventsCache.keys()) {
    if (!watchlistIds.has(id)) liveEventsCache.delete(id);
  }
  for (const id of directFetchStatus.keys()) {
    if (!watchlistIds.has(id)) directFetchStatus.delete(id);
  }
  // (Don't GC directMatchTeamCache — teams/league for a given id never change,
  // and the user may re-add the same id later.)

  const now = Date.now();
  const baseUrl = currentBaseUrl();
  const tasks: Promise<void>[] = [];

  // Per-tick budget controller. Aborting on timeout actually cancels the
  // in-flight fetches (via fetchRaw's extSignal plumbing) rather than letting
  // zombie requests linger and write to a dead tick's metaMap.
  const budgetController = new AbortController();
  const budgetTimer = setTimeout(
    () => budgetController.abort(),
    DIRECT_FETCH_TICK_BUDGET_MS,
  );

  const fetchIds = opts.onlyIds
    ? [...watchlistIds].filter((id) => opts.onlyIds!.has(id))
    : [...watchlistIds];
  for (const id of fetchIds) {
    const forced = forceIds.has(id);
    if (metaMap.has(id) && !forced) continue;
    const active = directFetchInFlight.get(id);
    if (active) {
      tasks.push(active);
      continue;
    }
    const last = lastDirectFetchAt.get(id) ?? 0;
    if (!opts.bypassThrottle && now - last < DIRECT_FETCH_MIN_INTERVAL_MS) continue;
    lastDirectFetchAt.set(id, now);
    directFetchStatus.set(id, { kind: "loading", updatedAt: now });

    const task = (async () => {
        try {
          // Step 1: teams + league (cached forever per id).
          let teamInfo = getDirectMatchCache(id);
          if (!teamInfo) {
            const htmlUrl = withCacheBuster(`${baseUrl}/match/live-${id}.html`);
            const html = await fetchRaw(htmlUrl, 0, budgetController.signal);
            const parsed = parsePerMatchHtml(html);
            if (!parsed) {
              directFetchStatus.set(id, {
                kind: "error",
                message: "NowGoal match page did not contain team/league metadata",
                updatedAt: Date.now(),
              });
              logger.warn(
                { matchId: id, htmlLen: html.length },
                "Direct watchlist meta-fetch: HTML title/leagueName regex did not match",
              );
              return;
            }
            // Synthetic leagueId namespaced so it can never collide with
            // upstream league ids (those are bare integers like "421").
            const leagueId = `direct:${id}`;
            teamInfo = {
              team1: parsed.team1,
              team2: parsed.team2,
              leagueId,
              leagueName: parsed.leagueName,
              homeTeamId: parsed.homeTeamId,
              guestTeamId: parsed.guestTeamId,
            };
            setDirectMatchCache(id, teamInfo);
            logger.info(
              { matchId: id, team1: parsed.team1, team2: parsed.team2, league: parsed.leagueName, cacheSize: directMatchTeamCache.size },
              "Direct watchlist meta-fetch: cached team/league from HTML scrape",
            );
          }

          // Always (re-)register the synthetic league name in leagueNames.
          // The 30-min refreshLeagueNames cycle does `leagueNames.clear()`,
          // so a cache HIT alone would otherwise lose the name after refresh
          // and the dashboard would show a blank league for the match.
          leagueNames.set(teamInfo.leagueId, teamInfo.leagueName);

          // Step 2: fresh score + isLive (must re-fetch every tick).
          const scoreUrl = withCacheBuster(
            `${baseUrl}/Ajax/SoccerAjax?type=11&id=${id}`,
          );
          const scoreText = await fetchRaw(scoreUrl, 0, budgetController.signal);
          const score =
            parsePerMatchScore(scoreText) ?? {
              homeScore: 0,
              awayScore: 0,
              isLive: false,
              state: null,
              clockLabel: null,
            };

          if (generation !== scannerGeneration || evidenceVersion !== runtimeEvidenceVersion || budgetController.signal.aborted) return;
          metaMap.set(id, {
            evidenceVersion,
            team1: teamInfo.team1,
            team2: teamInfo.team2,
            leagueId: teamInfo.leagueId,
            homeScore: score.homeScore,
            awayScore: score.awayScore,
            isLive: score.isLive,
            state: score.state,
            clockLabel: score.clockLabel,
            // Reuse the authoritative type=12 kickoff for this exact numeric
            // fixture when the direct score feed omits kickoff. Never infer it
            // from the current minute or from a different fixture.
            kickoffMs: metaMap.get(id)?.kickoffMs ??
              matchStates.get(id)?.lastMeta?.kickoffMs ?? null,
          });
          directFetchStatus.delete(id);

          // Step 3: live match-state events (cards + penalties) from the
          // per-match incident feed (type=15 `d_f`). Same per-tick cadence as
          // the score, bounded by the shared budget controller. Cards/penalties
          // exist ONLY here — never in the bulk feed or the tT_f stats block.
          // A failure here is non-fatal: the row simply shows no badges this
          // tick. Skipped entirely once the match is no longer live.
          try {
            const evUrl = withCacheBuster(
              `${baseUrl}/Ajax/SoccerAjax?type=15&id=${id}`,
            );
            const evText = await fetchRaw(evUrl, 0, budgetController.signal);
            const events = parseLiveEvents(
              evText,
              id,
              teamInfo.homeTeamId,
              teamInfo.guestTeamId,
            );
            if (events) liveEventsCache.set(id, events);
          } catch (evErr) {
            const evAborted = evErr instanceof Error && evErr.name === "AbortError";
            if (!evAborted) {
              logger.debug(
                {
                  matchId: id,
                  err: evErr instanceof Error ? evErr.message : String(evErr),
                },
                "Watchlist incident (type=15) fetch failed — no card/penalty badges this tick",
              );
            }
          }

          // Diagnostic when OU is ALSO missing — explains a watchlist row
          // that stays "no live data" even after we successfully resolved
          // teams/league. Cannot be auto-injected safely (see note at top).
          if (!primaryMap.has(id)) {
            logger.warn(
              { matchId: id, team1: teamInfo.team1, team2: teamInfo.team2 },
              "Direct meta resolved but no OU in bulk goal8.xml — match likely pre-kickoff or has no listed market",
            );
          }
        } catch (err) {
          // Budget abort surfaces as AbortError — demote to debug-level since
          // it's expected backpressure, not an upstream failure.
          const msg = err instanceof Error ? err.message : String(err);
          const aborted = err instanceof Error && err.name === "AbortError";
          if (aborted) {
            directFetchStatus.set(id, {
              kind: "error",
              message: "NowGoal refresh timed out before metadata was available",
              updatedAt: Date.now(),
            });
            logger.debug({ matchId: id }, "Direct watchlist match fetch aborted by tick budget");
          } else {
            directFetchStatus.set(id, {
              kind: "error",
              message: msg,
              updatedAt: Date.now(),
            });
            logger.warn({ matchId: id, err: msg }, "Direct watchlist match fetch failed");
          }
        } finally {
          directFetchInFlight.delete(id);
        }
    })();
    directFetchInFlight.set(id, task);
    tasks.push(task);
  }

  if (tasks.length === 0) {
    clearTimeout(budgetTimer);
    return;
  }
  // Bounded wait: either everything finishes within budget OR the timeout
  // fires, which aborts pending fetches via budgetController. Either way no
  // zombie requests live past this point.
  try {
    await Promise.race([
      Promise.allSettled(tasks),
      new Promise<void>((r) => setTimeout(r, DIRECT_FETCH_TICK_BUDGET_MS + 50)),
    ]);
  } finally {
    clearTimeout(budgetTimer);
    if (!budgetController.signal.aborted) budgetController.abort();
  }

  // A route-triggered refresh must be useful before the next bulk tick:
  // expose the freshly resolved teams/league/score immediately, while leaving
  // odds history untouched until the normal primary feed (or hyper-focus)
  // commits an OU sample. This creates an explicit loading row rather than
  // hiding an id that has no current market.
  if (opts.materializeState) {
    if (generation !== scannerGeneration || evidenceVersion !== runtimeEvidenceVersion) return;
    for (const id of forceIds) {
      const meta = metaMap.get(id);
      if (!meta) continue;
      if (!isManualWatchlistId(id) || !acceptRuntimeMeta(id, meta, true)) continue;
      let state = matchStates.get(id);
      if (!state) {
        state = {
          history: [],
          benchmarkHistory: [],
          lastAlertAt: 0,
          lastOddsChangeAt: Date.now(),
          lastAnalyzedAt: 0,
        };
      }
      const leagueName = meta.leagueName ?? leagueNames.get(meta.leagueId) ?? "";
      const liveState = resolveLiveState(meta, state.lastMeta);
      updateLastMetaWithScoreTracking(state, {
        team1: meta.team1,
        team2: meta.team2,
        leagueId: meta.leagueId,
        leagueName,
        homeScore: meta.homeScore,
        awayScore: meta.awayScore,
        ...liveState,
        kickoffMs: meta.kickoffMs,
        clockLabel: meta.clockLabel ?? null,
        updatedAt: Date.now(),
      }, Date.now());
      matchStates.set(id, state);
    }
  }
}

/**
 * Fetch and commit the complete NowGoal bookmaker grid for an explicit manual
 * refresh. The normal scanner owns recurring ticks; this bounded helper is
 * only the immediate user/API path and therefore never evaluates alerts or
 * samples Excapper volume.
 *
 * Direct HTML/type-11 enrichment above deliberately uses empty maps, because
 * it resolves teams/score/cards. That is not enough for an explicit refresh:
 * operators also expect Bet365, Crown, and every extra book to be refreshed
 * immediately and persisted into the same histories the dashboard reads.
 */
async function refreshManualWatchlistBookGrid(
  matchIds: readonly string[],
): Promise<void> {
  const ids = [...new Set(matchIds)].filter((id) => /^\d+$/.test(id)).slice(0, MANUAL_REFRESH_BATCH_SIZE);
  if (ids.length === 0) return;

  const ep = endpointsFor(currentBaseUrl());
  const abort = new AbortController();
  const deadline = setTimeout(() => abort.abort(), MANUAL_BOOK_REFRESH_BUDGET_MS);
  const extraRequests = EXTRA_BOOK_KEYS.map((book) =>
    fetchRaw(withCacheBuster(ep.extraBooks[book]), 2, abort.signal),
  );

  try {
    const results = await Promise.allSettled([
      fetchRaw(withCacheBuster(ep.primaryOu), 0, abort.signal),
      fetchRaw(withCacheBuster(ep.benchmarkOu), 0, abort.signal),
      ...extraRequests,
    ]);
    const primaryResult = results[0]!;
    const benchmarkResult = results[1]!;
    const primaryMap =
      primaryResult.status === "fulfilled" ? parseOUXml(primaryResult.value) : new Map<string, OUEntry>();
    const benchmarkMap =
      benchmarkResult.status === "fulfilled" ? parseOUXml(benchmarkResult.value) : new Map<string, OUEntry>();
    const extraBookMaps = new Map<ExtraBookKey, Map<string, OUEntry>>();
    EXTRA_BOOK_KEYS.forEach((book, index) => {
      const result = results[index + 2]!;
      if (result.status === "fulfilled") {
        extraBookMaps.set(book, parseOUXml(result.value));
      }
    });

    const now = Date.now();
    for (const id of ids) {
      const state = matchStates.get(id);
      if (!state?.lastMeta) continue;
      const primary = primaryMap.get(id);
      const previous = state.history[state.history.length - 1];

      // Preserve metadata-only rows when no Bet365 OU market exists. If a
      // primary sample does arrive, append it exactly as the regular tick does
      // so the immediate refresh is visible in the same history buffer.
      if (primary) {
        const current: OUSnapshot = {
          ts: now,
          overDecimal: primary.overDecimal,
          underDecimal: primary.underDecimal,
          line: primary.line,
        };
        state.history.push(current);
        state.history = pruneHistory(state.history, now);
        state.lastPrimaryTickAt = now;
        if (
          !previous ||
          previous.line !== current.line ||
          previous.overDecimal !== current.overDecimal ||
          previous.underDecimal !== current.underDecimal
        ) {
          state.lastOddsChangeAt = now;
        }
      }

      const benchmark = benchmarkMap.get(id);
      if (benchmark) {
        state.benchmarkHistory.push({
          ts: now,
          overDecimal: benchmark.overDecimal,
          underDecimal: benchmark.underDecimal,
          line: benchmark.line,
        });
        state.benchmarkHistory = pruneHistory(state.benchmarkHistory, now);
      }

      for (const book of EXTRA_BOOK_KEYS) {
        const sample = extraBookMaps.get(book)?.get(id);
        if (!sample) continue;
        if (!state.bookHistory) state.bookHistory = new Map();
        const history = state.bookHistory.get(book) ?? [];
        history.push({
          ts: now,
          overDecimal: sample.overDecimal,
          underDecimal: sample.underDecimal,
          line: sample.line,
        });
        state.bookHistory.set(book, pruneHistory(history, now));
      }
      state.lastMeta.updatedAt = now;
    }
  } finally {
    clearTimeout(deadline);
    if (!abort.signal.aborted) abort.abort();
  }
}

// Shared single-flight refresh control for new/duplicate manual URL pins.
// Requests coalesce into bounded batches instead of creating one timer/loop per
// click. The normal scanner/score-refresh loops remain the sole ongoing owners
// of recurring work.
const pendingManualRefreshIds = new Set<string>();
const activeManualRefreshIds = new Set<string>();
let manualRefreshInFlight: Promise<void> | null = null;
const MANUAL_REFRESH_BATCH_SIZE = 30;

/** Fresh NowGoal evidence for resolving operator-approved source placeholders. */
export async function refreshManualBindingEvidence(matchIds: readonly string[]): Promise<Set<string>> {
  const ids = new Set(matchIds.filter((id) => /^\d+$/.test(id) && isManualWatchlistId(id)));
  const meta = new Map<string, MatchMeta>();
  await injectMissingWatchlistMeta(new Map(), meta, {
    forceIds: ids, onlyIds: ids, bypassThrottle: true, materializeState: true,
  });
  return new Set(meta.keys());
}

export function requestManualWatchlistRefresh(matchIds?: readonly string[]): Promise<void> {
  const requested = matchIds
    ? matchIds
    : getNormalizedEntries()
        .filter(
          (entry) =>
            entry.matchId !== undefined &&
            (entry.origin === undefined || entry.origin === "manual"),
        )
        .map((entry) => entry.matchId!);
  for (const id of requested) {
    if (
      /^\d+$/.test(id) &&
      isManualWatchlistId(id) &&
      !activeManualRefreshIds.has(id)
    ) {
      pendingManualRefreshIds.add(id);
    }
  }
  if (manualRefreshInFlight) return manualRefreshInFlight;

  manualRefreshInFlight = (async () => {
    while (pendingManualRefreshIds.size > 0) {
      const batch = [...pendingManualRefreshIds].slice(0, MANUAL_REFRESH_BATCH_SIZE);
      for (const id of batch) pendingManualRefreshIds.delete(id);
      for (const id of batch) activeManualRefreshIds.add(id);
      const forceIds = new Set(batch);
      try {
        await injectMissingWatchlistMeta(new Map(), new Map(), {
          forceIds,
          onlyIds: forceIds,
          bypassThrottle: true,
          materializeState: true,
        });
        await refreshManualWatchlistBookGrid(batch);
      } finally {
        for (const id of batch) activeManualRefreshIds.delete(id);
      }
    }
  })().finally(() => {
    manualRefreshInFlight = null;
  });
  return manualRefreshInFlight;
}

/**
 * Sleep that resolves EARLY (→ true) the instant any supplied AbortSignal
 * fires, otherwise resolves → false after `ms`. Used by fetchRaw's retry
 * backoff so the 0.5–1.5s waits strictly respect both the per-request timeout
 * and the caller's outer budget — a retry can never push past the deadline.
 */
function abortableDelay(ms: number, ...signals: (AbortSignal | undefined)[]): Promise<boolean> {
  const live = signals.filter((s): s is AbortSignal => !!s);
  if (live.some((s) => s.aborted)) return Promise.resolve(true);
  return new Promise<boolean>((resolve) => {
    let settled = false;
    const finish = (aborted: boolean) => {
      if (settled) return;
      settled = true;
      clearTimeout(t);
      for (const s of live) s.removeEventListener("abort", onAbort);
      resolve(aborted);
    };
    const onAbort = () => finish(true);
    const t = setTimeout(() => finish(false), ms);
    for (const s of live) s.addEventListener("abort", onAbort, { once: true });
  });
}

/**
 * A request that hit our own deadline is an upstream failure, not a lifecycle
 * cancellation. Keeping that distinction is important: the dashboard should
 * show a useful timeout diagnosis and the scanner should count it as a real
 * failure, while stop/restart cancellation should be quiet and must not
 * trigger failover.
 */
export class UpstreamTimeoutError extends Error {
  readonly code = "UPSTREAM_TIMEOUT";
  readonly url: string;
  readonly timeoutMs: number;
  readonly attempt: number;

  constructor(url: string, timeoutMs: number, attempt: number, cause?: unknown) {
    super(`Upstream request timed out after ${timeoutMs}ms (attempt ${attempt + 1}): ${url}`, {
      cause,
    });
    this.name = "UpstreamTimeoutError";
    this.url = url;
    this.timeoutMs = timeoutMs;
    this.attempt = attempt;
  }
}

function makeAbortError(url: string, cause?: unknown): Error {
  const err = new Error(`Upstream request cancelled: ${url}`, { cause });
  err.name = "AbortError";
  return err;
}

function makeDeadlineError(url: string, attempt: number): UpstreamTimeoutError {
  return new UpstreamTimeoutError(url, HTTP_REQUEST_TOTAL_TIMEOUT_MS, attempt);
}

async function fetchRawAttempt(
  url: string,
  attempt: number,
  extSignal: AbortSignal | undefined,
  deadlineAt: number,
): Promise<UpstreamFetchDetails> {
  if (extSignal?.aborted) {
    throw makeAbortError(url, extSignal.reason);
  }

  const remainingMs = deadlineAt - Date.now();
  if (remainingMs <= 0) throw makeDeadlineError(url, attempt);

  const controller = new AbortController();
  // Keep a bounded per-attempt deadline inside the bounded whole-call
  // deadline. The boolean lets us distinguish our timeout from an explicit
  // caller cancellation even though both use AbortController.
  let timedOut = false;
  const timeoutMs = Math.min(HTTP_REQUEST_TIMEOUT_MS, remainingMs);
  const timeout = setTimeout(() => {
    if (extSignal?.aborted) return;
    timedOut = true;
    controller.abort();
  }, timeoutMs);
  // If caller supplied an external signal (e.g. the per-tick budget in
  // injectMissingWatchlistMeta), abort the request when EITHER fires.
  const onExtAbort = () => controller.abort();
  if (extSignal) {
    if (extSignal.aborted) controller.abort();
    else extSignal.addEventListener("abort", onExtAbort, { once: true });
  }
  // AbortController is best-effort for standards-compliant fetch, but a
  // transport adapter (or a test double) can ignore the signal and leave its
  // promise pending forever. Race the fetch with the controller so the
  // timeout remains a real wall-clock bound, not merely a signal hint.
  let onControllerAbort: (() => void) | null = null;
  const controllerAbort = new Promise<never>((_resolve, reject) => {
    onControllerAbort = () => reject(makeAbortError(url, controller.signal.reason));
    controller.signal.addEventListener("abort", onControllerAbort, { once: true });
  });
  try {
    const res = await Promise.race([
      fetch(url, { headers: buildHeaders(), signal: controller.signal }),
      controllerAbort,
    ]);
    if (!res.ok) {
      if ((res.status === 429 || res.status >= 500) && attempt < 2) {
        // Abort-aware backoff: bail out the moment the request deadline OR
        // caller's outer budget fires, so a retry can never overshoot the
        // whole-call deadline.
        const backoffMs = Math.min(500 + attempt * 1000, Math.max(0, deadlineAt - Date.now()));
        const aborted = await abortableDelay(backoffMs, controller.signal, extSignal);
        if (aborted) {
          if (extSignal?.aborted) throw makeAbortError(url, extSignal.reason);
          throw makeDeadlineError(url, attempt);
        }
        if (Date.now() >= deadlineAt) throw makeDeadlineError(url, attempt);
        return fetchRawAttempt(url, attempt + 1, extSignal, deadlineAt);
      }
      throw new Error(`HTTP ${res.status} from ${url}`);
    }
    // The response body can stall independently after headers arrive (for
    // example a truncated chunked response), so keep the same deadline around
    // body consumption rather than only bounding the initial fetch promise.
    const body = await Promise.race([res.text(), controllerAbort]);
    return {
      body,
      status: res.status,
      finalUrl: res.url || url,
      redirected:
        res.redirected ||
        (res.url ? new URL(res.url).origin !== new URL(url).origin : false),
    };
  } catch (err) {
    // A timeout generated by this function is an upstream failure. An abort
    // generated by stop/restart is expected cancellation and remains an
    // AbortError, so the tick can avoid poisoning consecutive-failure state.
    if (timedOut) {
      throw new UpstreamTimeoutError(url, timeoutMs, attempt, err);
    }
    if (extSignal?.aborted) {
      if (err instanceof Error && err.name === "AbortError") throw err;
      throw makeAbortError(url, extSignal.reason ?? err);
    }
    throw err;
  } finally {
    clearTimeout(timeout);
    if (onControllerAbort) {
      controller.signal.removeEventListener("abort", onControllerAbort);
    }
    if (extSignal) extSignal.removeEventListener("abort", onExtAbort);
  }
}

export async function fetchRaw(url: string, attempt = 0, extSignal?: AbortSignal): Promise<string> {
  return (await fetchRawAttempt(
    url,
    attempt,
    extSignal,
    Date.now() + HTTP_REQUEST_TOTAL_TIMEOUT_MS,
  )).body;
}

/** Probe transport retaining final URL/status so redirect aliases cannot be
 * mistaken for independent healthy mirrors. Scanner hot paths keep fetchRaw's
 * body-only contract. */
export async function fetchRawDetails(
  url: string,
  extSignal?: AbortSignal,
): Promise<UpstreamFetchDetails> {
  return fetchRawAttempt(url, 0, extSignal, Date.now() + HTTP_REQUEST_TOTAL_TIMEOUT_MS);
}

async function refreshLeagueNames(): Promise<void> {
  try {
    const text = await fetchRaw(endpointsFor(currentBaseUrl()).leagues);
    const parsed = parseLiveDirectory(text);
    leagueNames.clear();
    for (const [id, name] of parsed.leagues) leagueNames.set(id, name);
    liveDiscoveryCandidates = parsed.candidates;
    liveDiscoveryFetchedAt = Date.now();
    liveDiscoveryError = null;
    scannerStats.leaguesLoaded = leagueNames.size;
    logger.info({ count: leagueNames.size, discoveryCandidates: liveDiscoveryCandidates.size }, "League names refreshed");
  } catch (err) {
    liveDiscoveryError = err instanceof Error ? err.message : String(err);
    logger.warn({ err }, "Failed to refresh league names");
    if (scannerRunning && externallyScheduled) throw err;
  }
  // Stop-aware re-arm: if stopScanner() ran while this refresh was in-flight,
  // scannerRunning is already false (and the old leagueTimer was cleared), so
  // we must NOT resurrect a stale 30-min timer that would outlive the loop and
  // duplicate across the next start/restart.
  if (scannerRunning && !externallyScheduled) {
    leagueTimer = setTimeout(refreshLeagueNames, LEAGUE_REFRESH_MS);
  }
}

export function getLeagueNamesSnapshot(): ReadonlyMap<string, string> {
  return new Map(leagueNames);
}

export async function runLeagueDirectoryCycle(): Promise<void> {
  await refreshLeagueNames();
}

// Parsing handled by shared helper in healthcheck.ts to keep behaviour in sync.
import { parseKickoffMs } from "./healthcheck";

export function parseMatchMeta(text: string): Map<string, MatchMeta> {
  const result = new Map<string, MatchMeta>();
  let json: { ErrCode: number; Data: string };
  try {
    json = JSON.parse(text) as { ErrCode: number; Data: string };
  } catch {
    return result;
  }
  if (json.ErrCode !== 0 || !json.Data) return result;

  for (const record of json.Data.split("!").filter(Boolean)) {
    const f = record.split("^");
    const matchId = f[0];
    if (!matchId || matchId.length < 5) continue;

    const homeScore = parseInt(f[11] ?? "0", 10) || 0;
    const awayScore = parseInt(f[12] ?? "0", 10) || 0;

    // f[1] is an opaque identity, not a match-state code.
    const kickoffMs = parseKickoffMs(f[3] ?? "");
    // type=12 carries identity/scores, not an authoritative match phase.
    // A past kickoff or a non-zero score is not evidence of a current live game.
    const isLive = false;

    result.set(matchId, {
      team1: f[9] ?? "",
      team2: f[10] ?? "",
      leagueId: f[4] ?? "",
      homeScore,
      awayScore,
      isLive,
      kickoffMs,
    });
  }
  return result;
}

interface OUEntry {
  matchId: string;
  line: number;
  overDecimal: number;
  underDecimal: number;
}

export function parseOUXml(xml: string): Map<string, OUEntry> {
  const result = new Map<string, OUEntry>();
  const rowRegex = /<m>([^<]+)<\/m>/g;
  let m: RegExpExecArray | null;
  while ((m = rowRegex.exec(xml)) !== null) {
    const f = m[1].split(",");
    const matchId = f[0]?.trim();
    if (!matchId || matchId.length < 5) continue;
    const line = parseFloat(f[10] ?? "");
    const overMalay = parseFloat(f[11] ?? "");
    const underMalay = parseFloat(f[12] ?? "");
    if (isNaN(line) || isNaN(overMalay) || isNaN(underMalay)) continue;
    const overDecimal = malayToDecimal(overMalay);
    const underDecimal = malayToDecimal(underMalay);
    if (overDecimal <= 1 || overDecimal > 20) continue;
    if (underDecimal <= 1 || underDecimal > 20) continue;
    result.set(matchId, { matchId, line, overDecimal, underDecimal });
  }
  return result;
}

function matchLink(matchId: string): string {
  return nowgoalMatchUrl(matchId);
}

function formatLine(line: number): string {
  return line % 1 === 0 ? line.toFixed(1) : String(line);
}

function pruneHistory<T extends { ts: number }>(arr: T[], now: number): T[] {
  const cutoff = now - HISTORY_RETENTION_MS;
  let i = 0;
  while (i < arr.length && arr[i].ts < cutoff) i++;
  return i === 0 ? arr : arr.slice(i);
}

/** Pressure proxy: count odds movements ≥0.05 on the targeted side within window. */
function pressureMovements(
  history: OUSnapshot[],
  now: number,
  side: "OVER" | "UNDER" = "OVER",
): number {
  const windowStart = now - HISTORY_WINDOW_MS;
  let count = 0;
  for (let i = 1; i < history.length; i++) {
    const cur = history[i];
    const prev = history[i - 1];
    if (cur.ts < windowStart) continue;
    const curOdds = side === "OVER" ? cur.overDecimal : cur.underDecimal;
    const prevOdds = side === "OVER" ? prev.overDecimal : prev.underDecimal;
    if (Math.abs(curOdds - prevOdds) >= 0.05) count++;
  }
  return count;
}

type BenchmarkStatus = "dropping" | "stable" | "diverging" | "no-data";

interface BenchmarkResult {
  status: BenchmarkStatus;
  delta: number | null; // positive = dropping (good), negative = rising (bad)
  matchedLine: boolean;
}

/**
 * Compare benchmark odds movement for the targeted side within window.
 * Returns "dropping" if that side's decimal fell ≥ benchmarkConfirmDrop on the same line.
 */
function evalBenchmark(
  history: BenchmarkSnapshot[],
  primaryLine: number,
  now: number,
  side: "OVER" | "UNDER" = "OVER",
): BenchmarkResult {
  if (history.length < 2) return { status: "no-data", delta: null, matchedLine: false };
  const windowStart = now - HISTORY_WINDOW_MS;
  const windowed = history.filter((h) => h.ts >= windowStart);
  if (windowed.length < 2) return { status: "no-data", delta: null, matchedLine: false };

  // Exact-line only: a different handicap is a different market, not weak
  // confirmation. Return no-data rather than inflating confidence.
  const sameLine = windowed.filter((h) => h.line === primaryLine);
  if (sameLine.length < 2) return { status: "no-data", delta: null, matchedLine: false };
  const series = sameLine;
  const matchedLine = true;

  const oldest = series[0];
  const newest = series[series.length - 1];
  const oldestOdds = side === "OVER" ? oldest.overDecimal : oldest.underDecimal;
  const newestOdds = side === "OVER" ? newest.overDecimal : newest.underDecimal;
  const delta = oldestOdds - newestOdds; // >0 = dropping

  let status: BenchmarkStatus;
  if (delta >= config.benchmarkConfirmDrop) status = "dropping";
  else if (delta <= -config.benchmarkConfirmDrop) status = "diverging";
  else status = "stable";

  return { status, delta, matchedLine };
}

interface AlertFactors {
  drop: number;
  spread: number;
  pressure: number;
  bench: BenchmarkResult;
  isLive: boolean;
}

/**
 * Confidence anchored deterministically to user spec:
 *  - 10/10 ONLY when ALL THREE triad conditions are met:
 *      drop ≥ dropThreshold (already true by gate) AND
 *      benchmark dropping ≥ benchmarkConfirmDrop AND
 *      spread ≤ tightSpread
 *  - 5/10 baseline when drop fired but benchmark is stable/no-data (early-bird)
 *  - All other paths cap at 9 max so 10/10 stays unique to the triad.
 *  - Diverging benchmark drags score down.
 */
function computeConfidence(f: AlertFactors): number {
  // Hard anchor: full triad → 10/10, no other path can reach this.
  const tripleConfirmed =
    f.bench.status === "dropping" &&
    f.bench.delta !== null &&
    f.bench.delta >= config.benchmarkConfirmDrop &&
    f.spread <= config.tightSpread;
  if (tripleConfirmed) return 10;

  // Hard anchor: early-bird baseline = 5/10.
  if (f.bench.status === "stable" || f.bench.status === "no-data") {
    let score = 5;
    // Small bonuses still allowed within early-bird, but capped at 9.
    if (f.spread <= config.tightSpread) score += 1;
    if (f.drop >= 0.70) score += 1;
    if (f.drop >= 1.00) score += 1;
    if (f.pressure >= 4) score += 1;
    return Math.max(1, Math.min(9, score));
  }

  // Diverging benchmark → strong negative signal.
  if (f.bench.status === "diverging") {
    let score = 3;
    if (f.spread <= config.tightSpread) score += 1; // tight market mitigates slightly
    if (f.drop >= 1.00) score += 1;
    return Math.max(1, Math.min(5, score));
  }

  // Benchmark dropping but missing one of the other two triad conditions → 6–9 range.
  let score = 7; // benchmark confirmation alone
  if (f.spread <= config.tightSpread) score += 1;
  if (f.drop >= 0.70) score += 1;
  if (f.bench.delta !== null && f.bench.delta >= 0.10) score += 1; // strong bench drop
  return Math.max(1, Math.min(9, score)); // cap at 9 — 10 reserved for triad
}

function confidenceBadge(score: number): string {
  if (score >= 9) return "🟢🟢🟢";
  if (score >= 7) return "🟢🟢";
  if (score === 6) return "🟢";
  if (score === 5) return "🟡 EARLY BIRD";
  if (score >= 3) return "🟠";
  return "🔴";
}

function benchLabel(b: BenchmarkResult): string {
  switch (b.status) {
    case "dropping":
      return `↓ Dropping ${b.delta !== null ? b.delta.toFixed(2) : ""} ✅${b.matchedLine ? "" : " (different line)"}`;
    case "diverging":
      return `↑ Diverging ${b.delta !== null ? Math.abs(b.delta).toFixed(2) : ""} ⚠️`;
    case "stable":
      return `→ Stable (early bird)`;
    case "no-data":
      return `n/a (no benchmark data yet)`;
  }
}

// ----- Main tick -----
async function tick(expectedGeneration?: number): Promise<void> {
  // Capture the generation at tick entry. If stopScanner() or a restart bumps
  // the generation while this tick is in flight, we'll detect it at re-arm
  // time and skip rescheduling — otherwise the in-flight tick would resurrect
  // a timer chain that was supposed to be dead.
  // Timer callbacks pass the generation they were scheduled for. This entry
  // guard closes the small event-loop race where a cleared callback is already
  // queued when stop→start creates a new generation; without it that callback
  // would capture the NEW generation and create a duplicate loop.
  const myGen = expectedGeneration ?? scannerGeneration;
  if (
    expectedGeneration !== undefined &&
    (!scannerRunning || expectedGeneration !== scannerGeneration)
  ) {
    logger.debug(
      { expectedGeneration, currentGeneration: scannerGeneration, running: scannerRunning },
      "Scanner timer callback ignored after lifecycle change",
    );
    return;
  }
  if (scannerRunning && __tickInFlight) {
    logger.warn(
      { generation: scannerGeneration },
      "Scanner timer callback skipped because another tick is already in flight",
    );
    return;
  }
  // Did this tick complete its write phase without throwing? Drives the
  // "Last update" global heartbeat (scannerStats.lastGlobalUpdateAt): we only
  // advance it on a successful tick so a sustained upstream outage (loop alive
  // but writing nothing new) stops the timestamp, not just a hard freeze.
  let tickSucceeded = true;
  // Tick wall-time telemetry. We log every tick (not just slow ones) so the
  // cadence is visible alongside the configured interval — historically there
  // was no [TICK] log at all, so when users reported "odds lagging 20-40s"
  // we were flying blind on whether the loop or the upstream was at fault.
  // The structured fields let `rg "\\[TICK\\] complete"` give a one-line
  // cadence histogram (elapsedMs vs. since-prev) without parsing pino JSON.
  const __tickStartedAt = Date.now();
  const __tickSincePrev = __lastTickAt > 0 ? __tickStartedAt - __lastTickAt : null;
  __lastTickAt = __tickStartedAt;
  // Freeze-recovery bookkeeping: mark in-flight + open a fresh per-tick abort
  // controller so the watchdog / manual force-restart can cancel this tick's
  // core fetches and name its blocking phase. Cleared on settle in
  // scheduleNextTick (current-generation only).
  __tickInFlight = true;
  __currentTickAbort = new AbortController();
  setTickPhase("tick start");
  try {
    const ep = endpointsFor(currentBaseUrl());

    // ----- HYPER-FOCUS SHORT-CIRCUIT -----
    // When the user has paused the global scanner, skip the heavy pipeline
    // entirely: no bench, no meta, no alerts, no live-transition tracker, no
    // stale-ratio watchdog. Just refresh OU odds for the watchlist matchIds
    // and re-arm at the hyper cadence. Returns early — does NOT fall through
    // to the bulk pipeline below.
    if (isGlobalScannerPaused) {
      setTickPhase("hyper-focus tick (watchlist-only)");
      const hyperFocusSucceeded = await runHyperFocusTick();
      const __elapsedMs = Date.now() - __tickStartedAt;
      logger.info(
        { elapsedMs: __elapsedMs, sincePrevMs: __tickSincePrev, mode: "hyper-focus" },
        "[TICK] complete",
      );
      scheduleNextTick(myGen, hyperFocusSucceeded);
      return;
    }

    // Cache-bust each bulk fetch so intermediary HTTP caches never blind
    // us to in-play movement (especially important for regional/minor
    // fixtures that we may otherwise see "frozen" for many ticks).
    // Parallel fetch: primary + benchmark + meta (core), plus per-book OU
    // feeds (best-effort). The extras must NEVER lengthen tick wall time:
    //   - `attempt = 2` short-circuits fetchRaw's retry branch (`attempt < 2`
    //     is false) so a flaky extra never burns the retry budget.
    //   - a bounded external AbortController acts as a hard deadline (tighter
    //     than fetchRaw's own per-attempt budget) so a hung TCP socket cannot
    //     stall the tick beyond ~7s even worst-case.
    // All settle in one Promise.allSettled so the existing tail-slice
    // indexing stays valid.
    const extraAbort = new AbortController();
    const extraDeadline = setTimeout(() => extraAbort.abort(), EXTRA_BOOK_TIMEOUT_MS);
    const extraUrls = EXTRA_BOOK_KEYS.map((k) =>
      fetchRaw(withCacheBuster(ep.extraBooks[k]), 2, extraAbort.signal),
    );
    // Pass the per-tick abort signal to the core fetches (fetchRaw's existing
    // extSignal param) so a watchdog/force-restart can cancel them mid-flight.
    // Also chain it to the extras' controller so one abort cancels everything.
    const coreSignal = __currentTickAbort?.signal;
    if (coreSignal) {
      if (coreSignal.aborted) extraAbort.abort();
      else coreSignal.addEventListener("abort", () => extraAbort.abort(), { once: true });
    }
    setTickPhase(
      "core fetch: primaryOu(Bet365) + benchmark(Crown) + meta + extras[Sbobet,M88,12Bet,18Bet,VSBet]",
    );
    const allRes = await Promise.allSettled([
      fetchRaw(withCacheBuster(ep.primaryOu), 0, coreSignal),
      fetchRaw(withCacheBuster(ep.benchmarkOu), 0, coreSignal),
      fetchRaw(withCacheBuster(ep.meta), 0, coreSignal),
      ...extraUrls,
    ]);
    clearTimeout(extraDeadline);
    const primaryRes = allRes[0]!;
    const benchRes = allRes[1]!;
    const metaRes = allRes[2]!;
    const extraRes = allRes.slice(3);

    if (primaryRes.status !== "fulfilled") {
      scannerStats.primaryFetchFailures++;
      throw primaryRes.reason;
    }
    if (metaRes.status !== "fulfilled") throw metaRes.reason;

    let benchMap = new Map<string, OUEntry>();
    if (benchRes.status === "fulfilled") {
      benchMap = parseOUXml(benchRes.value);
    } else {
      scannerStats.benchmarkFetchFailures++;
      logger.warn({ err: benchRes.reason }, "Benchmark fetch failed — alerts will be early-bird only this tick");
    }

    // Per-book OU maps — best-effort, never blocks the main pipeline.
    // A failed feed for one book just means that row dashes this tick;
    // the others (and the primary/benchmark pipeline) are unaffected.
    const extraBookMaps = new Map<ExtraBookKey, Map<string, OUEntry>>();
    EXTRA_BOOK_KEYS.forEach((book, i) => {
      const res = extraRes[i]!;
      if (res.status === "fulfilled") {
        const parsed = parseOUXml(res.value);
        extraBookMaps.set(book, parsed);
        scannerStats.perBookFetch[book].ok++;
        scannerStats.perBookFetch[book].lastError = null;
        scannerStats.perBookFetch[book].lastParsedRows = parsed.size;
        scannerStats.perBookFetch[book].lastParsedAt = new Date();
        // First-time visibility: log empty parses at warn so we notice if a
        // mirror starts returning HTTP 200 with a body the parser can't read.
        if (parsed.size === 0) {
          logger.warn({ book, bodyPreview: res.value.slice(0, 200) }, "Extra book OU fetched but parsed zero rows");
        }
      } else {
        scannerStats.perBookFetch[book].fail++;
        const errMsg = res.reason instanceof Error ? res.reason.message : String(res.reason);
        scannerStats.perBookFetch[book].lastError = errMsg;
        logger.warn({ book, err: errMsg }, "Extra book OU fetch failed");
      }
    });

    // ----- VCBET PER-MATCH FALLBACK -----
    // goal14.xml only contains matches Vcbet quoted in the recent batch
    // window. For watchlist matches missing from that batch, NowGoal's own
    // oddscomp page hits /ajax/soccerajax?type=14&t=11&id=<MID>&h=0 which
    // returns a roddsList including cid:14 (Vcbet). We replay that call for
    // up to ~30 watchlist matches per tick, concurrency-capped, with a
    // bounded batch deadline. Snapshots merge into extraBookMaps.get("VSBet")
    // so the downstream bookHistory commit picks them up with no further
    // changes.
    try {
      const vcbetBatchMap = extraBookMaps.get("VSBet") ?? new Map<string, OUEntry>();
      // Watchlist pin-by-id entries are the URL-pasted matches the user
      // actively cares about; they're the highest-signal target for the
      // per-match fallback. Team-name-only entries get coverage from the
      // batch goal14.xml feed when they appear there.
      const wlSnap = getWatchlistSnapshot();
      const missing: string[] = [];
      for (const e of wlSnap.entries) {
        const id = e.matchId;
        if (!id) continue;
        if (vcbetBatchMap.has(id)) continue;
        missing.push(id);
        if (missing.length >= 30) break;
      }
      if (missing.length > 0) {
        setTickPhase(`vcbet per-match fallback (${missing.length} matches)`);
        const perMatch = await fetchVcbetBatch(missing, 1);
        let merged = 0;
        for (const [mid, snap] of perMatch) {
          vcbetBatchMap.set(mid, {
            matchId: mid,
            line: snap.line,
            overDecimal: snap.overDecimal,
            underDecimal: snap.underDecimal,
          });
          merged++;
        }
        if (merged > 0) {
          extraBookMaps.set("VSBet", vcbetBatchMap);
          scannerStats.perBookFetch.VSBet.lastParsedRows = vcbetBatchMap.size;
          scannerStats.perBookFetch.VSBet.lastParsedAt = new Date();
        }
        logger.info(
          { requested: missing.length, merged, totalVcbetRows: vcbetBatchMap.size },
          "[VCBET-PERMATCH] tick complete",
        );
      }
    } catch (err) {
      logger.warn(
        { err: err instanceof Error ? err.message : String(err) },
        "[VCBET-PERMATCH] batch failed (non-fatal)",
      );
    }

    consecutiveFailures = 0;
    scannerStats.consecutiveFailures = 0;

    const now = Date.now();
    scannerStats.lastCheckAt = new Date();
    scannerStats.checksTotal++;
    scannerStats.lastError = null;

    const primaryMap = parseOUXml(primaryRes.value);
    const metaMap = parseMatchMeta(metaRes.value);
    scannerStats.scheduleMatchesSeen = metaMap.size;
    scannerStats.liveMatchesConfirmed = 0;
    const discoveryIds = new Set<string>();
    if (Date.now() - liveDiscoveryFetchedAt < 2 * LEAGUE_REFRESH_MS) {
      for (const [id, candidate] of liveDiscoveryCandidates) {
        discoveryIds.add(id);
        // Both sources are identity-only here; explicit state arrives below.
        metaMap.set(id, { ...candidate, kickoffMs: metaMap.get(id)?.kickoffMs ?? candidate.kickoffMs });
      }
    }
    // Verify a bounded eligible feed batch via the actual type=11 state.
    // Bulk identity and odds alone must never revive cached fixtures.
    const eligibleIds = [...metaMap.keys()].filter((id) => {
      const meta = metaMap.get(id)!;
      return isManualWatchlistId(id) || !!matchTargetLeague(meta.leagueName ?? leagueNames.get(meta.leagueId));
    }).sort();
    const manualIds = new Set(eligibleIds.filter(isManualWatchlistId));
    const verificationIds = selectLiveVerificationIds(
      eligibleIds, manualIds, discoveryIds, LIVE_VERIFICATION_BUDGET, liveVerificationCursors,
    );
    scannerStats.liveVerificationEligible = eligibleIds.length;
    scannerStats.liveVerificationSelected = verificationIds.length;
    for (const id of verificationIds) {
      const evidenceVersion = runtimeEvidenceVersion;
      const fresh = await fetchFreshScoreNow(id);
      directScoreIdsFetchedThisCycle.add(id);
      if (myGen !== scannerGeneration) return;
      const meta = metaMap.get(id);
      if (meta && fresh) Object.assign(meta, fresh, { evidenceVersion });
      if (fresh?.isLive) recentLiveConfirmations.set(id, { verifiedAt: Date.now(), evidence: fresh });
      else if (fresh) recentLiveConfirmations.delete(id);
      if (meta && fresh?.isLive) scannerStats.liveMatchesConfirmed++;
      await new Promise((resolve) => setTimeout(resolve, 75));
    }
    // Retain only recent, directly observed type=11 live evidence for rows
    // awaiting their next turn. Never infer live from type=12 or expired data.
    for (const [id, confirmation] of recentLiveConfirmations) {
      if (Date.now() - confirmation.verifiedAt >= LIVE_CONFIRMATION_TTL_MS || !metaMap.has(id)) {
        recentLiveConfirmations.delete(id);
        continue;
      }
      if (verificationIds.includes(id)) continue;
      const meta = metaMap.get(id)!;
      Object.assign(meta, confirmation.evidence);
    }
    if (myGen !== scannerGeneration) return;
    radarOneX2Candidates.clear();
    for (const [id, meta] of metaMap) {
      if (primaryMap.has(id)) continue;
      // Directory A[] identifies possible live fixtures; an independently
      // checked type=11 positive state also suffices when A[] missed a match.
      if (!discoveryIds.has(id) && (meta.state == null || meta.state <= 0)) continue;
      if (!meta?.team1 || !meta.team2) continue;
      const leagueName = meta.leagueName ?? leagueNames.get(meta.leagueId) ?? "";
      if (!matchTargetLeague(leagueName)) continue;
      radarOneX2Candidates.set(id, {
        meta: {
          team1: meta.team1, team2: meta.team2, leagueId: meta.leagueId,
          leagueName, homeScore: meta.homeScore, awayScore: meta.awayScore,
          isLive: meta.isLive, state: meta.state ?? null, kickoffMs: meta.kickoffMs,
          clockLabel: meta.clockLabel ?? null, updatedAt: now,
        },
        lastScoreChangeAt: null,
      });
    }
    for (const [id, state] of matchStates) {
      const meta = metaMap.get(id);
      if (meta && !isLiveMeta(meta)) retireRuntimeMatch(id, { ...state.lastMeta!, ...meta, updatedAt: now });
    }
    // Refresh identity from the complete raw metadata feed before any
    // watchlist, low-liquidity or OU gates can suppress state materialization.

    // Watchlist bypass: pin-by-id entries (URL-pasted matches) may belong to
    // a regional league that isn't in the bulk type=12 meta feed. Fetch
    // per-match meta directly and inject so the main loop sees them. This
    // happens BEFORE the main loop so injected entries flow through the
    // normal priority/state-init/snapshot pipeline with no special casing.
    setTickPhase("inject missing watchlist meta (per-match HTML scrape)");
    const manualRefreshIds = new Set(
      getNormalizedEntries()
        .filter(
          (entry) =>
            entry.matchId !== undefined &&
            (entry.origin === undefined || entry.origin === "manual"),
        )
        .map((entry) => entry.matchId!),
    );
    await injectMissingWatchlistMeta(primaryMap, metaMap, {
      // Manual ids get the same deep score/incident enrichment even when the
      // bulk meta feed already contains them; the direct path is still
      // throttled to its bounded 12s cadence.
      forceIds: manualRefreshIds,
      materializeState: true,
    });
    // If a startup/API deep refresh just hydrated state while the per-id
    // direct request is still inside its 12s throttle, reuse that cached
    // metadata for an OU row already present in this bulk tick. The next
    // direct pass will refresh score/events; this avoids a needless one-tick
    // gap in odds history.
    for (const id of manualRefreshIds) {
      if (metaMap.has(id) || !primaryMap.has(id)) continue;
      const cached = matchStates.get(id)?.lastMeta;
      if (!cached) continue;
      metaMap.set(id, {
        team1: cached.team1,
        team2: cached.team2,
        leagueId: cached.leagueId,
        leagueName: cached.leagueName,
        homeScore: cached.homeScore,
        awayScore: cached.awayScore,
        isLive: cached.isLive,
        state: cached.state,
        kickoffMs: cached.kickoffMs,
      });
      leagueNames.set(cached.leagueId, cached.leagueName);
    }
    setTickPhase("process snapshots + alert evaluation (CPU)");

    // ----- TEMPORARY DIAGNOSTIC: bulk-feed coverage audit -----
    // Confirms the scraper sees the ENTIRE upstream match list each tick (not
    // just one match), and shows how each watchlist matchId is covered. Logged
    // once per BULK_FEED_AUDIT_INTERVAL_MS so it can't flood. Remove once the
    // "dashboard only shows one match" report is resolved.
    {
      const bulkNow = Date.now();
      if (bulkNow - lastBulkFeedAuditAt >= BULK_FEED_AUDIT_INTERVAL_MS) {
        lastBulkFeedAuditAt = bulkNow;
        let liveInMeta = 0;
        for (const m of metaMap.values()) if (m.isLive) liveInMeta++;
        const wlSnap = getWatchlistSnapshot();
        const watchlistCoverage = wlSnap.entries
          .filter((e) => e.matchId)
          .map((e) => ({
            matchId: e.matchId!,
            inOuFeed: primaryMap.has(e.matchId!),
            inMetaFeed: metaMap.has(e.matchId!),
            metaIsLive: metaMap.get(e.matchId!)?.isLive ?? null,
          }));
        logger.info(
          {
            ouFeedMatches: primaryMap.size,
            metaFeedMatches: metaMap.size,
            liveInMetaFeed: liveInMeta,
            liveDiscovery: liveDiscoveryDiagnostics.snapshot,
            watchlistCoverage,
            sampleMatchIds: Array.from(primaryMap.keys()).slice(0, 20),
          },
          "[BULK-FEED-AUDIT] Upstream feed coverage this tick (scraper should see the full list, not one match)",
        );
      }
    }

    // ----- ODDS VOLATILITY CHECK (frozen-mirror detection) -----
    // A mirror returning HTTP 200 + parseable data every tick can still be
    // FROZEN — same XML payload every poll. The HTTP-level watchdog won't
    // catch this. We fingerprint the primary OU snapshot and rotate mirrors
    // if N consecutive ticks produce identical signatures.
    {
      const sig = computeOddsSignature(primaryMap);
      let activePrimarySize = 0;
      for (const matchId of primaryMap.keys()) {
        const state = matchStates.get(matchId);
        // Kickoff-window inference alone is not proof that a market is live.
        // Arm freeze detection only after this process has actually observed
        // that match's odds move while it was in the active window.
        if (
          metaMap.get(matchId)?.isLive &&
          state &&
          hasObservedOddsMovement(state.history)
        ) activePrimarySize++;
      }
      const shouldRotate = recordVolatilityAndCheckStale(
        sig,
        primaryMap.size,
        activePrimarySize,
      );
      if (shouldRotate && !staleFailoverInFlight) {
        staleFailoverInFlight = true;
        const staleBase = currentBaseUrl();
        const identicalTicks = scannerStats.dataVolatility.consecutiveIdenticalTicks;
        logger.error(
          { mirror: staleBase, identicalTicks, primarySize: primaryMap.size, signature: sig },
          "[VOLATILITY] 🚨 STALE MIRROR DETECTED — forcing rotation",
        );

        // Note: we do NOT set lastStaleRotationAt here — only after a SUCCESSFUL
        // switch below. If we set it pre-emptively and the failover fails (no
        // healthy alternates), the cooldown would suppress retries even though
        // we never actually rotated, leaving us stuck on the frozen mirror.

        // Fire failover in the background so we don't block this tick's parse.
        // CRITICAL: pass force=true so tryFailover skips its "current host is
        // HTTP-healthy ⇒ no-op" early return. A frozen mirror IS HTTP-healthy
        // by every probe metric — without force, the failover would never
        // actually switch us off the dead mirror.
        void (async () => {
          try {
            const fo = await tryFailover(fetchRawDetails, "volatility_stale", { force: true });
            if (fo.switched) {
              scannerStats.dataVolatility.lastStaleRotationAt = new Date();
              scannerStats.dataVolatility.rotationsForStaleness++;
              // Per user request, mirror rotations are infra noise and must
              // NOT spam the Telegram chat — structured logger only.
              logger.warn(
                { from: fo.from, to: fo.to, identicalTicks, cooldownMs: VOLATILITY_ROTATION_COOLDOWN_MS },
                "[VOLATILITY] ✅ Rotation succeeded after frozen ticks — cooldown activated",
              );
              // Clean slate for the new mirror — don't carry the old mirror's
              // stale signature forward, or it'll look stale on first compare.
              volatilityRing.length = 0;
              scannerStats.dataVolatility.lastSignature = null;
              scannerStats.dataVolatility.consecutiveIdenticalTicks = 0;
              scannerStats.dataVolatility.successfulUnchangedSamples = 0;
              scannerStats.dataVolatility.unchangedSince = null;
              scannerStats.dataVolatility.isStale = false;
            } else {
              // No healthy alternate found — record the attempt so the
              // cooldown kicks in and we don't thrash through the pool every
              // tick when the whole upstream is degraded.
              scannerStats.dataVolatility.lastStaleRotationAt = new Date();
              logger.error(
                { report: fo.report, stayingOn: fo.from },
                "[VOLATILITY] ⚠️ No healthy alternate mirror found — staying on current until cooldown elapses",
              );
            }
          } catch (foErr) {
            logger.error({ err: foErr }, "[VOLATILITY] Failover attempt threw");
            // Also cool down on exceptions to prevent tight-loop retries.
            scannerStats.dataVolatility.lastStaleRotationAt = new Date();
          } finally {
            staleFailoverInFlight = false;
          }
        })();
      } else if (shouldRotate) {
        logger.debug("[VOLATILITY] Stale rotation already in flight — skipping duplicate trigger this tick");
      }
    }

    // ----- GLOBAL Live-transition alerts -----
    // Iterate the FULL meta feed (not the filtered primary loop below) so we
    // catch live transitions in every league we know about — including majors
    // that are excluded from the smart-money alert pipeline. The user wants
    // total visibility for manual cross-reference.
    //
    // SANITY GUARD: a healthy meta feed has ~900-1000 matches. If parsing
    // silently returns a much smaller map (truncated response, partial outage,
    // upstream serving an error page that still parses to a few rows), we
    // MUST NOT swap state — otherwise the next healthy tick would treat every
    // live match as a fresh transition and fire a Telegram storm. We keep the
    // previous liveMatchIds snapshot intact until the feed looks normal again.
    {
      const META_SANITY_MIN = 100;
      if (metaMap.size < META_SANITY_MIN) {
        logger.warn(
          { metaSize: metaMap.size, threshold: META_SANITY_MIN },
          "Live-transition tracker: meta feed below sanity threshold — preserving prior state to prevent storm",
        );
      } else {
        const currentLive = new Set<string>();
        const transitions: { matchId: string; meta: MatchMeta }[] = [];
        for (const [matchId, meta] of metaMap) {
          if (!meta.isLive) continue;
          // Live-transition bookkeeping is also an output path. Do not let a
          // broad meta feed turn an unknown/non-target competition into a
          // visible or alertable match merely because it is live.
          if (!matchTargetLeague(leagueNames.get(meta.leagueId) ?? "")) continue;
          currentLive.add(matchId);
          if (liveSeeded && !liveMatchIds.has(matchId) && meta.team1 && meta.team2) {
            transitions.push({ matchId, meta });
          }
        }
        // Swap state immediately so a late-firing alert never re-fires.
        liveMatchIds.clear();
        for (const id of currentLive) liveMatchIds.add(id);

        if (!liveSeeded) {
          liveSeeded = true;
          logger.info(
            { liveAtBoot: currentLive.size },
            "Live-transition tracker seeded — alerts armed from next tick",
          );
        } else if (transitions.length > 0) {
          // DISABLED 2026-05-23: live-transition Telegram digests are disabled.
          // The previous per-tick
          // "🟢 LIVE MONITORING UPDATED: Total Active Matches Now: N"
          // digest was spamming the channel every few seconds whenever any
          // match transitioned to live state. We still keep currentLive in
          // sync below so the rest of the priority/throttle logic works, but
          // we no longer notify Telegram on live transitions. Odds-drop and
          // standalone Excapper volume alerts remain separate enabled paths.
          logger.debug(
            { count: transitions.length, totalLive: currentLive.size },
            "Live transitions detected — Telegram digest suppressed",
          );
        }
      }
    }

    let liveCount = 0;
    let minorCount = 0;
    let skippedCount = 0;
    let benchCovered = 0;
    let lowLiqCount = 0;
    let priorityWatchlistMatches = 0;
    let globalPoolAnalyzed = 0;
    let globalPoolSkippedByThrottle = 0;
    let globalPoolSkippedByCap = 0;
    let lowLiqPrematchSkipped = 0;
    for (const [matchId, ou] of primaryMap) {
      if (myGen !== scannerGeneration) break;
      const meta = metaMap.get(matchId);
      if (!meta || !meta.team1 || !meta.team2) continue;
      if (!acceptRuntimeMeta(matchId, meta, true)) continue;

      const leagueName = leagueNames.get(meta.leagueId) ?? "";
      const targetLeague = matchTargetLeague(leagueName);
      // A direct numeric id entered by the operator is intentionally visible
      // outside the automated target allowlist. This exception only permits
      // state/UI enrichment; alert and Excapper volume gates remain strict.
      const explicitManualId =
        isManualWatchlistId(matchId) && targetLeague === null;
      if (!targetLeague && !explicitManualId) continue;
      const isLeaguePriority =
        config.priorityLeagueIds.length > 0 &&
        config.priorityLeagueIds.includes(meta.leagueId);

      // Watchlist priority is evaluated FIRST so that a user-listed fixture
      // always bypasses both the major-league filter and the low-liquidity
      // pre-match skip. Otherwise typing "Real Madrid" into the watchlist
      // would silently be ignored (La Liga = major league).
      const watchlistHit = matchesWatchlist(meta.team1, meta.team2, matchId);
      const isWatchlistPriority = watchlistHit !== null;
      const isPriority =
        isLeaguePriority || isWatchlistPriority;

      if (!isPriority && isMajorLeague(meta.leagueId, leagueName)) {
        skippedCount++;
        continue;
      }

      // Two-Tier filter: pre-match low-liquidity matches are skipped entirely
      // (huge volume of dead markets that just burn CPU on a Reserved VM).
      // Once a match goes live the drop pipeline still tracks it — live odds
      // movement in those leagues is exactly the signal we want.
      const isLowLiq = isLowLiquidityLeague(meta.leagueId, leagueName);
      if (isLowLiq && !meta.isLive && !isPriority) {
        lowLiqPrematchSkipped++;
        continue;
      }

      minorCount++;
      if (meta.isLive) liveCount++;
      if (isLowLiq) lowLiqCount++;

      let state = matchStates.get(matchId);
      if (!state) {
        state = {
          history: [],
          benchmarkHistory: [],
          lastAlertAt: 0,
          lastOddsChangeAt: now,   // seed at first sight so freshly-tracked matches don't immediately count as stale
          lastAnalyzedAt: 0,
        };
      }

      // Snapshot + prev are needed by the pool gate (to persist history on
      // throttle/cap skip) AND by the drop pipeline further down. Declare
      // them once here so both blocks share the same values.
      const current: OUSnapshot = {
        ts: now,
        overDecimal: ou.overDecimal,
        underDecimal: ou.underDecimal,
        line: ou.line,
      };
      const prev = state.history[state.history.length - 1];

      // Authoritative primary-freshness signal for the alt-mirror branch.
      // Stamped on EVERY tick visit (even when odds are unchanged or the
      // match is skipped by pool throttle below), so alt only overwrites
      // when the primary has truly fallen silent.
      state.lastPrimaryTickAt = now;

      // Persist last-seen meta so the dashboard can resolve matchId → teams
      // (for URL-based watchlist adds) and render watchlist live cards.
      const liveState = resolveLiveState(meta, state.lastMeta);
      updateLastMetaWithScoreTracking(state, {
        team1: meta.team1,
        team2: meta.team2,
        leagueId: meta.leagueId,
        leagueName,
        homeScore: meta.homeScore,
        awayScore: meta.awayScore,
        ...liveState,
        kickoffMs: meta.kickoffMs,
        clockLabel: meta.clockLabel ?? state.lastMeta?.clockLabel ?? null,
        updatedAt: now,
      }, now);
      if (!isLiveMeta(state.lastMeta)) {
        retireRuntimeMatch(matchId, state.lastMeta);
        continue;
      }
      matchStates.set(matchId, state);

      // Stale-data tracker: did the primary OU snapshot actually move? This
      // MUST run before the pool gate — even when a match is skipped by the
      // throttle/cap, we want to record genuine odds movement so the stale-
      // ratio watchdog isn't tricked into firing on a perfectly healthy feed.
      if (prev && (prev.line !== ou.line || prev.overDecimal !== ou.overDecimal || prev.underDecimal !== ou.underDecimal)) {
        state.lastOddsChangeAt = now;
      } else if (!prev) {
        state.lastOddsChangeAt = now;
      }

      if (isWatchlistPriority) priorityWatchlistMatches++;

      // ----- PRIORITY/GLOBAL POOL GATE -----
      // Priority matches (league-priority OR watchlist) bypass both the per-
      // match throttle AND the MAX_CONCURRENT_LIVE_MATCHES cap.
      //
      // Global pool matches: everyone else. Each non-priority live match is
      // re-analyzed at most every GLOBAL_POOL_INTERVAL_MS (~50s) and the per-
      // tick population is capped to MAX_CONCURRENT_LIVE_MATCHES.
      if (!isPriority && meta.isLive) {
        // Cap first — even before the per-match throttle — so we don't drift
        // past the budget by re-analyzing the same 60 matches every tick.
        if (globalPoolAnalyzed >= MAX_CONCURRENT_LIVE_MATCHES) {
          globalPoolSkippedByCap++;
          state.history.push(current);
          state.history = pruneHistory(state.history, now);
          continue;
        }
        if (now - state.lastAnalyzedAt < GLOBAL_POOL_INTERVAL_MS) {
          globalPoolSkippedByThrottle++;
          state.history.push(current);
          state.history = pruneHistory(state.history, now);
          continue;
        }
        globalPoolAnalyzed++;
      }
      state.lastAnalyzedAt = now;

      // Track benchmark
      const bench = benchMap.get(matchId);
      if (bench) {
        benchCovered++;
        state.benchmarkHistory.push({
          ts: now,
          overDecimal: bench.overDecimal,
          underDecimal: bench.underDecimal,
          line: bench.line,
        });
        state.benchmarkHistory = pruneHistory(state.benchmarkHistory, now);
      }

      // Track per-book OU for the extra NOWGOAL stack books. Lazy-init
      // the inner Map on first sample so existing init sites stay clean.
      for (const book of EXTRA_BOOK_KEYS) {
        const bookMap = extraBookMaps.get(book);
        if (!bookMap) continue;
        const sample = bookMap.get(matchId);
        if (!sample) continue;
        if (!state.bookHistory) state.bookHistory = new Map();
        const hist = state.bookHistory.get(book) ?? [];
        hist.push({
          ts: now,
          overDecimal: sample.overDecimal,
          underDecimal: sample.underDecimal,
          line: sample.line,
        });
        state.bookHistory.set(book, pruneHistory(hist, now));
      }

      // ============================================================
      // [DEBUG-DROP] Per-match raw drop math. Logs EVERY tracked match
      // every tick so we can see exactly why nothing is firing.
      // High-volume: ~700 matches × 6 ticks/min = ~4200 lines/min.
      // To silence later: set env DEBUG_DROPS=0.
      // ============================================================
      // [DEBUG-DROP] Per-match raw drop math. OFF by default — opt in by
      // setting env DEBUG_DROPS=1. At 12s ticks × ~600 matches this generates
      // ~5000 log lines/min, which floods the Reserved VM log file. Routed
      // through logger.debug so it respects log-level filtering even when on.
      if (process.env["DEBUG_DROPS"] === "1") {
        const teamA = meta.team1;
        const teamB = meta.team2;
        const curOver = ou.overDecimal.toFixed(3);
        if (!prev) {
          logger.debug({ matchId, teamA, teamB, curOver, line: ou.line }, "[DEBUG-DROP] SEEDED");
        } else if (prev.line !== ou.line) {
          logger.debug({ matchId, teamA, teamB, prevOver: prev.overDecimal, prevLine: prev.line, curOver, curLine: ou.line }, "[DEBUG-DROP] SKIPPED (line changed — handicap shift)");
        } else {
          const dropCalc = prev.overDecimal - ou.overDecimal;
          const passes = dropCalc >= config.dropThreshold;
          const cooldownLeft = Math.max(0, ALERT_COOLDOWN_MS - (now - state.lastAlertAt));
          logger.debug(
            { matchId, teamA, teamB, prevOver: prev.overDecimal, curOver, drop: dropCalc, threshold: config.dropThreshold, cooldownLeftMs: cooldownLeft, result: passes ? "PASSED" : "FAILED" },
            "[DEBUG-DROP]",
          );
        }
      }

      // Manual out-of-allowlist ids are tracked for the dashboard but must
      // never enter the automated odds-drop alert path.
      if (targetLeague) {
        evaluateOddsDropAlert({ matchId, state, prev, ou, meta, leagueName, isLowLiq, now });
      }

      state.history.push(current);
      state.history = pruneHistory(state.history, now);
    }

    // Prune matchStates for matches that left the feed — BUT only if this
    // tick's primaryMap looks healthy. A partial upstream response (mirror
    // glitch, single endpoint timeout, parse hiccup) can return far fewer
    // matches than we actually have in flight; if we blindly prune here we
    // wipe out alert cooldowns and prior-odds history that the next healthy
    // tick will need. Mirror the sanity-threshold guard we use for
    // liveMatchIds pruning (see live-transition tracker above).
    //
    // Rule: skip prune if the new primaryMap is <60% of the existing
    // matchStates size AND we have at least 50 tracked matches. The 50-match
    // floor avoids guard-tripping during normal cold-start / low-traffic
    // windows when the feed is genuinely small.
    const PRUNE_SANITY_RATIO = 0.6;
    for (const [id, state] of matchStates) {
      if (!metaMap.has(id) || !isLiveMeta(state.lastMeta)) retireRuntimeMatch(id);
    }
    const PRUNE_SANITY_MIN = 50;
    const trackedBefore = matchStates.size;
    const incomingSize = primaryMap.size;
    if (
      trackedBefore >= PRUNE_SANITY_MIN &&
      incomingSize < trackedBefore * PRUNE_SANITY_RATIO
    ) {
      logger.warn(
        { trackedBefore, incomingSize, ratio: incomingSize / trackedBefore },
        "matchStates prune skipped — primaryMap suspiciously small, preserving prior state to prevent cooldown/history wipeout",
      );
    } else {
      for (const matchId of matchStates.keys()) {
        // Keep explicit manual pins materialized even while their market is
        // absent from goal8.xml (pre-kickoff, suspended, or an upstream
        // partial feed). The dashboard can then show the stored id with an
        // honest loading/no-odds state instead of losing the row.
        if (!primaryMap.has(matchId) || !metaMap.has(matchId)) {
          retireRuntimeMatch(matchId);
        }
      }
    }

    scannerStats.liveMatchesTracked = liveCount;
    scannerStats.minorMatchesTracked = minorCount;
    scannerStats.majorMatchesSkipped = skippedCount;
    scannerStats.lowLiquidityMatchesTracked = lowLiqCount;
    scannerStats.benchmarkCoverage = benchCovered;
    scannerStats.pool = {
      priorityWatchlistMatches,
      globalPoolAnalyzed,
      globalPoolSkippedByThrottle,
      globalPoolSkippedByCap,
      lowLiqPrematchSkipped,
      maxConcurrentLiveMatches: MAX_CONCURRENT_LIVE_MATCHES,
      globalPoolIntervalSec: GLOBAL_POOL_INTERVAL_MS / 1000,
    };
    noteLiveCount(liveCount);

    // ----- STALE-RATIO ROTATION (per-match recency watchdog) -----
    // If >STALE_RATIO_TRIGGER of currently-live matches haven't seen any odds
    // movement in MATCH_STALE_AFTER_MS, the mirror is serving cached data on
    // a per-match basis (the whole-feed volatility check above only catches
    // identical-XML freezes). Force a rotation, respecting the volatility
    // cooldown so the two systems don't fight.
    if (liveCount >= STALE_RATIO_MIN_SAMPLE) {
      let staleLiveCount = 0;
      let sampledLiveCount = 0;
      for (const [matchId] of primaryMap) {
        const m = metaMap.get(matchId);
        if (!m || !m.isLive) continue;
        const st = matchStates.get(matchId);
        // A sparse/new match has not supplied enough successful observations
        // to prove staleness. Do not let it inflate the stale ratio.
        if (
          !st ||
          st.history.length < VOLATILITY_MIN_SUCCESSFUL_SAMPLES ||
          !hasObservedOddsMovement(st.history)
        ) continue;
        sampledLiveCount++;
        if (now - st.lastOddsChangeAt > MATCH_STALE_AFTER_MS) staleLiveCount++;
      }
      const staleRatio = sampledLiveCount > 0 ? staleLiveCount / sampledLiveCount : 0;
      // Truly shared cooldown with the whole-feed volatility rotation: both
      // triggers read AND write scannerStats.dataVolatility.lastStaleRotationAt,
      // so a recent volatility rotation suppresses a stale-ratio rotation and
      // vice versa. Prevents the two systems from fighting over the mirror.
      const lastRotationAt = scannerStats.dataVolatility.lastStaleRotationAt
        ? scannerStats.dataVolatility.lastStaleRotationAt.getTime()
        : 0;
      const sinceLastRotation = now - lastRotationAt;
      const cooledDown = sinceLastRotation >= VOLATILITY_ROTATION_COOLDOWN_MS;
      if (
        sampledLiveCount >= STALE_RATIO_MIN_SAMPLE &&
        staleRatio >= STALE_RATIO_TRIGGER &&
        cooledDown &&
        !staleFailoverInFlight
      ) {
        staleFailoverInFlight = true;
        scannerStats.dataVolatility.lastStaleRotationAt = new Date(now);
        const reason = `stale_ratio:${(staleRatio * 100).toFixed(0)}%`;
        logger.error(
          { staleLiveCount, sampledLiveCount, liveCount, staleRatio, threshold: STALE_RATIO_TRIGGER, mirror: currentBaseUrl(), staleAfterSec: MATCH_STALE_AFTER_MS / 1000 },
          "[STALE-RATIO] 🚨 No odds movement on too many live matches — forcing mirror rotation",
        );
        void (async () => {
          try {
            const fo = await tryFailover(fetchRawDetails, reason, { force: true });
            if (fo.switched) {
              logger.warn({ from: fo.from, to: fo.to, reason }, "[STALE-RATIO] ✅ Failover succeeded");
              // Fresh mirror: reset per-match recency so we don't immediately
              // re-trigger on still-empty histories.
              for (const st of matchStates.values()) st.lastOddsChangeAt = Date.now();
            } else {
              logger.error({ report: fo.report, stayingOn: fo.from }, "[STALE-RATIO] ⚠️ No healthy alternate mirror");
            }
          } catch (e) {
            logger.error({ err: e }, "Stale-ratio failover threw");
          } finally {
            staleFailoverInFlight = false;
          }
        })();
      }
    }

    logger.debug(
      {
        primary: primaryMap.size,
        bench: benchMap.size,
        minor: minorCount,
        live: liveCount,
        skipped: skippedCount,
        priorityWatchlist: priorityWatchlistMatches,
        globalAnalyzed: globalPoolAnalyzed,
        globalThrottled: globalPoolSkippedByThrottle,
        globalCapped: globalPoolSkippedByCap,
      },
      "Pro scan tick complete"
    );
    scannerStats.lastTickMapSizes = {
      primary: primaryMap.size,
      bench: benchMap.size,
      meta: metaMap.size,
      capturedAt: new Date(),
    };
  } catch (err: unknown) {
    tickSucceeded = false;

    // stopScanner()/force-restart intentionally abort the current generation.
    // That cancellation is not an upstream outage: do not increment the
    // consecutive-failure counter, overwrite a healthy lastError, or launch a
    // failover probe on behalf of a generation that has already been retired.
    const lifecycleCancelled =
      myGen !== scannerGeneration ||
      (expectedGeneration !== undefined && !scannerRunning) ||
      (__currentTickAbort?.signal.aborted === true &&
        err instanceof Error &&
        err.name === "AbortError");
    if (lifecycleCancelled) {
      logger.debug(
        {
          capturedGeneration: myGen,
          currentGeneration: scannerGeneration,
          running: scannerRunning,
          err: err instanceof Error ? err.message : String(err),
        },
        "Scanner tick cancelled by lifecycle change",
      );
      scheduleNextTick(myGen, false);
      return;
    }

    consecutiveFailures++;
    scannerStats.consecutiveFailures = consecutiveFailures;

    // Lazy failover with bounded retry: first attempt at 2 consecutive
    // failures, then re-attempt every 3 failures after that (5, 8, 11, ...)
    // until either the swap succeeds or we hit the cap. We avoid probing on
    // every tick so a transient network blip doesn't trigger a thundering-herd
    // probe; we also avoid one-shot behaviour so a single failed probe cascade
    // doesn't strand us on a dead primary until the 60s watchdog fires. The
    // singleflight lock inside tryFailover() coalesces with any concurrent
    // watchdog-triggered probe.
    const FAILOVER_TRIGGER_THRESHOLD = 2;
    const FAILOVER_RETRY_INTERVAL = 3;
    const FAILOVER_MAX_ATTEMPTS_PER_OUTAGE = 5;
    const attemptIndex = consecutiveFailures - FAILOVER_TRIGGER_THRESHOLD;
    const isFailoverAttempt =
      attemptIndex >= 0 &&
      attemptIndex % FAILOVER_RETRY_INTERVAL === 0 &&
      attemptIndex / FAILOVER_RETRY_INTERVAL < FAILOVER_MAX_ATTEMPTS_PER_OUTAGE;
    if (isFailoverAttempt) {
      logger.warn(
        { consecutiveFailures, base: currentBaseUrl(), attemptIndex },
        "Scanner: consecutive fetch failures — attempting lazy failover",
      );
      // Probing a mirror pool can take materially longer than the normal
      // cadence. Detach it so recovery always reaches scheduleNextTick; the
      // singleflight guard in upstream.ts prevents concurrent probe cascades.
      void tryFailover(fetchRawDetails, "scanner_consecutive_failures")
        .then((fo) => {
          if (fo.switched) {
            logger.warn({ from: fo.from, to: fo.to, coalesced: fo.coalesced }, "Scanner: failover succeeded");
          }
        })
        .catch((foErr) => {
          logger.error({ err: foErr }, "Scanner: failover attempt itself threw");
        });
    }
    const msg = err instanceof Error ? err.message : String(err);
    scannerStats.lastError = msg;
    if (err instanceof UpstreamTimeoutError) {
      logger.warn(
        { url: err.url, timeoutMs: err.timeoutMs, attempt: err.attempt + 1 },
        "NowGoal26 request timed out",
      );
    } else if (err instanceof Error && err.name === "AbortError") {
      // An AbortError that reaches this branch was not caused by our
      // stop/restart controller. Keep it visible as an actual upstream
      // cancellation rather than silently suppressing it.
      logger.warn({ err: msg }, "NowGoal26 request aborted unexpectedly");
    } else {
      logger.error({ err }, "NowGoal26 connection error");
    }
  }

  // Adaptive cadence + backoff:
  //   - Failure backoff dominates: on repeated upstream failures we slow
  //     down regardless of watchlist state to avoid hammering a sick mirror.
  //   - Otherwise both watchlist and steady-state work use the unified 12s
  //     active cadence.
  //   - Jitter is constant ±POLL_JITTER_MS in both modes so the request
  //     pattern still looks organic.
  {
    const __elapsedMs = Date.now() - __tickStartedAt;
    // Elevate to WARN when wall-time exceeds the watchlist target (12s) — a
    // healthy normal-mode tick should never overrun that, and overruns are
    // exactly the symptom users see as "watchlist odds lag 20-40s". This
    // gives ops a single grep target for the failure mode.
    const overran = __elapsedMs > WATCHLIST_FAST_POLL_INTERVAL_MS;
    const logFn = overran ? logger.warn.bind(logger) : logger.info.bind(logger);
    logFn(
      { elapsedMs: __elapsedMs, sincePrevMs: __tickSincePrev, mode: "normal", overran },
      "[TICK] complete",
    );
  }
  scheduleNextTick(myGen, tickSucceeded);
}

/**
 * Re-arm the next tick. Centralized so both the normal pipeline and the
 * hyper-focus short-circuit share the same generation guard + cadence
 * selection logic. Cadence priority:
 *   1. Failure backoff dominates regardless of mode (don't hammer a sick mirror).
 *   2. HYPER-FOCUS mode → 12s (single primaryOu fetch only).
 *   3. Watchlist non-empty → 12s (fast watchlist refresh).
 *   4. Empty watchlist → 12s (steady-state global cadence).
 * Jitter is constant ±POLL_JITTER_MS so the request pattern looks organic.
 */
function scheduleNextTick(myGen: number, tickSucceeded: boolean): void {
  // Settle bookkeeping — ONLY for the current generation's tick. A stale
  // zombie tick (generation bumped underneath it by stop/restart/watchdog)
  // must not clear the in-flight/phase state of the fresh tick that already
  // replaced it, or the watchdog would think nothing is running.
  if (myGen === scannerGeneration) {
    __tickInFlight = false;
    __lastTickCompletedAt = Date.now();
    // True global heartbeat: a tick fully settled its write phase for the
    // CURRENT generation WITHOUT throwing. Surfaced to the dashboard as "Last
    // update" so (a) a mid-tick freeze never reaches here → timestamp stops
    // dead, and (b) a sustained upstream outage (tick caught, tickSucceeded
    // false) also stops it — unlike a per-bookmaker price stamp it reflects
    // whole-scanner write health, not whether one book happened to move.
    if (tickSucceeded) {
      scannerStats.lastGlobalUpdateAt = new Date();
    }
    __tickPhase = null;
    __currentTickAbort = null;
  }

  // Do not even inspect watchlist/cadence for a retired generation. Apart
  // from avoiding needless work, this makes the re-arm invariant explicit:
  // every failed/successful current-generation tick schedules exactly one
  // callback, while a zombie generation schedules none.
  if (!scannerRunning || myGen !== scannerGeneration) {
    logger.info(
      { capturedGen: myGen, currentGen: scannerGeneration, running: scannerRunning },
      "Scanner tick finished after stop/restart — not re-arming",
    );
    return;
  }
  if (externallyScheduled) {
    __nextTickExpectedAt = 0;
    return;
  }

  let watchlistActive = false;
  try {
    watchlistActive = getWatchlistSnapshot().count > 0;
  } catch (err) {
    // Scheduling is a liveness invariant. A malformed/hot-reloading
    // watchlist must not strand the scanner after an otherwise recoverable
    // tick; use the conservative steady cadence for this one re-arm.
    logger.warn({ err }, "Scanner watchlist read failed while scheduling — using steady cadence");
  }
  let healthyDelay: number;
  if (isGlobalScannerPaused) {
    healthyDelay = WATCHLIST_HYPER_POLL_INTERVAL_MS;
  } else if (watchlistActive) {
    healthyDelay = WATCHLIST_FAST_POLL_INTERVAL_MS;
  } else {
    healthyDelay = POLL_INTERVAL_MS;
  }
  const baseDelay = consecutiveFailures > 0
    ? Math.min(POLL_INTERVAL_MS * (1 + consecutiveFailures), 60_000)
    : healthyDelay;
  const jitter = (Math.random() * 2 - 1) * POLL_JITTER_MS;

  // Hyper-focus tolerates a tighter floor than the steady-state 2s — when
  // paused we WANT the tightest possible cadence on the single remaining
  // upstream call. Otherwise the existing 2s floor protects against
  // pathological backoff math (e.g. extreme negative jitter).
  const floor = isGlobalScannerPaused ? 1_000 : 2_000;
  const delay = Math.max(floor, baseDelay + jitter);
  // Record when the next tick is due so the watchdog can detect a timer chain
  // that died WITHOUT re-arming (grace scales to whatever cadence/backoff is
  // currently scheduled, so a healthy 60s backoff window never false-trips).
  __nextTickExpectedAt = Date.now() + delay;
  scannerTimer = setTimeout(() => {
    scannerTimer = null;
    // The callback may already be queued when stop→start clears its timer.
    // Check the captured generation before entering tick so it cannot join the
    // fresh loop as a second owner.
    if (!scannerRunning || myGen !== scannerGeneration) {
      logger.debug(
        { capturedGen: myGen, currentGen: scannerGeneration, running: scannerRunning },
        "Scanner scheduled callback ignored after lifecycle change",
      );
      return;
    }
    void tick(myGen);
  }, delay);
}

/**
 * Odds-drop / benchmark Pro Alert evaluation for a single match. Extracted
 * verbatim from the main tick loop so BOTH the normal global pipeline and the
 * hyper-focus (global-scanner-paused) watchlist-only tick run the EXACT same
 * gates. Mutates state.lastAlertAt + scannerStats and fire-and-forgets the
 * Telegram dispatch when every gate passes. Deliberately does NOT touch
 * state.history — the caller appends the current snapshot exactly once after
 * this returns (preserves the original single-push-per-match contract).
 */
function evaluateOddsDropAlert(args: {
  matchId: string;
  state: MatchState;
  prev: OUSnapshot | undefined;
  ou: OUEntry;
  meta: {
    team1: string;
    team2: string;
    leagueId: string;
    isLive: boolean;
    homeScore: number;
    awayScore: number;
    kickoffMs: number | null;
  };
  leagueName: string;
  isLowLiq: boolean;
  now: number;
}): void {
  const { matchId, state, prev, ou, meta, leagueName, isLowLiq, now } = args;
  // Keep this guard inside the shared evaluator as defense in depth for both
  // the normal and hyper-focus paths. Callers may be priority/watchlist paths,
  // but those signals never authorize a non-target or unresolved league.
  if (!matchTargetLeague(leagueName)) return;
  // GOAL BLACKOUT: a goal inside the 5-min drop window reprices the line
  // and looks exactly like smart-money inflow. Skip alerting until the
  // market settles -- the drop math below can't tell them apart.
  if (state.lastScoreChangeAt != null && now - state.lastScoreChangeAt < GOAL_BLACKOUT_MS) {
    scannerStats.alertsSuppressedByGoalBlackout++;
    logger.debug(
      { matchId, blackoutLeftMs: GOAL_BLACKOUT_MS - (now - state.lastScoreChangeAt) },
      "Pro alert suppressed by goal blackout",
    );
    return;
  }
  // Reconstruct the current snapshot the same way the caller does. The caller
  // appends this to state.history exactly once AFTER we return, so here it is
  // not yet in state.history — matching the original loop's ordering where the
  // pressure window was [...state.history, current] before the trailing push.
  const current: OUSnapshot = {
    ts: now,
    overDecimal: ou.overDecimal,
    underDecimal: ou.underDecimal,
    line: ou.line,
  };
      // Blackout expiry is not evidence of a new baseline: the primary feed
      // may have been silent throughout it. Keep raw histories for other
      // consumers, but admit only strictly post-score-change SMART MONEY
      // evidence (same-tick quotes may have been fetched before the goal).
      const scoreCutoff = state.lastScoreChangeAt ?? -Infinity;
      if (!prev || prev.line !== ou.line || prev.ts <= scoreCutoff) return;
      const benchmarkHistory = state.benchmarkHistory.filter((h) => h.ts > scoreCutoff);
      const primaryHistory = state.history.filter((h) => h.ts > scoreCutoff);
      const prevSnap = prev;
      // Evaluate BOTH market directions symmetrically. An UNDER money move makes
      // the under price collapse while the over price rises, so it is invisible
      // to an over-only check — we run the exact same gates for each side and
      // fire/record whichever side's price actually dropped. The shared
      // Match-wide reservation covers the async score check; lastAlertAt
      // only consumes the cooldown once the final admission guards pass.
      const evaluateSide = (side: "OVER" | "UNDER"): void => {
        const sideLabel = side === "OVER" ? "Over" : "Under";
        const curOdds = side === "OVER" ? ou.overDecimal : ou.underDecimal;
        const prevOdds = side === "OVER" ? prevSnap.overDecimal : prevSnap.underDecimal;
        const drop = prevOdds - curOdds;

        if (!state.oddsDropAlertInFlight && drop >= config.dropThreshold && now - state.lastAlertAt >= ALERT_COOLDOWN_MS) {
          // ----- UPSTREAM VALUE GUARD (early exit) -----
          // Discard micro-odds parking and "guaranteed clear" unders BEFORE any
          // record/alert/stat/cooldown so the WIN% column only tracks actionable
          // value. The odds-drop path carries no live clock, so the late-game
          // rule is N/A here (minute: null) — the odds floor and the general
          // score-to-line buffer still apply. Returning skips ONLY this side and
          // does not consume the cooldown (we never actually alerted).
          const valueGuard = passesValueGuards({
            decimalOdds: curOdds,
            targetSide: side,
            line: ou.line,
            totalGoals: meta.homeScore + meta.awayScore,
            isLive: meta.isLive,
            minute: null,
          });
          if (!valueGuard.ok) {
            scannerStats.alertsSuppressedByValueGuard++;
            logger.info(
              { matchId, side, line: ou.line, curOdds, reason: valueGuard.reason },
              "Pro alert suppressed by value guard",
            );
            return;
          }

          // ----- HYBRID LIQUIDITY GATE (early exit) -----
          // When the operator toggle is ON, suppress the alert pipeline on
          // matches whose Excapper volume hasn't reached `minCumulativeEur`
          // on at least one FRESH line. Watchlist matches are exempt —
          // those are user-prioritized and must always fire.
          //
          // Important context for future readers: Excapper today only
          // scrapes volume for watchlist matches (see
          // `getWatchlistMatchesForVolume()`), so when this toggle is ON
          // it effectively reduces the alert stream to watchlist-only —
          // which is the operator-intended "high-conviction-only" mode.
          // If volume coverage is ever expanded to all matches, the same
          // gate naturally upgrades to a true per-match liquidity check.
          //
          // Freshness TTL guards against stale per-line samples that
          // could otherwise keep passing the gate after a line has gone
          // cold (volumes Map is intentionally not pruned across ticks).
          if (config.requireLiquidityConfirmation) {
            const watchlistHitForGate = matchesWatchlist(meta.team1, meta.team2, matchId);
            if (watchlistHitForGate === null) {
              const minCumulativeEur = getVolumeConfig().minCumulativeEur;
              const VOLUME_FRESHNESS_MS = 15 * 60 * 1000; // 15min — Excapper polls ~90s
              let liquidityOk = false;
              if (state.volumes) {
                for (const v of state.volumes.values()) {
                  if (now - v.updatedAt > VOLUME_FRESHNESS_MS) continue;
                  if (v.over + v.under >= minCumulativeEur) { liquidityOk = true; break; }
                }
              }
              if (!liquidityOk) {
                scannerStats.alertsSuppressedBySpread++;
                logger.debug(
                  { matchId, drop, minCumulativeEur, reason: "liquidity-gate" },
                  "Alert short-circuited: requireLiquidityConfirmation on and no fresh line met minCumulativeEur",
                );
                return;
              }
            }
          }
          logger.debug({ matchId, team1: meta.team1, team2: meta.team2, drop }, "[DEBUG-ALERT] PASSED drop+cooldown — entering gates");
          const spread = Math.abs(ou.overDecimal - ou.underDecimal);

          // ----- Tiered spread gate -----
          // 1. Absurd spread → always drop (almost certainly a broken quote / data glitch).
          // 2. Otherwise, the effective cap depends on region:
          //      - low-liquidity regions get the relaxed cap
          //      - everyone else gets the standard maxSpread (when requireDensity is on)
          // 3. A "big drop" (≥ bypassSpreadOnBigDrop) overrides the soft cap on the
          //    theory that a 0.80+ collapse on a wide market is exactly the
          //    fixed-match signature we WANT to catch.
          const effectiveMaxSpread = isLowLiq ? config.lowLiqMaxSpread : config.maxSpread;
          const bigDrop = drop >= config.bypassSpreadOnBigDrop;
          let lowLiqAlert = false;

          if (spread > config.absurdSpreadCap) {
            scannerStats.alertsSuppressedBySpread++;
            logger.info(
              { matchId, drop, spread, absurdSpreadCap: config.absurdSpreadCap, league: leagueName },
              "Alert discarded: spread above absurd cap (likely broken quote)"
            );
            return;
          }

          if (config.requireDensity && spread > effectiveMaxSpread && !bigDrop) {
            scannerStats.alertsSuppressedBySpread++;
            logger.info(
              { matchId, drop, spread, effectiveMaxSpread, isLowLiq, league: leagueName },
              "Alert discarded: spread above effective cap and drop not big enough to bypass"
            );
            return;
          }

          // We're letting it through but it's still a wide market — flag it.
          if (spread > config.maxSpread) lowLiqAlert = true;

          // Noise guard for the big-drop spread bypass: when we're firing on a
          // wide-spread market that only got past the gate via the bypass, the
          // benchmark book MUST NOT be moving in the opposite direction. A drop
          // on the primary while the sharp benchmark rises is the classic
          // "broken quote / one-sided liquidity" pattern, not a real signal.
          if (bigDrop && spread > effectiveMaxSpread) {
            const guard = evalBenchmark(benchmarkHistory, ou.line, now, side);
            if (guard.status === "diverging") {
              scannerStats.alertsSuppressedBySpread++;
              logger.info(
                { matchId, drop, spread, benchDelta: guard.delta, league: leagueName },
                "Alert discarded: bypass triggered but benchmark is diverging (likely noise)"
              );
              return;
            }
          }

          // ----- Compute factors -----
          const benchResult = evalBenchmark(benchmarkHistory, ou.line, now, side);
          const pressureHist = [...primaryHistory, current];
          const pressure = pressureMovements(pressureHist, now, side);

          const factors: AlertFactors = {
            drop,
            spread,
            pressure,
            bench: benchResult,
            isLive: meta.isLive,
          };
          const confidence = computeConfidence(factors);

          if (confidence < config.minConfidence) {
            scannerStats.alertsSuppressedByConfidence++;
            logger.info(
              { matchId, drop, confidence, min: config.minConfidence, factors },
              "Alert suppressed: confidence below threshold"
            );
            return;
          }

          const recentInflow = getRecentUnifiedInflow(matchId, ou.line, side, now);
          const unifiedInput: UnifiedAlertInput = {
            matchId,
            bookmaker: "Bet365",
            league: leagueName || `League #${meta.leagueId}`,
            home: meta.team1,
            away: meta.team2,
            isLive: meta.isLive,
            homeScore: meta.homeScore,
            awayScore: meta.awayScore,
            minute: resolveUnifiedAlertMinute(meta, recentInflow?.minute, now),
            side,
            line: ou.line,
            timeline: [...primaryHistory, current].map((point) => ({
              ts: point.ts,
              line: point.line,
              odds: side === "OVER" ? point.overDecimal : point.underDecimal,
            })),
            inflow: recentInflow,
            link: matchLink(matchId),
          };
          if (!claimUnifiedAlertEvent(unifiedInput, now)) {
            logger.debug(
              { matchId, side, line: ou.line },
              "Consolidated alert suppressed as duplicate event",
            );
            return;
          }

          // Re-read the authoritative score immediately before persistence and
          // delivery. A goal can settle this total while the alert is waiting
          // behind the async send path; the earlier tick snapshot is not enough.
          const alertGeneration = scannerGeneration;
          const alertEvidenceVersion = runtimeEvidenceVersion;
          // Reserve synchronously before either side can await. Keep this on
          // the state object so an old dispatch cannot unlock a replacement
          // state after retirement/reset.
          state.oddsDropAlertInFlight = true;
          void (async () => {
            let finalInput = unifiedInput;
            if (meta.isLive) {
              const scoreVersion = state.lastMeta?.updatedAt;
              const fresh = await fetchFreshScoreNow(matchId);
              // An in-flight score request must never deliver an alert after
              // retirement, reset, restart, or a different source's goal.
              if (
                scannerGeneration !== alertGeneration ||
                runtimeEvidenceVersion !== alertEvidenceVersion ||
                matchStates.get(matchId) !== state ||
                !isLiveMeta(state.lastMeta) ||
                state.lastMeta?.updatedAt !== scoreVersion
              ) {
                releaseUnifiedAlertEvent(unifiedInput);
                return;
              }
              const finalGuard = passesValueGuards({
                decimalOdds: curOdds,
                targetSide: side,
                line: ou.line,
                totalGoals: fresh ? fresh.homeScore + fresh.awayScore : null,
                isLive: true,
                minute: null,
              });
              if (!fresh || !fresh.isLive || !finalGuard.ok) {
                scannerStats.alertsSuppressedByValueGuard++;
                releaseUnifiedAlertEvent(unifiedInput);
                logger.info(
                  {
                    matchId,
                    side,
                    line: ou.line,
                    reason: !fresh || !fresh.isLive
                      ? "live-score-unavailable"
                      : finalGuard.ok ? "live-score-unavailable" : finalGuard.reason,
                  },
                  "Pro alert suppressed by final live-score guard",
                );
                return;
              }
              // The direct score may be newer than the tick's bulk meta. A
              // newly detected goal reprices odds even when it has not settled
              // this line yet: stamp it and refuse this pending alert.
              if (
                fresh.homeScore !== state.lastMeta!.homeScore ||
                fresh.awayScore !== state.lastMeta!.awayScore
              ) {
                const scoreNow = Date.now();
                updateLastMetaWithScoreTracking(state, {
                  ...state.lastMeta!, homeScore: fresh.homeScore,
                  awayScore: fresh.awayScore, updatedAt: scoreNow,
                }, scoreNow);
              }
              if (
                state.lastScoreChangeAt != null &&
                Date.now() - state.lastScoreChangeAt < GOAL_BLACKOUT_MS
              ) {
                scannerStats.alertsSuppressedByGoalBlackout++;
                releaseUnifiedAlertEvent(unifiedInput);
                logger.info({ matchId, side, line: ou.line },
                  "Pro alert suppressed by final goal blackout");
                return;
              }
              finalInput = {
                ...unifiedInput,
                homeScore: fresh.homeScore,
                awayScore: fresh.awayScore,
              };
            }
            if (
              scannerGeneration !== alertGeneration ||
              runtimeEvidenceVersion !== alertEvidenceVersion ||
              matchStates.get(matchId) !== state ||
              !isLiveMeta(state.lastMeta)
            ) {
              releaseUnifiedAlertEvent(unifiedInput);
              return;
            }
            // Async score refresh and Telegram backpressure must not turn an
            // expired/flat quote into an alert. Revalidate the exact market
            // immediately before persistence, cooldown consumption and send.
            if (!resolvePositiveOddsDrop(finalInput, Date.now())) {
              releaseUnifiedAlertEvent(unifiedInput);
              logger.info(
                { matchId, side, line: ou.line, reason: "odds-drop-unavailable-or-stale" },
                "Pro alert suppressed by final exact-market odds guard",
              );
              return;
            }

            scannerStats.anomaliesFound++;
            if (benchResult.status === "dropping") scannerStats.benchmarkConfirmedAlerts++;
            else if (benchResult.status === "stable" || benchResult.status === "no-data")
              scannerStats.earlyBirdAlerts++;
            if (lowLiqAlert || isLowLiq) scannerStats.lowLiquidityAlerts++;
            state.lastAlertAt = Date.now();

            if (matchesWatchlist(meta.team1, meta.team2, matchId) !== null) {
              recordAnomaly({
                matchId,
                team1: meta.team1,
                team2: meta.team2,
                league: leagueName || `League #${meta.leagueId}`,
                anomalyType: "ODDS_DROP",
                targetSide: side,
                line: ou.line,
                matchMinute: null,
                isLive: meta.isLive,
                homeScore: finalInput.homeScore!,
                awayScore: finalInput.awayScore!,
                oddsAtFire: curOdds - 1,
                kickoffAtMs: meta.kickoffMs ?? null,
              });
            }

            const displayLeague = leagueName || `League #${meta.leagueId}`;
            // The SMART MONEY admission above remains Bet365-only. Use its
            // already-qualified, exact-market price evidence for display;
            // other books, when available, are display-only and cannot create
            // a new alert or relax any admission/value/owner guard.
            const triggerQuoteAt = finalInput.timeline.at(-1)?.ts ?? now;
            const bet365Movement = Number.isFinite(prevOdds) && prevOdds > curOdds &&
              Number.isFinite(curOdds) && triggerQuoteAt <= Date.now() + 5_000
              ? [{
                cid: "8", bookmaker: "Bet365", type: "drop" as const,
                from: prevOdds, to: curOdds,
                percent: (curOdds - prevOdds) / prevOdds * 100,
                quoteAt: triggerQuoteAt,
                history: finalInput.timeline
                  .filter((point) => point.line === ou.line && point.ts <= triggerQuoteAt)
                  .map((point) => ({ ts: point.ts, odds: point.odds })),
              }]
              : [];
            const cachedMovements = getCachedBookMovements(matchId, side, ou.line, triggerQuoteAt)
              // The scanner's admitted Bet365 quote is the authority for this
              // card's trigger; cached secondary books are display evidence.
              .filter((book) => book.cid !== "8")
              // Cached moves can remain fresh beyond the 90s blackout.
              // Without a timestamped baseline (observed-only books expose
              // no history), we cannot prove both endpoints are post-goal.
              // Omit ambiguous/cross-goal moves rather than relabeling them.
              .filter((book) => state.lastScoreChangeAt == null || (
                book.quoteAt > scoreCutoff &&
                book.history.length >= 2 &&
                book.history.every((point) => point.ts > scoreCutoff) &&
                book.history[0]!.odds === book.from &&
                book.history.at(-1)!.odds === book.to
              ));
            const msg = formatUnifiedAlert({
              ...finalInput,
              quoteAt: triggerQuoteAt,
              radarBooks: [...bet365Movement, ...cachedMovements],
            });
            logger.info(
              {
                matchId,
                team1: meta.team1,
                team2: meta.team2,
                league: displayLeague,
                side,
                line: ou.line,
                from: prevOdds.toFixed(2),
                to: curOdds.toFixed(2),
                drop,
                spread,
                pressure,
                benchStatus: benchResult.status,
                benchDelta: benchResult.delta,
                confidence,
                isLive: meta.isLive,
                homeScore: finalInput.homeScore,
                awayScore: finalInput.awayScore,
              },
              "Pro alert fired",
            );
            const delivery = await sendTelegram(msg);
            if (delivery.primaryDelivered) lastDeliveredScannerAlertAt = Date.now();
          })().catch((err) => {
            releaseUnifiedAlertEvent(unifiedInput);
            logger.error({ err, matchId }, "[TG-SEND] ProAlert dispatch threw (post-detach)");
          }).finally(() => {
            state.oddsDropAlertInFlight = false;
          });
        }
      };

      evaluateSide("OVER");
      evaluateSide("UNDER");
}


/**
 * HYPER-FOCUS tick body. Runs when the user has paused the global scanner.
 * Fetches ONLY the primaryOu bulk endpoint (single HTTP call, returns OU odds
 * for every match in the feed) and updates state for matches whose IDs are
 * pinned in the watchlist. Skipped vs. the normal pipeline:
 *   - benchmarkOu fetch         (Crown odds — only needed for global alerts)
 *   - meta fetch                (team names / league — watchlist matches are
 *                                already in matchStates from before pause)
 *   - alert evaluation          (gates: drop, spread, confidence, bench)
 *   - live-transition tracker   (per-match prematch→live state machine)
 *   - stale-ratio watchdog      (auto-rotates frozen mirrors)
 *   - volatility ring + sig     (per-tick odds-signature stale detection)
 *   - matchStates prune         (would drop watchlist matches that legitimately
 *                                disappeared from the bulk feed)
 *   - benchmark history append  (no bench data in this mode)
 *
 * Text-only watchlist entries (no matchId) are best-effort — they only work
 * for explicit manual IDs using bounded direct metadata reads. Other rows
 * still require a previously resolved state; no global discovery runs here.
 */
async function runHyperFocusTick(): Promise<boolean> {
  const generation = scannerGeneration;
  const wl = getWatchlistSnapshot();
  const pinnedIds = new Set<string>();
  for (const e of wl.entries) {
    if (e.matchId) pinnedIds.add(e.matchId);
  }

  const ep = endpointsFor(currentBaseUrl());

  // Fetch primary OU (Bet365) AND the per-book extras (Sbobet/M88/12Bet/
  // 18Bet/VSBet) in parallel. Without this, paused/hyper-focus mode only
  // updates the primary line and every other bookmaker on the dashboard
  // appears frozen for as long as the scanner stays paused — exactly the
  // "only Bet365 updates" symptom the user reported.
  //
  // Wall-time is bounded the same way as the normal path: extras share a
  // bounded AbortController deadline, primary relies on fetchRaw's internal
  // cap. Promise.allSettled means a flaky book just
  // dashes its own row this tick; primary + the other books are unaffected.
  const extraAbort = new AbortController();
  const extraDeadline = setTimeout(() => extraAbort.abort(), EXTRA_BOOK_TIMEOUT_MS);
  const coreSignal = __currentTickAbort?.signal;
  if (coreSignal) {
    if (coreSignal.aborted) extraAbort.abort();
    else coreSignal.addEventListener("abort", () => extraAbort.abort(), { once: true });
  }
  setTickPhase(
    "hyper-focus core fetch: primaryOu(Bet365) + benchmark(Crown) + extras[Sbobet,M88,12Bet,18Bet,VSBet]",
  );
  const allRes = await Promise.allSettled([
    fetchRaw(withCacheBuster(ep.primaryOu), 0, coreSignal),
    fetchRaw(withCacheBuster(ep.benchmarkOu), 0, coreSignal),
    ...EXTRA_BOOK_KEYS.map((k) =>
      fetchRaw(withCacheBuster(ep.extraBooks[k]), 2, extraAbort.signal),
    ),
  ]);
  clearTimeout(extraDeadline);
  const primaryRes = allRes[0]!;
  const benchRes = allRes[1]!;
  const extraRes = allRes.slice(2);

  if (primaryRes.status !== "fulfilled") {
    if (__currentTickAbort?.signal.aborted) {
      logger.debug(
        { err: primaryRes.reason, mode: "hyper-focus" },
        "Hyper-focus primaryOu fetch cancelled by lifecycle",
      );
      return false;
    }
    scannerStats.primaryFetchFailures++;
    consecutiveFailures++;
    scannerStats.consecutiveFailures = consecutiveFailures;
    scannerStats.lastError =
      primaryRes.reason instanceof Error ? primaryRes.reason.message : String(primaryRes.reason);
    logger.warn({ err: primaryRes.reason, mode: "hyper-focus" }, "Hyper-focus primaryOu fetch failed");
    // The primary feed is the health heartbeat for hyper-focus. Optional
    // bookmaker failures below do not take this path, so a false result here
    // prevents the scheduler from stamping a failed tick as a fresh update.
    return false;
  }
  const primaryText = primaryRes.value;

  // Manual approval must keep score/minute metadata alive even while global
  // scanning is paused. Use the same bounded, throttled direct read as normal
  // priority ticks; do not derive a clock from elapsed wall time.
  const manualIds = new Set(
    [...pinnedIds].filter((id) => isManualWatchlistId(id)),
  );
  await injectMissingWatchlistMeta(new Map(), new Map(), {
    forceIds: manualIds,
    onlyIds: manualIds,
    materializeState: true,
  });
  if (generation !== scannerGeneration) return false;

  // Parse Crown/benchmark feed for the pinned matches so the dashboard's
  // benchmark column stays live in pause mode. Best-effort: a failure just
  // means benchmarkHistory doesn't gain a sample this tick — exactly the
  // same semantics as the normal path (scanner.ts ~2371-2377).
  let benchMap = new Map<string, OUEntry>();
  if (benchRes.status === "fulfilled") {
    benchMap = parseOUXml(benchRes.value);
  } else {
    scannerStats.benchmarkFetchFailures++;
    logger.warn(
      { err: benchRes.reason, mode: "hyper-focus" },
      "Hyper-focus benchmark fetch failed — benchmark column dashes this tick",
    );
  }

  // Mirror the normal-path per-book parse + stats update. Identical bookkeeping
  // so /api/scanner/health reflects hyper-focus activity, not just stale
  // "lastParsedAt" from the last normal tick before the user paused.
  const extraBookMaps = new Map<ExtraBookKey, Map<string, OUEntry>>();
  EXTRA_BOOK_KEYS.forEach((book, i) => {
    const res = extraRes[i]!;
    if (res.status === "fulfilled") {
      const parsed = parseOUXml(res.value);
      extraBookMaps.set(book, parsed);
      scannerStats.perBookFetch[book].ok++;
      scannerStats.perBookFetch[book].lastError = null;
      scannerStats.perBookFetch[book].lastParsedRows = parsed.size;
      scannerStats.perBookFetch[book].lastParsedAt = new Date();
    } else {
      scannerStats.perBookFetch[book].fail++;
      const errMsg = res.reason instanceof Error ? res.reason.message : String(res.reason);
      scannerStats.perBookFetch[book].lastError = errMsg;
      logger.warn({ book, err: errMsg, mode: "hyper-focus" }, "Extra book OU fetch failed");
    }
  });

  consecutiveFailures = 0;
  scannerStats.consecutiveFailures = 0;
  scannerStats.lastError = null;

  const now = Date.now();
  scannerStats.lastCheckAt = new Date();
  scannerStats.checksTotal++;

  const primaryMap = parseOUXml(primaryText);
  if (generation !== scannerGeneration) return false;
  for (const id of matchStates.keys()) {
    if (!pinnedIds.has(id)) retireRuntimeMatch(id);
  }
  for (const id of pinnedIds) {
    const state = matchStates.get(id);
    if (!state?.lastMeta) continue;
    const version = runtimeEvidenceVersion;
    const fresh = await fetchFreshScoreNow(id);
    directScoreIdsFetchedThisCycle.add(id);
    if (generation !== scannerGeneration) return false;
    if (version !== runtimeEvidenceVersion || matchStates.get(id) !== state) continue;
    if (!fresh || !isLiveMeta(fresh)) {
      retireRuntimeMatch(id, fresh ? { ...state.lastMeta, ...fresh } : state.lastMeta);
      continue;
    }
    const scoreNow = Date.now();
    updateLastMetaWithScoreTracking(state, {
      ...state.lastMeta, ...fresh, updatedAt: scoreNow,
    }, scoreNow);
  }

  // VCBET per-match fallback for the watchlist: same logic as the normal
  // path. goal14.xml only carries matches Vcbet quoted in the recent batch;
  // pinned watchlist matches missing from that feed get filled in via the
  // /Ajax/SoccerAjax?type=14 per-match endpoint, with a 3s deadline already
  // enforced by fetchVcbetBatch internally.
  try {
    const vcbetBatchMap = extraBookMaps.get("VSBet") ?? new Map<string, OUEntry>();
    const missing: string[] = [];
    for (const id of pinnedIds) {
      if (vcbetBatchMap.has(id)) continue;
      missing.push(id);
      if (missing.length >= 30) break;
    }
    if (missing.length > 0) {
      setTickPhase(`hyper-focus vcbet per-match fallback (${missing.length} matches)`);
      const perMatch = await fetchVcbetBatch(missing, 1);
      let merged = 0;
      for (const [mid, snap] of perMatch) {
        vcbetBatchMap.set(mid, {
          matchId: mid,
          line: snap.line,
          overDecimal: snap.overDecimal,
          underDecimal: snap.underDecimal,
        });
        merged++;
      }
      if (merged > 0) {
        extraBookMaps.set("VSBet", vcbetBatchMap);
        scannerStats.perBookFetch.VSBet.lastParsedRows = vcbetBatchMap.size;
        scannerStats.perBookFetch.VSBet.lastParsedAt = new Date();
      }
    }
  } catch (err) {
    logger.warn(
      { err: err instanceof Error ? err.message : String(err), mode: "hyper-focus" },
      "[VCBET-PERMATCH] hyper-focus batch failed (non-fatal)",
    );
  }

  // Update history for pinned watchlist IDs only. We deliberately do NOT
  // touch non-watchlist matchStates entries — they're preserved as-is for
  // when the user un-pauses, but won't generate alerts or move forward.
  let updated = 0;
  let seeded = 0;
  if (generation !== scannerGeneration) return false;
  for (const id of pinnedIds) {
    const ou = primaryMap.get(id);
    if (!ou) continue;
    const state = matchStates.get(id);
    // Hyper-focus deliberately does not fetch metadata. It may therefore
    // process only an already-resolved state; explicit manual ids are allowed
    // to continue refreshing outside the automated target allowlist, while
    // Excapper/unknown rows remain inert.
    if (!state?.lastMeta) continue;
    const targetLeague = matchTargetLeague(state.lastMeta.leagueName);
    if (!targetLeague && !isManualWatchlistId(id)) continue;
    const current: OUSnapshot = {
      ts: now,
      overDecimal: ou.overDecimal,
      underDecimal: ou.underDecimal,
      line: ou.line,
    };
    const prev = state.history[state.history.length - 1];
    if (
      prev &&
      (prev.line !== ou.line ||
        prev.overDecimal !== ou.overDecimal ||
        prev.underDecimal !== ou.underDecimal)
    ) {
      state.lastOddsChangeAt = now;
    } else if (!prev) {
      state.lastOddsChangeAt = now;
    }
    // Keep lastMeta.updatedAt fresh so the dashboard "Last Seen" reflects
    // the hyper-focus tick — without this, the existing meta would look
    // stuck because we're not running the meta fetch.
    if (state.lastMeta) {
      state.lastMeta.updatedAt = now;
    }
    // Mirror the normal-path benchmark commit (scanner.ts ~2733-2742) so
    // the Crown/benchmark column in the watchlist payload stays live in
    // pause mode. Committed BEFORE the alert evaluation below so the gate's
    // evalBenchmark() reads this tick's Crown sample (matches normal-path
    // ordering where benchmark history is appended before the alert gates).
    const bench = benchMap.get(id);
    if (bench) {
      state.benchmarkHistory.push({
        ts: now,
        overDecimal: bench.overDecimal,
        underDecimal: bench.underDecimal,
        line: bench.line,
      });
      state.benchmarkHistory = pruneHistory(state.benchmarkHistory, now);
    }

    // Mirror the normal-path bookHistory commit (scanner.ts ~2745–2761) so
    // the watchlist payload assembly reads fresh per-book samples for
    // Sbobet/M88/12Bet/18Bet/VSBet while the scanner is paused. Without
    // this, only the Bet365 (primary) column moves on the dashboard.
    for (const book of EXTRA_BOOK_KEYS) {
      const bookMap = extraBookMaps.get(book);
      if (!bookMap) continue;
      const sample = bookMap.get(id);
      if (!sample) continue;
      if (!state.bookHistory) state.bookHistory = new Map();
      const hist = state.bookHistory.get(book) ?? [];
      hist.push({
        ts: now,
        overDecimal: sample.overDecimal,
        underDecimal: sample.underDecimal,
        line: sample.line,
      });
      state.bookHistory.set(book, pruneHistory(hist, now));
    }

    // ----- WATCHLIST ALERT EVALUATION (decoupled from the global scanner) -----
    // Even with the global scanner paused, the user's PRIORITY watchlist must
    // keep firing odds-drop / benchmark Pro Alerts — that is the whole point of
    // the "Manual Override" model: global is opt-in, the watchlist is always
    // armed. We run the EXACT same gate function the normal pipeline uses
    // (evaluateOddsDropAlert), so thresholds/spread/confidence/benchmark logic
    // stay identical with zero drift.
    //
    // meta comes from lastMeta because hyper-focus deliberately does NOT fetch
    // the bulk meta endpoint — so team names / score / live status are as fresh
    // as the last normal tick before pause, while the drop math itself is fully
    // real-time off this tick's primary OU. If lastMeta is missing (match pinned
    // while paused and never meta-resolved), we skip alerting this tick; OU
    // tracking still proceeds and alerting resumes automatically once meta is
    // known. Smart-money / volume alerts are unaffected — they fire on their own
    // independent Excapper loop regardless of this flag.
    //
    // Called BEFORE the OU history push below so the gate's pressure window
    // ([...state.history, current]) sees `prev` as the last committed snapshot
    // and `current` as the not-yet-pushed new one — identical to normal-path.
    if (state.lastMeta && targetLeague) {
      const lm = state.lastMeta;
      evaluateOddsDropAlert({
        matchId: id,
        state,
        prev,
        ou,
        meta: {
          team1: lm.team1,
          team2: lm.team2,
          leagueId: lm.leagueId,
          isLive: lm.isLive,
          homeScore: lm.homeScore,
          awayScore: lm.awayScore,
          kickoffMs: lm.kickoffMs,
        },
        leagueName: lm.leagueName,
        isLowLiq: isLowLiquidityLeague(lm.leagueId, lm.leagueName),
        now,
      });
    }

    // Commit the OU snapshot AFTER alert evaluation (the gate reads the pressure
    // window as [...state.history, current], so `current` must not yet be in
    // history). Mirrors the normal-path trailing push.
    state.history.push(current);
    state.history = pruneHistory(state.history, now);
    // Stamp lastPrimaryTickAt so the alt-stream merge (mergeAltOddsSnapshot)
    // treats this pinned match as freshly served by the primary feed and
    // won't overwrite it with potentially older alt-stream data while
    // paused. Mirrors normal-path commit at scanner.ts ~2679.
    state.lastPrimaryTickAt = now;
    updated++;
  }

  logger.debug(
    { pinned: pinnedIds.size, updated, seeded, primarySize: primaryMap.size, intervalMs: WATCHLIST_HYPER_POLL_INTERVAL_MS },
    "[HYPER-FOCUS] Tick complete",
  );
  return true;
}

// ----- Public API -----
let scannerRunning = false;
let externallyScheduled = false;

/**
 * Shared teardown used by BOTH the manual UI force-restart and the auto-
 * watchdog. Cancels the hung tick's in-flight network work, invalidates it via
 * the generation counter so it can never re-arm, clears the stale timer, and
 * fires a fresh tick immediately on the new generation.
 *
 * Returns the diagnostic captured at the moment of restart so the caller can
 * surface "what was blocking" to the UI / Telegram.
 */
function abortAndRestartLoop(reason: string): {
  culprit: string;
  stalledMs: number | null;
  wasInFlight: boolean;
} {
  const now = Date.now();
  const wasInFlight = __tickInFlight;
  const culprit =
    __tickPhase?.label ??
    (wasInFlight ? "unknown (in-flight, no phase label yet)" : "idle (no tick in flight)");
  const stalledMs = wasInFlight && __lastTickAt > 0 ? now - __lastTickAt : null;

  // Guard: refuse to restart while startScanner() is still wiring up the
  // runtime (post-gate init not yet complete). startScanner() is already
  // bringing the loop up fresh and will run its own pre-flight gate; bumping
  // the generation here would preempt it (skipping leagues/watchlist/altStream/
  // watchdog init) while resumeAfterPreflight() schedules ticks against a
  // half-built runtime. There is no tick to abort during startup anyway.
  if (!__runtimeInitialized) {
    logger.warn(
      { reason, culprit },
      "[FREEZE-RECOVERY] restart ignored — startup init still in progress",
    );
    return { culprit, stalledMs, wasInFlight };
  }

  // 1. Cancel in-flight core fetches for the hung tick (best-effort — abort
  //    only reaches fetchRaw calls that received the per-tick signal).
  if (__currentTickAbort && !__currentTickAbort.signal.aborted) {
    __currentTickAbort.abort();
  }
  // 2. Invalidate the hung tick: when it (eventually) unblocks and calls
  //    scheduleNextTick(staleGen) it will see the mismatch and decline to
  //    re-arm, and — because the gen no longer matches — it won't clobber the
  //    fresh tick's in-flight/phase state either.
  scannerGeneration++;
  // 3. Drop any pending scheduled tick + reset freeze-recovery state.
  if (scannerTimer !== null) {
    clearTimeout(scannerTimer);
    scannerTimer = null;
  }
  __tickInFlight = false;
  __tickPhase = null;
  __currentTickAbort = null;
  // 4. Resume on the new generation (only if running) AFTER re-running the
  //    pre-flight validation gate. We do NOT fire tick directly: the user asked
  //    for a fresh upstream handshake on every restart, so a watchdog/manual
  //    restart that was triggered by a dead mirror won't immediately re-enter a
  //    hanging fetch — it re-validates (and fails over) first.
  if (scannerRunning) {
    const gen = scannerGeneration;
    __preflightInProgress = true;
    __nextTickExpectedAt = 0; // disable the idle-watchdog branch during the gate
    if (externallyScheduled) {
      __preflightInProgress = false;
      void import("./scanCoordinator").then((m) => m.requestCoordinatedScan());
      return { culprit, stalledMs, wasInFlight };
    }
    scannerTimer = setTimeout(() => {
      scannerTimer = null;
      if (!scannerRunning || gen !== scannerGeneration) return;
      void resumeAfterPreflight(gen, `restart:${reason}`);
    }, 0);
  }
  logger.warn(
    { reason, culprit, stalledMs, wasInFlight, generation: scannerGeneration },
    "[FREEZE-RECOVERY] loop force-restarted",
  );
  return { culprit, stalledMs, wasInFlight };
}

/**
 * Manual Force-Restart / Debug entrypoint (POST /api/scanner/force-restart).
 * Aborts hanging requests, resets loop state, forces an immediate fresh fetch,
 * and returns a diagnostic naming the phase that was blocking the loop.
 */
export function forceRestartScanner(): {
  ok: boolean;
  culprit: string;
  stalledMs: number | null;
  wasInFlight: boolean;
  running: boolean;
} {
  const r = abortAndRestartLoop("manual_force_restart");
  return { ok: true, ...r, running: scannerRunning };
}

/**
 * Read-only snapshot of the tick loop's liveness for the UI diagnostic panel
 * (GET /api/scanner/loop-diagnostic). Never mutates state.
 */
let lastDeliveredScannerAlertAt: number | null = null;
export function getScannerTelegramDiagnostics() {
  return {
    expectedActive: scannerRunning && !isGlobalScannerPaused,
    lastCompletedAt: __lastTickCompletedAt || null,
    matchesTracked: matchStates.size,
    liveNow: [...matchStates.values()].filter((state) => state.lastMeta?.isLive).length,
    lastAlertAt: lastDeliveredScannerAlertAt,
  };
}

export function getScannerLoopDiagnostic() {
  const now = Date.now();
  return {
    running: scannerRunning,
    paused: isGlobalScannerPaused,
    generation: scannerGeneration,
    inFlight: __tickInFlight,
    phase: __tickPhase?.label ?? null,
    phaseElapsedMs: __tickPhase ? now - __tickPhase.startedAt : null,
    tickElapsedMs: __tickInFlight && __lastTickAt > 0 ? now - __lastTickAt : null,
    lastTickStartedAt: __lastTickAt > 0 ? new Date(__lastTickAt).toISOString() : null,
    lastTickCompletedAt:
      __lastTickCompletedAt > 0 ? new Date(__lastTickCompletedAt).toISOString() : null,
    msSinceLastComplete: __lastTickCompletedAt > 0 ? now - __lastTickCompletedAt : null,
    nextTickExpectedInMs: __nextTickExpectedAt > 0 ? __nextTickExpectedAt - now : null,
    slowCycleThresholdMs: SCANNER_SLOW_CYCLE_THRESHOLD_MS,
    stallThresholdMs: SCANNER_STALL_THRESHOLD_MS,
    preflight: getPreflightState(),
    autoWatchdog: {
      triggers: scannerStats.autoWatchdog.triggers,
      lastTriggeredAt: scannerStats.autoWatchdog.lastTriggeredAt,
      lastCulprit: scannerStats.autoWatchdog.lastCulprit,
      lastStalledMs: scannerStats.autoWatchdog.lastStalledMs,
    },
  };
}

/**
 * Auto-watchdog poll. Runs on its OWN setInterval (off the tick chain) so it
 * keeps firing while a tick is hung. Detects two failure modes:
 *   1. A tick that has been in-flight longer than SCANNER_STALL_THRESHOLD_MS.
 *   2. A timer chain that died WITHOUT re-arming (no tick in flight, yet the
 *      next tick is overdue by more than the threshold).
 * On either, it force-restarts the loop and fires the Telegram alert.
 */
function checkScannerStall(): void {
  if (!scannerRunning) return;
  // Stand down while the pre-flight gate is validating upstream — there is no
  // tick to be "stalled" yet and the gate owns its own retry cadence.
  if (__preflightInProgress) return;
  // Under unified ownership an idle primary scanner means the coordinator is
  // legitimately running another sequential adapter or waiting for its 12s
  // completion-anchored timer. Only an actually in-flight primary tick can be
  // diagnosed here; coordinator liveness is exposed separately.
  if (externallyScheduled && !__tickInFlight) {
    __nextTickExpectedAt = 0;
    return;
  }
  const now = Date.now();

  // Compute how long the loop has been "busy" right now, and in which mode:
  //  - "in-flight tick": a tick is executing and hasn't settled.
  //  - "dead timer chain": no tick in flight, but the next one is overdue
  //    (the setTimeout chain died without re-arming).
  // `phaseLabel`/`phaseElapsedMs` name the EXACT phase the loop is wedged on.
  let busyMs = 0;
  let mode: "in-flight tick" | "dead timer chain" | null = null;
  if (__tickInFlight && __lastTickAt > 0) {
    busyMs = now - __lastTickAt;
    mode = "in-flight tick";
  } else if (!__tickInFlight && __nextTickExpectedAt > 0 && now > __nextTickExpectedAt) {
    busyMs = now - __nextTickExpectedAt;
    mode = "dead timer chain";
  }
  const phaseLabel =
    __tickPhase?.label ??
    (mode === "in-flight tick" ? "unknown (in-flight, no phase label yet)" : "loop timer not firing");
  const phaseElapsedMs = __tickPhase ? now - __tickPhase.startedAt : null;

  // ---- SLOW-CYCLE TRACE (loud, NON-destructive) ----------------------------
  // Once the loop has been busy longer than the slow threshold but before the
  // 45s stall/restart kicks in, emit a very loud, detailed trace naming exactly
  // which phase it's stuck on. Re-emits every poll (~5s) while still slow so the
  // console shows, in real time, where the bottleneck is. NO restart here.
  if (
    mode &&
    busyMs > SCANNER_SLOW_CYCLE_THRESHOLD_MS &&
    busyMs <= SCANNER_STALL_THRESHOLD_MS
  ) {
    const willForceRestartInMs = Math.max(0, SCANNER_STALL_THRESHOLD_MS - busyMs);
    logger.warn(
      {
        mode,
        STUCK_ON_PHASE: phaseLabel,
        phaseStartedAt: __tickPhase ? new Date(__tickPhase.startedAt).toISOString() : null,
        phaseElapsedMs,
        busyMs,
        generation: scannerGeneration,
        slowThresholdMs: SCANNER_SLOW_CYCLE_THRESHOLD_MS,
        stallThresholdMs: SCANNER_STALL_THRESHOLD_MS,
        willForceRestartInMs,
      },
      `[SLOW-CYCLE] !!! SCANNER CYCLE SLOW (>${Math.round(SCANNER_SLOW_CYCLE_THRESHOLD_MS / 1000)}s) — STUCK ON PHASE: "${phaseLabel}" ` +
        `(phase ${phaseElapsedMs ?? busyMs}ms / ${mode} ${busyMs}ms) — auto-restart in ${willForceRestartInMs}ms`,
    );
  }

  let stalled = false;
  let stalledMs = 0;
  if (__tickInFlight && __lastTickAt > 0 && now - __lastTickAt > SCANNER_STALL_THRESHOLD_MS) {
    stalled = true;
    stalledMs = now - __lastTickAt;
  } else if (
    !__tickInFlight &&
    __nextTickExpectedAt > 0 &&
    now - __nextTickExpectedAt > SCANNER_STALL_THRESHOLD_MS
  ) {
    stalled = true;
    stalledMs = now - __nextTickExpectedAt;
  }
  if (!stalled) return;

  const culprit =
    __tickPhase?.label ?? (__tickInFlight ? "unknown (in-flight)" : "loop timer not firing");
  scannerStats.autoWatchdog.triggers++;
  scannerStats.autoWatchdog.lastTriggeredAt = new Date();
  scannerStats.autoWatchdog.lastCulprit = culprit;
  scannerStats.autoWatchdog.lastStalledMs = stalledMs;
  logger.error(
    {
      culprit,
      STUCK_ON_PHASE: culprit,
      mode: mode ?? (__tickInFlight ? "in-flight tick" : "dead timer chain"),
      phaseStartedAt: __tickPhase ? new Date(__tickPhase.startedAt).toISOString() : null,
      phaseElapsedMs,
      stalledMs,
      generation: scannerGeneration,
      thresholdMs: SCANNER_STALL_THRESHOLD_MS,
    },
    `[WATCHDOG] !!! SCANNER STALL (>${Math.round(SCANNER_STALL_THRESHOLD_MS / 1000)}s) — STUCK ON PHASE: "${culprit}" ` +
      `for ${phaseElapsedMs ?? stalledMs}ms — AUTO-RESTARTING LOOP`,
  );

  abortAndRestartLoop("auto_watchdog_stall");

  // Fire-and-forget Telegram alert. MarkdownV2 is forced by sendTelegram, so
  // we escape the whole message — Telegram consumes the escapes and renders
  // the EXACT literal text the spec requires. Never block/throw the interval.
  const alert = escapeMdV2(
    `⚠️ WATCHDOG TRIGGERED: Scanner stalled for >45s. Auto-restarting loop. Culprit/Blocked by: ${culprit}.`,
  );
  void sendTelegram(alert).catch((err) =>
    logger.warn({ err }, "[WATCHDOG] Telegram alert dispatch failed"),
  );
}

function startScannerWatchdog(): void {
  if (watchdogTimer !== null) return;
  watchdogTimer = setInterval(checkScannerStall, WATCHDOG_POLL_MS);
  watchdogTimer.unref?.();
  logger.info(
    { pollMs: WATCHDOG_POLL_MS, stallThresholdMs: SCANNER_STALL_THRESHOLD_MS },
    "[WATCHDOG] freeze-recovery watchdog started",
  );
}

function stopScannerWatchdog(): void {
  if (watchdogTimer !== null) {
    clearInterval(watchdogTimer);
    watchdogTimer = null;
  }
}

export async function startScanner(options: { externalScheduling?: boolean } = {}): Promise<void> {
  if (!isTelegramConfigured()) {
    // Telegram delivery is optional transport, never a scanner kill-switch.
    // Continue collecting/baselining so restoring credentials does not create
    // startup spam or disable unrelated live-data behavior.
    logger.warn("Telegram delivery unavailable — scanner remains active");
  }
  if (scannerRunning) {
    logger.warn("startScanner() called while already running — clearing previous timers first");
    await stopScanner();
  }
  // Bump generation BEFORE flipping running=true. Any in-flight tick from a
  // previous run that completes after this point will see a generation
  // mismatch and decline to re-arm. Capture the generation locally so we can
  // detect if another start/stop ran while THIS startScanner() was awaiting
  // its async preflight / Telegram self-check / etc., and refuse to schedule
  // the initial tick in that case.
  scannerGeneration++;
  const startGen = scannerGeneration;
  scannerRunning = true;
  externallyScheduled = options.externalScheduling === true;

  logger.info(
    {
      pollIntervalMs: POLL_INTERVAL_MS,
      threshold: config.dropThreshold,
      maxSpread: config.maxSpread,
      tightSpread: config.tightSpread,
      benchmarkConfirmDrop: config.benchmarkConfirmDrop,
      minConfidence: config.minConfidence,
      benchmark: BENCHMARK_NAME,
      globalScannerPaused: isGlobalScannerPaused,
      mode: isGlobalScannerPaused ? "hyper-focus (watchlist-only)" : "global",
    },
    "NowGoal26 Pro scanner started"
  );

  // ALWAYS-ON LOCK: global scan boots ACTIVE and cannot be paused at runtime.
  logger.warn(
    { globalScannerPaused: isGlobalScannerPaused },
    "[SCANNER] Boot: global scanner ACTIVE (always-on default; manual dashboard pause is the only pause path)",
  );

  // Pre-flight validation GATE: block the main loop until upstream routing is
  // verified live (main mirror hard-gate + vcbet reachability soft-gate),
  // retrying every 10s. This is the requested root-cause guard — the loop never
  // starts against a dead/hanging upstream. Returns false only if a newer
  // start/stop superseded us mid-gate, in which case we must not proceed.
  __preflightInProgress = true;
  const gatePassed = await runPreflightGate(startGen, "startup");
  __preflightInProgress = false;
  if (!gatePassed) {
    logger.warn(
      { startGen, currentGen: scannerGeneration, running: scannerRunning },
      "startScanner() preempted during pre-flight gate — not starting loop",
    );
    return;
  }

  // Silent boot connectivity check — uses Telegram's getMe + getChat (does NOT
  // post to chat). The watchdog runs the same probe every minute. We only escalate to
  // console if the probe fails; success is intentionally quiet so the chat
  // doesn't get spammed with "Telegram is OK" pings on every restart.
  {
    const { probeTelegramSilent } = await import("./telegram");
    const probe = await probeTelegramSilent();
    if (!probe.ok) {
      logger.error(
        { reason: probe.reason },
        "[STARTUP] CRITICAL: Telegram self-check FAILED — check configured Telegram credentials",
      );
    } else {
      logger.info("Startup: Telegram self-check OK (silent)");
    }
  }

  await refreshLeagueNames();

  // Load the manual Priority Watchlist (config/watchlist.json) and start
  // hot-reload watching. Failures are non-fatal — the scanner runs without
  // a watchlist if the file is missing.
  await initWatchlist();
  // Force one bounded, shared deep refresh for persisted manual numeric ids.
  // This preserves membership, resolves teams/score/cards immediately, and
  // coalesces with any simultaneous API-triggered refreshes.
  void requestManualWatchlistRefresh().catch((err) => {
    logger.warn({ err }, "[WATCHLIST-REFRESH] startup deep refresh failed");
  });

  // ----- BRANCH B: coordinated alt-mirror odds adapter -----
  // Runs sequentially under scanCoordinator. If the primary mirror freezes or
  // drops a regional fixture, this branch supplements the data. Never produces
  // Telegram alerts — pure data-merge supplement.
  {
    // Gated by the persisted manual control (loaded in index.ts BEFORE the
    // scanner starts) — no stop-after-start race.
    const { getControls } = await import("./controls");
    if (getControls().altStreamEnabled) {
      const { startAltStream } = await import("./altStream");
      startAltStream();
    } else {
      logger.warn("[ALT-STREAM] not started — disabled via manual control");
    }
  }

  // ----- LIVE-SCORE WATCHDOG (Sofascore cross-reference) -----
  // Watchlist-only. Force-overrides scores when the primary freezes while
  // odds continue moving (the symptom the user reported: stuck at 2-0 while
  // real score is 3-1, breaking the Over/Under math).
  {
    // Same manual-control gate as the alt-stream above.
    const { getControls } = await import("./controls");
    if (getControls().scoreWatchdogEnabled) {
      const { startScoreWatchdog } = await import("./sofascoreWatchdog");
      startScoreWatchdog();
    } else {
      logger.warn("[SCORE-WATCHDOG] not started — disabled via manual control");
    }
  }

  // ----- WATCHLIST LIVE-SCORE FAST-REFRESH (per-match cache-bypass) -----
  // Closes the score-lag window between NowGoal's throttled bulk feed
  // (~15s after a goal) and the per-match endpoint (~2s). See the
  // [WATCHLIST LIVE-SCORE FAST-REFRESH LOOP] docblock above for scope
  // guarantees and concurrency limits.
  // Single-run score refresh is invoked by scanCoordinator.

  // NOTE: A previously planned multi-book drift stream is not started here —
  // see the historical comment in this file (above getWatchlistLiveSnapshot)
  // for the egress-block reason and what was removed.

  // Start the slow pre-match loop. The live loop (tick()) does the heavy
  // odds + benchmark + meta fetches; pre-match only refreshes the league-
  // name cache and emits a per-period stats log so we can audit pool sizes.
  // Pre-match loop. refreshLeagueNames() self-schedules its own 30-min
  // timer, so we deliberately do NOT call it here — doing so would create
  // orphan timers and a runaway refresh chain. This loop is stats-only.
  const startPrematchLoop = () => {
    prematchTimer = setTimeout(async () => {
      try {
        logger.info(
          {
            live: scannerStats.liveMatchesTracked,
            minor: scannerStats.minorMatchesTracked,
            priorityWatchlist: scannerStats.pool.priorityWatchlistMatches,
            globalAnalyzed: scannerStats.pool.globalPoolAnalyzed,
            throttled: scannerStats.pool.globalPoolSkippedByThrottle,
            capped: scannerStats.pool.globalPoolSkippedByCap,
            lowLiqPrematchSkipped: scannerStats.pool.lowLiqPrematchSkipped,
          },
          "Pre-match tick: league cache refreshed + pool stats",
        );
      } catch (err) {
        logger.warn({ err }, "Pre-match tick failed");
      } finally {
        if (scannerRunning) startPrematchLoop();
      }
    }, PREMATCH_TICK_MS);
  };
  startPrematchLoop();

  // Start the background watchdog: alarms + auto-failover when live count
  // is stuck at 0 while pre-match data looks healthy.
  startWatchdog({
    fetchFn: fetchRawDetails,
    getStats: () => ({
      liveMatchesTracked: scannerStats.liveMatchesTracked,
      minorMatchesTracked: scannerStats.minorMatchesTracked,
      lastError: scannerStats.lastError,
    }),
  });

  // Freeze-recovery watchdog: independent of the live-count watchdog above.
  // Detects a tick that hangs >45s and auto-restarts the loop + Telegram alert.
  startScannerWatchdog();

  // Runtime fully wired — restarts are now safe to supersede this generation.
  __runtimeInitialized = true;

  const e = escapeMdV2;
  await sendTelegram(
    `🚀 *Pro Scanner запущен*\n\n` +
    `📡 Real\\-Time опрос: \\~12 сек \\(после завершения цикла, UA rotation\\)\n` +
    `🎯 Primary: *Macauslot* \\(goal8\\)\n` +
    `🔍 Benchmark: *${e(BENCHMARK_NAME)}* \\(goal3\\)\n` +
    `\n*Pro filters:*` +
    `\n• Падение ≥ *${e(config.dropThreshold.toFixed(2))}* пт за тик` +
    `\n• Spread ≤ *${e(config.maxSpread.toFixed(2))}* \\(tight ≤ *${e(config.tightSpread.toFixed(2))}*\\)` +
    `\n• Bench confirm drop ≥ *${e(config.benchmarkConfirmDrop.toFixed(2))}*` +
    `\n• Confidence ≥ *${config.minConfidence}/10* \\(5 \\= early bird, 10 \\= all aligned\\)` +
    `\n` +
    `\n🚫 Топ\\-лиги исключены \\| Справочник upstream: *${scannerStats.leaguesLoaded}* \\| Whitelist: *${getLeaguePolicy().total}*` +
    `\nРасписание: *${scannerStats.scheduleMatchesSeen}* \\| Live подтверждено: *${scannerStats.liveMatchesConfirmed}*`
  );

  // Guard the initial tick schedule the same way the recursive re-arm in
  // tick() does: if another start/stop bumped the generation while we were
  // awaiting preflight, validation, watchdog wiring, or the startup Telegram
  // message above, do NOT schedule a tick into the current generation —
  // that would create a duplicate loop alongside whoever bumped us.
  if (!scannerRunning || startGen !== scannerGeneration) {
    logger.warn(
      { startGen, currentGen: scannerGeneration, running: scannerRunning },
      "startScanner() preempted by a newer start/stop during async preflight — not scheduling initial tick",
    );
    return;
  }
  if (!externallyScheduled) scannerTimer = setTimeout(() => {
    scannerTimer = null;
    if (!scannerRunning || startGen !== scannerGeneration) return;
    void tick(startGen);
  }, 0);
}

export async function runScannerCycle(): Promise<void> {
  if (!scannerRunning || !externallyScheduled || __tickInFlight) return;
  directScoreIdsFetchedThisCycle.clear();
  await tick(scannerGeneration);
}

export async function stopScanner(): Promise<void> {
  // Bump generation FIRST so any in-flight tick that returns from its
  // upstream fetches after this point sees the mismatch at re-arm time and
  // exits without rescheduling.
  scannerGeneration++;
  scannerRunning = false;
  externallyScheduled = false;
  if (scannerTimer !== null) { clearTimeout(scannerTimer); scannerTimer = null; }
  if (leagueTimer !== null) { clearTimeout(leagueTimer); leagueTimer = null; }
  if (prematchTimer !== null) { clearTimeout(prematchTimer); prematchTimer = null; }
  stopWatchdog();
  stopScannerWatchdog();
  // Cancel any in-flight tick's core fetches and reset freeze-recovery state so
  // a stop→start cycle doesn't leave a zombie controller around.
  if (__currentTickAbort && !__currentTickAbort.signal.aborted) __currentTickAbort.abort();
  __currentTickAbort = null;
  __tickInFlight = false;
  __tickPhase = null;
  __nextTickExpectedAt = 0;
  // Clear the pre-flight gate flag so a stop during validation doesn't leave
  // the auto-watchdog permanently stood down on the next start.
  __preflightInProgress = false;
  // Mark the runtime as torn down so the next startScanner()'s init is
  // protected from restart preemption (and any stale restart during teardown
  // is correctly ignored).
  __runtimeInitialized = false;
  radarOneX2Candidates.clear();
  // AWAIT teardown of cross-stream modules. Previously these were
  // fire-and-forget dynamic imports — under a quick stop→start cycle
  // (e.g. workflow restart) the late-resolving stop() calls could race
  // against the next start() and kill freshly-armed timers. Await
  // guarantees deterministic lifecycle ordering.
  await Promise.allSettled([
    import("./watchlist").then((m) => m.stopWatchlist()),
    import("./altStream").then((m) => m.stopAltStream()),
    import("./sofascoreWatchdog").then((m) => m.stopScoreWatchdog()),
  ]);
  stopWatchlistScoreRefresh();
  logger.info({ generation: scannerGeneration }, "NowGoal26 Pro scanner stopped");
}

/**
 * Run a non-destructive self-analysis on demand.
 *
 * Audits four things in parallel:
 *   1. All host mirrors (sequential probeHost — same path tryFailover takes,
 *      so the report tells you exactly what failover would see right now).
 *   2. Current upstream endpoints + freshness (validateUpstream).
 *   3. Scanner tick liveness — are primaryMap / benchMap / metaMap actually
 *      being rebuilt every tick? We compare scannerStats.lastTickMapSizes
 *      against the configured poll interval; if no tick has updated those
 *      sizes in > 3× the poll interval (~30s), something is hanging.
 *   4. Watchdog liveness (lastLiveSeenAt + lastAlarmAt).
 *
 * Does NOT mutate scanner state and does NOT trigger failover. Emits one
 * structured log line ("self-analysis report") so you can find it instantly
 * in the workflow log, and returns the same payload as JSON for the UI.
 */
export async function runSelfAnalysis(): Promise<{
  ranAt: string;
  ok: boolean;
  summary: string;
  mirrors: { host: string; ok: boolean; reason?: string; matches?: number; isCurrent: boolean; elapsedMs: number }[];
  validation: Awaited<ReturnType<typeof validateUpstream>>;
  tickLiveness: {
    ok: boolean;
    lastCheckAt: string | null;
    secondsSinceLastTick: number | null;
    expectedMaxSec: number;
    mapSizes: { primary: number; bench: number; meta: number; capturedAt: string | null };
    reason?: string;
  };
  watchdog: ReturnType<typeof import("./healthcheck")["getWatchdogState"]>;
  scannerCounters: {
    checksTotal: number;
    consecutiveFailures: number;
    primaryFetchFailures: number;
    benchmarkFetchFailures: number;
    leaguesLoaded: number;
    liveMatchesTracked: number;
    minorMatchesTracked: number;
    lastError: string | null;
  };
}> {
  const { listCandidates, currentBaseUrl, probeHost } = await import("./upstream");
  const { getWatchdogState } = await import("./healthcheck");

  const startedAt = Date.now();

  // STEP 1 — Probe every mirror in the pool. Sequential by design (we never
  // fan out parallel probes; see upstream.ts header for why).
  const candidates = listCandidates();
  const current = currentBaseUrl();
  const mirrors: { host: string; ok: boolean; reason?: string; matches?: number; isCurrent: boolean; elapsedMs: number }[] = [];
  for (const host of candidates) {
    const t0 = Date.now();
    const probe = await probeHost(host, fetchRaw);
    mirrors.push({
      host,
      ok: probe.ok,
      ...(probe.reason !== undefined && { reason: probe.reason }),
      ...(probe.matches !== undefined && { matches: probe.matches }),
      isCurrent: host === current,
      elapsedMs: Date.now() - t0,
    });
  }

  // STEP 2 — Full endpoint + freshness validation against current base.
  const validation = await validateUpstream(fetchRawDetails);

  // STEP 3 — Tick liveness. Threshold must grow with consecutiveFailures
  // because tick() applies adaptive backoff: baseDelay = POLL_INTERVAL_MS *
  // (1 + consecutiveFailures), capped at 60s. Naively flagging > 30s
  // would false-positive during a failure streak. We allow 2× the current
  // expected backoff + one extra tick of slack.
  const currentBackoffMs = Math.min(
    POLL_INTERVAL_MS * (1 + scannerStats.consecutiveFailures),
    60_000,
  );
  const STALE_TICK_THRESHOLD_SEC = Math.max(
    (POLL_INTERVAL_MS / 1000) * 3,
    (currentBackoffMs / 1000) * 2 + POLL_INTERVAL_MS / 1000,
  );
  const captured = scannerStats.lastTickMapSizes.capturedAt;
  const secondsSinceLastTick = captured ? (Date.now() - captured.getTime()) / 1000 : null;
  let tickReason: string | undefined;
  let tickOk = true;
  if (captured === null) {
    tickOk = false;
    tickReason = "no_tick_recorded_yet";
  } else if (secondsSinceLastTick !== null && secondsSinceLastTick > STALE_TICK_THRESHOLD_SEC) {
    tickOk = false;
    tickReason = `tick_stale_${Math.round(secondsSinceLastTick)}s`;
  } else if (scannerStats.lastTickMapSizes.primary < 5) {
    tickOk = false;
    tickReason = "primary_map_suspiciously_empty";
  } else if (scannerStats.lastTickMapSizes.meta < 50) {
    tickOk = false;
    tickReason = "meta_map_suspiciously_empty";
  }

  const tickLiveness = {
    ok: tickOk,
    lastCheckAt: scannerStats.lastCheckAt ? scannerStats.lastCheckAt.toISOString() : null,
    secondsSinceLastTick: secondsSinceLastTick === null ? null : Math.round(secondsSinceLastTick),
    expectedMaxSec: STALE_TICK_THRESHOLD_SEC,
    mapSizes: {
      primary: scannerStats.lastTickMapSizes.primary,
      bench: scannerStats.lastTickMapSizes.bench,
      meta: scannerStats.lastTickMapSizes.meta,
      capturedAt: captured ? captured.toISOString() : null,
    },
    ...(tickReason !== undefined && { reason: tickReason }),
  };

  // STEP 4 — Aggregate counters.
  const watchdog = getWatchdogState();
  const scannerCounters = {
    checksTotal: scannerStats.checksTotal,
    consecutiveFailures: scannerStats.consecutiveFailures,
    primaryFetchFailures: scannerStats.primaryFetchFailures,
    benchmarkFetchFailures: scannerStats.benchmarkFetchFailures,
    leaguesLoaded: scannerStats.leaguesLoaded,
    liveMatchesTracked: scannerStats.liveMatchesTracked,
    minorMatchesTracked: scannerStats.minorMatchesTracked,
    lastError: scannerStats.lastError,
  };

  const healthyMirrors = mirrors.filter((m) => m.ok).length;
  const ok = validation.ok && tickOk && healthyMirrors >= 1;
  const summary =
    `mirrors ${healthyMirrors}/${mirrors.length} healthy · ` +
    `validator ${validation.ok ? "✓" : "✗"} · ` +
    `tick ${tickOk ? "✓" : `✗ (${tickReason})`} · ` +
    `consecFails ${scannerCounters.consecutiveFailures}`;

  const report = {
    ranAt: new Date(startedAt).toISOString(),
    ok,
    summary,
    mirrors,
    validation,
    tickLiveness,
    watchdog,
    scannerCounters,
  };

  // STRICT log verification: single structured line, easy to grep.
  logger.info({ selfAnalysis: report }, `Self-analysis report: ${summary}`);

  // Best-effort Telegram echo so the user gets the report on their phone too.
  // Don't await with the response; fire-and-forget.
  if (isTelegramConfigured()) {
    const e = escapeMdV2;
    const msg =
      `🔍 *Self\\-Analysis Report*` +
      `\n` +
      `\n*Status:* ${ok ? "✓ All systems nominal" : "✗ Issues detected"}` +
      `\n*Mirrors:* ${healthyMirrors}/${mirrors.length} healthy` +
      `\n*Validator:* ${e(validation.summary)}` +
      `\n*Last tick:* ${tickLiveness.secondsSinceLastTick ?? "?"}s ago · ` +
        `primary ${tickLiveness.mapSizes.primary} / bench ${tickLiveness.mapSizes.bench} / meta ${tickLiveness.mapSizes.meta}` +
      (tickReason ? `\n*Tick issue:* ${e(tickReason)}` : "") +
      `\n*Consecutive fetch failures:* ${scannerCounters.consecutiveFailures}` +
      `\n*Live tracked:* ${scannerCounters.liveMatchesTracked} · *Tracked:* ${scannerCounters.minorMatchesTracked}` +
      `\n*Upstream directory:* ${scannerStats.leaguesLoaded} · *Whitelist:* ${getLeaguePolicy().total}` +
      `\n*Schedule:* ${scannerStats.scheduleMatchesSeen} · *Live confirmed:* ${scannerStats.liveMatchesConfirmed}`;
    void sendTelegram(msg);
  }

  return report;
}

/** Manual-trigger validator + (optionally) failover. Used by /scanner/validate. */
export async function runManualValidation(opts: { failover?: boolean } = {}) {
  const result = await validateUpstream(fetchRawDetails);
  let failover: Awaited<ReturnType<typeof tryFailover>> | null = null;
  if (opts.failover) {
    failover = await tryFailover(fetchRawDetails, "manual_trigger", { bypassCooldown: true });
  }
  return { validation: result, failover };
}

export function getHealthSnapshot() {
  return {
    upstream: getFailoverState(),
    watchdog: getWatchdogState(),
    lastValidation: getLastValidation(),
    telegramPolling: getTelegramPollingMode(),
  };
}

// ----- Test-only seam -----
// Exposes the two internal loop bodies (`tick` = normal global pipeline,
// `runHyperFocusTick` = watchlist-only paused pipeline) plus a state reset so
// the "watchlist alerts stay armed when global scan is OFF" decoupling can be
// regression-tested WITHOUT booting the HTTP server or the timer-driven
// scheduler. Calling `tick()` directly is timer-safe because `scannerRunning`
// stays false here, so `scheduleNextTick()` never re-arms. NOT used by any
// production code path — see scanner.test.ts.
export const __testOnly = {
  evaluateOddsDropAlert,
  refreshLeagueNames,
  tick,
  runHyperFocusTick,
  evalBenchmark,
  runWatchlistScoreRefreshTick: () =>
    watchlistScoreRefreshTick(scoreRefreshGeneration),
  recordVolatilityAndCheckStale,
  recordManualExactQuote,
  volatilityPolicy: {
    staleWindowMs: VOLATILITY_STALE_WINDOW_MS,
    minSuccessfulSamples: VOLATILITY_MIN_SUCCESSFUL_SAMPLES,
  },
  /** Wipe all volatile module state so each test starts from a cold boot. */
  reset(): void {
    matchStates.clear();
    radarOneX2Candidates.clear();
    directScoreIdsFetchedThisCycle.clear();
    manualExactOddsHistory.clear();
    runtimeArchive.clear();
    rejectedLiveIds.clear();
    manualTextVolumes.clear();
    leagueNames.clear();
    lastDirectFetchAt.clear();
    liveDiscoveryCandidates.clear();
    liveDiscoveryFetchedAt = 0;
    liveDiscoveryError = null;
    recentLiveConfirmations.clear();
    liveVerificationCursors.manual = 0;
    liveVerificationCursors.discovery = 0;
    liveVerificationCursors.other = 0;
    scannerStats.liveVerificationEligible = 0;
    scannerStats.liveVerificationSelected = 0;
    scannerStats.scheduleMatchesSeen = 0;
    scannerStats.liveMatchesConfirmed = 0;
    directFetchStatus.clear();
    directFetchInFlight.clear();
    pendingManualRefreshIds.clear();
    activeManualRefreshIds.clear();
    manualRefreshInFlight = null;
    isGlobalScannerPaused = false; // mirror the locked-ACTIVE boot flag
    consecutiveFailures = 0;
    liveSeeded = false;
    staleFailoverInFlight = false;
    volatilityRing.length = 0;
    scannerStats.dataVolatility.lastSignature = null;
    scannerStats.dataVolatility.consecutiveIdenticalTicks = 0;
    scannerStats.dataVolatility.successfulUnchangedSamples = 0;
    scannerStats.dataVolatility.unchangedSince = null;
    scannerStats.dataVolatility.lastChangedAt = null;
    scannerStats.dataVolatility.lastStaleRotationAt = null;
    scannerStats.dataVolatility.isStale = false;
    resetUnifiedAlertStateForTests();
  },
    setLeagueNames(map: Map<string, string>): void {
      leagueNames.clear();
      for (const [leagueId, leagueName] of map) {
        leagueNames.set(leagueId, leagueName);
      }
    },
};
