import { afterEach, describe, expect, it, vi } from "vitest";
import { parseBookHistory, parseBookRoster, refreshRadarBooks,
  getCachedBookMovements } from "./radarBookMarkets";

const now = 1_800_000_000_000;
const row = (ts: number, over: string, under: string, total = "2.5") => ({
  mt: ts / 1000, type: 0, close: false,
  odds: { u: over, d: under, g: total },
});
afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

describe("dynamic NowGoal bookmaker source", () => {
  it("discovers names and arbitrary new company IDs from the actual per-match grid", () => {
    const html = `<tr cid="8"><td>Bet365</td><td><a onclick="_oddsDetailWin.open('123',8, 'Bet365', -1, 0)">Trends</a></td></tr>
      <tr cid="987"><td>New House</td><td><a onclick="_oddsDetailWin.open('123',987, 'New House', -1, 0)">Trends</a></td></tr>`;
    expect(parseBookRoster(html, JSON.stringify({ ErrCode: 0, Data: {
      roddsList: [{ cid: 8 }, { cid: 987 }] } }))).toEqual([
      { cid: "8", bookmaker: "Bet365" }, { cid: "987", bookmaker: "New House" },
    ]);
    expect(() => parseBookRoster(html, '{"code":1002}')).toThrow("envelope");
  });

  it("parses real source mt, OP decimal and OU HK into independent exact-line markets", () => {
    const result = parseBookHistory(JSON.stringify({ ErrCode: 0, Data: {
      op: [row(now - 1000, "2.2", "2.4"), row(now - 50_000, "2.5", "2.1"),
        row(now - 90_000, "1", "2", "2.5")],
      ou: [row(now - 1000, "0.75", "0.93"), row(now - 50_000, "0.99", "0.72")],
    } }), "987", "New House", now);
    expect(result.find((m) => m.side === "HOME")?.history.map((p) => p.odds)).toEqual([2.5, 2.2]);
    expect(result.find((m) => m.side === "AWAY")?.history.map((p) => p.odds)).toEqual([2, 2.1, 2.4]);
    expect(result.find((m) => m.side === "OVER")?.history.map((p) => p.odds)).toEqual([1.99, 1.75]);
    expect(result.map((m) => m.side)).not.toContain("DRAW");
    expect(parseBookHistory(JSON.stringify({ ErrCode: 0, Data: { op: [
      row(now - 1000, "2", "3", "2.5"), { ...row(now - 50_000, "2.5", "3"), type: 2 },
      row(now - 60_000, "4", "3"),
    ] } }), "987", "New House", now)
      .find((m) => m.side === "HOME")?.history).toHaveLength(1);
  });

  it("preserves the intermediate 2.5/3 handicap in HK history rather than comparing across it", () => {
    const markets = parseBookHistory(JSON.stringify({ ErrCode: 0, Data: {
      ou: [row(now - 5_000, "0.83", "0.91", "2.5"),
        row(now - 35_000, "0.98", "0.91", "2.5/3"),
        row(now - 65_000, "0.98", "0.91", "2.5")],
    } }), "72", "Lines", now);
    expect(markets.find((m) => m.side === "OVER")).toMatchObject({
      line: 2.5, current: { odds: 1.83 },
      history: [
        { line: 2.5, odds: 1.98 },
        { line: 2.75, odds: 1.98 },
        { line: 2.5, odds: 1.83 },
      ],
    });
  });

  it("refreshes an unseen CID and exposes timestamp-limited display movements, not post-bet odds", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(now);
    const cid = "987";
    const html = `<tr cid="${cid}"><td><a onclick="_oddsDetailWin.open('9988',${cid}, 'New House', -1, 0)">Trends</a></td></tr>`;
    const history = JSON.stringify({ ErrCode: 0, Data: {
      op: [], ou: [row(now - 1000, "0.67", "0.88"),
        row(now - 30_000, "0.85", "0.69"),
        row(now - 60_000, "0.95", "0.59")],
    } });
    const request = vi.fn(async (url: string) => new Response(
      url.includes("/oddscomp/") ? html
        : url.includes("t=11") ? JSON.stringify({ ErrCode: 0, Data: { roddsList: [{ cid: 987 }] } })
          : history, { status: 200 }));
    vi.stubGlobal("fetch", request);
    const loaded = await refreshRadarBooks(["9988"]);
    expect(loaded.get("9988")?.find((m) => m.side === "OVER")?.history).toHaveLength(3);
    expect(getCachedBookMovements("9988", "OVER", 2.5, now)).toMatchObject([
      { cid: "987", bookmaker: "New House", type: "drop", from: 1.95, to: 1.67 },
    ]);
    expect(getCachedBookMovements("9988", "OVER", 2.5, now - 40_000)).toEqual([]);
    expect(request).toHaveBeenCalledTimes(3);
  });

  it("uses two actual t=11 observations for a live-only bookmaker without fabricating upstream mt", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(now);
    let second = false;
    const cid = 71;
    const html = `<tr cid="${cid}"><a onclick="_oddsDetailWin.open('9971',${cid}, 'Live Only', -1, 0)">Trends</a></tr>`;
    vi.stubGlobal("fetch", vi.fn(async (url: string) => new Response(
      url.includes("/oddscomp/") ? html :
        url.includes("t=11") ? JSON.stringify({ ErrCode: 0, Data: { roddsList: [{
          cid, euro: { u: second ? "2.17" : "2.50", d: "3.2" },
          ou: { u: second ? "0.70" : "0.95", g: "2.5", d: "0.90" },
        }] } }) :
          JSON.stringify({ ErrCode: 0, Data: { op: [], ou: [] } }), { status: 200 })));
    expect((await refreshRadarBooks(["9971"])).get("9971")).toBeUndefined();
    vi.advanceTimersByTime(60_000);
    second = true;
    const current = (await refreshRadarBooks(["9971"])).get("9971")!;
    expect(current.find((m) => m.side === "HOME")).toMatchObject({
      timeSource: "observed", history: [
        { ts: now, odds: 2.50 },
        { ts: now + 60_000, odds: 2.17 },
      ],
    });
    expect(getCachedBookMovements("9971", "OVER", 2.5, now + 60_000))
      .toMatchObject([{ bookmaker: "Live Only", from: 1.95, to: 1.70, history: [] }]);
  });

  it("never bridges A→B→A line changes, including an as-of bet cutoff inside B", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(now);
    const html = `<tr cid="72"><a onclick="_oddsDetailWin.open('9972',72, 'Lines', -1, 0)">Trends</a></tr>`;
    const history = JSON.stringify({ ErrCode: 0, Data: { op: [],
      ou: [row(now - 5_000, "0.65", "0.88", "2.5"),
        row(now - 40_000, "0.80", "0.82", "2.5"),
        row(now - 90_000, "0.70", "0.90", "3.5"),
        row(now - 120_000, "1.20", "0.78", "2.5")],
    } });
    vi.stubGlobal("fetch", vi.fn(async (url: string) => new Response(
      url.includes("/oddscomp/") ? html :
        url.includes("t=11") ? JSON.stringify({ ErrCode: 0, Data: { roddsList: [{ cid: 72 }] } }) :
          history, { status: 200 })));
    await refreshRadarBooks(["9972"]);
    expect(getCachedBookMovements("9972", "OVER", 2.5, now))
      .toMatchObject([{ from: 1.8, to: 1.65 }]);
    expect(getCachedBookMovements("9972", "OVER", 2.5, now - 80_000)).toEqual([]);
  });

  it("queries beyond the first 48 dynamic IDs on later cycles instead of retrying the first batch forever", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(now);
    const companies = Array.from({ length: 49 }, (_, i) => i + 100);
    const html = companies.map((cid) =>
      `<tr cid="${cid}"><a onclick="_oddsDetailWin.open('9949',${cid}, 'Book${cid}', -1, 0)">Trends</a></tr>`).join("");
    const request = vi.fn(async (url: string) => new Response(
      url.includes("/oddscomp/") ? html :
        url.includes("t=11") ? JSON.stringify({ ErrCode: 0, Data: {
          roddsList: companies.map((cid) => ({ cid })) } }) :
          JSON.stringify({ ErrCode: 0, Data: { op: [
            row(now - 5_000, "2.2", "2.5"), row(now - 55_000, "2.5", "2.2"),
          ], ou: [] } }), { status: 200 }));
    vi.stubGlobal("fetch", request);
    await refreshRadarBooks(["9949"]);
    const firstBatch = request.mock.calls.filter(([url]) => url.includes("t=20"));
    expect(firstBatch).toHaveLength(48);
    const covered = new Set(firstBatch.map(([url]) => new URL(url).searchParams.get("cid")));
    await refreshRadarBooks(["9949"]);
    const later = request.mock.calls.filter(([url]) => url.includes("t=20")).slice(48);
    expect(later.some(([url]) => !covered.has(new URL(url).searchParams.get("cid")))).toBe(true);
  });

  it("evicts failed bookmaker histories instead of reusing stale successful upstream evidence", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(now);
    let fail = false;
    const html = `<tr cid="73"><a onclick="_oddsDetailWin.open('9973',73, 'Outage', -1, 0)">Trends</a></tr>`;
    const history = JSON.stringify({ ErrCode: 0, Data: { op: [], ou: [
      row(now - 5_000, "0.70", "0.90"), row(now - 55_000, "0.99", "0.70"),
    ] } });
    vi.stubGlobal("fetch", vi.fn(async (url: string) => new Response(
      url.includes("/oddscomp/") ? html :
        url.includes("t=11") ? JSON.stringify({ ErrCode: 0, Data: { roddsList: [
          { cid: 73, euro: { u: "2.5", d: "2.8" }, ou: { u: "0.70", g: "2.5", d: "0.90" } },
        ] } }) :
          fail ? '{"code":1002}' : history, { status: 200 })));
    await refreshRadarBooks(["9973"]);
    expect(getCachedBookMovements("9973", "OVER", 2.5, now)).toHaveLength(1);
    vi.advanceTimersByTime(60_000);
    fail = true;
    await refreshRadarBooks(["9973"]);
    // The t=11 market remains genuinely observed, but an unsuccessful t=20
    // refresh cannot keep advertising its old upstream history as fresh.
    expect(getCachedBookMovements("9973", "OVER", 2.5, now + 60_000)).toEqual([]);
  });
});