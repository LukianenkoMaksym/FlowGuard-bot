import { describe, expect, it } from "vitest";
import { selectLiveVerificationIds } from "./liveVerification";

describe("bounded live verification", () => {
  it("reaches fixtures beyond the first ten, with an empty watchlist", () => {
    const ids = Array.from({ length: 29 }, (_, index) => `match-${index}`);
    const discovery = new Set(ids.slice(0, 24));
    const cursors = { manual: 0, discovery: 0, other: 0 };
    const seen = new Set<string>();
    for (let tick = 0; tick < 15; tick++) {
      const selected = selectLiveVerificationIds(ids, new Set(), discovery, 10, cursors);
      expect(selected).toHaveLength(10);
      selected.forEach((id) => seen.add(id));
    }
    expect(seen).toEqual(new Set(ids));
  });

  it("does not allow many manual pins to starve newly discovered live fixtures", () => {
    const ids = Array.from({ length: 40 }, (_, index) => `id-${index}`);
    const manual = new Set(ids.slice(0, 20));
    const directory = new Set(ids.slice(20, 36));
    const cursors = { manual: 0, discovery: 0, other: 0 };
    const seen = new Set<string>();
    for (let tick = 0; tick < 12; tick++) {
      selectLiveVerificationIds(ids, manual, directory, 10, cursors)
        .forEach((id) => seen.add(id));
    }
    expect(seen).toEqual(new Set(ids));
  });

  it("admits a newly discovered candidate after the previous 120-second cache expires", () => {
    const ids = Array.from({ length: 30 }, (_, i) => `id-${i}`);
    const cursors = { manual: 0, discovery: 0, other: 0 };
    const first = new Set(ids.slice(0, 20));
    selectLiveVerificationIds(ids, new Set(), first, 10, cursors);
    const newDirectory = new Set(["new-live"]);
    const selected = selectLiveVerificationIds(
      [...ids, "new-live"], new Set(), newDirectory, 10, cursors,
    );
    expect(selected).toContain("new-live");
  });
});