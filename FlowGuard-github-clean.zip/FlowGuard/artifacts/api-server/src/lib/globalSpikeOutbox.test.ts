import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  rows: new Map<string, any>(),
  send: vi.fn(),
  muted: false,
  now: Date.now(),
}));
vi.mock("@workspace/db", () => {
  const query = async (sql: string, params: any[] = []) => {
    if (sql.includes("pg_try_advisory_lock")) return { rows: [{ locked: true }] };
    if (sql.includes("SELECT event_key, game_id")) {
      return { rows: [...mocks.rows.values()].filter((row) =>
        !row.completed && row.nextAttempt <= mocks.now).map((row) => structuredClone(row)) };
    }
    if (sql.includes("INSERT INTO global_spike_outbox")) {
      if (!mocks.rows.has(params[0])) mocks.rows.set(params[0], {
        event_key: params[0], game_id: params[1], transaction: JSON.parse(params[2]),
        recipient_state: null, attempts: 0, nextAttempt: 0, completed: false,
        created_at: new Date(mocks.now).toISOString(),
      });
    } else if (sql.includes("UPDATE global_spike_outbox SET message")) {
      mocks.rows.get(params[0]).recipient_state = JSON.parse(params[2]);
    } else if (sql.includes("SET recipient_state")) {
      mocks.rows.get(params[0]).recipient_state = JSON.parse(params[1]);
    } else if (sql.includes("SET completed_at = now() WHERE event_key")) {
      mocks.rows.get(params[0]).completed = true;
    } else if (sql.includes("SET attempts = attempts + 1")) {
      mocks.rows.get(params[0]).attempts++;
      mocks.rows.get(params[0]).nextAttempt = mocks.now + params[1] * 1000;
    }
    return { rows: [] };
  };
  return { pool: { query, connect: async () => ({ query, release: () => undefined }) } };
});
vi.mock("./controls", () => ({ getControls: () => ({ alertsMuted: mocks.muted }) }));
vi.mock("./telegram", () => ({
  snapshotTelegramRecipients: async () => ({ ok: true, recipients: [
    { id: "primary", primary: true }, { id: "subscriber", primary: false },
  ] }),
  sendTelegramOutboxRecipient: (recipient: { id: string }, message: string) => mocks.send(recipient.id, message),
}));
import { admitGlobalSpike, drainGlobalSpikeOutbox } from "./globalSpikeOutbox";

const tx = { line: 2.5, side: "Over" as const, summ: 1500, change: 500,
  rawChange: "500 €", date: "", matchMinute: "54" };

describe("durable global spike outbox", () => {
  beforeEach(() => {
    mocks.rows.clear();
    mocks.send.mockReset();
    mocks.muted = false;
    mocks.now = Date.now();
  });

  it("retries resolved failed results without re-sending acknowledged recipients", async () => {
    await admitGlobalSpike("101", tx);
    mocks.send.mockImplementationOnce(async () => "ok")
      .mockImplementationOnce(async () => "failed")
      .mockImplementation(async () => "ok");
    const build = vi.fn(async () => "fresh live card");
    await drainGlobalSpikeOutbox(build);
    expect(mocks.rows.get("101:2.5:Over:1500").recipient_state.map((r: any) => r.state))
      .toEqual(["acked", "pending"]);
    mocks.now += 31_000;
    await drainGlobalSpikeOutbox(build);
    expect(mocks.send.mock.calls.map(([id]) => id)).toEqual(["primary", "subscriber", "subscriber"]);
    expect(mocks.rows.get("101:2.5:Over:1500").completed).toBe(true);
  });

  it("retains failed context builds and cancels a subsequently closed line", async () => {
    await admitGlobalSpike("102", tx);
    const build = vi.fn().mockResolvedValueOnce(null).mockResolvedValueOnce("closed");
    await drainGlobalSpikeOutbox(build);
    expect(mocks.rows.get("102:2.5:Over:1500").completed).toBe(false);
    mocks.now += 31_000;
    await drainGlobalSpikeOutbox(build);
    expect(mocks.rows.get("102:2.5:Over:1500").completed).toBe(true);
    expect(mocks.send).not.toHaveBeenCalled();
  });

  it("persists the one captured fallback cutoff through delayed retries and recipient rechecks", async () => {
    await admitGlobalSpike("103", tx);
    const captured = mocks.rows.get("103:2.5:Over:1500").transaction.betTime;
    expect(Number.isFinite(captured)).toBe(true);
    mocks.send.mockResolvedValueOnce("failed").mockResolvedValue("ok");
    const observed: number[] = [];
    const build = async (_gameId: string, transaction: typeof tx & { betTime?: number }) => {
      observed.push(transaction.betTime!);
      return "fresh";
    };
    await drainGlobalSpikeOutbox(build);
    mocks.now += 31_000;
    await drainGlobalSpikeOutbox(build);
    expect(observed.length).toBeGreaterThan(2);
    expect(new Set(observed)).toEqual(new Set([captured]));
  });
});