import { describe, it, expect } from "vitest";
import { passesValueGuards } from "./winRate";

describe("passesValueGuards — odds floor", () => {
  it("rejects any anomaly whose active odds are below 1.15", () => {
    const r = passesValueGuards({
      decimalOdds: 1.1,
      targetSide: "OVER",
      line: 2.5,
      totalGoals: 2,
      isLive: true,
      minute: 30,
    });
    expect(r).toEqual({ ok: false, reason: "odds-floor" });
  });

  it("accepts odds exactly at the 1.15 floor", () => {
    const r = passesValueGuards({
      decimalOdds: 1.15,
      targetSide: "OVER",
      line: 2.5,
      totalGoals: 2,
      isLive: true,
      minute: 30,
    });
    expect(r.ok).toBe(true);
  });

  it("cannot apply the floor when the price is unknown (null)", () => {
    const r = passesValueGuards({
      decimalOdds: null,
      targetSide: "OVER",
      line: 2.5,
      totalGoals: 0,
      isLive: false,
      minute: null,
    });
    expect(r.ok).toBe(true);
  });
});

describe("passesValueGuards — dynamic score-to-line buffer (UNDER only)", () => {
  it("rejects a wide 'guaranteed clear' under (gap >= 2.5)", () => {
    const r = passesValueGuards({
      decimalOdds: 1.9,
      targetSide: "UNDER",
      line: 3.5,
      totalGoals: 1, // gap = 2.5
      isLive: true,
      minute: 20,
    });
    expect(r).toEqual({ ok: false, reason: "score-buffer-general" });
  });

  it("rejects a late-game under with a 1.5 cushion (minute > 75)", () => {
    const r = passesValueGuards({
      decimalOdds: 1.9,
      targetSide: "UNDER",
      line: 3.5,
      totalGoals: 2, // gap = 1.5
      isLive: true,
      minute: 80,
    });
    expect(r).toEqual({ ok: false, reason: "score-buffer-late" });
  });

  it("keeps the user's example: 1-0 at 80' on UNDER 3.5 is discarded", () => {
    const r = passesValueGuards({
      decimalOdds: 1.5,
      targetSide: "UNDER",
      line: 3.5,
      totalGoals: 1, // gap = 2.5 -> general rule
      isLive: true,
      minute: 80,
    });
    expect(r.ok).toBe(false);
  });

  it("accepts a late-game under with a 1.0 cushion (gap < 1.5)", () => {
    const r = passesValueGuards({
      decimalOdds: 1.9,
      targetSide: "UNDER",
      line: 3.5,
      totalGoals: 2.5, // not realistic for goals but proves the boundary
      isLive: true,
      minute: 80,
    });
    expect(r.ok).toBe(true);
  });

  it("does NOT apply the late-game rule when the minute is unknown", () => {
    const r = passesValueGuards({
      decimalOdds: 1.9,
      targetSide: "UNDER",
      line: 3.5,
      totalGoals: 2, // gap = 1.5, but no clock -> general rule (2.5) not met
      isLive: true,
      minute: null,
    });
    expect(r.ok).toBe(true);
  });

  it("never applies the score buffer to OVER bets", () => {
    const r = passesValueGuards({
      decimalOdds: 1.9,
      targetSide: "OVER",
      line: 3.5,
      totalGoals: 0, // huge gap, irrelevant for OVER
      isLive: true,
      minute: 80,
    });
    expect(r.ok).toBe(true);
  });
});

describe("passesValueGuards — settled live totals", () => {
  it.each(["OVER", "UNDER"] as const)(
    "rejects %s 0.5, 1.5 and the push line 2.0 at 2-0",
    (targetSide) => {
      for (const line of [0.5, 1.5, 2]) {
        expect(passesValueGuards({
          decimalOdds: 1.9,
          targetSide,
          line,
          totalGoals: 2,
          isLive: true,
          minute: 40,
        })).toEqual({ ok: false, reason: "total-already-settled" });
      }
    },
  );

  it.each(["OVER", "UNDER"] as const)("keeps %s 2.5 active at 2-0", (targetSide) => {
    expect(passesValueGuards({
      decimalOdds: 1.9,
      targetSide,
      line: 2.5,
      totalGoals: 2,
      isLive: true,
      minute: 40,
    }).ok).toBe(true);
  });

  it("fails closed when a live score is unavailable", () => {
    expect(passesValueGuards({
      decimalOdds: 1.9,
      targetSide: "OVER",
      line: 2.5,
      totalGoals: null,
      isLive: true,
      minute: 40,
    })).toEqual({ ok: false, reason: "live-score-unavailable" });
  });

  it("does not apply the settled-total rule to prematch evaluation", () => {
    expect(passesValueGuards({
      decimalOdds: 1.9,
      targetSide: "OVER",
      line: 0.5,
      totalGoals: null,
      isLive: false,
      minute: null,
    }).ok).toBe(true);
  });

  it("invalidates a pending line when a fresh goal settles it", () => {
    const candidate = {
      decimalOdds: 1.9,
      targetSide: "OVER" as const,
      line: 1.5,
      isLive: true,
      minute: 40,
    };
    expect(passesValueGuards({ ...candidate, totalGoals: 1 }).ok).toBe(true);
    expect(passesValueGuards({ ...candidate, totalGoals: 2 }))
      .toEqual({ ok: false, reason: "total-already-settled" });
  });
});
