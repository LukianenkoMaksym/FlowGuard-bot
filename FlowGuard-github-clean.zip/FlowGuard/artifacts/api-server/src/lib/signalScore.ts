/**
 * Signal-score: per-match Over/Under "success rate" from current snapshot.
 *
 * --- DESIGN CONSTRAINTS (from user spec) ---
 *
 *   1. PURE FUNCTION. No I/O, no side effects, no module-level mutable
 *      state. Called inline by the buildLive serializer on every API
 *      tick (~7s for watchlist matches).
 *   2. ZERO HISTORY ACCUMULATION. We never build arrays of past odds in
 *      RAM here. The caller passes us the CURRENT snapshot only (plus
 *      whatever single prior data points it already keeps for trend
 *      arrows). The "odds drop" angle, when needed, is computed by the
 *      caller as a 2-point diff (current − initial) — no buffers.
 *   3. HARD VOLUME FLOOR. If the matched OU line carries less than
 *      MIN_VOLUME_EUR of two-sided native-feed liquidity we return null.
 *      (no further math), and more importantly suppresses noise from
 *      ghost markets whose tiny totals would otherwise produce wild
 *      probability swings under the volume-weight blend.
 *
 * --- MATH ---
 *
 *   pRaw_Over  = 1 / decimalOver
 *   pRaw_Under = 1 / decimalUnder
 *   margin     = pRaw_Over + pRaw_Under     (always > 1 for a vigged book)
 *   pFair_Over  = pRaw_Over  / margin       (margin-free implied prob)
 *   pFair_Under = pRaw_Under / margin
 *
 *   wOver  = volOver  / (volOver + volUnder)
 *   wUnder = volUnder / (volOver + volUnder)
 *
 *   scoreOver  = α · pFair_Over  + (1 − α) · wOver
 *   scoreUnder = α · pFair_Under + (1 − α) · wUnder
 *
 * α = MARKET_WEIGHT lets us tune how much the "wisdom of the book" matters
 * vs raw money flow. 0.5 is a deliberately neutral default — half book,
 * half money. Override on a per-call basis if a strategy wants to lean
 * harder on either side.
 *
 * --- PATTERN TAGS ---
 *
 *   🔥 Smart Money     — winning side carries a fresh Excapper spike AND
 *                        the Bet365 price ALSO shortened (trend === "down").
 *                        Both signals agree → genuine sharp action.
 *
 *   🛡️ Hidden Resistance — winning side carries a fresh spike but the
 *                        Bet365 price MOVED THE OTHER WAY (trend === "up").
 *                        Money is hitting but the layer is absorbing —
 *                        classic resistance pattern.
 */

export const MIN_VOLUME_EUR = 2000;
export const MARKET_WEIGHT = 0.5;

export type SignalSide = "Over" | "Under";
export type SignalPattern = "🔥 Smart Money" | "🛡️ Hidden Resistance";

export interface SignalScoreInput {
  /** Current Bet365 decimal odds, Over side (>1). */
  overDecimal: number;
  /** Current Bet365 decimal odds, Under side (>1). */
  underDecimal: number;
  /** Cumulative native-feed EUR traded on Over for the matched OU line. */
  volumeOver: number;
  /** Cumulative native-feed EUR traded on Under for the matched OU line. */
  volumeUnder: number;
  /** Fresh single-bet spike flag from the per-tx alert path. */
  overSpike: boolean;
  underSpike: boolean;
  /** Bet365 price direction since the previous tick. */
  overTrend: "up" | "down" | "flat";
  underTrend: "up" | "down" | "flat";
  /** Optional override of the volume floor (per-strategy). */
  minVolumeEur?: number;
}

export interface SignalScore {
  /** 0–100, never NaN. The winning side's blended score expressed as a %. */
  successRate: number;
  /** Which side the score points at. */
  targetSide: SignalSide;
  /** Optional anomaly tag, or null when no clear pattern is present. */
  patternTag: SignalPattern | null;
  /** Fair (margin-free) implied prob of the winning side, 0–1. Exposed for UI tooltips. */
  fairProb: number;
  /** Volume share of the winning side, 0–1. Exposed for UI tooltips. */
  volumeShare: number;
  /** Total two-sided native-feed EUR volume on the matched line. */
  totalVolume: number;
}

/**
 * Compute the signal score for one match's currently-matched OU line.
 * Returns null when:
 *   - Either decimal odds value is invalid (≤ 1 or NaN),
 *   - OR total two-sided volume is below the floor,
 *   - OR margin math degenerates (defensive — should not happen with valid
 *     bookmaker odds, but guarded so we never emit NaN to the UI).
 */
export function computeSignal(input: SignalScoreInput): SignalScore | null {
  const {
    overDecimal,
    underDecimal,
    volumeOver,
    volumeUnder,
    overSpike,
    underSpike,
    overTrend,
    underTrend,
    minVolumeEur = MIN_VOLUME_EUR,
  } = input;

  if (
    !isFinite(overDecimal) ||
    !isFinite(underDecimal) ||
    overDecimal <= 1 ||
    underDecimal <= 1
  ) {
    return null;
  }

  // Defensive volume validation — both sides must be finite & non-negative,
  // and the floor itself must be a finite positive number. Without this an
  // upstream parser glitch (NaN volume) or a misconfigured per-call override
  // (minVolumeEur ≤ 0) would propagate Infinity/NaN into volumeShare and
  // ultimately into the UI. We'd rather show "—" than poison the cell.
  if (
    !isFinite(volumeOver) ||
    !isFinite(volumeUnder) ||
    volumeOver < 0 ||
    volumeUnder < 0 ||
    !isFinite(minVolumeEur) ||
    minVolumeEur <= 0
  ) {
    return null;
  }

  const totalVolume = volumeOver + volumeUnder;
  if (totalVolume <= 0 || totalVolume < minVolumeEur) return null;

  const pRawOver = 1 / overDecimal;
  const pRawUnder = 1 / underDecimal;
  const margin = pRawOver + pRawUnder;
  if (!isFinite(margin) || margin <= 0) return null;

  const pFairOver = pRawOver / margin;
  const pFairUnder = pRawUnder / margin;

  const wOver = volumeOver / totalVolume;
  const wUnder = volumeUnder / totalVolume;

  const scoreOver = MARKET_WEIGHT * pFairOver + (1 - MARKET_WEIGHT) * wOver;
  const scoreUnder = MARKET_WEIGHT * pFairUnder + (1 - MARKET_WEIGHT) * wUnder;

  const overWins = scoreOver >= scoreUnder;
  const targetSide: SignalSide = overWins ? "Over" : "Under";
  const winningScore = overWins ? scoreOver : scoreUnder;
  const winningFair = overWins ? pFairOver : pFairUnder;
  const winningShare = overWins ? wOver : wUnder;
  const winningSpike = overWins ? overSpike : underSpike;
  const winningTrend = overWins ? overTrend : underTrend;

  let patternTag: SignalPattern | null = null;
  if (winningSpike) {
    if (winningTrend === "down") patternTag = "🔥 Smart Money";
    else if (winningTrend === "up") patternTag = "🛡️ Hidden Resistance";
    // trend === "flat" → spike present but no price reaction yet; leave untagged.
  }

  return {
    successRate: Math.max(0, Math.min(100, +(winningScore * 100).toFixed(1))),
    targetSide,
    patternTag,
    fairProb: +winningFair.toFixed(4),
    volumeShare: +winningShare.toFixed(4),
    totalVolume: Math.round(totalVolume),
  };
}
