import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    include: ["src/**/*.test.ts"],
    setupFiles: ["./src/testDbIsolation.setup.ts"],
    // The runner inherits a live DATABASE_URL. Never let a test use that URL,
    // including during module evaluation before a test's beforeEach runs.
    env: {
      DATABASE_URL: "",
      PGHOST: "",
      PGPORT: "",
      PGDATABASE: "",
      PGUSER: "",
      PGPASSWORD: "",
    },
  },
});
