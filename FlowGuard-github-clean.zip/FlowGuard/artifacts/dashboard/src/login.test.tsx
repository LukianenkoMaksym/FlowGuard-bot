import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import App from "./App";

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

function mockLogin(login: () => Promise<Response>) {
  const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
    const url = String(input);
    if (url === "/api/auth/login") return login();
    const body = url === "/api/auth/me"
      ? { authenticated: false }
      : url === "/api/scanner/status"
        ? { config: {}, recentAnomalies: [] }
        : { ok: false };
    return new Response(JSON.stringify(body), { status: 200 });
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

async function submitPassword() {
  const input = await screen.findByPlaceholderText("Password");
  fireEvent.change(input, { target: { value: "test-password" } });
  fireEvent.click(screen.getByRole("button", { name: "Unlock" }));
}

describe("dashboard login errors", () => {
  it.each([
    [401, "Invalid password."],
    [429, "Too many attempts. Try again in 10 minutes."],
    [500, "Server temporarily unavailable. Please try again later."],
    [502, "Server temporarily unavailable. Please try again later."],
    [503, "Server temporarily unavailable. Please try again later."],
    [504, "Server temporarily unavailable. Please try again later."],
    [403, "Unable to sign in. Please try again later."],
    [404, "Unable to sign in. Please try again later."],
  ])("shows the correct message for HTTP %s without unlocking", async (status, message) => {
    // Proxy errors may be HTML, not API JSON.
    const fetchMock = mockLogin(async () => new Response("<html>Error</html>", { status }));
    render(<App />);
    await submitPassword();
    expect(await screen.findByText(message)).toBeTruthy();
    if (status !== 401) expect(screen.queryByText("Invalid password.")).toBeNull();
    expect((screen.getByRole("button", { name: "Unlock" }) as HTMLButtonElement).disabled).toBe(false);
    expect((screen.getByPlaceholderText("Password") as HTMLInputElement).value).toBe("test-password");
    expect(fetchMock.mock.calls.some(([url]) => String(url) === "/api/scanner/status")).toBe(false);
  });

  it("handles a network failure without displaying raw errors or blaming the password", async () => {
    mockLogin(async () => { throw new TypeError("Failed to fetch"); });
    render(<App />);
    await submitPassword();
    expect(await screen.findByText("Unable to connect to the server. Check your connection and try again.")).toBeTruthy();
    expect(screen.queryByText("Invalid password.")).toBeNull();
    expect(screen.queryByText("Failed to fetch")).toBeNull();
    expect((screen.getByRole("button", { name: "Unlock" }) as HTMLButtonElement).disabled).toBe(false);
  });

  it("clears the error on retry, stays busy while pending, and unlocks on success", async () => {
    let resolveRetry!: (response: Response) => void;
    const login = vi.fn<() => Promise<Response>>()
      .mockResolvedValueOnce(new Response(null, { status: 502 }))
      .mockImplementationOnce(() => new Promise((resolve) => { resolveRetry = resolve; }));
    const fetchMock = mockLogin(login);
    render(<App />);
    await submitPassword();
    await screen.findByText("Server temporarily unavailable. Please try again later.");
    fireEvent.click(screen.getByRole("button", { name: "Unlock" }));
    expect(screen.queryByText("Server temporarily unavailable. Please try again later.")).toBeNull();
    expect((screen.getByRole("button", { name: "Unlocking…" }) as HTMLButtonElement).disabled).toBe(true);
    resolveRetry(new Response(null, { status: 200 }));
    await waitFor(() => expect(screen.queryByPlaceholderText("Password")).toBeNull());
    expect(fetchMock.mock.calls.some(([url]) => String(url) === "/api/scanner/status")).toBe(true);
    expect(fetchMock).toHaveBeenCalledWith("/api/auth/login", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: "test-password" }),
    });
  });
});