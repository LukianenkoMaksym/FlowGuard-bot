import { Fragment, useEffect, useRef, useState, useCallback } from "react";
import { ExcapperBindingStatus, type ExcapperBindingDiagnostic } from "./components/ExcapperBindingStatus";
import { ExcapperFreshness } from "./components/ExcapperFreshness";
import { ExcapperBatchNotice, type ExcapperBatchStatus } from "./components/ExcapperBatchNotice";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./components/ui/tooltip";
import {
  useVolumeIncreases,
  type VolumeIncrease,
} from "./hooks/use-volume-increases";
import {
  RuntimeAuditSummary,
  type RuntimeAudit,
} from "./components/RuntimeAuditSummary";
import { LeaguePolicyEditor } from "./components/LeaguePolicyEditor";
import { DropThresholdAutoTuner } from "./components/DropThresholdAutoTuner";

const API_BASE = `${import.meta.env.BASE_URL.replace(/\/$/, "")}/api`;

function finiteNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

async function describeFailedResponse(response: Response): Promise<string> {
  let detail: string | undefined;
  try {
    const body = (await response.clone().json()) as {
      error?: unknown;
      message?: unknown;
    };
    if (typeof body.error === "string") detail = body.error;
    else if (typeof body.message === "string") detail = body.message;
  } catch {
    // A proxy/error page may not be JSON; the status below is still useful.
  }
  return detail
    ? `HTTP ${response.status}: ${detail}`
    : `HTTP ${response.status}${response.statusText ? ` ${response.statusText}` : ""}`;
}

// Single-source-of-truth renderer for one bookmaker's OVER or UNDER cell.
// Renders the current HK price plus a tiny signed delta vs. the previous
// tick (e.g. "0.77 (+0.03)"). Delta colour follows the operator rule:
// odds shortened (delta < 0) → RED; odds lengthened (delta > 0) → GREEN.
// The main price uses the existing trend-coloured class so the row still
// pulses on movement. `delta == null` means no comparable prev sample
// (first tick, or line just shifted) → we hide the delta string entirely
// rather than show a misleading zero.
function OddCell({
  value,
  trend,
  delta,
  title,
}: {
  value: number | null | undefined;
  trend: "up" | "down" | "flat" | undefined;
  delta: number | null | undefined;
  title?: string;
}) {
  const trendClass =
    trend === "down"
      ? "text-rose-400"
      : trend === "up"
        ? "text-emerald-400"
        : "text-zinc-300";
  // Hide tick noise: anything < 0.005 HK rounds to "0.00" anyway and is
  // not actionable, so suppress it to keep the column clean.
  const safeValue = finiteNumber(value);
  const safeDelta = finiteNumber(delta);
  const showDelta = safeDelta !== null && Math.abs(safeDelta) >= 0.005;
  const deltaClass = !showDelta
    ? ""
    : safeDelta! < 0
      ? "text-rose-400"
      : "text-emerald-400";
  const deltaStr = showDelta
    ? `(${safeDelta! > 0 ? "+" : ""}${safeDelta!.toFixed(2)})`
    : "";
  // STRICT single-line layout: delta sits inline to the LEFT of the price
  // so that one bookmaker = exactly one row-height. This keeps the OVER /
  // UNDER sub-rows in perfect horizontal alignment with their matching
  // bookmaker label in the NOWGOAL column. Do NOT switch this back to a
  // flex-col / block layout — it visually breaks the per-book row grid.
  return (
    <span
      className="inline-flex items-baseline justify-center gap-1 leading-5 whitespace-nowrap"
      title={title}
    >
      {showDelta && (
        <span className={`font-mono tabular-nums text-[10px] ${deltaClass}`}>{deltaStr}</span>
      )}
      <span className={`font-mono tabular-nums ${trendClass}`}>
        {safeValue !== null ? safeValue.toFixed(2) : <span className="text-zinc-600">—</span>}
      </span>
    </span>
  );
}

interface ScannerConfig {
  dropThreshold: number;
  maxSpread: number;
  sources?: Partial<Record<"dropThreshold" | "maxSpread" | "bypassSpreadOnBigDrop", "env" | "file" | "default">>;
  tightSpread: number;
  benchmarkConfirmDrop: number;
  minConfidence: number;
  requireDensity: boolean;
  requireLiquidityConfirmation?: boolean;
  lowLiqMaxSpread: number;
  bypassSpreadOnBigDrop: number;
  absurdSpreadCap: number;
  pollIntervalSec: number;
  watchlistFastPollSec?: number;
  watchlistHyperPollSec?: number;
  watchlistGlobalPollSec?: number;
  isGlobalScannerPaused?: boolean;
  pollJitterSec: number;
  alertCooldownSec: number;
  benchmarkWindowSec: number;
  priorityLeagueIds: string[];
}

interface EndpointCheck {
  url: string;
  ok: boolean;
  bytes?: number;
  recordsParsed?: number;
  reason?: string;
  elapsedMs: number;
}
interface HealthSnapshot {
  upstream: { currentBase: string; lastFailoverAt: string | null; failoverHistory: { from: string; to: string; reason: string; at: number }[] };
  watchdog: { lastLiveSeenAt: string; lastAlarmAt: string | null; staleLiveThresholdSec: number };
  telegramPolling: { shouldPoll: boolean; reason: string };
  lastValidation: {
    ok: boolean;
    ranAt: string;
    base: string;
    summary: string;
    endpoints: EndpointCheck[];
    freshness: { ok: boolean; matchesNearNow: number; oldestKickoffIso: string | null; newestKickoffIso: string | null; reason?: string };
  } | null;
}

interface SelfAnalysisReport {
  ranAt: string;
  ok: boolean;
  summary: string;
  mirrors: { host: string; ok: boolean; reason?: string; matches?: number; isCurrent: boolean; elapsedMs: number }[];
  validation: { ok: boolean; summary: string; base: string };
  tickLiveness: {
    ok: boolean;
    lastCheckAt: string | null;
    secondsSinceLastTick: number | null;
    expectedMaxSec: number;
    mapSizes: { primary: number; bench: number; meta: number; capturedAt: string | null };
    reason?: string;
  };
  watchdog: { lastLiveSeenAt: string; lastAlarmAt: string | null; staleLiveThresholdSec: number };
  scannerCounters: {
    checksTotal: number;
    consecutiveFailures: number;
    primaryFetchFailures: number;
    benchmarkFetchFailures: number;
    leaguesLoaded: number;
    scheduleMatchesSeen?: number;
    liveMatchesConfirmed?: number;
    whitelistSize?: number;
    liveMatchesTracked: number;
    minorMatchesTracked: number;
    lastError: string | null;
  };
}

export interface WatchlistLiveEntry {
  excapperBinding?: ExcapperBindingDiagnostic;
  label: string;
  fragments: string[];
  matchId: string | null;
  signature: string;
  origin?: "manual";
  status?: "ready" | "loading" | "error";
  statusMessage?: string;
  excapperVolumes?: Array<{
    line: number;
    over: number;
    under: number;
    totalVolume: number;
    overSharePct: number | null;
    underSharePct: number | null;
    overDelta: number | null;
    underDelta: number | null;
    overSpike: boolean;
    underSpike: boolean;
    updatedAgoSec: number;
  }>;
  live: {
    matchId: string;
    team1: string;
    team2: string;
    league: string;
    isLive: boolean;
    matchStatus?: "live" | "scheduled" | "finished" | "unknown";
    homeScore: number;
    awayScore: number;
    // Estimated live match minute (elapsed since kickoff, includes HT break,
    // capped at 120). null when not live or kickoff unknown.
    minute?: number | null;
    // Live match-state events (cards + penalties), decoded server-side from
    // the per-match incident feed. `home` aligns with team1, `away` with
    // team2. null until the incident feed has been read for this match.
    events?: {
      yc: { home: number; away: number };
      rc: { home: number; away: number };
      penalty: { present: boolean; minute: number | null };
    } | null;
    line: number | null;
    // Hong Kong odds — 1:1 mirror of NowGoal26's Bet365 column. Always
    // positive (e.g. 0.85, 0.97, 1.05). No sign manipulation, no Malay
    // rendering, no dual-format. Pure pass-through of the bookmaker line.
    overHk: number | null;
    underHk: number | null;
    prevLine: number | null;
    prevOverHk: number | null;
    prevUnderHk: number | null;
    // Signed tick-over-tick HK-odds delta. Positive = price rose (red);
    // negative = price fell (green). null until we have a previous tick to
    // compare against, or when the handicap line moved (cross-line deltas
    // are meaningless). Refreshed every active-watchlist poll (~12s).
    overDeltaHk: number | null;
    underDeltaHk: number | null;
    overTrend: "up" | "down" | "flat";
    underTrend: "up" | "down" | "flat";
    lineChanged: boolean;
    lastChangeAgoSec: number | null;
    lastSeenAgoSec: number;
    historyPoints: number;
    // ----- Excapper multi-line native-feed EUR volume -----
    // One entry per OU line with any liquidity (0.5, 1.5, 2.5, 3.5, ...).
    // Empty array until the first Excapper sample lands for this match
    // (every ~35s). Each entry carries the per-window DELTA (not the
    // running total — that's in the tooltip) plus a spike flag rendered
    // as a pulsing blue cell.
    volumes?: Array<{
      line: number;
      over: number;
      under: number;
      totalVolume: number;
      overSharePct: number | null;
      underSharePct: number | null;
      overDelta: number | null;
      underDelta: number | null;
      overSpike: boolean;
      underSpike: boolean;
      updatedAgoSec: number;
    }>;
    // Server-side signal score for the matched OU line. Null when total
    // two-sided volume on that line is below MIN_VOLUME_EUR (hard liquidity
    // floor) or when odds are degenerate. Lightweight pure-function output —
    // see lib/signalScore.ts on the server. The dashboard renders it as a
    // single "Signal" column with successRate %, target side, and an optional
    // pattern tag (🔥 Smart Money / 🛡️ Hidden Resistance).
    signal?: {
      successRate: number;
      targetSide: "Over" | "Under";
      patternTag: string | null;
      fairProb: number;
      volumeShare: number;
      totalVolume: number;
    } | null;
    // Cross-stream provenance. Null until the corresponding branch has
    // actually touched this row at least once.
    altOddsAgoSec?: number | null;
    scoreOverrideAgoSec?: number | null;
    scoreOverrideCount?: number;
    // ----- Dynamic win-rate (live probability engine) -----
    // Historical resolved OVER win-rate for the money-flow pattern currently
    // active on this match. The active odds-drop / money-spike anomaly selects
    // the pattern (type + phase), but the rate is always for the Over side, so
    // `targetSide` is always "OVER". null when no recent anomaly fired on the
    // match. `pct` is null until `sufficient` (the chosen bucket has enough
    // resolved cases) — the UI then shows a "building N/5" state instead.
    // `adjusted` is true when the specific minute-bucket rate was used.
    winRate?: {
      pct: number | null;
      wins: number;
      total: number;
      anomalyType: "ODDS_DROP" | "MONEY_SPIKE";
      targetSide: "OVER" | "UNDER";
      adjusted: boolean;
      sufficient: boolean;
    } | null;
    // Crown (benchmark book) — same NowGoal `goal3.xml` feed already
    // polled for Bet365. Each book tracks its OWN active line; the UI
    // renders `crownLine` as a yellow handicap label next to the Crown
    // row even when it differs from Bet365's line. null only when no
    // Crown sample has arrived for this match yet.
    crownLine?: number | null;
    crownOverDecimal?: number | null;
    crownUnderDecimal?: number | null;
    crownOverTrend?: "up" | "down" | "flat";
    crownUnderTrend?: "up" | "down" | "flat";
    crownOverDeltaHk?: number | null;
    crownUnderDeltaHk?: number | null;
    // Per-book Sbobet/M88/12Bet/18Bet/VSBet payloads. Each book carries its
    // OWN active handicap (often divergent from Bet365's). Backend ships
    // European decimal odds; we subtract 1 here to render in HK style
    // (consistent with the Bet365 and Crown rows). null = no sample yet
    // → row renders "—" and shows no yellow line badge.
    books?: Partial<
      Record<
        "Sbobet" | "M88" | "12Bet" | "18Bet" | "VSBet",
        {
          line: number;
          overDecimal: number;
          underDecimal: number;
          overTrend: "up" | "down" | "flat";
          underTrend: "up" | "down" | "flat";
          overDeltaHk: number | null;
          underDeltaHk: number | null;
        } | null
      >
    >;
  } | null;
}

export interface WatchlistResponse {
  ok: boolean;
  path: string;
  count: number;
  entries: WatchlistLiveEntry[];
  /**
   * Full configured pin list for management. This is intentionally separate
   * from live-only entries and must never feed the active table.
   */
  savedEntries?: WatchlistLiveEntry[];
  lastLoadedAt: string | null;
  lastError: string | null;
  excapperHealth: {
    state: "healthy" | "backoff" | "recovering";
    retryAt: number | null;
    lastErrorStatus: number | null;
    lastSuccessAt: number | null;
  };
  excapperBatch?: ExcapperBatchStatus;
  runtimeAudit?: RuntimeAudit;
  /** Number of persisted pins, including non-live entries. */
  configuredWatchlistTotal?: number;
  /** Number of retained non-live diagnostic rows, when supplied by the API. */
  archiveCount?: number;
}

/**
 * Defense in depth for the active table.  A server-supplied matchStatus is
 * authoritative; isLive is only used for older responses where that explicit
 * field is absent.  Deliberately do not infer live state from minute/score.
 */
export function isCurrentLiveWatchlistEntry(entry: WatchlistLiveEntry): boolean {
  if (!entry.live) return false;
  if (entry.live.matchStatus !== undefined) return entry.live.matchStatus === "live";
  return entry.live.isLive === true;
}

/** An empty live array is not a volume sample; keep a populated row-level sample visible. */
export function availableExcapperVolumes(entry: WatchlistLiveEntry): NonNullable<WatchlistLiveEntry["excapperVolumes"]> {
  if (entry.live?.volumes?.length) return entry.live.volumes;
  if (entry.excapperVolumes?.length) return entry.excapperVolumes;
  return [];
}

export function savedNonLiveWatchlistEntries(
  response: WatchlistResponse | null,
  activeRefreshFailed: boolean,
): WatchlistLiveEntry[] {
  if (!response) return [];
  // Presence (including an explicitly empty array) means the new backend
  // contract is available. Only older responses may fall back to entries.
  if (response.savedEntries !== undefined) {
    return response.savedEntries.filter((entry) => !isCurrentLiveWatchlistEntry(entry));
  }
  return activeRefreshFailed
    ? response.entries
    : response.entries.filter((entry) => !isCurrentLiveWatchlistEntry(entry));
}

interface ScannerStatus {
  ok: boolean;
  lastCheckAt: string | null;
  lastGlobalUpdateAt: string | null;
  checksTotal: number;
  anomaliesFound: number;
  benchmarkConfirmedAlerts: number;
  earlyBirdAlerts: number;
  alertsSuppressedBySpread: number;
  alertsSuppressedByConfidence: number;
  benchmarkCoverage: number;
  benchmarkName: string;
  primaryFetchFailures: number;
  benchmarkFetchFailures: number;
  consecutiveFailures: number;
  lastError: string | null;
  leaguesLoaded: number;
  /** All META schedule rows, before the live-state and league filters. */
  scheduleMatchesSeen?: number;
  /** Explicitly live META rows, before the tracked-match filters. */
  liveMatchesConfirmed?: number;
  /** Configured target league policy entries, not upstream directory rows. */
  whitelistSize?: number;
  liveMatchesTracked: number;
  minorMatchesTracked: number;
  majorMatchesSkipped: number;
  config: ScannerConfig;
}

const fetchOpts: RequestInit = { credentials: "include" };

/**
 * Compact, team-specific live card badges shown inline after a team name in
 * the watchlist fixture cell. Renders 🟨/🟥 with counts only when > 0, so a
 * clean match adds zero visual noise. Inline + small so it never wraps the
 * row or shifts the tight stacked-name layout.
 */
function TeamCardBadges({ yc, rc }: { yc: number; rc: number }): React.ReactElement | null {
  if (yc <= 0 && rc <= 0) return null;
  return (
    <span className="ml-1.5 inline-flex items-center gap-1 align-middle text-[10px] font-normal">
      {yc > 0 && (
        <span
          className="rounded-sm bg-yellow-400/15 px-1 text-yellow-300 ring-1 ring-yellow-400/40"
          title={`${yc} yellow card${yc > 1 ? "s" : ""}`}
        >
          🟨{yc}
        </span>
      )}
      {rc > 0 && (
        <span
          className="rounded-sm bg-rose-500/15 px-1 text-rose-300 ring-1 ring-rose-500/40"
          title={`${rc} red card${rc > 1 ? "s" : ""}`}
        >
          🟥{rc}
        </span>
      )}
    </span>
  );
}

/** Compact EUR formatter: 21788 → "€21.8k", 530 → "€530". Always positive. */
function formatEur(n: number): string {
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return `€${(abs / 1_000_000).toFixed(1)}M`;
  if (abs >= 1_000) return `€${(abs / 1_000).toFixed(1)}k`;
  return `€${abs}`;
}

/** Signed EUR delta: 1200 → "+€1.2k", -500 → "−€500", 0/null → "—". */
function formatEurDelta(n: number | null): string {
  if (n === null || n === 0) return "—";
  return `${n > 0 ? "+" : "−"}${formatEur(n)}`;
}

function volumeKey(
  matchKey: string,
  line: number,
  side: "over" | "under",
): string {
  return `${matchKey}|${line}|${side}`;
}

function compactAge(seconds: number): string {
  const safeSeconds = Math.max(0, Math.floor(seconds));
  if (safeSeconds < 60) return `${safeSeconds}s`;
  if (safeSeconds < 3_600) return `${Math.floor(safeSeconds / 60)}m`;
  return `${Math.floor(safeSeconds / 3_600)}h`;
}

function CumulativeVolume({
  amount,
  increase,
  side,
  spike,
  line,
}: {
  amount: number;
  increase: VolumeIncrease | undefined;
  side: "over" | "under";
  spike: boolean;
  line: number;
}) {
  const sideLabel = side === "over" ? "Over" : "Under";
  return (
    <span
      className={`watchlist-volume-value rounded font-mono text-xs tabular-nums ${
        spike
          ? "text-sky-200"
          : "text-zinc-300"
      }`}
      title={`${sideLabel} ${line.toFixed(1)} cumulative: ${formatEur(amount)}${
        increase ? ` · inbound ${formatEurDelta(increase.delta)}` : ""
      }`}
    >
      {increase && (
        <span
          key={increase.eventId}
          className={`watchlist-volume-delta volume-increase-badge ${
            side === "over" ? "watchlist-influx-over" : "watchlist-influx-under"
          }`}
        >
          ({formatEurDelta(increase.delta)})
        </span>
      )}
      <span className="watchlist-volume-total">{formatEur(amount)}</span>
    </span>
  );
}

function ExcapperFeedBadge({
  health,
}: {
  health: WatchlistResponse["excapperHealth"] | undefined;
}) {
  if (!health || health.state === "healthy") return null;

  const retryAt = finiteNumber(health.retryAt);
  const retryMs = retryAt === null ? null : Math.max(0, retryAt - Date.now());
  const retrySeconds = retryMs === null ? null : Math.ceil(retryMs / 1_000);
  const statusDetail =
    health.lastErrorStatus === 429
      ? "Excapper rate limited the feed (HTTP 429)."
      : health.lastErrorStatus === 503
        ? "Excapper's upstream feed is unavailable (HTTP 503)."
        : health.lastErrorStatus === 200
          ? "Excapper returned an invalid or challenge response."
          : "The Excapper upstream feed is temporarily unavailable.";
  const retryDetail =
    health.state === "recovering"
      ? "A recovery probe is in progress."
      : retryAt !== null
        ? `Automatic retry at ${new Date(retryAt).toLocaleTimeString()} (${retrySeconds ?? 0}s).`
        : "The existing watchlist poll will retry automatically.";
  const accessibleDescription = `${statusDetail} ${retryDetail} This is a feed-wide upstream issue, not a missing match binding.`;

  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] font-medium text-amber-200"
            aria-label={`Excapper Feed Reconnecting. ${accessibleDescription}`}
          >
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-400" aria-hidden="true" />
            <span>Excapper Feed Reconnecting</span>
            <span className="font-mono text-[10px] text-amber-300/80">
              {health.state === "recovering"
                ? "probing"
                : retrySeconds !== null
                  ? `${retrySeconds}s`
                  : "automatic"}
            </span>
          </button>
        </TooltipTrigger>
        <TooltipContent
          side="bottom"
          className="max-w-xs border border-amber-700/60 bg-zinc-950 text-amber-100 shadow-xl"
        >
          <p className="font-medium">{statusDetail}</p>
          <p className="mt-1 text-zinc-300">{retryDetail}</p>
          <p className="mt-1 text-zinc-500">Feed-wide upstream issue — not a missing match binding.</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function StatCard({
  label,
  value,
  accent,
  badge,
}: {
  label: string;
  value: string | number;
  accent?: string;
  badge?: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5">
      <div className="flex items-center justify-between gap-2">
        <div className="text-xs uppercase tracking-wider text-zinc-500">{label}</div>
        {badge}
      </div>
      <div className={`mt-2 text-3xl font-bold tabular-nums ${accent ?? "text-zinc-100"}`}>{value}</div>
    </div>
  );
}

function timeAgo(iso: string | null): string {
  if (!iso) return "—";
  const diffSec = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (diffSec < 60) return `${diffSec}s ago`;
  if (diffSec < 3600) return `${Math.round(diffSec / 60)}m ago`;
  return `${Math.round(diffSec / 3600)}h ago`;
}

function LoginScreen({ onSuccess }: { onSuccess: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (res.status === 429) {
        setError("Too many attempts. Try again in 10 minutes.");
        return;
      }
      if (res.status === 401) {
        setError("Invalid password.");
        return;
      }
      if (res.status >= 500) {
        setError("Server temporarily unavailable. Please try again later.");
        return;
      }
      if (!res.ok) {
        setError("Unable to sign in. Please try again later.");
        return;
      }
      onSuccess();
    } catch {
      setError("Unable to connect to the server. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 px-6 text-zinc-100">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl border border-zinc-800 bg-zinc-900/70 p-8 shadow-2xl">
        <div className="mb-6 text-center">
          <div className="text-5xl">🔒</div>
          <h1 className="mt-3 text-xl font-bold">Pro Scanner · Private Access</h1>
          <p className="mt-1 text-sm text-zinc-400">Enter your dashboard password to continue.</p>
        </div>
        <input
          type="password"
          autoFocus
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className="w-full rounded-lg border border-zinc-700 bg-zinc-950 px-4 py-3 text-zinc-100 outline-none focus:border-cyan-500"
        />
        {error && (
          <div className="mt-3 rounded-md border border-red-900/60 bg-red-950/40 px-3 py-2 text-sm text-red-300">
            {error}
          </div>
        )}
        <button
          type="submit"
          disabled={busy || !password}
          className="mt-5 w-full rounded-lg bg-cyan-600 px-5 py-2.5 font-medium text-white transition-colors hover:bg-cyan-500 disabled:opacity-60"
        >
          {busy ? "Unlocking…" : "Unlock"}
        </button>
        <p className="mt-5 text-center text-xs text-zinc-600">
          Telegram alerts continue 24/7 regardless of dashboard sign-in.
        </p>
      </form>
    </div>
  );
}

// Historical Over-Bet win-rate report (GET /api/winrate/stats). UNDER bets are
// excluded server-side, so `resolved.winRatePct` is the Over-strategy win-rate
// over every match where an OVER anomaly was actually placed and settled.
interface WinRateStats {
  side: "OVER";
  byStatus: { pending: number; win: number; loss: number; void: number };
  resolved: { wins: number; losses: number; total: number; winRatePct: number | null };
  byPattern: Array<{
    anomalyType: string;
    targetSide: string;
    wins: number;
    losses: number;
    total: number;
    winRatePct: number | null;
  }>;
}

// Signal history includes anomaly snapshots and delivered-alert ledger rows.
interface AnomalyHistoryRow {
  id: number | string;
  matchId: string;
  team1: string;
  team2: string;
  league: string;
  anomalyType: "ODDS_DROP" | "MONEY_SPIKE" | "SMART_MONEY" | "EXCAPPER" | "RADAR_DROP" | "RADAR_RISE" | "RADAR_LINE" | "RADAR_REVERT";
  source?: "RADAR" | "TELEGRAM" | "LEGACY";
  targetSide: "OVER" | "UNDER" | "HOME" | "AWAY" | "";
  line: number | null;
  minuteBucket: string | null;
  matchMinute: number | null;
  homeScoreAtFire: number | null;
  awayScoreAtFire: number | null;
  oddsAtFire: number | null;
  status: string;
  finalHomeScore: number | null;
  finalAwayScore: number | null;
  finalTotal: number | null;
  createdAt: string;
  resolvedAt: string | null;
}
interface AnomalyHistoryFilter {
  type: "" | AnomalyHistoryRow["anomalyType"];
  side: "" | "OVER" | "UNDER" | "HOME" | "AWAY";
  status: "" | "PENDING" | "WIN" | "LOSS" | "VOID";
  days: "" | "7" | "30" | "90" | "365";
}
const HISTORY_TYPE_LABELS: Record<AnomalyHistoryRow["anomalyType"], string> = {
  ODDS_DROP: "Odds Drop",
  MONEY_SPIKE: "Money Spike",
  SMART_MONEY: "Smart Money",
  EXCAPPER: "Smart Excapper",
  RADAR_DROP: "Radar Drop",
  RADAR_RISE: "Radar Rise",
  RADAR_LINE: "Radar Line (archived)",
  RADAR_REVERT: "Radar Revert",
};

export default function App() {
  const [authState, setAuthState] = useState<"checking" | "unauth" | "authed">("checking");
  const [status, setStatus] = useState<ScannerStatus | null>(null);
  const [health, setHealth] = useState<HealthSnapshot | null>(null);
  const [validating, setValidating] = useState(false);
  const [selfAnalyzing, setSelfAnalyzing] = useState(false);
  const [selfReport, setSelfReport] = useState<SelfAnalysisReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [draft, setDraft] = useState<Partial<ScannerConfig> | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [filterSaveError, setFilterSaveError] = useState<string | null>(null);
  const [manualApplyRevision, setManualApplyRevision] = useState(0);
  const [, setTick] = useState(0);
  const [watchlist, setWatchlist] = useState<WatchlistResponse | null>(null);
  const [watchlistLoading, setWatchlistLoading] = useState(true);
  const [watchlistError, setWatchlistError] = useState<string | null>(null);
  const [watchlistInput, setWatchlistInput] = useState("");
  const [watchlistAdding, setWatchlistAdding] = useState(false);
  const [watchlistRefreshing, setWatchlistRefreshing] = useState<string | null>(null);
  // Multiple manual cards may stay open independently. New and duplicate pins
  // are added here immediately so "Already monitored" never leaves the user
  // staring at a collapsed row while its bounded refresh runs.
  const [watchlistExpanded, setWatchlistExpanded] = useState<Set<string>>(
    () => new Set(),
  );
  const [watchlistMessage, setWatchlistMessage] = useState<
    { kind: "success" | "error" | "info"; text: string } | null
  >(null);
  // A failed refresh leaves the last successful payload in state for pin
  // management, but that stale payload must never be asserted as currently live.
  const liveWatchlistEntries = watchlistError
    ? []
    : watchlist?.entries.filter(isCurrentLiveWatchlistEntry) ?? [];
  const savedNonLiveEntries = savedNonLiveWatchlistEntries(
    watchlist,
    watchlistError !== null,
  );
  const volumeObservations =
    liveWatchlistEntries.flatMap((entry) => {
      const matchKey = entry.matchId ?? entry.signature;
      const volumes = availableExcapperVolumes(entry);
      return volumes.flatMap((volume) => [
        {
          key: volumeKey(matchKey, volume.line, "over"),
          amount: volume.over,
        },
        {
          key: volumeKey(matchKey, volume.line, "under"),
          amount: volume.under,
        },
      ]);
    });
  const volumeIncreases = useVolumeIncreases(volumeObservations);
  // ----- Freeze-recovery: manual force-restart / debug -----
  const [forceRestarting, setForceRestarting] = useState(false);
  const [restartDiag, setRestartDiag] = useState<{
    culprit: string;
    stalledMs: number | null;
    wasInFlight: boolean;
    at: number;
  } | null>(null);
  const [overStats, setOverStats] = useState<WinRateStats | null>(null);
  // Overlap guard for the 12s poll: true while a load() is in flight so a
  // slow/stalled tick can't stack concurrent request sets that accumulate
  // response buffers and sockets over a multi-hour session.
  const loadInFlight = useRef(false);
  // A user-triggered "refresh now" (bypassCache) that arrived while a poll was
  // already running. We never drop these — once the current load settles we
  // immediately run one more bypass-cache load so the UI reflects the action.
  const pendingForceRefresh = useRef(false);
  // ----- Signal History (GET /api/winrate/history) -----
  const [historyRows, setHistoryRows] = useState<AnomalyHistoryRow[] | null>(null);
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyOffset, setHistoryOffset] = useState(0);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);
  const [historyFilter, setHistoryFilter] = useState<AnomalyHistoryFilter>({
    type: "",
    side: "",
    status: "",
    days: "30",
  });
  const HISTORY_LIMIT = 50;

  const loadHistory = useCallback(async (filter: AnomalyHistoryFilter, offset: number) => {
    setHistoryLoading(true);
    setHistoryError(null);
    try {
      const params = new URLSearchParams();
      if (filter.type) params.set("type", filter.type);
      if (filter.side) params.set("side", filter.side);
      if (filter.status) params.set("status", filter.status);
      if (filter.days) params.set("days", filter.days);
      params.set("limit", String(HISTORY_LIMIT));
      params.set("offset", String(offset));
      const res = await fetch(`${API_BASE}/winrate/history?${params}`, fetchOpts);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = (await res.json()) as {
        ok: boolean;
        rows: AnomalyHistoryRow[];
        total: number;
        error?: string;
      };
      if (!json.ok) throw new Error(json.error ?? "Unknown error");
      setHistoryRows(json.rows);
      setHistoryTotal(json.total);
      setHistoryOffset(offset);
    } catch (e) {
      setHistoryError(e instanceof Error ? e.message : String(e));
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  // Manual controls (restored 2026-08-17): the scanner still BOOTS active and
  // nothing pauses it automatically, but the user can pause/resume manually.
  const [togglingScanner, setTogglingScanner] = useState(false);
  const toggleGlobalScanner = useCallback(async () => {
    setTogglingScanner(true);
    try {
      const res = await fetch(`${API_BASE}/scanner/toggle`, {
        ...fetchOpts,
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await load({ bypassCache: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setTogglingScanner(false);
    }
  }, []);

  // Subsystem controls: alerts mute, alt-stream, score watchdog.
  const [controls, setControls] = useState<{
    alertsMuted: boolean;
    altStreamEnabled: boolean;
    scoreWatchdogEnabled: boolean;
  } | null>(null);
  const [controlBusy, setControlBusy] = useState<string | null>(null);
  const loadControls = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/scanner/controls`, fetchOpts);
      if (!res.ok) return;
      const j = (await res.json()) as { ok: boolean; controls?: typeof controls };
      if (j.ok && j.controls) setControls(j.controls);
    } catch {
      /* non-fatal — panel simply stays hidden */
    }
  }, []);
  const setControlFlag = useCallback(
    async (key: "alertsMuted" | "altStreamEnabled" | "scoreWatchdogEnabled", enabled: boolean) => {
      setControlBusy(key);
      try {
        const res = await fetch(`${API_BASE}/scanner/controls`, {
          ...fetchOpts,
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key, enabled }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const j = (await res.json()) as { ok: boolean; controls?: typeof controls };
        if (j.ok && j.controls) setControls(j.controls);
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        setControlBusy(null);
      }
    },
    [],
  );
  useEffect(() => {
    void loadControls();
  }, [loadControls]);

  // Freeze-recovery: abort any hanging tick request, reset the loop, force a
  // fresh fetch, and surface the diagnostic naming whatever was blocking it.
  const forceRestartLoop = useCallback(async () => {
    setForceRestarting(true);
    try {
      const res = await fetch(`${API_BASE}/scanner/force-restart`, {
        ...fetchOpts,
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const j = (await res.json()) as {
        culprit: string;
        stalledMs: number | null;
        wasInFlight: boolean;
      };
      setRestartDiag({
        culprit: j.culprit,
        stalledMs: j.stalledMs,
        wasInFlight: j.wasInFlight,
        at: Date.now(),
      });
      await load({ bypassCache: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setForceRestarting(false);
    }
  }, []);

  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/auth/me`, fetchOpts);
      if (!res.ok) {
        setAuthState("unauth");
        return false;
      }
      const j = (await res.json()) as { authenticated: boolean };
      setAuthState(j.authenticated ? "authed" : "unauth");
      return j.authenticated;
    } catch {
      setAuthState("unauth");
      return false;
    }
  }, []);

  const load = useCallback(async (opts: { bypassCache?: boolean } = {}) => {
    // Skip this tick if the previous poll is still running. Without this, a
    // stalled upstream lets the 12s interval stack request sets indefinitely —
    // the memory/socket growth that kills the tab over a long session. A
    // user-triggered force-refresh is never dropped though: we remember it and
    // re-run it the moment the in-flight load settles.
    if (loadInFlight.current) {
      if (opts.bypassCache) pendingForceRefresh.current = true;
      return;
    }
    loadInFlight.current = true;
    setWatchlistLoading(true);
    const controller = new AbortController();
    // Hard ceiling so a hung request can never wedge the in-flight guard
    // permanently: abort the whole set after 20s and let the next tick retry.
    const abortTimer = window.setTimeout(() => controller.abort(), 20000);
    try {
      const reqInit: RequestInit = opts.bypassCache
        ? {
            ...fetchOpts,
            cache: "no-store",
            headers: { "Cache-Control": "no-cache" },
            signal: controller.signal,
          }
        : { ...fetchOpts, signal: controller.signal };
      const [
        statusRes,
        healthRes,
        watchlistRes,
        winStatsRes,
      ] =
        await Promise.all([
          fetch(`${API_BASE}/scanner/status`, reqInit),
          fetch(`${API_BASE}/scanner/health`, reqInit),
          fetch(`${API_BASE}/watchlist`, reqInit),
          fetch(`${API_BASE}/winrate/stats`, reqInit),
        ]);
      if (
        statusRes.status === 401 ||
        healthRes.status === 401 ||
        watchlistRes.status === 401
      ) {
        setAuthState("unauth");
        return;
      }
      if (!statusRes.ok) throw new Error(`HTTP ${statusRes.status}`);
      const data = (await statusRes.json()) as ScannerStatus;
      setStatus(data);
      setError(null);
      setDraft((d) => d ?? { ...data.config });
      if (healthRes.ok) {
        const h = (await healthRes.json()) as { ok: boolean } & HealthSnapshot;
        setHealth(h);
      }
      if (watchlistRes.ok) {
        const w = (await watchlistRes.json()) as WatchlistResponse;
        setWatchlist(w);
        setWatchlistError(null);
      } else {
        setWatchlistError(await describeFailedResponse(watchlistRes));
      }
      // Historical Over-Bet win-rate report. A non-fatal failure
      // failure just leaves the primary metric showing its last value.
      if (winStatsRes.status === 401) {
        setAuthState("unauth");
        return;
      }
      if (winStatsRes.ok) {
        const s = (await winStatsRes.json()) as { ok: boolean; stats: WinRateStats };
        if (s.ok) setOverStats(s.stats);
      }
    } catch (e) {
      if (controller.signal.aborted) {
        setError("Refresh timed out — retrying on the next tick.");
      } else {
        const message = e instanceof Error ? e.message : String(e);
        setError(message);
      }
    } finally {
      window.clearTimeout(abortTimer);
      loadInFlight.current = false;
      setWatchlistLoading(false);
      // A force-refresh queued during this load now gets its turn.
      if (pendingForceRefresh.current) {
        pendingForceRefresh.current = false;
        void load({ bypassCache: true });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const addToWatchlist = async () => {
    const input = watchlistInput.trim();
    if (!input) return;
    setWatchlistAdding(true);
    setWatchlistMessage(null);
    try {
      const res = await fetch(`${API_BASE}/watchlist`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input }),
      });
      const json = (await res.json()) as {
        ok: boolean;
        added?: boolean;
        reason?: string;
        entry?: { label: string; teams: string[]; matchId?: string };
        signature?: string;
        snapshot?: WatchlistResponse;
        error?: string;
      };
      if (!res.ok || !json.ok) {
        setWatchlistMessage({ kind: "error", text: json.error ?? `HTTP ${res.status}` });
        return;
      }
      if (json.snapshot) setWatchlist(json.snapshot);
      const addedSignature =
        json.signature ??
        json.snapshot?.entries.find(
          (entry) =>
            entry.matchId != null &&
            entry.matchId === json.entry?.matchId,
        )?.signature;
      if (addedSignature) {
        setWatchlistExpanded((current) => {
          const next = new Set(current);
          next.add(addedSignature);
          return next;
        });
      }
      if (json.added === false) {
        setWatchlistMessage({
          kind: "info",
          text: `Already monitored: ${json.entry?.label ?? input} · refresh started`,
        });
      } else {
        setWatchlistMessage({
          kind: "success",
          text: `Now monitoring: ${json.entry?.label ?? input}`,
        });
        setWatchlistInput("");
      }
      // Bypass cache so the next status tick reflects the new entry instantly.
      await load({ bypassCache: true });
    } catch (e) {
      setWatchlistMessage({ kind: "error", text: e instanceof Error ? e.message : String(e) });
    } finally {
      setWatchlistAdding(false);
    }
  };

  const refreshWatchlistEntry = async (signature: string, label: string) => {
    if (!signature || watchlistRefreshing) return;
    setWatchlistRefreshing(signature);
    setWatchlistMessage({ kind: "info", text: `Refreshing ${label}…` });
    try {
      const res = await fetch(`${API_BASE}/watchlist/${encodeURIComponent(signature)}/refresh`, {
        ...fetchOpts,
        method: "POST",
        cache: "no-store",
        headers: { "Cache-Control": "no-cache" },
      });
      const json = (await res.json()) as {
        ok: boolean;
        snapshot?: WatchlistResponse;
        error?: string;
      };
      if (!res.ok || !json.ok) {
        throw new Error(json.error ?? `HTTP ${res.status}`);
      }
      if (json.snapshot) setWatchlist(json.snapshot);
      setWatchlistMessage({ kind: "success", text: `Refresh requested: ${label}` });
      // The endpoint waits for the bounded direct enrichment, but this second
      // read also picks up any score/events state materialized by the scanner
      // tick that completed alongside it.
      await load({ bypassCache: true });
    } catch (e) {
      setWatchlistMessage({
        kind: "error",
        text: e instanceof Error ? e.message : String(e),
      });
    } finally {
      setWatchlistRefreshing(null);
    }
  };

  const removeFromWatchlist = async (sig: string) => {
    if (!sig) return;
    try {
      const res = await fetch(`${API_BASE}/watchlist/${encodeURIComponent(sig)}`, {
        method: "DELETE",
        credentials: "include",
      });
      const json = (await res.json()) as { ok: boolean; snapshot?: WatchlistResponse; error?: string };
      if (!res.ok || !json.ok) {
        setWatchlistMessage({ kind: "error", text: json.error ?? `HTTP ${res.status}` });
        return;
      }
      if (json.snapshot) setWatchlist(json.snapshot);
    } catch (e) {
      setWatchlistMessage({ kind: "error", text: e instanceof Error ? e.message : String(e) });
    }
  };

  const runValidation = async (failover: boolean) => {
    setValidating(true);
    try {
      const res = await fetch(`${API_BASE}/scanner/validate?failover=${failover ? 1 : 0}`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setValidating(false);
    }
  };

  const runSelfAnalysis = async () => {
    setSelfAnalyzing(true);
    setError(null);
    try {
      const res = await fetch(`${API_BASE}/scanner/self-analysis`, {
        method: "POST",
        credentials: "include",
        cache: "no-store",
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = (await res.json()) as { ok: boolean; report: SelfAnalysisReport };
      setSelfReport(json.report);
      // Force-refresh the dashboard's status + health views, bypassing any
      // browser/proxy cache. This clears any stale UI rendering without
      // touching the live scanner loop.
      await load({ bypassCache: true });
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSelfAnalyzing(false);
    }
  };

  useEffect(() => {
    void checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    if (authState !== "authed") return;
    void load();
    const i = setInterval(load, 12_000);
    return () => clearInterval(i);
  }, [authState, load]);

  useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(i);
  }, []);

  const save = async () => {
    if (!draft) return;
    setSaving(true);
    setSavedAt(null);
    setFilterSaveError(null);
    try {
      const res = await fetch(`${API_BASE}/scanner/config`, {
        method: "PATCH",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dropThreshold: Number(draft.dropThreshold),
          maxSpread: Number(draft.maxSpread),
          tightSpread: Number(draft.tightSpread),
          benchmarkConfirmDrop: Number(draft.benchmarkConfirmDrop),
          minConfidence: Number(draft.minConfidence),
          requireDensity: !!draft.requireDensity,
          requireLiquidityConfirmation: !!draft.requireLiquidityConfirmation,
          lowLiqMaxSpread: Number(draft.lowLiqMaxSpread),
          bypassSpreadOnBigDrop: Number(draft.bypassSpreadOnBigDrop),
          absurdSpreadCap: Number(draft.absurdSpreadCap),
        }),
      });
      const json = await res.json();
      if (!res.ok || json?.persisted !== true) {
        const msgs = Array.isArray(json?.errors) ? json.errors.join(", ") : `Filters were not saved (HTTP ${res.status})`;
        throw new Error(msgs);
      }
      // The PATCH response contains effective scanner values (which may still be
      // overridden by env), not necessarily the values just written to disk.
      if (!json.config || typeof json.config !== "object") {
        throw new Error("Filters were saved, but the server did not return effective config. Refresh to verify.");
      }
      setStatus((current) => current ? { ...current, config: json.config as ScannerConfig } : current);
      setDraft({ ...json.config as ScannerConfig });
      setSavedAt(Date.now());
      setManualApplyRevision((revision) => revision + 1);
      await load({ bypassCache: true });
    } catch (e) {
      setFilterSaveError(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(false);
    }
  };

  const logout = async () => {
    await fetch(`${API_BASE}/auth/logout`, { method: "POST", credentials: "include" });
    setAuthState("unauth");
    setStatus(null);
    setDraft(null);
  };

  if (authState === "checking") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950 text-zinc-500">
        Checking session…
      </div>
    );
  }

  if (authState === "unauth") {
    return <LoginScreen onSuccess={() => setAuthState("authed")} />;
  }

  const isHealthy =
    status &&
    !status.lastError &&
    status.lastCheckAt &&
    Date.now() - new Date(status.lastCheckAt).getTime() < 60_000;

  const setDraftField = <K extends keyof ScannerConfig>(k: K, v: ScannerConfig[K]) => {
    setDraft((d) => ({ ...(d ?? {}), [k]: v }));
    setSavedAt(null);
    setFilterSaveError(null);
  };

  const benchPct = status && status.minorMatchesTracked > 0
    ? Math.round((status.benchmarkCoverage / status.minorMatchesTracked) * 100)
    : null;

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-5xl px-6 py-10">
        <header className="mb-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">⚽ NowGoal26 Smart-Money · <span className="text-cyan-400">Pro</span></h1>
            <p className="mt-1 text-sm text-zinc-400">
              Cross-referenced with <span className="text-zinc-200">{status?.benchmarkName ?? "Crown"}</span> benchmark · Telegram alerts 24/7
            </p>
          </div>
          <div className="flex items-center gap-2">
            {(() => {
              const r = overStats?.resolved;
              const pct = r?.winRatePct ?? null;
              const tone =
                pct === null
                  ? "border-zinc-700 bg-zinc-900/60 text-zinc-300"
                  : pct >= 60
                    ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                    : pct >= 45
                      ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                      : "border-rose-500/40 bg-rose-500/10 text-rose-300";
              return (
                <div
                  className={`flex flex-col rounded-xl border px-4 py-2 ${tone}`}
                  title={
                    r
                      ? `Over-Bet win-rate across ${r.total} resolved matches where an OVER bet was placed (${r.wins} won / ${r.losses} lost). Under bets are excluded.`
                      : "Over-Bet win-rate — loading…"
                  }
                >
                  <span className="text-[10px] font-semibold uppercase tracking-wider opacity-80">
                    Over-Bet Win Rate
                  </span>
                  <span className="text-2xl font-bold leading-none">
                    {pct === null ? "—" : `${pct}%`}
                  </span>
                  <span className="mt-0.5 text-[10px] opacity-70">
                    {r ? `${r.wins}W · ${r.losses}L · ${r.total} bets` : "no resolved over bets yet"}
                  </span>
                </div>
              );
            })()}
            <div className="flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/60 px-4 py-2 text-sm">
              <span
                className={`inline-block h-2.5 w-2.5 rounded-full ${
                  isHealthy ? "bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.7)]" : "bg-red-500"
                }`}
              />
              {isHealthy ? "Healthy" : status ? "Stale / error" : "Connecting…"}
            </div>
            <button
              onClick={logout}
              className="rounded-full border border-zinc-800 bg-zinc-900/60 px-4 py-2 text-sm text-zinc-300 hover:bg-zinc-800"
            >
              Sign out
            </button>
          </div>
        </header>

        {/* GLOBAL SCAN status + manual pause/resume control. Boots ACTIVE and
            never pauses automatically; the toggle is a manual override. */}
        {(() => {
          const fastSec = status?.config?.watchlistFastPollSec ?? 20;
          const globalSec = status?.config?.watchlistGlobalPollSec ?? 60;
          const paused = status?.config?.isGlobalScannerPaused === true;
          return (
            <div
              className={`mb-6 flex flex-wrap items-center justify-between gap-4 rounded-xl border px-5 py-4 ${
                paused
                  ? "border-amber-800/70 bg-amber-950/30"
                  : "border-emerald-800/70 bg-emerald-950/30"
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`inline-block h-3 w-3 rounded-full ${
                    paused
                      ? "bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.7)]"
                      : "bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.7)]"
                  }`}
                />
                <div>
                  <div className={`text-sm font-bold ${paused ? "text-amber-200" : "text-emerald-200"}`}>
                    {paused ? "GLOBAL SCAN · PAUSED (manual)" : "GLOBAL SCAN · ACTIVE"}
                  </div>
                  <div className="mt-0.5 text-xs text-zinc-400">
                    {paused
                      ? "Hyper-focus mode — watchlist-only polling (~12s). Global pipeline suspended until you resume."
                      : `Always-on by default · full global pipeline · polling every ~${status?.config?.pollIntervalSec ?? globalSec}s (fast: ${fastSec}s with watchlist) · never pauses automatically`}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={forceRestartLoop}
                  disabled={forceRestarting}
                  title="Abort any hanging request, reset the scan loop, and force a fresh fetch"
                  className="rounded-full border border-red-700/70 bg-red-950/40 px-4 py-2 text-sm font-semibold text-red-200 transition hover:bg-red-900/50 disabled:opacity-50"
                >
                  {forceRestarting ? "Restarting…" : "Force Restart / Debug"}
                </button>
                <button
                  onClick={toggleGlobalScanner}
                  disabled={togglingScanner}
                  title={paused ? "Resume the full global pipeline" : "Manually pause the global scanner (watchlist-only hyper-focus mode)"}
                  className={`rounded-full border px-4 py-2 text-sm font-semibold transition disabled:opacity-50 ${
                    paused
                      ? "border-emerald-700/70 bg-emerald-900/40 text-emerald-200 hover:bg-emerald-800/50"
                      : "border-amber-700/70 bg-amber-950/40 text-amber-200 hover:bg-amber-900/50"
                  }`}
                >
                  {togglingScanner ? "…" : paused ? "▶ Resume Global Scan" : "⏸ Pause (manual)"}
                </button>
              </div>
            </div>
          );
        })()}

        <LeaguePolicyEditor />

        {/* MANUAL CONTROLS — subsystem switches (persisted server-side). */}
        {controls && (
          <div className="mb-6 flex flex-wrap items-center gap-3 rounded-xl border border-zinc-800 bg-zinc-900/40 px-5 py-3">
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              Manual controls
            </span>
            {(
              [
                {
                  key: "alertsMuted" as const,
                  on: !controls.alertsMuted,
                  labelOn: "🔔 Alerts ON",
                  labelOff: "🔕 Alerts MUTED",
                  invert: true,
                  title: "Mute/unmute Telegram broadcast alerts (detection keeps running)",
                },
                {
                  key: "altStreamEnabled" as const,
                  on: controls.altStreamEnabled,
                  labelOn: "Alt-stream ON",
                  labelOff: "Alt-stream OFF",
                  invert: false,
                  title: "Alternate-mirror odds supplement feed (branch B)",
                },
                {
                  key: "scoreWatchdogEnabled" as const,
                  on: controls.scoreWatchdogEnabled,
                  labelOn: "Score watchdog ON",
                  labelOff: "Score watchdog OFF",
                  invert: false,
                  title: "Sofascore score cross-reference watchdog",
                },
              ]
            ).map((c) => (
              <button
                key={c.key}
                onClick={() => setControlFlag(c.key, c.invert ? c.on : !c.on)}
                disabled={controlBusy === c.key}
                title={c.title}
                className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition disabled:opacity-50 ${
                  c.on
                    ? "border-emerald-700/60 bg-emerald-900/30 text-emerald-200 hover:bg-emerald-800/40"
                    : "border-zinc-700 bg-zinc-800/60 text-zinc-400 hover:bg-zinc-700/60"
                }`}
              >
                {controlBusy === c.key ? "…" : c.on ? c.labelOn : c.labelOff}
              </button>
            ))}
          </div>
        )}

        {restartDiag && (
          <div className="mb-6 rounded-lg border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-200">
            <div className="flex items-center justify-between gap-3">
              <div>
                <span className="font-bold">Loop force-restarted.</span>{" "}
                {restartDiag.wasInFlight ? (
                  <>
                    Blocked by:{" "}
                    <span className="font-mono text-red-100">{restartDiag.culprit}</span>
                    {restartDiag.stalledMs != null && (
                      <> · stalled for {(restartDiag.stalledMs / 1000).toFixed(1)}s</>
                    )}
                  </>
                ) : (
                  <span className="text-red-300">
                    No request was in flight — loop was idle / between ticks.
                  </span>
                )}
              </div>
              <button
                onClick={() => setRestartDiag(null)}
                className="shrink-0 rounded px-2 py-0.5 text-xs text-red-400 hover:text-red-200"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="mb-6 rounded-lg border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-300">
            {error}
          </div>
        )}

        {status?.lastError && (
          <div className="mb-6 rounded-lg border border-amber-900/60 bg-amber-950/40 px-4 py-3 text-sm text-amber-200">
            <span className="font-semibold">Last scanner error:</span> {status.lastError}
            {status.consecutiveFailures > 0 && (
              <span className="ml-2 text-xs">({status.consecutiveFailures} consecutive)</span>
            )}
          </div>
        )}

        <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Upstream league directory" value={status?.leaguesLoaded ?? "unknown"} />
          <StatCard label="Whitelist leagues" value={status?.whitelistSize ?? "unknown"} />
          <StatCard label="Schedule matches seen" value={status?.scheduleMatchesSeen ?? "unknown"} />
          <StatCard label="Live confirmed (feed)" value={status?.liveMatchesConfirmed ?? "unknown"} accent="text-rose-400" />
          <StatCard label="Matches tracked (post-filter)" value={status?.minorMatchesTracked ?? "unknown"} accent="text-emerald-400" />
          <StatCard label="Live tracked (post-filter)" value={status?.liveMatchesTracked ?? "unknown"} accent="text-rose-400" />
          <StatCard
            label={`Bench coverage (${status?.benchmarkName ?? "—"})`}
            value={benchPct !== null ? `${benchPct}%` : "—"}
            accent="text-cyan-400"
          />
          <StatCard label="Last scan" value={timeAgo(status?.lastCheckAt ?? null)} />
          <StatCard
            label="Last update"
            value={timeAgo(status?.lastGlobalUpdateAt ?? null)}
            accent="text-emerald-400"
            badge={
              status?.config?.isGlobalScannerPaused === true ? (
                <span className="inline-flex items-center gap-1 rounded-full border border-amber-500/40 bg-amber-500/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-300">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-400" />
                  Paused
                </span>
              ) : undefined
            }
          />
          <StatCard label="Alerts fired" value={status?.anomaliesFound ?? "—"} accent="text-amber-400" />
          <StatCard
            label="Bench confirmed"
            value={status?.benchmarkConfirmedAlerts ?? "—"}
            accent="text-emerald-400"
          />
          <StatCard
            label="Early bird"
            value={status?.earlyBirdAlerts ?? "—"}
            accent="text-yellow-400"
          />
          <StatCard
            label="Discarded (low liq)"
            value={status?.alertsSuppressedBySpread ?? "—"}
            accent="text-zinc-400"
          />
        </section>

        <section className="mt-10 rounded-xl border border-zinc-800 bg-zinc-900/60 p-6">
          <h2 className="text-lg font-semibold">Confidence anchors</h2>
          <div className="mt-4 grid gap-3 text-sm md:grid-cols-3">
            <div className="rounded-lg border border-emerald-900/60 bg-emerald-950/30 p-3">
              <div className="font-bold text-emerald-300">10/10 🟢🟢🟢</div>
              <div className="mt-1 text-xs text-emerald-100/80">
                Drop ≥ {status?.config?.dropThreshold?.toFixed(2) ?? "—"} + benchmark dropping ≥{" "}
                {status?.config?.benchmarkConfirmDrop?.toFixed(2) ?? "—"} + spread ≤{" "}
                {status?.config?.tightSpread?.toFixed(2) ?? "—"}
              </div>
            </div>
            <div className="rounded-lg border border-yellow-900/60 bg-yellow-950/30 p-3">
              <div className="font-bold text-yellow-300">5/10 🟡 EARLY BIRD</div>
              <div className="mt-1 text-xs text-yellow-100/80">
                Drop ≥ threshold but benchmark hasn't reacted yet — potentially first to spot it
              </div>
            </div>
            <div className="rounded-lg border border-zinc-700 bg-zinc-950/40 p-3">
              <div className="font-bold text-zinc-300">DISCARD ⚠️</div>
              <div className="mt-1 text-xs text-zinc-400">
                Spread &gt; {status?.config?.maxSpread?.toFixed(2) ?? "—"} = low liquidity, signal unreliable
              </div>
            </div>
          </div>
        </section>

        <section className="mt-6 rounded-xl border border-zinc-800 bg-zinc-900/60 p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-semibold">Self-Check &amp; Watchdog</h2>
            <div className="flex gap-2">
              <button
                onClick={() => runValidation(false)}
                disabled={validating}
                className="rounded-lg border border-zinc-700 bg-zinc-800 px-3 py-1.5 text-sm hover:bg-zinc-700 disabled:opacity-50"
              >
                {validating ? "Running…" : "Run validation"}
              </button>
              <button
                onClick={() => runValidation(true)}
                disabled={validating}
                className="rounded-lg border border-amber-700 bg-amber-900/40 px-3 py-1.5 text-sm text-amber-100 hover:bg-amber-900/60 disabled:opacity-50"
              >
                {validating ? "Running…" : "Validate + try failover"}
              </button>
              <button
                onClick={runSelfAnalysis}
                disabled={selfAnalyzing}
                className="rounded-lg border border-cyan-700 bg-cyan-900/40 px-3 py-1.5 text-sm text-cyan-100 hover:bg-cyan-900/60 disabled:opacity-50"
                title="Probes every mirror, checks tick freshness, emits a structured log report. Non-destructive."
              >
                {selfAnalyzing ? "Analyzing…" : "🔍 Run Self-Analysis"}
              </button>
            </div>
          </div>
          {health?.telegramPolling && (
            <div
              className={`mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border px-3 py-2 text-sm ${
                health.telegramPolling.shouldPoll
                  ? "border-emerald-900/60 bg-emerald-950/30"
                  : "border-zinc-700 bg-zinc-950/40"
              }`}
            >
              <span
                className={`font-medium ${
                  health.telegramPolling.shouldPoll ? "text-emerald-300" : "text-zinc-400"
                }`}
              >
                {health.telegramPolling.shouldPoll ? "✓" : "○"} Telegram polling
              </span>
              <span className={health.telegramPolling.shouldPoll ? "text-emerald-100/80" : "text-zinc-500"}>
                {health.telegramPolling.shouldPoll ? "Active" : "Disabled"} · {health.telegramPolling.reason}
              </span>
            </div>
          )}
          {selfReport && (
            <div className="mt-4 rounded-lg border border-cyan-900/50 bg-cyan-950/20 p-4 text-sm">
              <div className="flex flex-wrap items-center gap-3">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${
                    selfReport.ok
                      ? "bg-emerald-900/50 text-emerald-300"
                      : "bg-red-900/50 text-red-300"
                  }`}
                >
                  {selfReport.ok ? "✓ All systems nominal" : "✗ Issues detected"}
                </span>
                <span className="text-zinc-300">{selfReport.summary}</span>
                <span className="text-zinc-500 text-xs">ran {timeAgo(selfReport.ranAt)}</span>
              </div>

              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <div className="rounded-md border border-zinc-800 bg-zinc-950/50 p-3">
                  <div className="text-xs uppercase tracking-wider text-zinc-500 mb-2">
                    Mirror pool ({selfReport.mirrors.filter((m) => m.ok).length}/{selfReport.mirrors.length} healthy)
                  </div>
                  <div className="space-y-1.5">
                    {selfReport.mirrors.map((m) => (
                      <div key={m.host} className="flex items-center justify-between gap-2 text-xs">
                        <span className="font-mono text-zinc-300 truncate">
                          {m.ok ? "✓" : "✗"} {m.host.replace(/^https?:\/\//, "")}
                          {m.isCurrent && <span className="ml-1 rounded bg-cyan-900/60 px-1.5 text-cyan-300">active</span>}
                        </span>
                        <span className="text-zinc-500 shrink-0">
                          {m.ok ? `${m.matches ?? 0} matches · ${m.elapsedMs}ms` : m.reason ?? "fail"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-md border border-zinc-800 bg-zinc-950/50 p-3">
                  <div className="text-xs uppercase tracking-wider text-zinc-500 mb-2">
                    Tick liveness {selfReport.tickLiveness.ok ? "✓" : "✗"}
                  </div>
                  <div className="space-y-1 text-xs text-zinc-300">
                    <div>
                      Last tick: <span className="text-zinc-100">{selfReport.tickLiveness.secondsSinceLastTick ?? "?"}s ago</span>
                      {" "}<span className="text-zinc-500">(threshold {selfReport.tickLiveness.expectedMaxSec}s)</span>
                    </div>
                    <div>
                      primaryMap: <span className="text-zinc-100 tabular-nums">{selfReport.tickLiveness.mapSizes.primary}</span>
                      {" · "}benchMap: <span className="text-zinc-100 tabular-nums">{selfReport.tickLiveness.mapSizes.bench}</span>
                      {" · "}metaMap: <span className="text-zinc-100 tabular-nums">{selfReport.tickLiveness.mapSizes.meta}</span>
                    </div>
                    {selfReport.tickLiveness.reason && (
                      <div className="text-amber-400">⚠ {selfReport.tickLiveness.reason}</div>
                    )}
                    <div className="text-zinc-500 pt-1">
                      Counters: {selfReport.scannerCounters.checksTotal} ticks ·{" "}
                      {selfReport.scannerCounters.consecutiveFailures} consec fails ·{" "}
                      upstream league directory {selfReport.scannerCounters.leaguesLoaded ?? "unknown"} ·{" "}
                      whitelist leagues {selfReport.scannerCounters.whitelistSize ?? "unknown"} ·{" "}
                      schedule matches seen {selfReport.scannerCounters.scheduleMatchesSeen ?? "unknown"} ·{" "}
                      live confirmed (feed) {selfReport.scannerCounters.liveMatchesConfirmed ?? "unknown"} ·{" "}
                      live tracked (post-filter) {selfReport.scannerCounters.liveMatchesTracked ?? "unknown"} ·{" "}
                      matches tracked (post-filter) {selfReport.scannerCounters.minorMatchesTracked ?? "unknown"}
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-3 text-xs text-zinc-500">
                Full diagnostic report also written to server logs · Telegram echo sent to your chat
              </div>
            </div>
          )}
          {health?.lastValidation ? (
            <div className="mt-4 space-y-3 text-sm">
              <div className="flex flex-wrap items-center gap-3">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${
                    health.lastValidation.ok
                      ? "bg-emerald-900/50 text-emerald-300"
                      : "bg-red-900/50 text-red-300"
                  }`}
                >
                  {health.lastValidation.ok ? "✓ Healthy" : "✗ Issues"}
                </span>
                <span className="text-zinc-400">
                  Active mirror: <span className="text-zinc-200">{health.upstream.currentBase}</span>
                </span>
                <span className="text-zinc-500">
                  Last check: {timeAgo(health.lastValidation.ranAt)}
                </span>
              </div>
              <div className="text-zinc-300">{health.lastValidation.summary}</div>
              <div className="grid gap-2 md:grid-cols-2">
                {health.lastValidation.endpoints.map((e) => (
                  <div
                    key={e.url}
                    className={`rounded-md border px-3 py-2 text-xs ${
                      e.ok ? "border-emerald-900/40 bg-emerald-950/20" : "border-red-900/50 bg-red-950/30"
                    }`}
                  >
                    <div className="font-mono text-zinc-300">{e.url.replace(/^https?:\/\/[^/]+/, "")}</div>
                    <div className="mt-1 text-zinc-500">
                      {e.ok
                        ? `${e.recordsParsed} records · ${e.bytes} B · ${e.elapsedMs} ms`
                        : `✗ ${e.reason}`}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-zinc-500">
                <span>
                  Freshness: {health.lastValidation.freshness.ok ? "✓" : "✗"} ·{" "}
                  {health.lastValidation.freshness.matchesNearNow ?? "unknown"} scheduled kickoffs in -6/+36h window
                  {health.lastValidation.freshness.reason && (
                    <span className="ml-1 text-amber-400">({health.lastValidation.freshness.reason})</span>
                  )}
                </span>
                <span>
                  Watchdog: live last seen {timeAgo(health.watchdog.lastLiveSeenAt)} · alarm at{" "}
                  {Math.round(health.watchdog.staleLiveThresholdSec / 60)}m stuck
                </span>
                {health.upstream.lastFailoverAt && (
                  <span className="text-amber-400">
                    Last failover: {timeAgo(health.upstream.lastFailoverAt)}
                  </span>
                )}
              </div>
            </div>
          ) : (
            <div className="mt-3 text-sm text-zinc-500">No validation data yet.</div>
          )}
        </section>

        <section className="mt-6 rounded-xl border border-zinc-800 bg-zinc-900/60 p-6">
          <h2 className="text-lg font-semibold">Resilience &amp; Privacy</h2>
          <ul className="mt-3 space-y-1.5 text-sm text-zinc-300">
            <li>🔒 Dashboard + API protected by signed session cookie (HMAC-SHA256, 7-day TTL)</li>
            <li>🔒 Login rate-limited (8 attempts / 10 min per IP)</li>
            <li>🔒 Telegram alerts → only your chat ID (outbound-only bot, no inbound polling)</li>
            <li>• User-Agent rotation (5 browsers) + Referer rotation across requests</li>
            <li>• Active NowGoal/watchlist polling ~12s, with overlap guards and retry backoff</li>
            <li>
              • Reserved VM 24/7 ·{" "}
              <span className="text-zinc-500">
                primary fails: {status?.primaryFetchFailures ?? 0} · bench fails:{" "}
                {status?.benchmarkFetchFailures ?? 0}
              </span>
            </li>
          </ul>
        </section>

        <section className="watchlist-section mt-6 rounded-xl border border-cyan-900/40 bg-gradient-to-br from-cyan-950/30 to-zinc-900/60 p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-semibold">
                  🎯 Priority Watchlist · NowGoal Multi-Book Tracker
                </h2>
                <ExcapperFeedBadge health={watchlist?.excapperHealth} />
              </div>
              <ExcapperBatchNotice status={watchlist?.excapperBatch} />
              <p className="text-xs text-zinc-500">
                Over / Under shown in <span className="text-zinc-300">Hong Kong odds</span> (raw NowGoal values,
                e.g. 0.80, 0.97 — no conversion), stacked per book under <span className="text-zinc-300">NOWGOAL</span>.
                Bookmaker order is fixed (Bet365 · Sbobet · M88 · 12Bet · Crown · 18Bet · VS Bet); a row shows{" "}
                <span className="text-zinc-300">—</span> when that book isn&apos;t quoting the active line.
                Colour pulses every tick:{" "}
                <span className="text-rose-400">red = price dropping</span> (shortening),{" "}
                <span className="text-emerald-400">green = price rising</span> (lengthening).
                The Bet365 row also tags the active handicap (e.g. <span className="text-zinc-300">@2.50</span>);
                amber pulse there = handicap moved between ticks.
              </p>
              <p className="mt-1 text-xs text-zinc-400">
                <strong className="text-cyan-300">Hybrid loop:</strong> when this watchlist has
                entries the scanner uses{" "}
                <span className="font-mono text-zinc-200">~12s</span> ticks for active volatility
                tracking. Global 24/7 discovery still runs in the background at the steady{" "}
                <span className="font-mono text-zinc-200">~60s</span> cadence to reduce background load.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-zinc-900/60 px-3 py-1 text-xs text-zinc-400">
                {watchlistLoading && !watchlist
                  ? "Loading monitored…"
                  : `${liveWatchlistEntries.length} в эфире`}
              </span>
              <button
                type="button"
                onClick={() => void load({ bypassCache: true })}
                disabled={watchlistLoading}
                className="rounded-md border border-cyan-800/70 px-2 py-1 text-xs text-cyan-300 hover:bg-cyan-950/50 disabled:opacity-40"
                title="Refresh the watchlist table and scanner metadata"
              >
                {watchlistLoading ? "Refreshing…" : "Refresh"}
              </button>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <input
              type="text"
              value={watchlistInput}
              onChange={(e) => setWatchlistInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !watchlistAdding) void addToWatchlist();
              }}
              placeholder='e.g. "Dinamo vs Besiktas" or paste a nowgoal26.com match URL'
              className="min-w-[260px] flex-1 rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-cyan-500"
            />
            <button
              onClick={addToWatchlist}
              disabled={watchlistAdding || !watchlistInput.trim()}
              className="rounded-lg bg-cyan-600 px-4 py-2 text-sm font-medium text-white hover:bg-cyan-500 disabled:opacity-50"
            >
              {watchlistAdding ? "Adding…" : "+ Add to Monitor"}
            </button>
          </div>

          {watchlistMessage && (
            <div
              className={`mt-3 rounded-lg border px-3 py-2 text-sm ${
                watchlistMessage.kind === "error"
                  ? "border-red-900/60 bg-red-950/40 text-red-300"
                  : watchlistMessage.kind === "info"
                    ? "border-zinc-700 bg-zinc-900/60 text-zinc-300"
                    : "border-emerald-900/60 bg-emerald-950/40 text-emerald-300"
              }`}
            >
              {watchlistMessage.text}
            </div>
          )}
          {watchlistError && watchlist && (
            <div
              className="mt-3 rounded-lg border border-rose-800/60 bg-rose-950/30 px-3 py-2 text-xs text-rose-300"
              role="alert"
            >
              Не удалось обновить watchlist: {watchlistError}. Устаревшие строки скрыты из
              активной таблицы; сохранёнными закреплениями можно управлять отдельно.
            </div>
          )}

          <RuntimeAuditSummary
            runtimeAudit={watchlistError ? undefined : watchlist?.runtimeAudit}
            loading={watchlistLoading && !watchlist}
            error={watchlistError}
            endpoint={`${API_BASE}/watchlist/runtime-audit`}
          />

          {watchlist && savedNonLiveEntries.length > 0 && (
            <details className="mt-4 rounded-lg border border-zinc-800 bg-zinc-950/35">
              <summary className="cursor-pointer px-3 py-2 text-xs font-medium text-zinc-300">
                Управление сохранёнными матчами вне эфира ({savedNonLiveEntries.length})
              </summary>
              <p className="border-t border-zinc-800 px-3 pt-3 text-xs text-zinc-500">
                Эти сохранённые матчи не входят в активную таблицу и её счётчики. Здесь их
                можно удалить, не теряя закрепления автоматически.
              </p>
              <ul className="divide-y divide-zinc-800 px-3 pb-2">
                {savedNonLiveEntries.map((entry) => (
                  <li
                    key={entry.signature}
                    className="flex flex-wrap items-center justify-between gap-2 py-2 text-xs"
                  >
                    <span>
                      <span className="text-zinc-200">
                        {entry.live
                          ? `${entry.live.team1} vs ${entry.live.team2}`
                          : entry.label}
                      </span>
                      <span className="ml-2 text-zinc-500">
                        {entry.live?.matchStatus === "scheduled"
                          ? "запланирован"
                          : entry.live?.matchStatus === "finished"
                            ? "завершён"
                            : "статус эфира не подтверждён"}
                      </span>
                    </span>
                    <button
                      type="button"
                      onClick={() => void removeFromWatchlist(entry.signature)}
                      className="rounded border border-rose-900/60 px-2 py-1 text-rose-300 hover:bg-rose-950/60"
                    >
                      Удалить
                    </button>
                  </li>
                ))}
              </ul>
            </details>
          )}

          {watchlistLoading && !watchlist ? (
            <div
              className="mt-4 rounded-lg border border-amber-800/70 bg-amber-950/20 px-3 py-4 text-sm text-amber-200"
              role="status"
            >
              <div className="font-medium">Loading monitored matches…</div>
              <div className="mt-1 text-xs text-amber-200/70">
                The table will keep explicit match IDs visible while NowGoal metadata and odds arrive.
              </div>
            </div>
          ) : watchlistError && !watchlist ? (
            <div
              className="mt-4 rounded-lg border border-rose-800/70 bg-rose-950/30 px-3 py-4 text-sm text-rose-300"
              role="alert"
            >
              <div className="font-medium">Watchlist refresh failed</div>
              <div className="mt-1 text-xs text-rose-200/80">{watchlistError}</div>
            </div>
          ) : watchlist && liveWatchlistEntries.length > 0 ? (
            <div className="mt-4 overflow-x-auto">
              {/* COLUMN SEQUENCE (per spec):
                    Fixture | League | Score | EXC TOTAL | NOWGOAL | OVER | UNDER | VOL O | VOL U | Last update | ✕
                  - Standalone Line/Over/Under columns removed; the active Bet365
                    handicap is shown inline at the top of NOWGOAL.
                  - NOWGOAL is a FIXED vertical stack of 7 books in this exact
                    order: Bet365, Sbobet, M88, 12Bet, Crown, 18Bet, VS Bet.
                    OVER and UNDER are parallel stacks aligned row-by-row with
                    NOWGOAL. All seven books are wired to live NowGoal feeds
                    (goal8 / goal31 / goal17 / goal24 / goal3 / goal42 /
                    goal14 .xml respectively); a row only renders "—" when
                    that particular book isn't currently quoting the match.
                  - Decimal odds (1.85 style), not HK. Trend colours: drop = RED,
                    rise = GREEN per operator spec.
                  - Sofascore consensus column is gone. */}
              <table className="watchlist-table text-sm">
                <colgroup>
                  <col className="watchlist-fixture-column" />
                  <col style={{ width: 90 }} />
                  <col style={{ width: 60 }} />
                  <col style={{ width: 80 }} />
                  <col style={{ width: 85 }} />
                  <col style={{ width: 85 }} />
                  <col style={{ width: 75 }} />
                  <col style={{ width: 90 }} />
                  <col style={{ width: 140 }} />
                  <col style={{ width: 140 }} />
                  <col style={{ width: 60 }} />
                  <col style={{ width: 64 }} />
                </colgroup>
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wider text-zinc-500">
                    <th className="pb-2 pr-3">Fixture</th>
                    <th className="pb-2 pr-3 text-center">League</th>
                    <th className="pb-2 pr-3 text-center">Score</th>
                    <th className="pb-2 pr-3 text-center" title="Fixed bookmaker stack from the NowGoal odds matrix">NOWGOAL</th>
                    <th className="pb-2 pr-3 text-center" title="HK Over odds per book at the active Bet365 line (raw NowGoal values)">OVER</th>
                    <th className="pb-2 pr-3 text-center" title="HK Under odds per book at the active Bet365 line (raw NowGoal values)">UNDER</th>
                    <th className="pb-2 pr-3 text-center" title="Excapper Over/Under line — one row per active total market">EXC TOTAL</th>
                    <th
                      className="pb-2 pr-3 text-center"
                      title="Volume Split — share of total native-feed EUR matched on this line going Over vs Under (Over% / Under%). Computed from running per-line cumulative totals, not per-tick deltas."
                    >
                      V/S %
                    </th>
                    <th className="watchlist-volume-column pb-2 text-center" title="Cumulative native-feed EUR matched Over (Excapper)">VOL O</th>
                    <th className="watchlist-volume-column pb-2 text-center" title="Cumulative native-feed EUR matched Under (Excapper)">VOL U</th>
                    <th className="watchlist-updated-column pb-2 text-center">Updated</th>
                    <th className="pb-2"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/70">
                  {liveWatchlistEntries.map((e) => {
                    const excapperVolumes = availableExcapperVolumes(e);
                    const isExpanded = watchlistExpanded.has(e.signature);
                    const rowStatus = e.status ?? (e.live ? "ready" : "loading");
                    const rowStatusClass =
                      rowStatus === "error"
                        ? "border-rose-800/70 bg-rose-950/30 text-rose-300"
                        : rowStatus === "loading"
                          ? "border-amber-800/70 bg-amber-950/20 text-amber-200"
                          : "border-emerald-800/60 bg-emerald-950/20 text-emerald-300";
                    return (
                    <Fragment key={e.signature}>
                    <tr className="align-middle">
                      <td
                        className="watchlist-fixture-cell py-2 pr-3"
                        title={e.live ? `${e.live.team1} vs ${e.live.team2}` : e.label}
                      >
                        {e.live ? (
                          // Stacked home/away — drops fixture column width by
                          // ~40% on long club names. The live-pulse dot sits
                          // in a leading column so the team names stay
                          // perfectly left-aligned in a tight vertical block.
                          <div className="flex items-start gap-2">
                            {e.live.isLive && (
                              <span className="flex shrink-0 flex-col items-center gap-0.5">
                                <span className="mt-1.5 inline-block h-2 w-2 animate-pulse rounded-full bg-rose-500" />
                                {finiteNumber(e.live.minute) !== null ? (
                                  <span
                                    className="text-[10px] font-semibold tabular-nums text-rose-300"
                                    title="Estimated match minute (elapsed since kickoff, incl. HT break)"
                                  >
                                    {e.live.minute}'
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-zinc-500" title="Match minute not available from NowGoal">
                                    min —
                                  </span>
                                )}
                              </span>
                            )}
                            <div className="min-w-0 flex-1 overflow-hidden leading-tight text-zinc-100">
                              <span className="watchlist-team-name font-medium" title={e.live.team1}>
                                {e.live.team1}
                                <TeamCardBadges
                                  yc={e.live.events?.yc.home ?? 0}
                                  rc={e.live.events?.rc.home ?? 0}
                                />
                              </span>
                              <span className="watchlist-team-name font-medium" title={e.live.team2}>
                                {e.live.team2}
                                <TeamCardBadges
                                  yc={e.live.events?.yc.away ?? 0}
                                  rc={e.live.events?.rc.away ?? 0}
                                />
                              </span>
                              {e.live.events?.penalty.present && (
                                <span
                                  className="mt-0.5 inline-flex w-fit items-center rounded-sm bg-emerald-500/15 px-1 text-[10px] font-normal text-emerald-300 ring-1 ring-emerald-500/40"
                                  title="Penalty awarded"
                                >
                                  🥅 Pen
                                  {e.live.events.penalty.minute != null
                                    ? ` ${e.live.events.penalty.minute}'`
                                    : ""}
                                </span>
                              )}
                            </div>
                            {rowStatus !== "ready" && (
                              <span
                                className={`mt-0.5 rounded border px-1.5 py-0.5 text-[10px] ${
                                  rowStatus === "error"
                                    ? "border-rose-800/70 bg-rose-950/30 text-rose-300"
                                    : "border-amber-800/70 bg-amber-950/20 text-amber-200"
                                }`}
                                role={rowStatus === "error" ? "alert" : "status"}
                              >
                                {rowStatus === "error" ? "refresh error" : "odds loading — metadata tracked"}
                              </span>
                            )}
                          </div>
                        ) : (
                          <div className={`rounded-md border px-2 py-1.5 ${rowStatusClass}`} role={rowStatus === "error" ? "alert" : "status"}>
                            <div className="flex items-center gap-2 font-medium">
                              <span>{rowStatus === "error" ? "⚠ Match refresh failed" : "↻ Match metadata loading"}</span>
                              {e.matchId && (
                                <span className="rounded bg-black/20 px-1.5 py-0.5 font-mono text-[10px]">
                                  #{e.matchId}
                                </span>
                              )}
                            </div>
                            <div className="mt-1 text-[10px] opacity-80">
                              {e.statusMessage ?? e.label}
                            </div>
                          </div>
                        )}
                      </td>
                      <td className="py-2 pr-3 text-center text-zinc-400">{e.live?.league ?? "—"}</td>
                      <td className="py-2 pr-3 text-center font-mono text-zinc-200">
                        {e.live ? (
                          <span className="inline-flex items-center justify-center gap-1">
                            <span>{e.live.homeScore} – {e.live.awayScore}</span>
                            {e.live.matchStatus === "finished" && (
                              <span
                                className="rounded bg-zinc-700/60 px-1 py-0.5 text-[9px] font-medium uppercase tracking-wide text-zinc-300"
                                title="Finished match — historical score, not live"
                              >
                                final
                              </span>
                            )}
                            {/* Score-watchdog badge: shown for ~2 minutes after a
                                Sofascore correction so the user can see the freeze
                                was caught. Tooltip carries total override count. */}
                            {typeof e.live.scoreOverrideAgoSec === "number" &&
                              e.live.scoreOverrideAgoSec < 120 && (
                                <span
                                  className="rounded bg-amber-500/20 px-1 py-0.5 text-[9px] font-medium uppercase tracking-wide text-amber-300 ring-1 ring-amber-400/50"
                                  title={`Score corrected by Sofascore watchdog ${e.live.scoreOverrideAgoSec}s ago · ${e.live.scoreOverrideCount ?? 0} total overrides`}
                                >
                                  ✓sofa
                                </span>
                              )}
                            {/* Alt-stream badge: shown when alt mirror touched
                                the row in the last 90s (primary was stale). */}
                            {typeof e.live.altOddsAgoSec === "number" &&
                              e.live.altOddsAgoSec < 90 && (
                                <span
                                  className="rounded bg-purple-500/20 px-1 py-0.5 text-[9px] font-medium uppercase tracking-wide text-purple-300 ring-1 ring-purple-400/50"
                                  title={`Alt-mirror stream refreshed odds ${e.live.altOddsAgoSec}s ago (primary was stale)`}
                                >
                                  alt
                                </span>
                              )}
                          </span>
                        ) : (
                          "—"
                        )}
                      </td>
                      {/* NOWGOAL / OVER / UNDER — fixed 7-row vertical book stack.
                          Order is hard-coded and identical for every match so the
                          UI never shifts. Values are rendered RAW in Hong Kong
                          style (e.g. 0.80, 0.97) — exactly what NowGoal's own
                          matrix shows — so operators can eyeball-compare without
                          mental math. Bet365 uses live.overHk/underHk verbatim
                          (already HK). Crown + Sbobet/M88/12Bet/18Bet come off
                          the backend as European decimal, so we subtract 1 here
                          to put them back on the HK scale. Each book labels its
                          OWN active line in yellow next to its name (lines
                          often diverge between books — operators want to see
                          that, not have it hidden by a global line filter).
                          VS Bet (goal14.xml) replaced Easybet in this slot — it
                          serves the same XML transport as the other extras, so
                          its row carries live odds and a yellow line badge like
                          the rest. Drop=RED, rise=GREEN. */}
                      <td className="py-2 pr-3 text-center align-top">
                        {/* Each row labels its OWN active line in yellow next
                            to the book name. Bet365 still pulses amber on
                            line moves. VS Bet ("VSBet" internally, "VS Bet"
                            on screen) is the 7th row and is fully wired. */}
                        <div className="flex flex-col items-center gap-0.5 text-xs text-zinc-300">
                          {(["Bet365","Sbobet","M88","12Bet","Crown","18Bet","VSBet"] as const).map((b) => {
                            let bookLine: number | null = null;
                            if (b === "Bet365") bookLine = finiteNumber(e.live?.line);
                            else if (b === "Crown") bookLine = finiteNumber(e.live?.crownLine);
                            else if (b === "Sbobet" || b === "M88" || b === "12Bet" || b === "18Bet" || b === "VSBet") {
                              bookLine = finiteNumber(e.live?.books?.[b]?.line);
                            }
                            const isBet365Moved = b === "Bet365" && e.live?.lineChanged;
                            const displayName = b === "VSBet" ? "VS Bet" : b;
                            return (
                              <span key={b} className="font-mono leading-5 tabular-nums">
                                {displayName}
                                {bookLine != null && (
                                  <span
                                    className={`ml-1 text-[10px] ${
                                      isBet365Moved
                                        ? "animate-pulse rounded bg-amber-500/20 px-1 text-amber-200 ring-1 ring-amber-400/60"
                                        : "rounded bg-yellow-500/10 px-1 text-yellow-300/90 ring-1 ring-yellow-500/30"
                                    }`}
                                    title={
                                      isBet365Moved && finiteNumber(e.live?.prevLine) !== null && bookLine !== null
                                        ? `Bet365 line moved: ${finiteNumber(e.live?.prevLine)!.toFixed(2)} → ${bookLine.toFixed(2)}`
                                        : `${displayName} active handicap ${bookLine.toFixed(2)}`
                                    }
                                  >
                                    [{bookLine.toFixed(2)}]
                                  </span>
                                )}
                              </span>
                            );
                          })}
                        </div>
                      </td>
                      <td className="py-2 pr-3 text-center align-top">
                        <div className="flex flex-col items-center gap-0.5 text-xs">
                          {/* Bet365: raw HK from backend, e.g. 0.85 */}
                          <OddCell
                            value={finiteNumber(e.live?.overHk)}
                            trend={e.live?.overTrend}
                            delta={e.live?.overDeltaHk}
                            title={
                              finiteNumber(e.live?.prevOverHk) !== null && finiteNumber(e.live?.overHk) !== null
                                ? `Bet365 (HK): ${finiteNumber(e.live?.prevOverHk)!.toFixed(2)} → ${finiteNumber(e.live?.overHk)!.toFixed(2)}`
                                : undefined
                            }
                          />
                          {/* Sbobet, M88, 12Bet — backend decimal → render as HK (dec − 1) */}
                          {(["Sbobet","M88","12Bet"] as const).map((b) => {
                            const bk = e.live?.books?.[b];
                            const line = finiteNumber(bk?.line);
                            const over = finiteNumber(bk?.overDecimal);
                            return (
                              <OddCell
                                key={b}
                                value={over !== null ? over - 1 : null}
                                trend={bk?.overTrend}
                                delta={bk?.overDeltaHk}
                                title={
                                  line !== null && over !== null
                                    ? `${b} @ ${line.toFixed(2)} (HK): ${(over - 1).toFixed(2)}`
                                    : `${b} not quoting yet`
                                }
                              />
                            );
                          })}
                          {/* Crown: backend stores decimal → render as HK (dec − 1) */}
                          <OddCell
                            value={
                              finiteNumber(e.live?.crownOverDecimal) !== null
                                ? finiteNumber(e.live?.crownOverDecimal)! - 1
                                : null
                            }
                            trend={e.live?.crownOverTrend}
                            delta={e.live?.crownOverDeltaHk}
                            title={
                              finiteNumber(e.live?.crownOverDecimal) !== null && finiteNumber(e.live?.crownLine) !== null
                                ? `Crown @ ${finiteNumber(e.live?.crownLine)!.toFixed(2)} (HK): ${(finiteNumber(e.live?.crownOverDecimal)! - 1).toFixed(2)}`
                                : "Crown not quoting yet"
                            }
                          />
                          {/* 18Bet + VS Bet (goal14.xml) — both wired */}
                          {(["18Bet","VSBet"] as const).map((b) => {
                            const bk = e.live?.books?.[b];
                            const display = b === "VSBet" ? "VS Bet" : b;
                            const line = finiteNumber(bk?.line);
                            const over = finiteNumber(bk?.overDecimal);
                            return (
                              <OddCell
                                key={b}
                                value={over !== null ? over - 1 : null}
                                trend={bk?.overTrend}
                                delta={bk?.overDeltaHk}
                                title={
                                  line !== null && over !== null
                                    ? `${display} @ ${line.toFixed(2)} (HK): ${(over - 1).toFixed(2)}`
                                    : `${display} not quoting yet`
                                }
                              />
                            );
                          })}
                        </div>
                      </td>
                      <td className="py-2 pr-3 text-center align-top">
                        <div className="flex flex-col items-center gap-0.5 text-xs">
                          <OddCell
                            value={finiteNumber(e.live?.underHk)}
                            trend={e.live?.underTrend}
                            delta={e.live?.underDeltaHk}
                            title={
                              finiteNumber(e.live?.prevUnderHk) !== null && finiteNumber(e.live?.underHk) !== null
                                ? `Bet365 (HK): ${finiteNumber(e.live?.prevUnderHk)!.toFixed(2)} → ${finiteNumber(e.live?.underHk)!.toFixed(2)}`
                                : undefined
                            }
                          />
                          {(["Sbobet","M88","12Bet"] as const).map((b) => {
                            const bk = e.live?.books?.[b];
                            const line = finiteNumber(bk?.line);
                            const under = finiteNumber(bk?.underDecimal);
                            return (
                              <OddCell
                                key={b}
                                value={under !== null ? under - 1 : null}
                                trend={bk?.underTrend}
                                delta={bk?.underDeltaHk}
                                title={
                                  line !== null && under !== null
                                    ? `${b} @ ${line.toFixed(2)} (HK): ${(under - 1).toFixed(2)}`
                                    : `${b} not quoting yet`
                                }
                              />
                            );
                          })}
                          <OddCell
                            value={
                              finiteNumber(e.live?.crownUnderDecimal) !== null
                                ? finiteNumber(e.live?.crownUnderDecimal)! - 1
                                : null
                            }
                            trend={e.live?.crownUnderTrend}
                            delta={e.live?.crownUnderDeltaHk}
                            title={
                              finiteNumber(e.live?.crownUnderDecimal) !== null && finiteNumber(e.live?.crownLine) !== null
                                ? `Crown @ ${finiteNumber(e.live?.crownLine)!.toFixed(2)} (HK): ${(finiteNumber(e.live?.crownUnderDecimal)! - 1).toFixed(2)}`
                                : "Crown not quoting yet"
                            }
                          />
                          {(["18Bet","VSBet"] as const).map((b) => {
                            const bk = e.live?.books?.[b];
                            const display = b === "VSBet" ? "VS Bet" : b;
                            const line = finiteNumber(bk?.line);
                            const under = finiteNumber(bk?.underDecimal);
                            return (
                              <OddCell
                                key={b}
                                value={under !== null ? under - 1 : null}
                                trend={bk?.underTrend}
                                delta={bk?.underDeltaHk}
                                title={
                                  line !== null && under !== null
                                    ? `${display} @ ${line.toFixed(2)} (HK): ${(under - 1).toFixed(2)}`
                                    : `${display} not quoting yet`
                                }
                              />
                            );
                          })}
                        </div>
                      </td>
                      {/* EXC TOTAL — Excapper active-line column. Lands between
                          the NowGoal bookmaker block and the Betfair volume
                          (VOL O / VOL U) columns so the visual flow is:
                          per-book odds → per-line market context → per-line
                          EUR flow. One row per active OU line; empty → "—". */}
                      <td className="py-2 pr-3 text-center">
                        {excapperVolumes.length > 0 ? (
                          <div className="flex flex-col gap-0.5">
                            {excapperVolumes.map((v) => (
                              <span
                                key={v.line}
                                className="font-mono tabular-nums text-xs text-zinc-300"
                                title={`Excapper Over/Under ${v.line.toFixed(1)} · sampled ${v.updatedAgoSec}s ago`}
                              >
                                {v.line.toFixed(1)}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-zinc-600">—</span>
                        )}
                        <ExcapperBindingStatus
                          diagnostic={e.excapperBinding}
                          signature={e.signature}
                          nowgoalId={e.matchId}
                          fallbackTarget={e.live ? {
                            team1: e.live.team1,
                            team2: e.live.team2,
                            league: e.live.league,
                            score: finiteNumber(e.live.homeScore) !== null && finiteNumber(e.live.awayScore) !== null
                              ? { home: e.live.homeScore, away: e.live.awayScore } : null,
                            minute: e.live.minute,
                          } : e.fragments.length >= 2 ? {
                            team1: e.fragments[0]!,
                            team2: e.fragments[1]!,
                            league: "Not available yet",
                          } : {
                            team1: e.label,
                            team2: "Not available yet",
                            league: "Not available yet",
                          }}
                          onApproved={() => load({ bypassCache: true })}
                        />
                      </td>
                      {/* V/S % — single color-coded skew per line. Shows the
                          DOMINANT side's share of total native-feed EUR matched, with GREEN
                          for Over-dominated flow, RED for Under-dominated, and
                          neutral zinc on an exact 50/50 split. Per-line totals
                          come from the running per-(line,side) cumulative
                          (v.over / v.under) — entire-match flow, not per-tick.
                          Uses the same font metrics (font-mono tabular-nums
                          text-xs, default line-height) and middle alignment as
                          EXC TOTAL / VOL O / VOL U so the four per-line stacks
                          stay row-for-row aligned regardless of the 7-row
                          NOWGOAL bookmaker stack height. Narrow column — no
                          width override needed; the short "70%" string keeps
                          it naturally compact. */}
                      <td className="py-2 pr-3 text-center">
                        {excapperVolumes.length > 0 ? (
                          <div className="flex flex-col gap-0.5">
                            {excapperVolumes.map((v) => {
                              const total = finiteNumber(v.totalVolume);
                              const exactOverPct = finiteNumber(v.overSharePct);
                              const exactUnderPct = finiteNumber(v.underSharePct);
                              if (total === null || total <= 0 || exactOverPct === null || exactUnderPct === null) {
                                return (
                                  <span
                                    key={v.line}
                                    className="font-mono tabular-nums text-xs text-zinc-600"
                                    title={`Line ${v.line.toFixed(1)} · no traded volume yet`}
                                  >
                                    —
                                  </span>
                                );
                              }
                              const pctOver = Math.round(exactOverPct);
                              const pctUnder = Math.round(exactUnderPct);
                              // Dominant side = whichever cumulative bucket is
                              // larger. We render that side's pct only. Exact
                              // 50/50 (both pcts are 50) shows neutral zinc.
                              const dominantPct = Math.max(pctOver, pctUnder);
                              const isNeutral = pctOver === pctUnder; // 50/50
                              const colorClass = isNeutral
                                ? "text-zinc-300"
                                : pctOver > pctUnder
                                  ? "text-emerald-300" // Over-dominated
                                  : "text-rose-300"; // Under-dominated
                              return (
                                <span
                                  key={v.line}
                                  className={`font-mono tabular-nums text-xs ${colorClass}`}
                                  title={
                                    isNeutral
                                      ? `Line ${v.line.toFixed(1)} · 50% neutral · Over ${formatEur(v.over)} / Under ${formatEur(v.under)} · total ${formatEur(total)}`
                                      : `Line ${v.line.toFixed(1)} · ${pctOver > pctUnder ? "OVER" : "UNDER"}-dominated ${dominantPct}% · Over ${formatEur(v.over)} (${pctOver}%) / Under ${formatEur(v.under)} (${pctUnder}%) · total ${formatEur(total)}`
                                  }
                                >
                                  {dominantPct}%
                                  {isNeutral && (
                                    <span className="ml-1 text-[9px] uppercase tracking-wide text-zinc-500">
                                      neutral
                                    </span>
                                  )}
                                </span>
                              );
                            })}
                          </div>
                        ) : (
                          <span className="text-zinc-600">—</span>
                        )}
                      </td>
                      <td className="watchlist-volume-column py-2 text-center">
                        {excapperVolumes.length > 0 ? (
                          <div className="flex flex-col gap-0.5">
                            {excapperVolumes.map((v) => {
                              const matchKey = e.matchId ?? e.signature;
                              return (
                                <CumulativeVolume
                                  key={v.line}
                                  amount={v.over}
                                  increase={volumeIncreases.get(volumeKey(matchKey, v.line, "over"))}
                                  side="over"
                                  spike={v.overSpike}
                                  line={v.line}
                                />
                              );
                            })}
                          </div>
                        ) : (
                          <span className="text-zinc-600">—</span>
                        )}
                      </td>
                      <td className="watchlist-volume-column py-2 text-center">
                        {excapperVolumes.length > 0 ? (
                          <div className="flex flex-col gap-0.5">
                            {excapperVolumes.map((v) => {
                              const matchKey = e.matchId ?? e.signature;
                              return (
                                <CumulativeVolume
                                  key={v.line}
                                  amount={v.under}
                                  increase={volumeIncreases.get(volumeKey(matchKey, v.line, "under"))}
                                  side="under"
                                  spike={v.underSpike}
                                  line={v.line}
                                />
                              );
                            })}
                          </div>
                        ) : (
                          <span className="text-zinc-600">—</span>
                        )}
                      </td>
                      <td className="watchlist-updated-column py-2 text-center font-mono text-[11px] tabular-nums text-zinc-400">
                        {e.live?.lastSeenAgoSec !== null && e.live?.lastSeenAgoSec !== undefined
                          ? `NG ${compactAge(e.live.lastSeenAgoSec)}`
                          : "NG —"}
                        <span aria-hidden="true" className="text-zinc-600"> · </span>
                        <ExcapperFreshness diagnostic={e.excapperBinding} />
                      </td>
                      <td className="py-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() =>
                              setWatchlistExpanded((current) =>
                                {
                                  const next = new Set(current);
                                  if (next.has(e.signature)) next.delete(e.signature);
                                  else next.add(e.signature);
                                  return next;
                                },
                              )
                            }
                            className={`rounded-md border px-2 py-1 text-xs ${
                              isExpanded
                                ? "border-cyan-700 bg-cyan-950/40 text-cyan-200"
                                : "border-zinc-800 text-zinc-400 hover:border-cyan-800 hover:text-cyan-300"
                            }`}
                            title={isExpanded ? "Collapse match details" : "Expand match details"}
                            aria-label={isExpanded ? "Collapse match details" : "Expand match details"}
                          >
                            {isExpanded ? "▴" : "▾"}
                          </button>
                          <details className="relative">
                            <summary
                              className="cursor-pointer list-none rounded-md border border-zinc-800 px-2 py-1 text-xs text-zinc-400 hover:border-cyan-800 hover:text-cyan-300"
                              title="Match actions"
                              aria-label="Match actions"
                            >
                              ⋮
                            </summary>
                            <div className="absolute right-0 z-20 mt-1 flex min-w-32 flex-col rounded-md border border-zinc-700 bg-zinc-950 p-1 text-left shadow-xl">
                              <button
                                type="button"
                                onClick={() => void refreshWatchlistEntry(e.signature, e.label)}
                                disabled={watchlistRefreshing !== null}
                                className="rounded px-2 py-1.5 text-left text-xs text-cyan-300 hover:bg-cyan-950/60 disabled:opacity-40"
                              >
                                {watchlistRefreshing === e.signature ? "Refreshing…" : "Refresh now"}
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setWatchlistExpanded((current) =>
                                    {
                                      const next = new Set(current);
                                      if (next.has(e.signature)) next.delete(e.signature);
                                      else next.add(e.signature);
                                      return next;
                                    },
                                  )
                                }
                                className="rounded px-2 py-1.5 text-left text-xs text-zinc-300 hover:bg-zinc-800"
                              >
                                {isExpanded ? "Collapse details" : "Expand details"}
                              </button>
                              <button
                                type="button"
                                onClick={() => void removeFromWatchlist(e.signature)}
                                className="rounded px-2 py-1.5 text-left text-xs text-rose-300 hover:bg-rose-950/60"
                              >
                                Remove
                              </button>
                            </div>
                          </details>
                        </div>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="bg-zinc-950/30">
                        <td colSpan={12} className="px-3 py-3">
                          <div className={`rounded-lg border p-3 text-xs ${rowStatusClass}`}>
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <strong>
                                {rowStatus === "error"
                                  ? "Refresh error"
                                  : rowStatus === "loading"
                                    ? "Waiting for NowGoal enrichment"
                                    : "NowGoal match details"}
                              </strong>
                              <span className="font-mono text-[10px]">
                                {e.matchId ? `match #${e.matchId}` : e.signature}
                              </span>
                            </div>
                            <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                              <div>
                                <span className="text-[10px] uppercase tracking-wide opacity-70">Fixture</span>
                                <div className="mt-0.5 text-zinc-100">
                                  {e.live ? `${e.live.team1} vs ${e.live.team2}` : e.label}
                                </div>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase tracking-wide opacity-70">League / score</span>
                                <div className="mt-0.5 text-zinc-100">
                                  {e.live
                                    ? `${e.live.league} · ${e.live.homeScore}–${e.live.awayScore}${
                                        e.live.matchStatus === "finished"
                                          ? " · FINAL"
                                          : e.live.isLive
                                            ? " · LIVE"
                                            : e.live.matchStatus === "scheduled"
                                              ? " · SCHEDULED"
                                              : ""
                                      }`
                                    : "Metadata not available yet"}
                                </div>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase tracking-wide opacity-70">Odds state</span>
                                <div className="mt-0.5 text-zinc-100">
                                  {e.live && e.live.historyPoints > 0
                                    ? `${e.live.historyPoints} odds snapshot${e.live.historyPoints === 1 ? "" : "s"}`
                                    : "No odds snapshot yet — metadata is still tracked"}
                                </div>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase tracking-wide opacity-70">Provenance</span>
                                <div className="mt-0.5 text-zinc-100">
                                  Manual NowGoal pin
                                </div>
                              </div>
                            </div>
                            <div className="mt-2 flex flex-wrap items-center gap-2">
                              <span>{e.statusMessage ?? (e.live ? "Enrichment is current." : "Waiting for scanner state.")}</span>
                              {e.live?.events && (
                                <span className="rounded bg-black/20 px-2 py-0.5">
                                  cards {e.live.events.yc.home + e.live.events.yc.away} yellow ·{" "}
                                  {e.live.events.rc.home + e.live.events.rc.away} red ·{" "}
                                  {e.live.events.penalty.present ? "penalty" : "no penalty"}
                                </span>
                              )}
                              <button
                                type="button"
                                onClick={() => void refreshWatchlistEntry(e.signature, e.label)}
                                disabled={watchlistRefreshing !== null}
                                className="rounded border border-current px-2 py-1 font-medium hover:bg-black/20 disabled:opacity-40"
                              >
                                {watchlistRefreshing === e.signature ? "Refreshing…" : "Refresh this match"}
                              </button>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                    </Fragment>
                    );
                  })}
                </tbody>
              </table>
              {watchlist.lastError && (
                <p className="mt-2 text-xs text-amber-400">Last reload error: {watchlist.lastError}</p>
              )}
            </div>
          ) : (
            <p className="mt-4 text-sm text-zinc-500">
              Сейчас нет подтверждённых матчей в прямом эфире. Сохранённые матчи вне
              эфира доступны в отдельном списке управления выше.
            </p>
          )}
        </section>

        {draft && (
          <section className="mt-6 rounded-xl border-2 border-cyan-700/40 bg-cyan-950/10 p-6">
            <div className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-cyan-400/80">
              === STRATEGIC MONITOR FILTERS · Drop Triggers ===
            </div>
            <h2 className="text-lg font-semibold">Tune filters</h2>

            {/* Three-column grid grouped by logic:
                  Col 1 = Core Drop Triggers (primary config drivers, accent border)
                  Col 2 = Spread Safeguards (nested grid of spread rules)
                  Col 3 = Liquidity & Confidence (range slider + density toggle)
                Mobile collapses to a single column. */}
            <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">

              {/* ----- Column 1: Core Drop Triggers ----- */}
              <div className="rounded-lg border-2 border-cyan-700/40 bg-cyan-950/10 p-4">
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-cyan-300">
                  Core Drop Triggers
                </h3>
                <div className="flex flex-col gap-3">
                  <NumberInput label="Drop threshold (decimal pts)" source={status?.config?.sources?.dropThreshold} step={0.01} min={0.01} max={5}
                    value={draft.dropThreshold ?? 0.4}
                    onChange={(v) => setDraftField("dropThreshold", v)} />
                  <NumberInput label="Benchmark confirm drop" step={0.01} min={0.01} max={5}
                    value={draft.benchmarkConfirmDrop ?? 0.05}
                    onChange={(v) => setDraftField("benchmarkConfirmDrop", v)} />
                </div>
              </div>

              {/* ----- Column 2: Spread Safeguards ----- */}
              <div className="rounded-lg border border-zinc-800 bg-zinc-950/30 p-4">
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Spread Safeguards
                </h3>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <NumberInput label="Max spread (discard above)" source={status?.config?.sources?.maxSpread} step={0.05} min={0.05} max={5}
                    value={draft.maxSpread ?? 0.5}
                    onChange={(v) => setDraftField("maxSpread", v)} />
                  <NumberInput label="Absurd spread cap (always reject)" step={0.10} min={0.5} max={10}
                    value={draft.absurdSpreadCap ?? 1.5}
                    onChange={(v) => setDraftField("absurdSpreadCap", v)} />
                  <NumberInput label="Tight spread (10/10 bonus)" step={0.05} min={0.05} max={5}
                    value={draft.tightSpread ?? 0.15}
                    onChange={(v) => setDraftField("tightSpread", v)} />
                  <NumberInput label="Low-liq max spread (regional cap)" step={0.05} min={0.05} max={5}
                    value={draft.lowLiqMaxSpread ?? 1.0}
                    onChange={(v) => setDraftField("lowLiqMaxSpread", v)} />
                  <NumberInput label="Bypass spread on big drop ≥" source={status?.config?.sources?.bypassSpreadOnBigDrop} step={0.05} min={0.10} max={10}
                    value={draft.bypassSpreadOnBigDrop ?? 0.8}
                    onChange={(v) => setDraftField("bypassSpreadOnBigDrop", v)} />
                </div>
              </div>

              {/* ----- Column 3: Liquidity & Confidence ----- */}
              <div className="rounded-lg border border-zinc-800 bg-zinc-950/30 p-4">
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  Liquidity &amp; Confidence
                </h3>
                <div className="flex flex-col gap-4">
                  {/* HTML5 range slider with live digital counter badge.
                      Backend treats minConfidence as integer 1–10. */}
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs uppercase tracking-wider text-zinc-500">
                        Min confidence (1–10)
                      </span>
                      <span className="rounded-md bg-cyan-600/20 px-2 py-0.5 font-mono text-sm font-bold text-cyan-200 ring-1 ring-cyan-500/40 tabular-nums">
                        {draft.minConfidence ?? 5}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={10}
                      step={1}
                      value={draft.minConfidence ?? 5}
                      onChange={(e) => setDraftField("minConfidence", Number(e.target.value))}
                      className="mt-2 w-full accent-cyan-500"
                    />
                    <div className="mt-1 flex justify-between text-[10px] text-zinc-600 tabular-nums">
                      <span>1</span><span>5</span><span>10</span>
                    </div>
                  </div>
                  <Toggle label="Discard low-liquidity (density gate)"
                    checked={!!draft.requireDensity}
                    onChange={(v) => setDraftField("requireDensity", v)} />
                  {/* HYBRID liquidity-confirmation gate. When ON, odds-drop
                      alerts are short-circuited for matches whose Excapper
                      volume hasn't reached Min Total Volume on any line —
                      EXCEPT watchlist matches, which always run full eval.
                      Default OFF so today's alert stream stays intact.
                      Short label keeps the row visually compact + matches
                      the "Discard low-liquidity" toggle directly above. */}
                  <Toggle label="Require liquidity confirmation"
                    checked={!!draft.requireLiquidityConfirmation}
                    onChange={(v) => setDraftField("requireLiquidityConfirmation", v)} />
                </div>
              </div>

            </div>

            <p className="mt-4 text-[11px] text-zinc-500/80">
              <span className="text-zinc-400">Low-liq regions</span> (S. America lower divs, C. America, Africa) use the
              relaxed cap instead of <span className="font-mono">Max spread</span>. A drop ≥{" "}
              <span className="font-mono">{(draft.bypassSpreadOnBigDrop ?? 0.8).toFixed(2)}</span> bypasses the spread
              gate entirely (fixed-match-style move). Anything above{" "}
              <span className="font-mono">{(draft.absurdSpreadCap ?? 1.5).toFixed(2)}</span> is always rejected as a
              broken quote.
            </p>

            <DropThresholdAutoTuner apiBase={API_BASE} manualApplyRevision={manualApplyRevision} />
            <p className="mt-4 text-xs text-amber-300/80">
              Apply saves filter values to file, but environment variables still take priority. An env-sourced value may remain unchanged after saving.
            </p>
            {/* Apply button bottom-right per design spec. */}
            <div className="mt-5 flex items-center justify-end gap-3">
              {filterSaveError && (
                <span role="alert" className="text-sm text-red-400">✗ Not saved: {filterSaveError}</span>
              )}
              {savedAt && Date.now() - savedAt < 4000 && (
                <span role="status" className="text-sm text-emerald-400">✓ Saved to disk</span>
              )}
              <button
                onClick={save}
                disabled={saving}
                className="rounded-lg bg-cyan-600 px-5 py-2 font-medium text-white transition-colors hover:bg-cyan-500 disabled:opacity-60"
              >
                {saving ? "Saving…" : "Apply filters"}
              </button>
            </div>
          </section>
        )}

        {/* ===== SIGNAL HISTORY — past tips and their outcomes ===== */}
        <section className="mt-10 rounded-xl border border-zinc-800 bg-zinc-900/60 p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-semibold">📋 Signal History</h2>
              <p className="mt-0.5 text-xs text-zinc-500">
                Sent alerts across both sides, including pending and settled results.
              </p>
            </div>
            <button
              onClick={() => loadHistory(historyFilter, 0)}
              disabled={historyLoading}
              className="rounded-lg bg-cyan-700/60 px-4 py-2 text-sm font-medium text-cyan-100 transition hover:bg-cyan-600/70 disabled:opacity-50"
            >
              {historyLoading ? "Loading…" : historyRows === null ? "Load History" : "Refresh"}
            </button>
          </div>

          {/* Filter bar */}
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-1.5 text-xs text-zinc-400">
              Type
              <select
                value={historyFilter.type}
                onChange={(e) => setHistoryFilter((f) => ({ ...f, type: e.target.value as AnomalyHistoryFilter["type"] }))}
                className="rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-zinc-200 focus:border-cyan-500 focus:outline-none"
              >
                <option value="">All</option>
                <option value="ODDS_DROP">Odds Drop</option>
                <option value="MONEY_SPIKE">Money Spike</option>
                <option value="SMART_MONEY">Smart Money</option>
                <option value="EXCAPPER">Smart Excapper</option>
                <option value="RADAR_DROP">Radar Drop</option>
                <option value="RADAR_RISE">Radar Rise</option>
                <option value="RADAR_REVERT">Radar Revert</option>
              </select>
            </label>
            <label className="flex items-center gap-1.5 text-xs text-zinc-400">
              Side
              <select
                value={historyFilter.side}
                onChange={(e) => setHistoryFilter((f) => ({ ...f, side: e.target.value as AnomalyHistoryFilter["side"] }))}
                className="rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-zinc-200 focus:border-cyan-500 focus:outline-none"
              >
                <option value="">All</option>
                <option value="OVER">Over</option>
                <option value="UNDER">Under</option>
                <option value="HOME">Победа хозяев</option>
                <option value="AWAY">Победа гостей</option>
              </select>
            </label>
            <label className="flex items-center gap-1.5 text-xs text-zinc-400">
              Outcome
              <select
                value={historyFilter.status}
                onChange={(e) => setHistoryFilter((f) => ({ ...f, status: e.target.value as AnomalyHistoryFilter["status"] }))}
                className="rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-zinc-200 focus:border-cyan-500 focus:outline-none"
              >
                <option value="">All</option>
                <option value="WIN">WIN</option>
                <option value="LOSS">LOSS</option>
                <option value="PENDING">Pending</option>
                <option value="VOID">Void</option>
              </select>
            </label>
            <label className="flex items-center gap-1.5 text-xs text-zinc-400">
              Period
              <select
                value={historyFilter.days}
                onChange={(e) => setHistoryFilter((f) => ({ ...f, days: e.target.value as AnomalyHistoryFilter["days"] }))}
                className="rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-zinc-200 focus:border-cyan-500 focus:outline-none"
              >
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
                <option value="365">Last 365 days</option>
                <option value="">All time</option>
              </select>
            </label>
          </div>

          {historyError && (
            <div className="mt-3 rounded-md border border-red-900/60 bg-red-950/40 px-3 py-2 text-sm text-red-300">
              {historyError}
            </div>
          )}

          {historyRows === null && !historyLoading && (
            <p className="mt-6 text-sm text-zinc-600">
              Press <span className="font-medium text-zinc-400">Load History</span> to fetch past signals.
            </p>
          )}

          {historyRows !== null && historyRows.length === 0 && (
            <p className="mt-6 text-sm text-zinc-500">No signals match the current filters.</p>
          )}

          {historyRows !== null && historyRows.length > 0 && (
            <>
              <div className="mt-4 overflow-x-auto">
                <table className="w-full min-w-[700px] border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-zinc-800 text-left text-[10px] uppercase tracking-wider text-zinc-500">
                      <th className="pb-2 pr-3">Fired</th>
                      <th className="pb-2 pr-3">Match</th>
                      <th className="pb-2 pr-3">Type</th>
                      <th className="pb-2 pr-3 text-center">Side</th>
                      <th className="pb-2 pr-3 text-center">Line</th>
                      <th className="pb-2 pr-3 text-center">Odds</th>
                      <th className="pb-2 pr-3 text-center">Phase</th>
                      <th className="pb-2 pr-3 text-center">Score at fire</th>
                      <th className="pb-2 pr-3 text-center">Final score</th>
                      <th className="pb-2 text-center">Outcome</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {historyRows.map((row) => {
                      const firedAt = new Date(row.createdAt);
                      const dateStr = firedAt.toLocaleDateString(undefined, {
                        month: "short",
                        day: "numeric",
                      });
                      const timeStr = firedAt.toLocaleTimeString(undefined, {
                        hour: "2-digit",
                        minute: "2-digit",
                      });
                      // The delivered type is authoritative: RADAR source alone
                      // does not tell us which radar movement fired.
                      const signalType = row.anomalyType;
                      const typeLabel = HISTORY_TYPE_LABELS[signalType] ?? signalType;
                      const typeColour =
                        signalType === "ODDS_DROP"
                          ? "text-violet-300"
                          : signalType.startsWith("RADAR_") ? "text-amber-300" : "text-sky-300";
                      const sideColour =
                        row.targetSide === "OVER" ? "text-amber-300"
                        : row.targetSide === "UNDER" ? "text-cyan-300"
                        : row.targetSide === "HOME" || row.targetSide === "AWAY" ? "text-emerald-300" : "text-zinc-500";
                      const marketLabel = row.targetSide === "HOME" ? "Победа хозяев"
                        : row.targetSide === "AWAY" ? "Победа гостей"
                        : row.targetSide === "OVER" && row.line != null ? `Тотал больше ${row.line.toFixed(1)}`
                        : row.targetSide === "UNDER" && row.line != null ? `Тотал меньше ${row.line.toFixed(1)}`
                        : row.targetSide || "—";
                      const phaseLabel =
                        row.minuteBucket === "prematch"
                          ? "pre"
                          : row.minuteBucket === "early"
                            ? "early"
                            : row.minuteBucket === "mid"
                              ? "mid"
                              : row.minuteBucket === "late"
                                ? "late"
                                : "?";
                      // oddsAtFire is stored as HK (decimal - 1)
                      const decimalOdds =
                        row.oddsAtFire != null ? row.oddsAtFire + 1 : null;
                      const scoreAtFire =
                        row.homeScoreAtFire != null && row.awayScoreAtFire != null
                          ? `${row.homeScoreAtFire}–${row.awayScoreAtFire}`
                          : "—";
                      const finalScore =
                        row.finalHomeScore != null && row.finalAwayScore != null
                          ? `${row.finalHomeScore}–${row.finalAwayScore}`
                          : null;
                      const outcomeColour =
                        row.status === "WIN"
                          ? "bg-emerald-500/15 text-emerald-300 ring-emerald-500/40"
                          : row.status === "LOSS"
                            ? "bg-rose-500/15 text-rose-300 ring-rose-500/40"
                            : row.status === "VOID"
                              ? "bg-zinc-700/40 text-zinc-400 ring-zinc-600/50"
                              : "bg-amber-500/10 text-amber-300 ring-amber-500/30";
                      const outcomeLabel =
                        row.status === "WIN"
                          ? "✓ WIN"
                          : row.status === "LOSS"
                            ? "✗ LOSS"
                            : row.status === "VOID"
                              ? "VOID"
                              : "⏳";
                      // Highlight rows where final total beats or misses the line
                      // to make the WIN/LOSS outcome self-evident.
                      const totalVsLine =
                        row.finalHomeScore != null && row.finalAwayScore != null &&
                        (row.targetSide === "HOME" || row.targetSide === "AWAY")
                          ? `Итог: ${row.finalHomeScore}–${row.finalAwayScore}`
                        : row.finalTotal != null && row.line != null
                          ? row.finalTotal > row.line
                            ? `total ${row.finalTotal} > line ${row.line}`
                            : row.finalTotal < row.line
                              ? `total ${row.finalTotal} < line ${row.line}`
                              : `total ${row.finalTotal} = line ${row.line} (push)`
                          : null;
                      return (
                        <tr
                          key={`${row.source ?? "anomaly"}:${row.id}`}
                          className="group transition-colors hover:bg-zinc-800/30"
                          title={totalVsLine ?? undefined}
                        >
                          <td className="py-2 pr-3 text-zinc-500">
                            <div className="leading-4">{dateStr}</div>
                            <div className="text-[10px] text-zinc-600">{timeStr}</div>
                          </td>
                          <td className="py-2 pr-3">
                            <div className="font-medium text-zinc-200 leading-4">
                              {row.team1} <span className="text-zinc-600">vs</span> {row.team2}
                            </div>
                            <div className="text-[10px] text-zinc-600 truncate max-w-[160px]" title={row.league}>
                              {row.league || "—"}
                            </div>
                          </td>
                          <td className={`py-2 pr-3 font-medium ${typeColour}`}>{typeLabel}</td>
                          <td className={`py-2 pr-3 text-center font-bold ${sideColour}`}>
                            {marketLabel}
                          </td>
                          <td className="py-2 pr-3 text-center font-mono text-zinc-300">
                            {row.line != null ? row.line.toFixed(1) : "—"}
                          </td>
                          <td className="py-2 pr-3 text-center font-mono text-zinc-400">
                            {decimalOdds != null ? decimalOdds.toFixed(2) : "—"}
                          </td>
                          <td className="py-2 pr-3 text-center text-zinc-500 capitalize">
                            {phaseLabel}
                            {row.matchMinute != null && (
                              <span className="ml-0.5 text-zinc-600">{row.matchMinute}'</span>
                            )}
                          </td>
                          <td className="py-2 pr-3 text-center font-mono text-zinc-400">
                            {scoreAtFire}
                          </td>
                          <td className="py-2 pr-3 text-center font-mono">
                            {finalScore != null ? (
                              <span className={row.status === "WIN" ? "text-emerald-400" : row.status === "LOSS" ? "text-rose-400" : "text-zinc-400"}>
                                {finalScore}
                              </span>
                            ) : (
                              <span className="text-zinc-600">—</span>
                            )}
                          </td>
                          <td className="py-2 text-center">
                            <span
                              className={`inline-flex items-center rounded-sm px-1.5 py-0.5 text-[10px] font-bold ring-1 ${outcomeColour}`}
                            >
                              {outcomeLabel}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="mt-4 flex items-center justify-between text-xs text-zinc-500">
                <span>
                  Showing {historyOffset + 1}–{Math.min(historyOffset + HISTORY_LIMIT, historyTotal)} of {historyTotal} signals
                </span>
                <div className="flex gap-2">
                  <button
                    disabled={historyOffset === 0 || historyLoading}
                    onClick={() => loadHistory(historyFilter, Math.max(0, historyOffset - HISTORY_LIMIT))}
                    className="rounded border border-zinc-700 px-3 py-1 transition hover:border-zinc-600 hover:text-zinc-300 disabled:opacity-30"
                  >
                    ← Prev
                  </button>
                  <button
                    disabled={historyOffset + HISTORY_LIMIT >= historyTotal || historyLoading}
                    onClick={() => loadHistory(historyFilter, historyOffset + HISTORY_LIMIT)}
                    className="rounded border border-zinc-700 px-3 py-1 transition hover:border-zinc-600 hover:text-zinc-300 disabled:opacity-30"
                  >
                    Next →
                  </button>
                </div>
              </div>
            </>
          )}
        </section>

        <footer className="mt-10 text-center text-xs text-zinc-600">
          Auto-refreshes every 12 seconds · Pro mode · Reserved VM
        </footer>
      </div>
    </div>
  );
}

function NumberInput({
  label, source, value, min, max, step, onChange,
}: {
  label: string; source?: "env" | "file" | "default"; value: number; min: number; max: number; step: number; onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-zinc-500">
        {label}{source && <span className="ml-1 rounded border border-zinc-700 px-1 text-cyan-300" data-testid={`source-${label}`}>{source}</span>}
      </span>
      <input
        type="number" step={step} min={min} max={max} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 outline-none focus:border-cyan-500"
      />
    </label>
  );
}

function Toggle({
  label, checked, onChange,
}: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-zinc-800 bg-zinc-950/40 px-3 py-2.5">
      <span className="text-sm text-zinc-200">{label}</span>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
          checked ? "bg-cyan-600" : "bg-zinc-700"
        }`}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            checked ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </button>
    </label>
  );
}
