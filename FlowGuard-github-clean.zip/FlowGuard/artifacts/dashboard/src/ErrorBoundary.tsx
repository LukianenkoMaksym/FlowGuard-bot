import { Component, type ErrorInfo, type ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  error: Error | null;
  source: "render" | "global" | "rejection" | null;
}

// How many times we silently auto-recover before falling back to a manual
// button. A burst of crashes means something is genuinely wrong, so we stop
// retrying to avoid a reload/recover loop that pegs the CPU.
const MAX_AUTO_RECOVERIES = 3;
// Delay before an automatic soft recovery attempt.
const AUTO_RECOVER_MS = 6000;
// If this long has passed since the previous crash, treat the next one as
// fresh and reset the attempt counter. This is what lets the dashboard stay
// up for hours unattended: an occasional transient crash always self-heals,
// while a tight crash loop still gives up after MAX_AUTO_RECOVERIES.
const ATTEMPT_RESET_MS = 120_000;

// Noisy-but-harmless errors that must never take over the screen.
const BENIGN_PATTERNS: RegExp[] = [
  /ResizeObserver loop/i,
  /Non-Error promise rejection captured/i,
];

function isBenign(message: string): boolean {
  return BENIGN_PATTERNS.some((re) => re.test(message));
}

/**
 * Top-level resilience boundary.
 *
 * React error boundaries only catch errors thrown during render/commit. That
 * leaves the dashboard exposed to the failures that actually cause a "dead
 * window" in a long-running session: uncaught errors in async callbacks/timers
 * and unhandled promise rejections. This boundary also listens for those at the
 * window level, surfaces the real error message, and auto-recovers without a
 * manual reload so the screen comes back on its own.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null, source: null };

  private attempts = 0;
  private lastErrorAt = 0;
  private autoTimer: number | null = null;

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { error, source: "render" };
  }

  componentDidMount(): void {
    window.addEventListener("error", this.handleWindowError);
    window.addEventListener("unhandledrejection", this.handleRejection);
  }

  componentWillUnmount(): void {
    window.removeEventListener("error", this.handleWindowError);
    window.removeEventListener("unhandledrejection", this.handleRejection);
    if (this.autoTimer != null) window.clearTimeout(this.autoTimer);
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error("[dashboard] render error caught by boundary", error, info);
    this.registerError();
  }

  // Uncaught errors that escape React entirely (event handlers, setInterval
  // callbacks). These are the "silent" crashes the old boundary never saw.
  //
  // We only take over the screen for genuine runtime exceptions — i.e. events
  // that carry a real Error object. Resource-load failures (img/script/link)
  // also fire a window "error" event but have no `.error`, and cross-origin
  // script failures surface as an empty "Script error." with none either;
  // neither breaks the React tree, so we must not hijack the page for them.
  private handleWindowError = (event: ErrorEvent): void => {
    if (!(event.error instanceof Error)) return;
    const message = event.error.message || event.message || "Unknown error";
    if (isBenign(message)) return;
    console.error("[dashboard] uncaught window error", event.error);
    if (this.state.error) return; // already showing the fallback
    this.setState({ error: event.error, source: "global" });
    this.registerError();
  };

  // Unhandled promise rejections (e.g. a stray failed fetch) almost never break
  // the rendered tree, so we surface them in the console for diagnosis but do
  // NOT take over the screen — doing so would blank a perfectly working
  // dashboard over a background hiccup.
  private handleRejection = (event: PromiseRejectionEvent): void => {
    const reason = event.reason;
    const message = reason instanceof Error ? reason.message : String(reason);
    if (isBenign(message)) return;
    console.error("[dashboard] unhandled promise rejection", reason);
  };

  // Decide whether to schedule an automatic recovery, resetting the attempt
  // budget if enough quiet time has elapsed since the last crash.
  private registerError(): void {
    const now = Date.now();
    if (now - this.lastErrorAt > ATTEMPT_RESET_MS) this.attempts = 0;
    this.lastErrorAt = now;
    this.scheduleAutoRecover();
  }

  private scheduleAutoRecover(): void {
    if (this.autoTimer != null) return;
    if (this.attempts >= MAX_AUTO_RECOVERIES) return;
    this.autoTimer = window.setTimeout(() => {
      this.autoTimer = null;
      this.attempts += 1;
      this.setState({ error: null, source: null });
    }, AUTO_RECOVER_MS);
  }

  private handleRetry = (): void => {
    if (this.autoTimer != null) {
      window.clearTimeout(this.autoTimer);
      this.autoTimer = null;
    }
    this.setState({ error: null, source: null });
  };

  private handleReload = (): void => {
    window.location.reload();
  };

  render(): ReactNode {
    const { error, source } = this.state;
    if (!error) return this.props.children;

    const autoRecovering = this.attempts < MAX_AUTO_RECOVERIES;
    const message = error.message || "An unexpected error occurred.";

    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#0a0a0a",
          color: "#e5e5e5",
          fontFamily: "Inter, system-ui, sans-serif",
          padding: "1.5rem",
        }}
      >
        <div style={{ maxWidth: "32rem", textAlign: "center" }}>
          <h1 style={{ fontSize: "1.25rem", fontWeight: 600, marginBottom: "0.5rem" }}>
            The dashboard hit an error
          </h1>
          <p style={{ fontSize: "0.875rem", color: "#a3a3a3", marginBottom: "1rem" }}>
            {source === "render"
              ? "Something failed while drawing the page. This is often caused by a browser extension or page translation modifying the page — if you have automatic translation on for this site, turn it off."
              : "A background process failed. The dashboard will try to recover on its own."}
          </p>
          <pre
            style={{
              fontSize: "0.75rem",
              color: "#f87171",
              background: "#1a1a1a",
              border: "1px solid #2a2a2a",
              borderRadius: "0.5rem",
              padding: "0.625rem 0.75rem",
              marginBottom: "1.25rem",
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              textAlign: "left",
            }}
          >
            {message}
          </pre>
          {autoRecovering && (
            <p style={{ fontSize: "0.8125rem", color: "#737373", marginBottom: "1rem" }}>
              Attempting automatic recovery…
            </p>
          )}
          <div style={{ display: "flex", gap: "0.75rem", justifyContent: "center" }}>
            <button
              type="button"
              onClick={this.handleRetry}
              style={{
                background: "#2563eb",
                color: "white",
                border: "none",
                borderRadius: "0.5rem",
                padding: "0.5rem 1rem",
                fontSize: "0.875rem",
                fontWeight: 500,
                cursor: "pointer",
              }}
            >
              Try again
            </button>
            <button
              type="button"
              onClick={this.handleReload}
              style={{
                background: "transparent",
                color: "#e5e5e5",
                border: "1px solid #404040",
                borderRadius: "0.5rem",
                padding: "0.5rem 1rem",
                fontSize: "0.875rem",
                fontWeight: 500,
                cursor: "pointer",
              }}
            >
              Reload dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }
}
