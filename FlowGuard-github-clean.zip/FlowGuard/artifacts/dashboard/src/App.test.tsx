import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import App, {
  availableExcapperVolumes,
  isCurrentLiveWatchlistEntry,
  savedNonLiveWatchlistEntries,
  type WatchlistLiveEntry,
  type WatchlistResponse,
} from "./App";

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("Signal History", () => {
  it("fetches all sides by default and shows real delivered types, settled UNDER, and pending rows without inventing scores", async () => {
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      let body: unknown;
      if (url === "/api/auth/me") body = { authenticated: true };
      else if (url === "/api/scanner/status") body = { config: {}, recentAnomalies: [] };
      else if (url === "/api/scanner/health") body = { ok: true, telegramPolling: { shouldPoll: false, reason: "test" } };
      else if (url === "/api/scanner/controls") body = { ok: false };
      else if (url === "/api/watchlist") body = { ok: true, entries: [] };
      else if (url === "/api/winrate/stats") body = {
        ok: true, stats: {
          side: "OVER", byStatus: { pending: 0, win: 3, loss: 1, void: 0 },
          resolved: { wins: 3, losses: 1, total: 4, winRatePct: 75 }, byPattern: [],
        },
      };
      else if (url.startsWith("/api/winrate/history?")) body = {
        ok: true, total: 8, rows: [
          {
            id: 1, matchId: "1", team1: "Under Home", team2: "Under Away",
            league: "League", anomalyType: "MONEY_SPIKE", source: "LEGACY", targetSide: "UNDER",
            line: 2.5, minuteBucket: "mid", matchMinute: 65,
            homeScoreAtFire: 1, awayScoreAtFire: 0, oddsAtFire: 0.8,
            status: "WIN", finalHomeScore: 1, finalAwayScore: 1,
            finalTotal: 2, createdAt: "2026-08-01T12:00:00Z", resolvedAt: "2026-08-01T15:00:00Z",
          },
          {
            id: -2, matchId: "", team1: "Radar Home", team2: "Radar Away",
            league: "League", anomalyType: "RADAR_DROP", source: "RADAR", targetSide: "",
            line: null, minuteBucket: null, matchMinute: null,
            homeScoreAtFire: null, awayScoreAtFire: null, oddsAtFire: null,
            status: "PENDING", finalHomeScore: null, finalAwayScore: null,
            finalTotal: null, createdAt: "2026-08-01T12:00:00Z", resolvedAt: null,
          },
          {
            id: -22, matchId: "654321", team1: "1X2 Hosts", team2: "1X2 Visitors",
            league: "League", anomalyType: "RADAR_RISE", source: "RADAR", targetSide: "HOME",
            line: null, minuteBucket: "late", matchMinute: 67,
            homeScoreAtFire: 0, awayScoreAtFire: 0, oddsAtFire: 1.2,
            status: "WIN", finalHomeScore: 2, finalAwayScore: 1,
            finalTotal: 3, createdAt: "2026-08-01T12:00:00Z", resolvedAt: "2026-08-01T15:00:00Z",
          },
          ...(["RADAR_RISE", "RADAR_LINE", "RADAR_REVERT", "SMART_MONEY", "EXCAPPER"] as const).map((anomalyType, index) => ({
            id: -index - 3, matchId: "", team1: `${anomalyType} Home`, team2: "Away",
            league: "League", anomalyType, source: anomalyType.startsWith("RADAR_") ? "RADAR" : "TELEGRAM",
            targetSide: "UNDER", line: null, minuteBucket: "unknown", matchMinute: null,
            homeScoreAtFire: null, awayScoreAtFire: null, oddsAtFire: null,
            status: "PENDING", finalHomeScore: null, finalAwayScore: null,
            finalTotal: null, createdAt: "2026-08-01T12:00:00Z", resolvedAt: null,
          })),
        ],
      };
      else throw new Error(`Unexpected request: ${url}`);
      return new Response(JSON.stringify(body), { headers: { "Content-Type": "application/json" } });
    });
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);
    const section = (await screen.findByRole("heading", { name: /Signal History/ })).closest("section")!;
    expect((within(section).getByLabelText("Side") as HTMLSelectElement).value).toBe("");
    const typeFilter = within(section).getByLabelText("Type") as HTMLSelectElement;
    expect(Array.from(typeFilter.options).map((option) => option.value)).toEqual([
      "", "ODDS_DROP", "MONEY_SPIKE", "SMART_MONEY", "EXCAPPER",
      "RADAR_DROP", "RADAR_RISE", "RADAR_REVERT",
    ]);
    fireEvent.click(within(section).getByRole("button", { name: "Load History" }));
    const under = (await within(section).findByText(/Under Home/)).closest("tr")!;
    const radar = within(section).getByText(/Radar Home/).closest("tr")!;
    expect(within(under).getByText("Money Spike")).toBeTruthy();
    expect(within(under).getByText("Тотал меньше 2.5")).toBeTruthy();
    expect(within(under).getByText("✓ WIN")).toBeTruthy();
    expect(within(under).getByText("1–0")).toBeTruthy();
    expect(within(under).getByText("1–1")).toBeTruthy();
    expect(within(radar).getByText("Radar Drop")).toBeTruthy();
    expect(within(radar).getByText("⏳")).toBeTruthy();
    expect(within(radar).getAllByText("—").length).toBeGreaterThanOrEqual(4);
    expect(within(radar).queryByText("0–0")).toBeNull();
    expect(within(radar).queryByRole("link")).toBeNull();
    const oneX2 = within(section).getByText(/1X2 Hosts/).closest("tr")!;
    expect(within(oneX2).getByText("Победа хозяев")).toBeTruthy();
    expect(within(oneX2).getByText("—")).toBeTruthy();
    expect(within(oneX2).getByText("✓ WIN")).toBeTruthy();
    for (const label of ["Radar Rise", "Radar Line (archived)", "Radar Revert", "Smart Money", "Smart Excapper"]) {
      expect(within(section).getAllByRole("cell", { name: label }).length).toBeGreaterThan(0);
    }
    const historyUrl = fetchMock.mock.calls.map(([request]) => String(request)).find((url) => url.startsWith("/api/winrate/history?"))!;
    expect(new URL(historyUrl, "http://localhost").searchParams.has("side")).toBe(false);
    expect(screen.getByText("75%")).toBeTruthy();
    expect(fetchMock.mock.calls.some(([request]) => String(request) === "/api/winrate/stats")).toBe(true);

    fireEvent.change(within(section).getByLabelText("Side"), { target: { value: "UNDER" } });
    fireEvent.click(within(section).getByRole("button", { name: "Refresh" }));
    await waitFor(() => expect(fetchMock.mock.calls.filter(([request]) => String(request).includes("/api/winrate/history?side=UNDER")).length).toBe(1));
    fireEvent.change(within(section).getByLabelText("Side"), { target: { value: "HOME" } });
    fireEvent.click(within(section).getByRole("button", { name: "Refresh" }));
    await waitFor(() => expect(fetchMock.mock.calls.filter(([request]) => String(request).includes("/api/winrate/history?side=HOME")).length).toBe(1));
    fireEvent.change(typeFilter, { target: { value: "RADAR_REVERT" } });
    fireEvent.click(within(section).getByRole("button", { name: "Refresh" }));
    await waitFor(() => expect(fetchMock.mock.calls.some(([request]) => {
      const url = String(request);
      return url.startsWith("/api/winrate/history?") && new URL(url, "http://localhost").searchParams.get("type") === "RADAR_REVERT";
    })).toBe(true));
  });
});

describe("independent NowGoal and Excapper display", () => {
  const live: WatchlistLiveEntry["live"] = {
    matchId: "3094867", team1: "Home", team2: "Away", league: "Test",
    isLive: true, matchStatus: "live", homeScore: 0, awayScore: 2,
    minute: null, line: 3.25, overHk: 0.83, underHk: 0.8,
    prevLine: null, prevOverHk: null, prevUnderHk: null,
    overDeltaHk: null, underDeltaHk: null, overTrend: "flat", underTrend: "flat",
    lineChanged: false, lastChangeAgoSec: null, lastSeenAgoSec: 5, historyPoints: 1,
    volumes: [],
  };
  const volume: NonNullable<WatchlistLiveEntry["excapperVolumes"]>[number] = {
    line: 3.5, over: 220, under: 120, totalVolume: 340, overSharePct: 64.7,
    underSharePct: 35.3, overDelta: null, underDelta: null,
    overSpike: false, underSpike: false, updatedAgoSec: 4,
  };
  const entry: WatchlistLiveEntry = {
    label: "Home vs Away", fragments: ["Home", "Away"], matchId: "3094867",
    signature: "id:3094867", live, excapperVolumes: [],
    excapperBinding: { status: "fetch_failed", source: null, lastSuccessfulUpdateAt: null },
  };

  it("prefers a populated source sample over a live empty array, then prefers live samples when they arrive", () => {
    expect(availableExcapperVolumes({ ...entry, excapperVolumes: [volume] })).toEqual([volume]);
    expect(availableExcapperVolumes({ ...entry, excapperVolumes: [volume], live: { ...live, volumes: [{ ...volume, line: 4.5 }] } })[0]?.line).toBe(4.5);
  });

  it("renders live score, Bet365 odds and unknown minute without an Excapper ID, then updates volumes without a modal", async () => {
    let current = entry;
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      let body: unknown;
      if (url === "/api/auth/me") body = { authenticated: true };
      else if (url === "/api/scanner/status") body = { config: {}, recentAnomalies: [] };
      else if (url === "/api/scanner/health") body = { ok: true, telegramPolling: { shouldPoll: false, reason: "test" } };
      else if (url === "/api/scanner/controls") body = { ok: false };
      else if (url === "/api/winrate/stats") body = { ok: false };
      else if (url === "/api/watchlist") body = { ok: true, entries: [current] };
      else throw new Error(`Unexpected request: ${url}`);
      return new Response(JSON.stringify(body), { status: 200, headers: { "Content-Type": "application/json" } });
    });
    vi.stubGlobal("fetch", fetchMock);
    render(<App />);
    expect(await screen.findByText("0 – 2")).toBeTruthy();
    expect(screen.getByText("min —")).toBeTruthy();
    expect(screen.queryByTestId("excapper-source-clock")).toBeNull();
    expect(screen.getByText("[3.25]")).toBeTruthy();
    expect(screen.getAllByText("0.80").length).toBeGreaterThan(0);
    const readiness = screen.getByTestId("excapper-source-readiness");
    expect(readiness.textContent).toBe("EXC —!");
    expect(readiness.title).toContain("no accepted volume sample");
    expect(readiness.closest("td")?.classList.contains("watchlist-updated-column")).toBe(true);
    expect(readiness.closest("td")?.textContent).toBe("NG 5s · EXC —!");
    const totalCell = screen.getByRole("button", { name: "Review Request" }).closest("td");
    expect(totalCell?.querySelector('[data-testid="excapper-source-readiness"]')).toBeNull();
    expect(screen.queryByText(/Excapper source:/)).toBeNull();
    current = { ...entry, excapperVolumes: [volume], excapperBinding: {
      status: "hydrated", lastSuccessfulUpdateAt: Date.now() - 5_000,
      source: { team1: "Home", team2: "Away", league: "Test",
        score: { home: 1, away: 1 }, minute: 57, period: "second-half" },
    } };
    fireEvent.click(screen.getByRole("button", { name: "Refresh" }));
    await waitFor(() => expect(screen.getByText("3.5")).toBeTruthy());
    expect(screen.getByTestId("excapper-source-readiness").textContent).toMatch(/^EXC \d+s$/);
    expect(screen.getByTestId("excapper-source-readiness").title).toContain("57′");
    expect(screen.queryByTestId("excapper-source-clock")).toBeNull();
    expect(screen.getByText("0 – 2")).toBeTruthy();
    expect(screen.getByText("min —")).toBeTruthy();
    expect(screen.queryByRole("dialog")).toBeNull();
  });
});

describe("scanner health Telegram polling ownership", () => {
  it.each([
    {
      shouldPoll: true,
      reason: "Production instance owns Telegram polling",
      state: "Active",
      labelClass: "text-emerald-300",
      borderClass: "border-emerald-900/60",
      backgroundClass: "bg-emerald-950/30",
      reasonClass: "text-emerald-100/80",
    },
    {
      shouldPoll: false,
      reason: "Development instance defers polling to production",
      state: "Disabled",
      labelClass: "text-zinc-400",
      borderClass: "border-zinc-700",
      backgroundClass: "bg-zinc-950/40",
      reasonClass: "text-zinc-500",
    },
  ])("renders $state ownership from the health response", async ({
    shouldPoll, reason, state, labelClass, borderClass, backgroundClass, reasonClass,
  }) => {
    // Only the network boundary is mocked: App must fetch health, store it,
    // and render it in the real panel. A disconnected consumer must fail.
    const responses: Record<string, unknown> = {
      "/api/auth/me": { authenticated: true },
      "/api/scanner/status": { config: {}, recentAnomalies: [] },
      "/api/scanner/health": {
        ok: true,
        upstream: { currentBase: "https://example.test", lastFailoverAt: null, failoverHistory: [] },
        watchdog: { lastLiveSeenAt: null, lastAlarmAt: null, staleLiveThresholdSec: 300 },
        lastValidation: null,
        telegramPolling: { shouldPoll, reason },
      },
      "/api/scanner/controls": { ok: false },
      "/api/watchlist": { ok: true, entries: [] },
      "/api/winrate/stats": { ok: false },
    };
    const fetchMock = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (!(url in responses)) throw new Error(`Unexpected request: ${url}`);
      return new Response(JSON.stringify(responses[url]), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    });
    vi.stubGlobal("fetch", fetchMock);

    render(<App />);

    const label = await screen.findByText(/^[✓○] Telegram polling$/);
    const panel = screen.getByRole("heading", { name: "Self-Check & Watchdog" }).closest("section")!;
    expect(within(panel).getByText(/^[✓○] Telegram polling$/)).toBe(label);
    const detail = within(panel).getByText(`${state} · ${reason}`);
    expect(label.classList.contains(labelClass)).toBe(true);
    expect(label.parentElement!.classList.contains(borderClass)).toBe(true);
    expect(label.parentElement!.classList.contains(backgroundClass)).toBe(true);
    expect(detail.classList.contains(reasonClass)).toBe(true);
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/scanner/health",
      expect.objectContaining({ credentials: "include", signal: expect.any(AbortSignal) }),
    );
  });
});

describe("scanner count provenance", () => {
  it.each([
    {
      name: "reports distinct upstream, whitelist, scheduled, confirmed, and tracked counts",
      status: {
        leaguesLoaded: 148,
        whitelistSize: 21,
        scheduleMatchesSeen: 291,
        liveMatchesConfirmed: 7,
        minorMatchesTracked: 12,
        liveMatchesTracked: 3,
      },
      values: ["148", "21", "291", "7", "12", "3"],
    },
    {
      name: "does not infer unavailable counts from other fields",
      status: { leaguesLoaded: 148, minorMatchesTracked: 12, liveMatchesTracked: 3 },
      values: ["148", "unknown", "unknown", "unknown", "12", "3"],
    },
  ])("$name", async ({ status, values }) => {
    const responses: Record<string, unknown> = {
      "/api/auth/me": { authenticated: true },
      "/api/scanner/status": { ...status, config: {}, recentAnomalies: [] },
      "/api/scanner/health": {
        ok: true,
        upstream: { currentBase: "https://example.test", lastFailoverAt: null, failoverHistory: [] },
        watchdog: { lastLiveSeenAt: null, lastAlarmAt: null, staleLiveThresholdSec: 300 },
        lastValidation: {
          ok: true,
          ranAt: "2026-08-01T12:00:00Z",
          base: "https://example.test",
          summary: "291 scheduled kickoffs in -6/+36h window · upstream league directory: 148 · whitelist leagues: 21",
          endpoints: [],
          freshness: { ok: true, matchesNearNow: 291, oldestKickoffIso: null, newestKickoffIso: null },
        },
        telegramPolling: { shouldPoll: false, reason: "Development" },
      },
      "/api/scanner/controls": { ok: false },
      "/api/watchlist": { ok: true, entries: [] },
      "/api/winrate/stats": { ok: false },
    };
    vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (!(url in responses)) throw new Error(`Unexpected request: ${url}`);
      return new Response(JSON.stringify(responses[url]), {
        headers: { "Content-Type": "application/json" },
      });
    }));

    render(<App />);
    const labels = [
      "Upstream league directory",
      "Whitelist leagues",
      "Schedule matches seen",
      "Live confirmed (feed)",
      "Matches tracked (post-filter)",
      "Live tracked (post-filter)",
    ];
    await screen.findByText("148");
    labels.forEach((label, index) => {
      const card = screen.getByText(label).closest<HTMLElement>("div.rounded-xl")!;
      expect(within(card).getByText(values[index])).toBeTruthy();
    });
    expect(screen.getByText(/Freshness:.*291 scheduled kickoffs in -6\/\+36h window/)).toBeTruthy();
  });
});

describe("manual filter sources and Apply", () => {
  const fields = [
    ["Drop threshold (decimal pts)", "dropThreshold"],
    ["Max spread (discard above)", "maxSpread"],
    ["Bypass spread on big drop ≥", "bypassSpreadOnBigDrop"],
  ] as const;
  const config = {
    dropThreshold: 0.4,
    maxSpread: 0.5,
    tightSpread: 0.15,
    benchmarkConfirmDrop: 0.05,
    minConfidence: 5,
    requireDensity: false,
    requireLiquidityConfirmation: false,
    lowLiqMaxSpread: 1,
    bypassSpreadOnBigDrop: 0.8,
    absurdSpreadCap: 1.5,
  };

  function mockScanner(initial: Record<string, unknown>, applied?: Record<string, unknown>) {
    const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = String(input);
      let body: unknown;
      if (url === "/api/auth/me") body = { authenticated: true };
      else if (url === "/api/scanner/status") body = { config: applied && fetchMock.mock.calls.some(
        ([request, options]) => String(request) === "/api/scanner/config" && options?.method === "PATCH",
      ) ? applied : initial, recentAnomalies: [] };
      else if (url === "/api/scanner/config" && init?.method === "PATCH") body = { ok: true, persisted: true, config: applied };
      else if (url === "/api/scanner/health") body = { ok: true, telegramPolling: { shouldPoll: false, reason: "test" } };
      else if (url === "/api/watchlist") body = { ok: true, entries: [] };
      else if (url === "/api/winrate/stats") body = { ok: false };
      else if (url === "/api/scanner/auto-tuner") body = { error: "unavailable in this test" };
      else if (url === "/api/scanner/controls") body = { ok: false };
      else throw new Error(`Unexpected request: ${url}`);
      return new Response(JSON.stringify(body), {
        status: url === "/api/scanner/auto-tuner" ? 503 : 200,
        headers: { "Content-Type": "application/json" },
      });
    });
    vi.stubGlobal("fetch", fetchMock);
    return fetchMock;
  }

  it.each(["env", "file", "default"] as const)("shows %s beside each of the three labels", async (source) => {
    mockScanner({ ...config, sources: {
      dropThreshold: source, maxSpread: source, bypassSpreadOnBigDrop: source,
    } });
    render(<App />);
    for (const [label] of fields) {
      expect((await screen.findByTestId(`source-${label}`)).textContent).toBe(source);
      expect(screen.getByTestId(`source-${label}`).closest("label")?.querySelector("input")).toBeTruthy();
    }
    expect(screen.getByText(/Apply saves filter values to file, but environment variables still take priority/)).toBeTruthy();
  });

  it("sends only filter values and displays effective server values and sources after Apply", async () => {
    const fetchMock = mockScanner(
      { ...config, sources: { dropThreshold: "file", maxSpread: "file", bypassSpreadOnBigDrop: "file" } },
      { ...config, dropThreshold: 0.4, maxSpread: 0.65, bypassSpreadOnBigDrop: 0.9,
        sources: { dropThreshold: "env", maxSpread: "file", bypassSpreadOnBigDrop: "default" } },
    );
    render(<App />);
    const input = (label: string) =>
      screen.getByTestId(`source-${label}`).closest("label")!.querySelector("input")!;
    await screen.findByTestId("source-Drop threshold (decimal pts)");
    const drop = input("Drop threshold (decimal pts)");
    fireEvent.change(drop, { target: { value: "0.7" } });
    fireEvent.change(input("Max spread (discard above)"), { target: { value: "0.65" } });
    fireEvent.change(input("Bypass spread on big drop ≥"), { target: { value: "0.9" } });
    fireEvent.click(screen.getByRole("button", { name: "Apply filters" }));
    await screen.findByText("✓ Saved to disk");
    const patchCall = fetchMock.mock.calls.find(
      ([request, options]) => String(request) === "/api/scanner/config" && options?.method === "PATCH",
    );
    expect(patchCall).toBeDefined();
    expect(JSON.parse(patchCall![1]!.body as string)).toEqual({
      ...config, dropThreshold: 0.7, maxSpread: 0.65, bypassSpreadOnBigDrop: 0.9,
    });
    await waitFor(() => {
      expect(screen.getByTestId("source-Drop threshold (decimal pts)").textContent).toBe("env");
      expect(screen.getByTestId("source-Max spread (discard above)").textContent).toBe("file");
      expect(screen.getByTestId("source-Bypass spread on big drop ≥").textContent).toBe("default");
      expect(input("Drop threshold (decimal pts)").value).toBe("0.4");
      expect(input("Max spread (discard above)").value).toBe("0.65");
      expect(input("Bypass spread on big drop ≥").value).toBe("0.9");
    });
  });
});

describe("active watchlist lifecycle guard", () => {
  const entry = (live: Record<string, unknown> | null) =>
    ({ signature: "test", label: "Test", fragments: [], matchId: "1", live }) as never;

  it("includes live and excludes cached, finished, scheduled, and unresolved rows", () => {
    expect(
      isCurrentLiveWatchlistEntry(entry({ isLive: true, matchStatus: "live" })),
    ).toBe(true);
    expect(
      isCurrentLiveWatchlistEntry(entry({ isLive: true, matchStatus: "finished" })),
    ).toBe(false);
    expect(
      isCurrentLiveWatchlistEntry(entry({ isLive: true, matchStatus: "scheduled" })),
    ).toBe(false);
    expect(
      isCurrentLiveWatchlistEntry(entry({ isLive: true, matchStatus: "unknown" })),
    ).toBe(false);
    expect(isCurrentLiveWatchlistEntry(entry(null))).toBe(false);
  });

  it("uses savedEntries for non-live management without feeding active entries", () => {
    const live = entry({ isLive: true, matchStatus: "live" });
    const scheduled = entry({ isLive: false, matchStatus: "scheduled" });
    const response = {
      entries: [live],
      savedEntries: [live, scheduled],
    } as unknown as WatchlistResponse;

    expect(savedNonLiveWatchlistEntries(response, false)).toEqual([scheduled]);
    expect(isCurrentLiveWatchlistEntry(response.entries[0])).toBe(true);
  });

  it("honors an explicitly empty savedEntries list instead of falling back", () => {
    const response = {
      entries: [entry({ isLive: false, matchStatus: "scheduled" })],
      savedEntries: [],
    } as unknown as WatchlistResponse;

    expect(savedNonLiveWatchlistEntries(response, false)).toEqual([]);
  });

  it("treats explicit status as authoritative and never infers from minute", () => {
    expect(
      isCurrentLiveWatchlistEntry(
        entry({ isLive: true, matchStatus: "finished", minute: 55 }),
      ),
    ).toBe(false);
    expect(
      isCurrentLiveWatchlistEntry(entry({ isLive: false, matchStatus: "live" })),
    ).toBe(true);
    expect(isCurrentLiveWatchlistEntry(entry({ isLive: false, minute: 55 }))).toBe(false);
  });
});