import { act, cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  useVolumeIncreases,
  type VolumeObservation,
} from "./use-volume-increases";

function Harness({ observations }: { observations: VolumeObservation[] }) {
  const increases = useVolumeIncreases(observations);
  return (
    <div>
      {[...increases].map(([key, increase]) => (
        <span key={key} data-testid={key}>
          {increase.delta}
        </span>
      ))}
    </div>
  );
}

const key = "match-1|2.5|over";
const sample = (amount: number): VolumeObservation[] => [{ key, amount }];

afterEach(() => {
  cleanup();
  vi.useRealTimers();
});

describe("useVolumeIncreases", () => {
  it("uses the initial cumulative amount only as a baseline", () => {
    render(<Harness observations={sample(42_800)} />);
    expect(screen.queryByTestId(key)).toBeNull();
  });

  it("does not replay or renew a badge on an unchanged poll", () => {
    vi.useFakeTimers();
    const view = render(<Harness observations={sample(100)} />);
    view.rerender(<Harness observations={sample(110)} />);
    expect(screen.getByTestId(key).textContent).toBe("10");

    act(() => vi.advanceTimersByTime(9_000));
    view.rerender(<Harness observations={sample(110)} />);
    act(() => vi.advanceTimersByTime(1_001));

    expect(screen.queryByTestId(key)).toBeNull();
  });

  it("shows the same increase amount again when a later cumulative event is real", () => {
    vi.useFakeTimers();
    const view = render(<Harness observations={sample(100)} />);
    view.rerender(<Harness observations={sample(110)} />);
    act(() => vi.advanceTimersByTime(10_001));
    expect(screen.queryByTestId(key)).toBeNull();

    view.rerender(<Harness observations={sample(120)} />);
    expect(screen.getByTestId(key).textContent).toBe("10");
  });

  it("treats a cumulative decrease as a reset without fake inbound volume", () => {
    vi.useFakeTimers();
    const view = render(<Harness observations={sample(100)} />);
    view.rerender(<Harness observations={sample(120)} />);
    expect(screen.getByTestId(key)).toBeTruthy();

    view.rerender(<Harness observations={sample(5)} />);
    expect(screen.queryByTestId(key)).toBeNull();

    view.rerender(<Harness observations={sample(8)} />);
    expect(screen.getByTestId(key).textContent).toBe("3");
  });

  it("clears pending expiry timers on unmount", () => {
    vi.useFakeTimers();
    const clearTimeoutSpy = vi.spyOn(globalThis, "clearTimeout");
    const view = render(<Harness observations={sample(100)} />);
    view.rerender(<Harness observations={sample(110)} />);

    view.unmount();

    expect(clearTimeoutSpy).toHaveBeenCalled();
    clearTimeoutSpy.mockRestore();
  });
});