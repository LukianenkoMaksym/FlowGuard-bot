import { useEffect, useRef, useState } from "react";

export interface VolumeObservation {
  key: string;
  amount: number;
}

export interface VolumeIncrease {
  delta: number;
  eventId: number;
}

/**
 * Derives short-lived inbound badges from observed cumulative volume.
 * Server-provided deltas are deliberately not used: comparing cumulative
 * samples prevents an identical poll from replaying or extending an event.
 */
export function useVolumeIncreases(
  observations: VolumeObservation[],
  visibleMs = 10_000,
): ReadonlyMap<string, VolumeIncrease> {
  const previousAmounts = useRef(new Map<string, number>());
  const expiryTimers = useRef(new Map<string, ReturnType<typeof setTimeout>>());
  const nextEventId = useRef(1);
  const [increases, setIncreases] = useState<Map<string, VolumeIncrease>>(
    () => new Map(),
  );

  useEffect(() => {
    const activeKeys = new Set(observations.map(({ key }) => key));

    for (const { key, amount } of observations) {
      if (!Number.isFinite(amount)) continue;

      const previous = previousAmounts.current.get(key);
      previousAmounts.current.set(key, amount);

      // First observation establishes the baseline. Equal samples are stale
      // polls and must not renew the current badge's ten-second lifetime.
      if (previous === undefined || amount === previous) continue;

      if (amount < previous) {
        // A cumulative-feed reset establishes a new baseline, not an inbound
        // event. Remove any badge from the pre-reset sequence.
        const timer = expiryTimers.current.get(key);
        if (timer !== undefined) clearTimeout(timer);
        expiryTimers.current.delete(key);
        setIncreases((current) => {
          if (!current.has(key)) return current;
          const next = new Map(current);
          next.delete(key);
          return next;
        });
        continue;
      }

      const existingTimer = expiryTimers.current.get(key);
      if (existingTimer !== undefined) clearTimeout(existingTimer);

      setIncreases((current) => {
        const next = new Map(current);
        next.set(key, {
          delta: amount - previous,
          eventId: nextEventId.current++,
        });
        return next;
      });

      const timer = setTimeout(() => {
        expiryTimers.current.delete(key);
        setIncreases((current) => {
          if (!current.has(key)) return current;
          const next = new Map(current);
          next.delete(key);
          return next;
        });
      }, visibleMs);
      expiryTimers.current.set(key, timer);
    }

    // Forget removed markets so re-adding one starts with a clean baseline.
    for (const key of previousAmounts.current.keys()) {
      if (activeKeys.has(key)) continue;
      previousAmounts.current.delete(key);
      const timer = expiryTimers.current.get(key);
      if (timer !== undefined) clearTimeout(timer);
      expiryTimers.current.delete(key);
      setIncreases((current) => {
        if (!current.has(key)) return current;
        const next = new Map(current);
        next.delete(key);
        return next;
      });
    }
  }, [observations, visibleMs]);

  useEffect(
    () => () => {
      for (const timer of expiryTimers.current.values()) clearTimeout(timer);
      expiryTimers.current.clear();
    },
    [],
  );

  return increases;
}