import { useCallback, useEffect, useRef, useState } from "react";

export interface AutoTunerStatus {
  enabled: boolean;
  state: "off" | "collecting" | "paused" | "cooldown" | "ready" | "holding" | "error";
  sampleSize: number;
  minSamples: number;
  winRatePct: number | null;
  pausedUntil: string | null;
  lastAdjustment: {
    at: string;
    oldThreshold: number;
    newThreshold: number;
    winRatePct: number;
    sampleSize: number;
  } | null;
  nextAdjustmentAt: string | null;
  dropThreshold: number;
  error?: string;
  persisted?: boolean;
}

function dateLabel(value: string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

function failure(response: Response, body: unknown): string {
  if (body && typeof body === "object" && "error" in body && typeof body.error === "string") {
    return `HTTP ${response.status}: ${body.error}`;
  }
  return `HTTP ${response.status}${response.statusText ? ` ${response.statusText}` : ""}`;
}

export function DropThresholdAutoTuner({
  apiBase,
  manualApplyRevision,
}: {
  apiBase: string;
  manualApplyRevision: number;
}) {
  const [status, setStatus] = useState<AutoTunerStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const controller = useRef<AbortController | null>(null);
  const mounted = useRef(false);
  const mutating = useRef(false);

  const refresh = useCallback(async () => {
    if (!mounted.current || controller.current || mutating.current) return;
    const request = new AbortController();
    controller.current = request;
    try {
      const response = await fetch(`${apiBase}/scanner/auto-tuner`, {
        credentials: "include",
        signal: request.signal,
      });
      const body: unknown = await response.json();
      if (!response.ok) throw new Error(failure(response, body));
      if (!body || typeof body !== "object" || typeof (body as AutoTunerStatus).enabled !== "boolean") {
        throw new Error("Invalid auto-tuner status response.");
      }
      if (mounted.current && !request.signal.aborted) {
        setStatus(body as AutoTunerStatus);
        setError(null);
      }
    } catch (cause) {
      if (!request.signal.aborted && mounted.current) {
        setError(cause instanceof Error ? cause.message : String(cause));
      }
    } finally {
      if (controller.current === request) controller.current = null;
    }
  }, [apiBase]);

  useEffect(() => {
    mounted.current = true;
    void refresh();
    const interval = setInterval(() => void refresh(), 60_000);
    return () => {
      mounted.current = false;
      clearInterval(interval);
      controller.current?.abort();
      controller.current = null;
    };
  }, [refresh]);

  // A successful manual Apply pauses the backend tuner; read its new state without
  // touching the parent's editable filter draft.
  useEffect(() => {
    if (manualApplyRevision > 0) {
      controller.current?.abort();
      controller.current = null;
      void refresh();
    }
  }, [manualApplyRevision, refresh]);

  const toggle = async () => {
    if (!status || mutating.current) return;
    const enabled = !status.enabled;
    mutating.current = true;
    controller.current?.abort();
    controller.current = null;
    setBusy(true);
    setError(null);
    try {
      const response = await fetch(`${apiBase}/scanner/auto-tuner`, {
        method: "PATCH",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled }),
      });
      const body: unknown = await response.json();
      if (!response.ok) throw new Error(failure(response, body));
      if (!body || typeof body !== "object" || (body as AutoTunerStatus).persisted !== true ||
          (body as AutoTunerStatus).enabled !== enabled) {
        throw new Error("Auto-tuner change was not persisted. Retry or refresh to check server state.");
      }
      if (mounted.current) setStatus(body as AutoTunerStatus);
    } catch (cause) {
      if (mounted.current) setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      mutating.current = false;
      if (mounted.current) setBusy(false);
    }
  };

  const stateLabel = status?.state === "off" ? "Off"
    : status?.state === "collecting" ? "Collecting data"
    : status?.state === "paused" ? "Paused"
    : status?.state === "cooldown" ? "Cooldown"
    : status?.state === "ready" ? "Ready"
    : status?.state === "holding" ? "Holding"
    : status?.state === "error" ? "Error" : "Loading";

  return (
    <div className="mt-5 rounded-lg border border-zinc-700 bg-zinc-950/50 p-4 text-xs text-zinc-400" data-testid="panel-drop-auto-tuner">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-zinc-200">Adaptive drop threshold</h3>
          <p className="mt-1">Optional, default OFF. Tunes only dropThreshold from the last 60 real settled ODDS_DROP WIN/LOSS alerts; all other filters remain manual.</p>
        </div>
        <button
          type="button"
          data-testid="button-toggle-drop-auto-tuner"
          aria-label={`Turn auto-tuner ${status?.enabled ? "off" : "on"}`}
          aria-pressed={status?.enabled ?? false}
          disabled={!status || busy}
          onClick={() => void toggle()}
          className="rounded-md border border-zinc-600 px-3 py-1.5 font-medium text-zinc-100 hover:border-cyan-500 disabled:opacity-50"
        >
          {busy ? "Saving…" : status ? (status.enabled ? "ON · Turn off" : "OFF · Turn on") : "Loading…"}
        </button>
      </div>
      {status && (
        <div className="mt-3 space-y-1" data-testid="status-drop-auto-tuner">
          <p><span className="text-zinc-200">{stateLabel}</span> · Collecting data: {status.sampleSize}/{status.minSamples} settled signals
            {status.winRatePct !== null ? ` · Win rate ${status.winRatePct.toFixed(1)}%` : ""}
          </p>
          <p>Current server dropThreshold: <span className="font-mono text-zinc-200" data-testid="text-server-drop-threshold">{status.dropThreshold.toFixed(2)}</span> (your unsaved filter edits are unchanged).</p>
          {status.state === "paused" && status.pausedUntil && <p>Manual Apply pauses tuning for 7 days, until {dateLabel(status.pausedUntil)}.</p>}
          {status.nextAdjustmentAt && <p>Next eligible adjustment: {dateLabel(status.nextAdjustmentAt)}.</p>}
          {status.lastAdjustment && <p data-testid="text-last-drop-adjustment">Last adjustment: {status.lastAdjustment.oldThreshold.toFixed(2)} → {status.lastAdjustment.newThreshold.toFixed(2)} · {status.lastAdjustment.winRatePct.toFixed(1)}% WIN · N={status.lastAdjustment.sampleSize} · {dateLabel(status.lastAdjustment.at)}</p>}
          {status.error && <p role="alert" className="text-rose-400">{status.error}</p>}
        </div>
      )}
      <p className="mt-2 text-zinc-500">Starts at 40 real settled signals. Adjustments are capped at ±0.05 per 24 hours, within 0.15–1.00; manual Apply pauses tuning for 7 days.</p>
      {error && (
        <div role="alert" className="mt-2 text-rose-400">
          Auto-tuner: {error}{" "}
          <button type="button" data-testid="button-retry-drop-auto-tuner" onClick={() => void refresh()} className="underline hover:text-rose-200">Retry status</button>
        </div>
      )}
    </div>
  );
}