import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { BindingDecisionHistory } from "./BindingDecisionHistory";
import { ExcapperBindingStatus } from "./ExcapperBindingStatus";

afterEach(() => { cleanup(); vi.unstubAllGlobals(); });
const evidence = { id: "123", home: "Alpha", away: "Beta", league: "League", score: null, period: null, minute: null };
const decision = { id: "event-1", action: "bind", mode: "manual_override", occurredAt: "2026-09-22T12:00:00Z", target: evidence, source: { ...evidence, id: "456" }, reason: "Operator confirmed score/timing conflict." };

describe("binding history", () => {
  it("loads saved snapshots and refreshes without mutating fixtures", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, json: async () => ({ decisions: [decision] }) });
    vi.stubGlobal("fetch", fetchMock);
    render(<BindingDecisionHistory signature="id:123" />);
    expect(await screen.findByText("Привязано · Ручное подтверждение счёта/времени")).toBeTruthy();
    expect(screen.getByText("Оператор подтвердил привязку при расхождении счёта или времени.")).toBeTruthy();
    expect(screen.getAllByText("Счёт неизвестен · Период неизвестен")).toHaveLength(2);
    fireEvent.click(screen.getByRole("button", { name: "Обновить историю" }));
    expect(await screen.findByText("Оператор подтвердил привязку при расхождении счёта или времени.")).toBeTruthy();
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(fetchMock).toHaveBeenCalledWith("/api/excapper-binding/history?matchId=123", expect.objectContaining({ credentials: "include" }));
    expect(fetchMock.mock.calls.every((call) => !call[1].method)).toBe(true);
  });

  it("shows an explicit failure and supports retry", async () => {
    vi.stubGlobal("fetch", vi.fn()
      .mockResolvedValueOnce({ ok: false, status: 503 })
      .mockResolvedValueOnce({ ok: true, json: async () => ({ decisions: [] }) }));
    render(<BindingDecisionHistory signature="id:123" />);
    expect(await screen.findByRole("alert")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Обновить историю" }));
    expect(await screen.findByText(/Решений пока нет/)).toBeTruthy();
  });

  it("localizes saved period values and safely labels unknown reasons", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => ({
      decisions: [{
        ...decision,
        reason: "Legacy imported decision",
        target: { ...evidence, period: "first_half" },
        source: { ...evidence, id: "456", period: "second-half" },
      }],
    }) }));
    render(<BindingDecisionHistory signature="id:123" />);
    expect(await screen.findByText("Счёт неизвестен · первый тайм")).toBeTruthy();
    expect(screen.getByText("Счёт неизвестен · второй тайм")).toBeTruthy();
    expect(screen.getByText("Другая сохранённая причина: Legacy imported decision")).toBeTruthy();
  });

  it("keeps history accessible after reset without current source evidence", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => ({
      decisions: [{ ...decision, action: "reset", mode: "manual" }],
    }) }));
    render(<ExcapperBindingStatus signature="id:123" diagnostic={{
      status: "pending", source: null, lastSuccessfulUpdateAt: null,
    }} />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(await screen.findByText("Привязка отменена · Вручную")).toBeTruthy();
    expect(screen.getByRole("button", { name: /Подтвердить/ })).toBeTruthy();
    expect(vi.mocked(fetch).mock.calls.every((call) => !call[1]?.method)).toBe(true);
  });

  it("reopens history after a reset clears the current candidates", async () => {
    const fetchMock = vi.fn().mockImplementation((_url, options) => Promise.resolve({
      ok: true,
      status: 200,
      json: async () => options?.method === "POST"
        ? { ok: true }
        : { decisions: [{ ...decision, action: "reset", mode: "manual" }] },
    }));
    vi.stubGlobal("fetch", fetchMock);
    const fallbackTarget = { team1: "Fallback home", team2: "Fallback away", league: "Fallback league" };
    const onApproved = vi.fn().mockResolvedValue(undefined);
    const view = render(<ExcapperBindingStatus signature="id:123" fallbackTarget={fallbackTarget}
      onApproved={onApproved} diagnostic={{ status: "hydrated", source: null,
        candidateExcapperId: "90001", bindingMode: "manual_override", lastSuccessfulUpdateAt: null }} />);
    expect(fetchMock).not.toHaveBeenCalled();
    fireEvent.click(screen.getByTestId("excapper-binding-status"));
    await screen.findByText("Привязка отменена · Вручную");
    fireEvent.click(screen.getByRole("checkbox", { name: "Подтвердить отмену привязки" }));
    fireEvent.click(screen.getByRole("button", { name: "Отменить привязку" }));
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    expect(onApproved).toHaveBeenCalledOnce();
    view.rerender(<ExcapperBindingStatus signature="id:123" fallbackTarget={fallbackTarget}
      diagnostic={{ status: "pending", source: null, candidates: [], lastSuccessfulUpdateAt: null }} />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getByText("Fallback home — Fallback away")).toBeTruthy();
    expect(await screen.findByText("Привязка отменена · Вручную")).toBeTruthy();
    expect(fetchMock.mock.calls.filter((call) => call[1]?.method === "POST")).toHaveLength(1);
    expect(fetchMock.mock.calls.filter((call) => !call[1]?.method)).toHaveLength(2);
  });

  it("refetches on reopen and cancels the closed dialog request", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, json: async () => ({ decisions: [] }) });
    vi.stubGlobal("fetch", fetchMock);
    const first = render(<BindingDecisionHistory signature="text-pair" />);
    await screen.findByText(/Решений пока нет/);
    first.unmount();
    expect(fetchMock.mock.calls[0][1].signal.aborted).toBe(true);
    render(<BindingDecisionHistory signature="text-pair" />);
    await screen.findByText(/Решений пока нет/);
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(fetchMock.mock.calls[1][0]).toContain("manual-text%3Atext-pair");
  });
});