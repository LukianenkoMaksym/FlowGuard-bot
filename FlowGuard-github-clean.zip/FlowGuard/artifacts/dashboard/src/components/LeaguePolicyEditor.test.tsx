import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { LeaguePolicyEditor, type LeaguePolicy } from "./LeaguePolicyEditor";

const policy: LeaguePolicy = {
  revision: "rev-1",
  mode: "whitelist",
  total: 2,
  entries: [
    { name: "Premier League", displayNameRu: "Премьер-лига", custom: false, patterns: ["^Premier League$"] },
    { name: "Custom Cup", displayNameRu: "Пользовательский кубок", custom: true, patterns: [] },
  ],
  rulesRu: ["Совпадение выполняется по каноническому имени."],
  storageNoticeRu: "Список хранится постоянно.",
};

function response(body: unknown, status = 200) {
  return Promise.resolve(new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  }));
}

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("редактор белого списка лиг", () => {
  it("adds and removes aliases, rejects collisions and submits entries", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ok: true, policy }))
      .mockImplementationOnce(() => response({ ok: false, error: "Конфликт алиаса на сервере." }, 400));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeaguePolicyEditor />);
    const input = await screen.findByLabelText("Новый алиас Premier League");
    fireEvent.change(input, { target: { value: "Custom Cup" } });
    fireEvent.click(screen.getByLabelText("Добавить алиас Premier League"));
    expect((await screen.findByRole("alert")).textContent).toContain("Конфликт");
    fireEvent.change(input, { target: { value: " Feed name " } });
    fireEvent.click(screen.getByLabelText("Добавить алиас Premier League"));
    expect(screen.getByText("Feed name")).toBeTruthy();
    fireEvent.click(screen.getByLabelText("Удалить алиас Feed name"));
    expect(screen.queryByText("Feed name")).toBeNull();
    fireEvent.change(input, { target: { value: "Feed name" } });
    fireEvent.click(screen.getByLabelText("Добавить алиас Premier League"));
    fireEvent.click(screen.getByTestId("button-save-league-policy"));
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
    expect(fetchMock).toHaveBeenLastCalledWith("/api/scanner/league-policy", expect.objectContaining({
      body: JSON.stringify({ entries: [{ name: "Premier League", aliases: ["Feed name"] }, { name: "Custom Cup", aliases: [] }], revision: "rev-1" }),
    }));
    expect((await screen.findByRole("alert")).textContent).toBe("Конфликт алиаса на сервере.");
    expect(screen.getByText("Feed name")).toBeTruthy();
  });
  it("показывает полный список, канонические имена, правила и шаблоны", async () => {
    vi.stubGlobal("fetch", vi.fn(() => response({ ok: true, policy })));
    render(<LeaguePolicyEditor />);

    const list = await screen.findByTestId("list-league-policy");
    expect(within(list).getByText("Премьер-лига")).toBeTruthy();
    expect(within(list).getByText("Premier League")).toBeTruthy();
    expect(within(list).getByText("Пользовательский кубок")).toBeTruthy();
    expect(screen.getByTestId("count-league-policy").textContent).toContain("2");
    expect(screen.getByText("Совпадение выполняется по каноническому имени.")).toBeTruthy();
    expect(screen.getByTestId("notice-league-policy-storage").textContent).toBe("Список хранится постоянно.");
    fireEvent.click(screen.getByText("Шаблоны сопоставления (1)"));
    expect(screen.getByText("^Premier League$")).toBeTruthy();
  });

  it("отправляет добавления и удаления только после сохранения", async () => {
    const changed: LeaguePolicy = {
      ...policy,
      revision: "rev-2",
      entries: [
        policy.entries[0],
        { name: "Новая лига", displayNameRu: "Новая лига", custom: true, patterns: [] },
      ],
    };
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ok: true, policy }))
      .mockImplementationOnce(() => response({ ok: true, policy: changed }));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeaguePolicyEditor />);

    const input = await screen.findByTestId("input-league-policy");
    fireEvent.change(input, { target: { value: "Premier League\nНовая лига" } });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    fireEvent.click(screen.getByTestId("button-save-league-policy"));

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
    expect(fetchMock).toHaveBeenLastCalledWith("/api/scanner/league-policy", expect.objectContaining({
      method: "PUT",
      credentials: "include",
      body: JSON.stringify({ entries: [{ name: "Premier League", aliases: [] }, { name: "Новая лига", aliases: [] }], revision: "rev-1" }),
    }));
    expect(await screen.findByText("Белый список лиг сохранён.")).toBeTruthy();
  });

  it("сохраняет черновик и показывает указание перезагрузить при конфликте", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ok: true, policy }))
      .mockImplementationOnce(() => response({ ok: false }, 409));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeaguePolicyEditor />);

    const input = await screen.findByTestId("input-league-policy") as HTMLTextAreaElement;
    fireEvent.change(input, { target: { value: "Premier League\nДругой кубок" } });
    fireEvent.click(screen.getByTestId("button-save-league-policy"));

    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toContain("Загрузить с сервера");
    expect(alert.textContent).toContain("черновик не перезаписан");
    expect(input.value).toContain("Другой кубок");
  });

  it("показывает ошибку сохранения и не сбрасывает изменения", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ok: true, policy }))
      .mockImplementationOnce(() => response({ ok: false }, 500));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeaguePolicyEditor />);

    const input = await screen.findByTestId("input-league-policy") as HTMLTextAreaElement;
    fireEvent.change(input, { target: { value: "Только новая лига" } });
    fireEvent.click(screen.getByTestId("button-save-league-policy"));

    expect((await screen.findByRole("alert")).textContent).toContain("HTTP 500");
    expect(input.value).toBe("Только новая лига");
  });

  it("показывает русскую причину ошибки, возвращённую сервером", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ok: true, policy }))
      .mockImplementationOnce(() => response({
        ok: false,
        error: "Неизвестное каноническое имя лиги.",
      }, 400));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeaguePolicyEditor />);

    const input = await screen.findByTestId("input-league-policy") as HTMLTextAreaElement;
    fireEvent.change(input, { target: { value: "Ошибочная лига" } });
    fireEvent.click(screen.getByTestId("button-save-league-policy"));

    expect((await screen.findByRole("alert")).textContent).toBe("Неизвестное каноническое имя лиги.");
    expect(input.value).toBe("Ошибочная лига");
  });

  it("записывает в журнал сохранённую политику без отправки черновика", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ok: true, policy }))
      .mockImplementationOnce(() => response({ ok: true, policy }));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeaguePolicyEditor />);

    fireEvent.change(await screen.findByTestId("input-league-policy"), {
      target: { value: "Несохранённый черновик" },
    });
    fireEvent.click(screen.getByTestId("button-log-league-policy"));

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
    expect(fetchMock).toHaveBeenLastCalledWith("/api/scanner/league-policy/log", {
      method: "POST",
      credentials: "include",
    });
    expect(await screen.findByText(/Сохранённый на сервере белый список записан/)).toBeTruthy();
    expect(screen.getByText(/Несохранённый черновик не отправлялся/)).toBeTruthy();
  });

  it("требует явного подтверждения перед очисткой", async () => {
    const confirm = vi.fn(() => false);
    vi.stubGlobal("confirm", confirm);
    const fetchMock = vi.fn(() => response({ ok: true, policy }));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeaguePolicyEditor />);

    fireEvent.change(await screen.findByTestId("input-league-policy"), { target: { value: "" } });
    fireEvent.click(screen.getByTestId("button-save-league-policy"));

    expect(confirm).toHaveBeenCalledWith(expect.stringContaining("запретит все лиги"));
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});