import type { ExcapperBindingDiagnostic } from "./ExcapperBindingStatus";

/** Presentation only: age of the accepted sample, not of the binding or match clock. */
export function ExcapperFreshness({ diagnostic }: { diagnostic?: ExcapperBindingDiagnostic }) {
  const timestamp = diagnostic?.lastSuccessfulUpdateAt;
  const now = Date.now();
  const age = timestamp != null && Number.isFinite(timestamp) && timestamp <= now
    ? Math.floor((now - timestamp) / 1000) : null;
  const stale = age != null && age > 15 * 60;
  const failed = diagnostic?.status === "fetch_failed" || diagnostic?.status === "source_unavailable";
  const label = age == null ? "—" : age < 60 ? `${age}s` : age < 3600 ? `${Math.floor(age / 60)}m` : `${Math.floor(age / 3600)}h`;
  const minute = diagnostic?.source?.minute;
  const clock = age != null && !stale &&
    (diagnostic?.status === "hydrated" || diagnostic?.status === "bound_verified") &&
    typeof minute === "number" && Number.isFinite(minute) && minute >= 0
      ? ` Observed Excapper match clock: ${minute}′ (not the NowGoal minute).` : "";
  const detail = `Excapper: ${age == null ? "no accepted volume sample" : `last accepted volume sample ${age}s ago`}${stale ? " (stale)" : ""}${failed ? "; latest fetch unavailable" : ""}.${clock}`;
  return <span
    data-testid="excapper-source-readiness"
    className={`whitespace-nowrap ${failed || stale ? "text-amber-400" : "text-zinc-500"}`}
    title={detail}
    aria-label={detail}
  >EXC {label}{failed || stale ? "!" : ""}</span>;
}