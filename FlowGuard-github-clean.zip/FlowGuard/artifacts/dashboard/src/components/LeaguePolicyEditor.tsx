import { useCallback, useEffect, useMemo, useRef, useState } from "react";

const API_BASE = `${import.meta.env.BASE_URL.replace(/\/$/, "")}/api`;

export interface LeaguePolicyEntry {
  name: string;
  aliases?: string[];
  displayNameRu: string;
  custom: boolean;
  patterns: string[];
}

export interface LeaguePolicy {
  revision: string;
  mode: "whitelist" | "empty";
  total: number;
  entries: LeaguePolicyEntry[];
  rulesRu: string[];
  storageNoticeRu: string;
}

interface LeaguePolicyEnvelope {
  ok: true;
  policy: LeaguePolicy;
}

function namesFromText(value: string): string[] {
  const seen = new Set<string>();
  const names: string[] = [];
  for (const line of value.split(/\r?\n/)) {
    const name = line.trim();
    if (name && !seen.has(name)) {
      seen.add(name);
      names.push(name);
    }
  }
  return names;
}

function textFromPolicy(policy: LeaguePolicy): string {
  return policy.entries.map((entry) => entry.name).join("\n");
}

function isEnvelope(value: unknown): value is LeaguePolicyEnvelope {
  if (!value || typeof value !== "object") return false;
  const envelope = value as Partial<LeaguePolicyEnvelope>;
  return envelope.ok === true
    && !!envelope.policy
    && typeof envelope.policy.revision === "string"
    && Array.isArray(envelope.policy.entries)
    && Array.isArray(envelope.policy.rulesRu)
    && typeof envelope.policy.storageNoticeRu === "string";
}

async function readEnvelope(response: Response): Promise<LeaguePolicyEnvelope | null> {
  try {
    const value: unknown = await response.json();
    return isEnvelope(value) ? value : null;
  } catch {
    return null;
  }
}

async function readServerError(response: Response): Promise<string | null> {
  try {
    const value = await response.clone().json() as { error?: unknown };
    if (typeof value.error !== "string") return null;
    const error = value.error.trim();
    return error ? error.slice(0, 500) : null;
  } catch {
    return null;
  }
}

export function LeaguePolicyEditor() {
  const [policy, setPolicy] = useState<LeaguePolicy | null>(null);
  const [draft, setDraft] = useState("");
  const [aliases, setAliases] = useState<Record<string, string[]>>({});
  const [aliasInputs, setAliasInputs] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [action, setAction] = useState<"save" | "reload" | "log" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const dirtyRef = useRef(false);

  const draftNames = useMemo(() => namesFromText(draft), [draft]);
  const savedText = policy ? textFromPolicy(policy) : "";
  const dirty = policy !== null && (draft !== savedText || policy.entries.some(
    (entry) => JSON.stringify(aliases[entry.name] ?? []) !== JSON.stringify(entry.aliases ?? []),
  ));
  dirtyRef.current = dirty;

  const applyLoadedPolicy = useCallback((nextPolicy: LeaguePolicy) => {
    setPolicy(nextPolicy);
    setDraft(textFromPolicy(nextPolicy));
    setAliases(Object.fromEntries(nextPolicy.entries.map((entry) => [entry.name, entry.aliases ?? []])));
    setAliasInputs({});
  }, []);

  const load = useCallback(async (manual: boolean) => {
    if (manual && dirtyRef.current && !window.confirm(
      "Несохранённые изменения будут потеряны. Загрузить список с сервера?",
    )) {
      return;
    }
    if (manual) setAction("reload");
    else setLoading(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`${API_BASE}/scanner/league-policy`, {
        credentials: "include",
      });
      const envelope = await readEnvelope(response);
      if (!response.ok || !envelope) {
        setError(`Не удалось загрузить список лиг (HTTP ${response.status}).`);
        return;
      }
      applyLoadedPolicy(envelope.policy);
      if (manual) setMessage("Список лиг загружен с сервера.");
    } catch {
      setError("Не удалось загрузить список лиг: проверьте соединение.");
    } finally {
      setLoading(false);
      if (manual) setAction(null);
    }
  }, [applyLoadedPolicy]);

  useEffect(() => {
    void load(false);
  }, [load]);

  const save = async () => {
    if (!policy || action) return;
    if (draftNames.length === 0 && !window.confirm(
      "Подтвердите очистку белого списка. Автоматический сканер запретит все лиги; это не режим «разрешить все». Очистить список?",
    )) {
      return;
    }
    setAction("save");
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`${API_BASE}/scanner/league-policy`, {
        method: "PUT",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entries: draftNames.map((name) => ({
          name, aliases: aliases[Object.keys(aliases).find((key) => key.toLowerCase() === name.toLowerCase()) ?? name] ?? [],
        })), revision: policy.revision }),
      });
      if (response.status === 409) {
        setError("Список уже изменён в другой сессии. Нажмите «Загрузить с сервера», проверьте изменения и сохраните снова. Ваш черновик не перезаписан.");
        return;
      }
      const serverError = response.ok ? null : await readServerError(response);
      const envelope = await readEnvelope(response);
      if (!response.ok || !envelope) {
        setError(serverError ?? `Не удалось сохранить список лиг (HTTP ${response.status}).`);
        return;
      }
      applyLoadedPolicy(envelope.policy);
      setMessage("Белый список лиг сохранён.");
    } catch {
      setError("Не удалось сохранить список лиг: проверьте соединение.");
    } finally {
      setAction(null);
    }
  };

  const writeLog = async () => {
    if (!policy || action) return;
    setAction("log");
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`${API_BASE}/scanner/league-policy/log`, {
        method: "POST",
        credentials: "include",
      });
      if (response.status === 409) {
        setError("Список уже изменён в другой сессии. Сначала нажмите «Загрузить с сервера». Ваш черновик не перезаписан.");
        return;
      }
      const envelope = await readEnvelope(response);
      if (!response.ok || !envelope) {
        setError(`Не удалось записать полный список в журнал (HTTP ${response.status}).`);
        return;
      }
      setMessage("Сохранённый на сервере белый список записан в журнал. Несохранённый черновик не отправлялся.");
    } catch {
      setError("Не удалось записать список в журнал: проверьте соединение.");
    } finally {
      setAction(null);
    }
  };

  const reset = () => {
    if (!policy || !dirty) return;
    applyLoadedPolicy(policy);
    setError(null);
    setMessage("Черновик сброшен к последней загруженной версии.");
  };

  return (
    <section
      className="mb-6 rounded-xl border-2 border-cyan-700/60 bg-cyan-950/20 p-5 shadow-lg shadow-cyan-950/20"
      aria-labelledby="league-policy-heading"
      data-testid="panel-league-policy"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-cyan-400">
            Настройки автоматического сканера
          </div>
          <h2 id="league-policy-heading" className="mt-1 text-xl font-bold text-zinc-100">
            Белый список лиг
          </h2>
          <p className="mt-1 max-w-2xl text-sm text-zinc-400">
            Разрешены только перечисленные лиги. Каноническое имя сравнивается точно, с учётом регистра.
          </p>
        </div>
        <div
          className="rounded-full border border-cyan-700/60 bg-cyan-950/50 px-3 py-1 text-sm font-semibold text-cyan-200"
          data-testid="count-league-policy"
        >
          {policy ? `Включено: ${policy.total}` : "Включено: —"}
        </div>
      </div>

      {loading && (
        <div className="mt-4 text-sm text-zinc-400" data-testid="status-league-policy-loading">
          Загрузка полного списка…
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-lg border border-rose-800/70 bg-rose-950/40 px-3 py-2 text-sm text-rose-200" role="alert" data-testid="error-league-policy">
          {error}
        </div>
      )}
      {message && (
        <div className="mt-4 rounded-lg border border-emerald-800/70 bg-emerald-950/30 px-3 py-2 text-sm text-emerald-200" role="status" data-testid="status-league-policy">
          {message}
        </div>
      )}

      {policy && (
        <>
          {policy.mode === "empty" && (
            <div className="mt-4 rounded-lg border border-amber-700/70 bg-amber-950/30 px-3 py-2 text-sm font-medium text-amber-200" data-testid="empty-league-policy">
              Белый список пуст: автоматический сканер запрещает все лиги. Это не означает «разрешить все».
            </div>
          )}

          <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
            <div>
              <h3 className="text-sm font-semibold text-zinc-200">Полный включённый список</h3>
              <div className="mt-2 max-h-80 space-y-2 overflow-y-auto pr-1" data-testid="list-league-policy">
                {policy.entries.length === 0 ? (
                  <div className="rounded-lg border border-zinc-800 bg-zinc-950/40 px-3 py-4 text-sm text-zinc-500">
                    Включённых лиг нет.
                  </div>
                ) : policy.entries.map((entry) => (
                  <div key={entry.name} className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2" data-testid={`league-policy-entry-${entry.name}`}>
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <span className="font-medium text-zinc-100">{entry.displayNameRu}</span>
                      {entry.custom && (
                        <span className="rounded bg-violet-950/60 px-1.5 py-0.5 text-[10px] font-semibold text-violet-300">
                          Пользовательская
                        </span>
                      )}
                    </div>
                    <code className="mt-1 block break-all text-xs text-cyan-300">{entry.name}</code>
                    <div className="mt-2 space-y-1 text-xs text-zinc-300">
                      <p>Алиасы (точные имена, без учёта регистра)</p>
                      {(aliases[entry.name] ?? []).map((alias) => (
                        <div key={alias} className="flex items-center justify-between gap-2">
                          <span>{alias}</span>
                          <button type="button" aria-label={`Удалить алиас ${alias}`} disabled={action !== null}
                            onClick={() => setAliases((current) => ({ ...current, [entry.name]: current[entry.name].filter((item) => item !== alias) }))}>
                            Удалить
                          </button>
                        </div>
                      ))}
                      <div className="flex gap-2">
                        <input aria-label={`Новый алиас ${entry.name}`} maxLength={200}
                          className="min-w-0 flex-1 rounded border border-zinc-700 bg-zinc-950 px-2 py-1"
                          value={aliasInputs[entry.name] ?? ""}
                          onChange={(event) => setAliasInputs((current) => ({ ...current, [entry.name]: event.target.value }))} />
                        <button type="button" disabled={action !== null} aria-label={`Добавить алиас ${entry.name}`}
                          onClick={() => {
                            const alias = (aliasInputs[entry.name] ?? "").trim();
                            if (!alias) return;
                            const key = alias.toLowerCase();
                            if (draftNames.some((name) => name.toLowerCase() === key)
                              || Object.values(aliases).flat().some((item) => item.toLowerCase() === key)) {
                              setError(`Конфликт алиаса «${alias}»: имя уже используется.`);
                              return;
                            }
                            setAliases((current) => ({ ...current, [entry.name]: [...(current[entry.name] ?? []), alias] }));
                            setAliasInputs((current) => ({ ...current, [entry.name]: "" }));
                            setError(null);
                          }}>Добавить</button>
                      </div>
                    </div>
                    {entry.patterns.length > 0 && (
                      <details className="mt-1 text-xs text-zinc-400">
                        <summary className="cursor-pointer select-none">Шаблоны сопоставления ({entry.patterns.length})</summary>
                        <ul className="mt-1 space-y-1 pl-4">
                          {entry.patterns.map((pattern, index) => (
                            <li key={`${pattern}-${index}`}><code className="break-all">{pattern}</code></li>
                          ))}
                        </ul>
                      </details>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="league-policy-input" className="text-sm font-semibold text-zinc-200">
                Редактор канонических имён
              </label>
              <p className="mt-1 text-xs text-zinc-500">
                Одно точное каноническое имя на строку. Добавляйте новые произвольные буквальные имена или удаляйте строки.
              </p>
              <textarea
                id="league-policy-input"
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                rows={10}
                spellCheck={false}
                className="mt-2 w-full resize-y rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-sm text-zinc-100 outline-none focus:border-cyan-500"
                data-testid="input-league-policy"
              />
              <div className="mt-2 text-xs text-zinc-500" data-testid="count-league-policy-draft">
                В черновике: {draftNames.length}{dirty ? " · есть несохранённые изменения" : " · без изменений"}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <button type="button" onClick={save} disabled={!dirty || action !== null} className="rounded-lg bg-cyan-600 px-3 py-2 text-sm font-semibold text-white hover:bg-cyan-500 disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-save-league-policy">
                  {action === "save" ? "Сохранение…" : "Сохранить"}
                </button>
                <button type="button" onClick={reset} disabled={!dirty || action !== null} className="rounded-lg border border-zinc-700 px-3 py-2 text-sm text-zinc-300 hover:bg-zinc-800 disabled:opacity-50" data-testid="button-reset-league-policy">
                  Сбросить черновик
                </button>
                <button type="button" onClick={() => void load(true)} disabled={action !== null} className="rounded-lg border border-zinc-700 px-3 py-2 text-sm text-zinc-300 hover:bg-zinc-800 disabled:opacity-50" data-testid="button-reload-league-policy">
                  {action === "reload" ? "Загрузка…" : "Загрузить с сервера"}
                </button>
                <button type="button" onClick={writeLog} disabled={action !== null} className="rounded-lg border border-violet-800/70 bg-violet-950/30 px-3 py-2 text-sm text-violet-200 hover:bg-violet-900/40 disabled:opacity-50" data-testid="button-log-league-policy">
                  {action === "log" ? "Запись…" : "Записать сохранённый список в журнал"}
                </button>
              </div>
            </div>
          </div>

          <div className="mt-5 rounded-lg border border-zinc-800 bg-zinc-950/40 px-4 py-3">
            <h3 className="text-sm font-semibold text-zinc-200">Правила применения</h3>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-zinc-400">
              {policy.rulesRu.map((rule, index) => <li key={`${rule}-${index}`}>{rule}</li>)}
            </ul>
            <p className="mt-3 text-sm font-medium text-amber-300" data-testid="notice-league-policy-storage">
              {policy.storageNoticeRu}
            </p>
          </div>
        </>
      )}
    </section>
  );
}