import { useEffect, useState } from "react";

interface Evidence {
  id: string | null;
  home: string | null;
  away: string | null;
  league: string | null;
  score: { home: number; away: number } | null;
  period: string | null;
  minute: number | null;
}

interface Decision {
  id: string;
  action: "bind" | "reset";
  mode: "automatic" | "manual" | "manual_override";
  occurredAt: string;
  target: Evidence;
  source: Evidence;
  reason: string;
}

function periodLabel(value: string | null): string {
  if (!value) return "Период неизвестен";
  const normalized = value.trim().toLowerCase().replace(/[_\s]+/g, "-");
  const known: Record<string, string> = {
    "first-half": "первый тайм",
    "half-time": "перерыв",
    "second-half": "второй тайм",
    "extra-time": "дополнительное время",
    "penalties": "серия пенальти",
    "finished": "матч завершён",
  };
  return known[normalized] ?? `другой период: ${value.replace(/[\u0000-\u001f\u007f]/g, " ").trim()}`;
}

function reasonLabel(reason: string): string {
  const known: Record<string, string> = {
    "Unique team and league match with live score and period corroboration; initial market hydration accepted.":
      "Найдена единственная пара команд и лига; счёт и период совпали, начальная загрузка рынка принята.",
    "Operator approved the reviewed fixture after live identity, score and period revalidation.":
      "Оператор подтвердил матч после повторной проверки участников, счёта и периода.",
    "Operator explicitly confirmed the reviewed live fixture despite score or timing corroboration differences.":
      "Оператор явно подтвердил матч, несмотря на расхождения в счёте или времени.",
    "Operator reset the binding; the previous source fixture is blocked from automatic reattachment. Evidence is the original binding snapshot.":
      "Оператор отменил привязку; прежний матч источника заблокирован для автоматического повторного присоединения. Показан исходный снимок привязки.",
    "Operator reset pending review; this source fixture is blocked from automatic reattachment.":
      "Оператор сбросил ожидающую проверку; этот матч источника заблокирован для автоматического повторного присоединения.",
    "Operator confirmed score/timing conflict.":
      "Оператор подтвердил привязку при расхождении счёта или времени.",
  };
  const clean = reason.replace(/[\u0000-\u001f\u007f]/g, " ").trim();
  return known[clean] ?? `Другая сохранённая причина: ${clean || "подробности отсутствуют"}`;
}

function FixtureEvidence({ title, evidence }: { title: string; evidence: Evidence }) {
  return <div className="min-w-0 break-words">
    <h5 className="font-medium">{title} · ID {evidence.id ?? "нет данных"}</h5>
    <p>{evidence.home ?? "Неизвестно"} — {evidence.away ?? "Неизвестно"}</p>
    <p className="text-zinc-400">{evidence.league ?? "Лига неизвестна"}</p>
    <p>{evidence.score ? `${evidence.score.home} – ${evidence.score.away}` : "Счёт неизвестен"}
      {" · "}{periodLabel(evidence.period)}
      {evidence.minute != null && ` · ${evidence.minute}′`}
    </p>
  </div>;
}

export function BindingDecisionHistory({ signature }: { signature: string }) {
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reload, setReload] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    const matchId = signature.startsWith("id:") ? signature.slice(3) : `manual-text:${signature}`;
    setLoading(true);
    setError("");
    setDecisions([]);
    void fetch(`/api/excapper-binding/history?matchId=${encodeURIComponent(matchId)}`, {
      credentials: "include", signal: controller.signal, cache: "no-store",
    }).then(async (response) => {
      if (!response.ok) throw new Error(response.status === 401
        ? "Войдите, чтобы просмотреть историю привязок." : "Не удалось загрузить историю привязок.");
      const payload = await response.json();
      if (!Array.isArray(payload.decisions)) throw new Error("Получен неверный ответ истории привязок.");
      if (!controller.signal.aborted) setDecisions(payload.decisions);
    }).catch((cause: unknown) => {
      if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "Не удалось загрузить историю привязок.");
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [signature, reload]);

  return <section aria-label="История решений о привязке" className="border-t border-zinc-700 pt-3">
    <div className="flex items-center justify-between gap-2">
      <h3 className="text-sm font-semibold">История решений о привязке</h3>
      <button type="button" disabled={loading} onClick={() => setReload((value) => value + 1)}
        className="text-xs text-zinc-300 underline disabled:opacity-50">Обновить историю</button>
    </div>
    <p className="mt-1 text-xs text-zinc-400">Показаны данные, сохранённые в момент решения, а не текущие значения.</p>
    {loading && <p role="status" className="mt-2 text-xs">Загрузка истории…</p>}
    {error && <p role="alert" className="mt-2 text-xs text-red-300">{error}</p>}
    {!loading && !error && !decisions.length && <p className="mt-2 text-xs text-zinc-400">
      Решений пока нет. Старые привязки, созданные до включения истории, здесь не отображаются.
    </p>}
    {!loading && !error && <ol className="mt-2 max-h-64 space-y-3 overflow-y-auto">
      {decisions.map((decision) => <li key={decision.id} className="rounded border border-zinc-700 p-3 text-xs">
        <h4 className="font-semibold">
          {decision.action === "reset" ? "Привязка отменена" : "Привязано"}
          {" · "}{decision.mode === "automatic" ? "Автоматически" : decision.mode === "manual_override" ? "Ручное подтверждение счёта/времени" : "Вручную"}
        </h4>
        <time dateTime={decision.occurredAt} className="text-zinc-400">{new Date(decision.occurredAt).toLocaleString("ru-RU")}</time>
        <p className="my-2">{reasonLabel(decision.reason)}</p>
        <div className="grid gap-2 sm:grid-cols-2">
          <FixtureEvidence title="NowGoal" evidence={decision.target} />
          <FixtureEvidence title="Excapper" evidence={decision.source} />
        </div>
      </li>)}
    </ol>}
  </section>;
}