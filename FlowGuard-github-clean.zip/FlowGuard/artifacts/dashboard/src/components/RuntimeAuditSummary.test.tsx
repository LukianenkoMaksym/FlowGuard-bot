import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { RuntimeAuditSummary, type RuntimeAudit } from "./RuntimeAuditSummary";

const runtimeAudit: RuntimeAudit = {
  generatedAt: "2025-02-03T04:05:06.000Z",
  total: 17,
  watchlistTotal: 3,
  matches: [
    {
      key: "nowgoal:123",
      nowGoalMatchId: "123",
      matchName: "Home vs Away",
      leagueName: "Test League",
      status: "Review Request",
      excapperMatchId: null,
      score: null,
      elapsedTime: "54'",
      matchPhase: "cached/finished",
      sources: ["NowGoal", "Excapper"],
    },
    {
      key: "nowgoal:456",
      nowGoalMatchId: "456",
      matchName: "Live Home vs Live Away",
      leagueName: "Live League",
      status: "Verified",
      excapperMatchId: "exc-456",
      score: "1-0",
      elapsedTime: "54'",
      matchPhase: "live",
      matchStatus: "live",
      isLive: true,
      sources: ["NowGoal"],
    },
    {
      key: "nowgoal:789",
      nowGoalMatchId: "789",
      matchName: "Finished Home vs Finished Away",
      leagueName: "Old League",
      status: "Verified",
      excapperMatchId: "exc-789",
      score: "2-1",
      elapsedTime: "90'",
      matchPhase: "live",
      matchStatus: "finished",
      isLive: true,
      sources: ["NowGoal"],
    },
  ],
};

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("RuntimeAuditSummary", () => {
  it("renders only current live rows and honest displayed totals", () => {
    render(
      <RuntimeAuditSummary
        runtimeAudit={runtimeAudit}
        loading={false}
        endpoint="/api/watchlist/runtime-audit"
      />,
    );

    expect(screen.getByText("МАТЧЕЙ В ЭФИРЕ В WATCHLIST: 1")).toBeTruthy();
    expect(screen.getByTestId("text-runtime-total").textContent).toBe("1");
    const row = screen.getByTestId("row-runtime-audit-nowgoal:456");
    expect(within(row).getByText("Live Home vs Live Away")).toBeTruthy();
    expect(screen.queryByTestId("row-runtime-audit-nowgoal:123")).toBeNull();
    expect(screen.queryByTestId("row-runtime-audit-nowgoal:789")).toBeNull();
    expect(screen.getByTestId("scroll-runtime-audit").classList.contains("overflow-x-auto")).toBe(true);
  });

  it("prints through the authenticated endpoint and reports success", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ runtimeAudit }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(
      <RuntimeAuditSummary
        runtimeAudit={runtimeAudit}
        loading={false}
        endpoint="/api/watchlist/runtime-audit"
      />,
    );

    fireEvent.click(screen.getByTestId("button-print-runtime-audit"));
    await waitFor(() =>
      expect(screen.getByTestId("status-print-runtime-audit").textContent).toContain(
        "printed to server logs",
      ),
    );
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/watchlist/runtime-audit",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );
  });

  it("does not show a misleading zero while loading", () => {
    render(
      <RuntimeAuditSummary
        loading
        endpoint="/api/watchlist/runtime-audit"
      />,
    );

    expect(screen.getByTestId("status-runtime-audit").textContent).toContain("Loading");
    expect(screen.queryByText(/МАТЧЕЙ В ЭФИРЕ В WATCHLIST:/)).toBeNull();
  });

  it("shows the latest decision signals and gates without inventing a source ID or score", () => {
    render(<RuntimeAuditSummary runtimeAudit={{
      ...runtimeAudit,
      matches: [{
        ...runtimeAudit.matches[1]!,
        status: "Review Request",
        excapperMatchId: null,
        score: null,
        bindingDecision: {
          status: "ambiguous",
          reason: "Two live fixtures claim the same teams",
          candidateCount: 2,
          chosenId: null,
          thresholds: { threshold: 35, epsilon: 3, windowMs: 300_000 },
          evaluatedAt: "2025-02-03T04:05:06.000Z",
          scored: [{
            candidate: { id: "exc-456", team1: "Home", team2: "Away", league: "League", kickoffMs: null },
            home: 0.99, away: 0.98, time: 0, league: true, delta: null, score: 0.94,
            reason: "one-to-one identity failed",
            normalized: { sourceHome: "home", sourceAway: "away", candidateHome: "home", candidateAway: "away" },
            contributions: { teams: 0.69, time: 0, league: 0.05, corroboration: 0.2 },
            gates: { teams: true, kickoff: false, scorePeriod: true, conflict: true },
          }],
        },
      }],
    }} loading={false} endpoint="/api/watchlist/runtime-audit" />);
    const row = screen.getByTestId("row-runtime-audit-nowgoal:456");
    expect(within(row).getByText("Ambiguous — no binding selected")).toBeTruthy();
    expect(within(row).getByText("Two live fixtures claim the same teams")).toBeTruthy();
    fireEvent.click(within(row).getByText("Candidate scores and gates (1)"));
    expect(within(row).getByText(/one-to-one identity failed/)).toBeTruthy();
    expect(within(row).getByText((_, node) =>
      node?.tagName === "P" && /Home:\s*0.99\s*· Away:\s*0.98/.test(node.textContent ?? ""))).toBeTruthy();
    expect(within(row).getByText((_, node) =>
      node?.tagName === "P" && /Gates — teams:\s*yes, kickoff:\s*no/.test(node.textContent ?? ""))).toBeTruthy();
    expect(within(row).getAllByText(/No data/).length).toBeGreaterThan(0);
    expect(within(row).getAllByText("—").length).toBeGreaterThan(0);
    expect(row.querySelector("a")).toBeNull();
  });

  it("renders a manually verified binding distinctly even when no numerical join is available", () => {
    render(<RuntimeAuditSummary runtimeAudit={{
      ...runtimeAudit,
      matches: [{
        ...runtimeAudit.matches[1]!,
        status: "Verified",
        excapperMatchId: null,
        score: null,
        bindingDecision: {
          status: "manual", reason: "Operator confirmed the live fixture",
          candidateCount: 0, chosenId: null,
          thresholds: { threshold: 35, epsilon: 3, windowMs: 300_000 },
          scored: [], evaluatedAt: "2025-02-03T04:05:06.000Z",
        },
      }],
    }} loading={false} endpoint="/api/watchlist/runtime-audit" />);
    const row = screen.getByTestId("row-runtime-audit-nowgoal:456");
    expect(within(row).getByText("NowGoal подтверждён · EXC без ID")).toBeTruthy();
    expect(within(row).getAllByText("Verified manually")).toHaveLength(1);
    expect(within(row).getByText("NowGoal подтверждён · EXC без ID").className).toContain("border-amber");
    expect(within(row).getByText("Operator confirmed the live fixture")).toBeTruthy();
    expect(row.querySelector("a")).toBeNull();
    expect(within(row).getAllByText("—").length).toBeGreaterThan(0);
  });
  it("shows the durable numeric source ID even before a scanner quote arrives", () => {
    render(<RuntimeAuditSummary runtimeAudit={{
      ...runtimeAudit,
      matches: [{
        ...runtimeAudit.matches[1]!,
        excapperMatchId: null,
        bindingDecision: {
          status: "manual", reason: "Operator confirmed the numeric pair",
          candidateCount: 0, chosenId: "36113216",
          thresholds: { threshold: 35, epsilon: 3, windowMs: 300_000 },
          scored: [], evaluatedAt: "2025-02-03T04:05:06.000Z",
        },
      }],
    }} loading={false} endpoint="/api/watchlist/runtime-audit" />);
    const row = screen.getByTestId("row-runtime-audit-nowgoal:456");
    expect(within(row).getByText("36113216")).toBeTruthy();
    expect(within(row).getAllByText("Verified manually")).toHaveLength(2);
  });
  it("retains the scored search candidate while manual review options are empty", () => {
    render(<RuntimeAuditSummary runtimeAudit={{
      ...runtimeAudit,
      matches: [{
        ...runtimeAudit.matches[1]!,
        bindingDecision: {
          status: "manual", reason: "Operator verified; source sample pending",
          candidateCount: 1, chosenId: null,
          thresholds: { threshold: 35, epsilon: 3, windowMs: 300_000 },
          evaluatedAt: "2025-02-03T04:05:06.000Z",
          scored: [{
            candidate: { id: "36109446", team1: "Home", team2: "Away", league: "League", kickoffMs: null },
            home: 0.9, away: 0.9, time: 0, league: true, delta: null, score: 0.8,
            reason: "source score stale", normalized: { sourceHome: "home", sourceAway: "away", candidateHome: "home", candidateAway: "away" },
            contributions: { teams: 0.6, time: 0, league: 0.1, corroboration: 0 },
            gates: { teams: true, kickoff: false, scorePeriod: false, conflict: false },
          }],
        },
      }],
    }} loading={false} endpoint="/api/watchlist/runtime-audit" />);
    const row = screen.getByTestId("row-runtime-audit-nowgoal:456");
    expect(within(row).getByText(/Search candidates scored: 1/)).toBeTruthy();
    fireEvent.click(within(row).getByText("Candidate scores and gates (1)"));
    expect(within(row).getByText(/ID 36109446/)).toBeTruthy();
  });
});