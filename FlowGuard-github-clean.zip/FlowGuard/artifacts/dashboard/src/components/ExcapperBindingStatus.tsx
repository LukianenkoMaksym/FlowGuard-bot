import { LeagueAliasReport, type BindingReviewCandidate, type LeagueReportIdentity } from "./LeagueAliasReport";
import type { BindingDecisionDiagnosticData } from "./BindingDecisionDiagnostic";

export interface ExcapperBindingDiagnostic {
  status: "source_unavailable" | "no_directory_match" | "ambiguous_identity" | "missing_league_alias" | "non_live_candidate" | "missing_live_corroboration" | "score_period_conflict" | "empty_market" | "bound_pending" | "bound_verified" | "identity_only" | "hydrated" | "pending" | "fetch_failed";
  source: LeagueReportIdentity | null;
  target?: LeagueReportIdentity | null;
  lastSuccessfulUpdateAt: number | null;
  resolvedCandidate?: string | null;
  candidateExcapperId?: string | null;
  candidates?: BindingReviewCandidate[];
  bindingMode?: "automatic" | "manual_override";
  bindingDecision?: BindingDecisionDiagnosticData | null;
}

const descriptions: Record<ExcapperBindingDiagnostic["status"], [string, string]> = {
  source_unavailable: ["Feed unavailable", "The shared Excapper feed is unavailable. This is not a row identity failure; any retained values may be stale."],
  no_directory_match: ["No match", "No complete team pair was found in the Excapper directory. A successful HTTP response does not guarantee a matching fixture."],
  ambiguous_identity: ["Ambiguous pair", "More than one fixture or watchlist identity could claim this match. No binding was selected."],
  missing_league_alias: ["Review required", "A live complete team pair was found. League translations do not block automatic binding when score and timing align; review the remaining evidence."],
  non_live_candidate: ["Not live", "Matching is live-only. The fixture is not confirmed active in both feeds; scheduled and finished fixtures cannot bind."],
  missing_live_corroboration: ["Awaiting live evidence", "Team and league matching is not enough: current score and period evidence is missing or stale. No unverified binding was selected."],
  score_period_conflict: ["Review required", "The feeds disagree on score or timing. The candidate remains available for explicit review because one feed may lag."],
  empty_market: ["Empty market", "The fixture is bound, but its source page has no usable Over/Under market values."],
  bound_pending: ["Bound · volume pending", "The league approval is saved and the exact fixture is verified and bound. Live volume is temporarily unavailable; retained values may be stale."],
  bound_verified: ["Bound · verified", "The league approval is saved, the exact live fixture is verified, and volume was loaded."],
  identity_only: ["Матч подтверждён · источник не привязан", "NowGoal подтверждён оператором, но числовой ID Excapper не привязан; объёмы не загрузятся."],
  hydrated: ["Updated", "The fixture is bound and Excapper market values were successfully loaded."],
  pending: ["Pending", "This row has not completed an Excapper binding and market check yet."],
  fetch_failed: ["Fetch failed", "The source page could not be loaded for this row. This alone does not establish a source-wide outage or IP block."],
};

export function ExcapperBindingStatus({ diagnostic, signature, nowgoalId, fallbackTarget, onApproved }: {
  diagnostic?: ExcapperBindingDiagnostic;
  signature?: string;
  nowgoalId?: string | null;
  fallbackTarget?: LeagueReportIdentity | null;
  onApproved?: () => void | Promise<void>;
}) {
  const status = diagnostic?.status ?? "pending";
  const [, defaultExplanation] = descriptions[status] ?? descriptions.pending;
  const source = diagnostic?.source;
  const identityOnly = status === "identity_only" ||
    (diagnostic?.bindingDecision?.status === "manual" &&
      diagnostic.bindingDecision.chosenId == null &&
      !/^[1-9]\d*$/.test(diagnostic.candidateExcapperId ?? ""));
  const verified = status === "hydrated" || status === "bound_pending" ||
    status === "bound_verified" || status === "identity_only" || diagnostic?.bindingMode !== undefined ||
    diagnostic?.bindingDecision?.status === "manual";
  const sourceBound = !identityOnly && /^(?:[1-9]\d*)$/.test(diagnostic?.bindingDecision?.chosenId ??
    (diagnostic?.bindingMode ? diagnostic?.candidateExcapperId ?? "" : ""));
  const explanation = identityOnly ? descriptions.identity_only[1]
    : sourceBound && diagnostic?.lastSuccessfulUpdateAt == null
    ? "Числовая привязка источника сохранена; последний образец объёмов Excapper ещё не получен."
    : defaultExplanation;
  return (
    <LeagueAliasReport
      target={diagnostic?.target ?? fallbackTarget}
      source={source ?? null}
      signature={signature}
      nowgoalId={nowgoalId}
      candidateExcapperId={diagnostic?.candidateExcapperId}
      resolvedCandidate={diagnostic?.resolvedCandidate}
      candidates={diagnostic?.candidates}
      verified={verified}
      sourceBound={sourceBound}
      bindingMode={diagnostic?.bindingMode}
      bindingDecision={diagnostic?.bindingDecision}
      triggerLabel={identityOnly ? "Матч подтверждён · EXC не привязан" :
        verified ? status === "hydrated" ? "Источник привязан · объёмы идут" :
          sourceBound ? "Источник привязан · объёмы ожидаются" : "Verified manually" : "Review Request"}
      triggerStatus={status}
      triggerAriaLabel={verified ? `Excapper: ${explanation}` : "Review Request"}
      onApproved={onApproved}
    />
  );
}
