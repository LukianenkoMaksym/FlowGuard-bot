import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { LeagueAliasReport } from "./LeagueAliasReport";
import { ExcapperBindingStatus } from "./ExcapperBindingStatus";

afterEach(() => { cleanup(); vi.unstubAllGlobals(); });

const target = { team1: "Home United", team2: "Away FC", league: "NowGoal League" };
const source = { team1: "Away FC", team2: "Home United", league: "Excapper League" };
function renderMismatch() {
  render(<ExcapperBindingStatus diagnostic={{
    status: "missing_league_alias", target, source, lastSuccessfulUpdateAt: null,
  }} />);
  fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
}

describe("league alias reports", () => {
  it("shows only the four comparison fields", () => {
    renderMismatch();
    for (const field of ["ЛИГА", "КОМАНДЫ", "СЧЁТ", "ВРЕМЯ / ПЕРИОД"]) {
      expect(screen.getByText(field)).toBeTruthy();
    }
    expect(screen.queryByText("Review report")).toBeNull();
  });

  it("does not offer reporting for hydrated rows", () => {
    render(<ExcapperBindingStatus diagnostic={{ status: "hydrated", target, source, lastSuccessfulUpdateAt: null }} />);
    expect(screen.queryByRole("button", { name: "Review & Bind" })).toBeNull();
  });

  it("without a visible source ID confirms only the match, not an unseen opaque candidate", async () => {
    const onApproved = vi.fn().mockResolvedValue(undefined);
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: vi.fn().mockResolvedValue({
        ok: true,
        approval: { saved: true },
        binding: { volumePending: false },
      }),
    });
    vi.stubGlobal("fetch", fetchMock);
    render(
      <LeagueAliasReport
        target={target}
        source={source}
        signature="id:12345"
        resolvedCandidate="opaque_candidate_1234567890"
        onApproved={onApproved}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    fireEvent.click(screen.getByRole("button", { name: /Подтвердить/ }));
    await waitFor(() => expect(onApproved).toHaveBeenCalledOnce());
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/matches/bind",
      expect.objectContaining({
        method: "POST",
        credentials: "include",
        body: JSON.stringify({
          nowgoalId: "12345",
          force: true,
          signature: "id:12345",
          source,
        }),
      }),
    );
    await waitFor(() => {
      expect(screen.queryByRole("dialog")).toBeNull();
    });
  });

  it("keeps the dialog open and offers retry when approval conflicts", async () => {
    const onApproved = vi.fn().mockResolvedValue(undefined);
    vi.stubGlobal("fetch", vi.fn().mockImplementation((_url, options) => Promise.resolve(options?.method === "POST" ? {
      ok: false,
      status: 409,
      json: vi.fn().mockResolvedValue({
        ok: false,
        error: "The source fixture changed. No alias was saved.",
      }),
    } : { ok: true, json: async () => ({ decisions: [] }) })));
    render(
      <LeagueAliasReport
        target={target}
        source={source}
        signature="id:12345"
        resolvedCandidate="opaque_candidate_1234567890"
        onApproved={onApproved}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    fireEvent.click(screen.getByRole("button", { name: /Подтвердить/ }));
    expect((await screen.findByRole("alert")).textContent).toContain("Данные источника изменились");
    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(onApproved).toHaveBeenCalledOnce();
    expect((screen.getByRole("button", { name: /Подтвердить/ }) as HTMLButtonElement).disabled).toBe(false);
  });
});
