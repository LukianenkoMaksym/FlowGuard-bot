import { afterEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { LeagueAliasReport } from "./LeagueAliasReport";

afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

const target = {
  team1: "Alpha",
  team2: "Beta",
  league: "Translated league",
  score: { home: 1, away: 0 },
  period: "second-half",
};
const candidates = [
  {
    ref: "opaque_candidate_first_12345",
    gameId: "90001",
    source: { team1: "Alpha FC", team2: "Beta FC", league: "League A" },
    score: { home: 2, away: 0 },
    period: "second-half",
    minute: 60,
    observedTime: "20:30 20.09",
    conflict: "score" as const,
  },
  {
    ref: "opaque_candidate_second_1234",
    gameId: "90002",
    source: { team1: "Alpha", team2: "Beta", league: "League B" },
    score: { home: 1, away: 0 },
    period: "second-half",
    minute: 61,
    observedTime: "20:31 20.09",
    conflict: "timing" as const,
  },
];

describe("fixture binding review", () => {
  it("offers a scored numeric candidate to replace an identity-only approval without fabricating live evidence", async () => {
    const fetchMock = vi.fn().mockImplementation((url) => Promise.resolve({
      ok: true, status: 200,
      json: async () => String(url).includes("/history") ? { decisions: [] } : { ok: true },
    }));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeagueAliasReport
      target={{ team1: "Alpha", team2: "Beta", league: "NowGoal", score: null, period: null }}
      source={null} signature="id:710001" nowgoalId="710001"
      verified bindingMode="manual_override" bindingDecision={{
        status: "manual", reason: "Operator verified NowGoal fixture only",
        chosenId: null, candidateCount: 1,
        evaluatedAt: "2026-09-25T19:00:00Z",
        thresholds: { threshold: .86, epsilon: .03, windowMs: 10800000 },
        scored: [{
          candidate: { id: "90001", team1: "Alpha FC", team2: "Beta FC",
            league: "Excapper League", kickoffMs: null },
          home: .99, away: .99, time: 0, league: false, delta: null,
          score: .7, reason: "live period unavailable",
          normalized: { sourceHome: "alpha", sourceAway: "beta",
            candidateHome: "alpha fc", candidateAway: "beta fc" },
          contributions: { teams: .7, time: 0, league: 0, corroboration: 0 },
          gates: { teams: true, kickoff: false, scorePeriod: false, conflict: false },
        }],
      }}
    />);
    fireEvent.click(screen.getByTestId("excapper-binding-status"));
    expect(screen.getByText("NowGoal · ID 710001")).toBeTruthy();
    expect(screen.getByText("Excapper · ID 90001")).toBeTruthy();
    expect(screen.getAllByText("Нет данных").length).toBeGreaterThan(0);
    fireEvent.click(screen.getByRole("button", { name: /Подтвердить и привязать · ID 710001 ↔ 90001/ }));
    await waitFor(() => expect(fetchMock.mock.calls.some((call) => call[1]?.method === "POST")).toBe(true));
    const request = fetchMock.mock.calls.find((call) => call[1]?.method === "POST")!;
    expect(JSON.parse(request[1].body)).toMatchObject({
      nowgoalId: "710001", excapperId: "90001", force: true,
    });
  });

  it("deduplicates rapid approval clicks without disabling the action", async () => {
    let resolve!: (value: object) => void;
    const fetchMock = vi.fn().mockImplementation((_url, options) =>
      options?.method === "POST"
        ? new Promise((done) => { resolve = done; })
        : Promise.resolve({ ok: true, json: async () => ({ decisions: [] }) }),
    );
    vi.stubGlobal("fetch", fetchMock);
    render(<LeagueAliasReport
      target={target}
      source={candidates[0]!.source}
      signature="id:710001"
      candidates={candidates}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getByText("2 – 0")).toBeTruthy();
    const approve = screen.getByRole("button", { name: /Подтвердить/ }) as HTMLButtonElement;
    fireEvent.click(approve);
    fireEvent.click(approve);
    expect(approve.disabled).toBe(false);
    expect(approve.getAttribute("aria-busy")).toBe("true");
    expect(fetchMock.mock.calls.filter((call) => call[1]?.method === "POST")).toHaveLength(1);
    resolve({ ok: true, status: 200, json: async () => ({ ok: true }) });
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  });

  it("shows conflict evidence without gating and submits the selected candidate", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: vi.fn().mockResolvedValue({ ok: true }),
    });
    vi.stubGlobal("fetch", fetchMock);
    render(<LeagueAliasReport
      target={target}
      source={candidates[0]!.source}
      signature="id:710001"
      candidates={candidates}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getByText("2 – 0")).toBeTruthy();
    const approve = screen.getByRole("button", { name: /Подтвердить/ }) as HTMLButtonElement;
    expect(approve.disabled).toBe(false);

    fireEvent.change(screen.getByLabelText("Команды Excapper"), {
      target: { value: candidates[1]!.ref },
    });
    fireEvent.click(approve);
    await waitFor(() => expect(fetchMock.mock.calls.some((call) => call[1]?.method === "POST")).toBe(true));
    const request = fetchMock.mock.calls.find((call) => call[1]?.method === "POST")!;
    expect(request[0]).toBe("/api/matches/bind");
    expect(JSON.parse(request[1].body)).toMatchObject({
      nowgoalId: "710001",
      candidateId: candidates[1]!.ref,
      force: true,
      source: candidates[1]!.source,
    });
  });

  it.each(["90001", undefined])("binds displayed teams without candidate state (source ID %s)", async (excapperId) => {
    const onApproved = vi.fn();
    const fetchMock = vi.fn().mockImplementation((url) => Promise.resolve({
      ok: true, status: 200,
      json: async () => String(url).includes("/history") ? { decisions: [] } : { success: true },
    }));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeagueAliasReport target={target} source={candidates[0]!.source}
      signature="id:710001" candidateExcapperId={excapperId} onApproved={onApproved} />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    fireEvent.click(screen.getByRole("button", { name: /Подтвердить/ }));
    const request = fetchMock.mock.calls.find((call) => call[1]?.method === "POST")!;
    expect(request[0]).toBe("/api/matches/bind");
    expect(JSON.parse(request[1].body)).toEqual({
      nowgoalId: "710001", ...(excapperId ? { excapperId } : {}),
      force: true, signature: "id:710001", source: candidates[0]!.source,
    });
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    expect(onApproved).toHaveBeenCalledOnce();
  });

  it("renders unavailable instead of inventing a zero score", () => {
    render(<LeagueAliasReport
      target={{ ...target, score: null }}
      source={candidates[0]!.source}
      candidates={[{ ...candidates[0]!, score: null }]}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getAllByText("Нет данных").length).toBeGreaterThanOrEqual(2);
  });

  it("force-saves a numeric binding while score and time are unavailable", async () => {
    const fetchMock = vi.fn().mockImplementation((url) => Promise.resolve({
      ok: true,
      status: 200,
      json: async () => String(url).includes("/history")
        ? { decisions: [] }
        : { success: true, binding: { status: "Verified" } },
    }));
    vi.stubGlobal("fetch", fetchMock);
    render(<LeagueAliasReport
      target={{ ...target, score: null, minute: null, period: null }}
      source={candidates[0]!.source}
      signature="id:710001"
      candidateExcapperId="90001"
      candidates={[{
        ...candidates[0]!,
        gameId: "90001",
        score: null,
        minute: null,
        period: null,
      }]}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getAllByText("Нет данных").length).toBeGreaterThanOrEqual(2);
    const approve = screen.getByRole("button", { name: /Подтвердить/ }) as HTMLButtonElement;
    expect(approve.disabled).toBe(false);
    fireEvent.click(approve);

    await waitFor(() => expect(fetchMock.mock.calls.some((call) => call[1]?.method === "POST")).toBe(true));
    const request = fetchMock.mock.calls.find((call) => call[1]?.method === "POST")!;
    expect(JSON.parse(request[1].body)).toMatchObject({
      nowgoalId: "710001",
      excapperId: "90001",
      force: true,
    });
  });

  it("localizes periods and browser network errors", async () => {
    vi.stubGlobal("fetch", vi.fn().mockImplementation((url, options) =>
      String(url).includes("/history")
        ? Promise.resolve({ ok: true, json: async () => ({ decisions: [] }) })
        : options?.method === "POST"
          ? Promise.reject(new TypeError("Failed to fetch"))
          : Promise.resolve({ ok: true, json: async () => ({}) }),
    ));
    render(<LeagueAliasReport
      target={{ ...target, period: "first_half" }}
      source={candidates[0]!.source}
      signature="id:localized"
      candidates={[{ ...candidates[0]!, period: "second-half" }]}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getByText(/первый тайм/)).toBeTruthy();
    expect(screen.getByText(/второй тайм/)).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Повторить поиск" }));
    expect(await screen.findByText("Не удалось связаться с сервером. Повторите попытку.")).toBeTruthy();
    expect(screen.queryByText(/Failed to fetch/)).toBeNull();
  });

  it.each(["Excapper", "NowGoal"])("retries missing %s fields after 12 seconds without overlap and aborts on close", async (missingSource) => {
    vi.useFakeTimers();
    let refreshSignal: AbortSignal | undefined;
    const fetchMock = vi.fn().mockImplementation((url, options) => {
      if (String(url).includes("/history")) {
        return Promise.resolve({ ok: true, json: async () => ({ decisions: [] }) });
      }
      refreshSignal = options?.signal;
      return new Promise(() => undefined);
    });
    vi.stubGlobal("fetch", fetchMock);
    render(<LeagueAliasReport
      target={target}
      source={candidates[0]!.source}
      signature="id:retry"
      candidates={missingSource === "Excapper"
        ? [{ ...candidates[0]!, score: null, period: null, minute: null }]
        : [candidates[0]!]}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getByText(/Автопоиск повторяется каждые 12 секунд/)).toBeTruthy();
    await act(async () => { await vi.advanceTimersByTimeAsync(11_999); });
    expect(fetchMock.mock.calls.filter((call) => call[1]?.method === "POST")).toHaveLength(0);
    await act(async () => { await vi.advanceTimersByTimeAsync(1); });
    expect(fetchMock.mock.calls.filter((call) => call[1]?.method === "POST")).toHaveLength(1);
    await act(async () => { await vi.advanceTimersByTimeAsync(24_000); });
    expect(fetchMock.mock.calls.filter((call) => call[1]?.method === "POST")).toHaveLength(1);
    fireEvent.click(screen.getByRole("button", { name: "Закрыть" }));
    expect(refreshSignal?.aborted).toBe(true);
  });

  it("keeps a refreshed row despite stale props and highlights approval when live evidence arrives", async () => {
    const refreshedCandidate = {
      ...candidates[1]!,
      source: { team1: "Новый хозяин", team2: "Новый гость", league: "Новая лига" },
      conflict: "none" as const,
    };
    const fetchMock = vi.fn().mockImplementation((url, options) => Promise.resolve(
      String(url).includes("/history")
        ? { ok: true, json: async () => ({ decisions: [] }) }
        : {
          ok: true,
          status: 200,
          json: async () => ({
            ok: true,
            row: {
              signature: "id:dynamic",
              excapperBinding: {
                status: "missing_league_alias",
                source: refreshedCandidate.source,
                candidates: [refreshedCandidate],
              },
            },
          }),
        },
    ));
    vi.stubGlobal("fetch", fetchMock);
    const view = render(<LeagueAliasReport
      target={target}
      source={candidates[0]!.source}
      signature="id:dynamic"
      candidates={[{ ...candidates[0]!, score: null, period: null, minute: null }]}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    fireEvent.click(screen.getByRole("button", { name: "Повторить поиск" }));
    expect(await screen.findByText("Новый хозяин — Новый гость")).toBeTruthy();
    const approve = screen.getByRole("button", { name: /Подтвердить/ });
    expect(approve.className).toContain("ring-2");

    view.rerender(<LeagueAliasReport
      target={target}
      source={candidates[0]!.source}
      signature="id:dynamic"
      candidates={[{ ...candidates[0]!, score: null, period: null, minute: null }]}
    />);
    expect(screen.getByText("Новый хозяин — Новый гость")).toBeTruthy();
  });
});
