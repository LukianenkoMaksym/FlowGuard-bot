import { useState } from "react";
import { BindingDecisionDiagnostic, type BindingDecisionDiagnosticData } from "./BindingDecisionDiagnostic";

export interface RuntimeAuditMatch {
  key: string;
  nowGoalMatchId: string | null;
  matchName: string;
  leagueName: string;
  status: "Verified" | "Review Request" | "Pending";
  excapperMatchId: string | null;
  score: string | null;
  elapsedTime: string | null;
  matchPhase: string;
  /** Explicit lifecycle fields supplied by newer API versions. */
  matchStatus?: "live" | "scheduled" | "finished" | "unknown";
  isLive?: boolean;
  sources: string[];
  /** Latest authoritative binding decision, when supplied by the server. */
  bindingDecision?: BindingDecisionDiagnosticData | null;
}

export interface RuntimeAudit {
  generatedAt: string;
  total: number;
  watchlistTotal: number;
  configuredWatchlistTotal?: number;
  archiveCount?: number;
  matches: RuntimeAuditMatch[];
}

interface RuntimeAuditSummaryProps {
  runtimeAudit?: RuntimeAudit;
  loading: boolean;
  error?: string | null;
  endpoint: string;
}

type PrintState =
  | { kind: "idle" }
  | { kind: "pending" }
  | { kind: "success"; message: string }
  | { kind: "error"; message: string };

function display(value: string | null | undefined): string {
  return value?.trim() || "—";
}

function formatGeneratedAt(value: string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString();
}

function statusClass(status: RuntimeAuditMatch["status"]): string {
  if (status === "Verified") {
    return "border-emerald-800/70 bg-emerald-950/40 text-emerald-300";
  }
  if (status === "Review Request") {
    return "border-amber-800/70 bg-amber-950/40 text-amber-200";
  }
  return "border-zinc-700 bg-zinc-900 text-zinc-300";
}

export function isCurrentLiveAuditMatch(match: RuntimeAuditMatch): boolean {
  if (match.matchStatus !== undefined) return match.matchStatus === "live";
  if (match.isLive !== undefined) return match.isLive === true;
  const phase = match.matchPhase.trim().toLowerCase();
  return phase === "live" || phase === "in-play" || phase === "in play";
}

export function RuntimeAuditSummary({
  runtimeAudit,
  loading,
  error,
  endpoint,
}: RuntimeAuditSummaryProps) {
  const [printState, setPrintState] = useState<PrintState>({ kind: "idle" });
  const liveMatches = runtimeAudit?.matches.filter(isCurrentLiveAuditMatch) ?? [];
  const displayedWatchlistTotal = runtimeAudit
    ? Math.min(Math.max(0, runtimeAudit.watchlistTotal), liveMatches.length)
    : 0;

  const printFullList = async () => {
    setPrintState({ kind: "pending" });
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        credentials: "include",
        headers: { Accept: "application/json" },
      });
      if (!response.ok) {
        let detail = `HTTP ${response.status}`;
        try {
          const body = (await response.json()) as { error?: unknown; message?: unknown };
          if (typeof body.error === "string") detail = body.error;
          else if (typeof body.message === "string") detail = body.message;
        } catch {
          // The HTTP status remains an explicit error if the response is not JSON.
        }
        throw new Error(detail);
      }
      const body = (await response.json()) as { runtimeAudit?: RuntimeAudit };
      if (!body.runtimeAudit) throw new Error("Server returned no runtime audit.");
      setPrintState({ kind: "success", message: "Full runtime list printed to server logs." });
    } catch (printError) {
      setPrintState({
        kind: "error",
        message: printError instanceof Error ? printError.message : String(printError),
      });
    }
  };

  return (
    <section
      className="mt-4 rounded-xl border border-violet-900/60 bg-violet-950/10 p-4"
      aria-labelledby="runtime-audit-heading"
      data-testid="section-runtime-audit"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3
            id="runtime-audit-heading"
            className="text-sm font-semibold text-violet-200"
          >
            Активная диагностика
          </h3>
          <p className="mt-1 text-xs text-zinc-400">
             Активные матчи в прямом эфире и последние решения привязки: причины, вклад каждой команды,
             лиги, времени, счёта и периода, пороги и блокирующие условия (если переданы сервером).
             Завершённые, запланированные и матчи с неизвестным статусом здесь не показываются.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void printFullList()}
          disabled={printState.kind === "pending"}
          className="rounded-md border border-violet-700/70 px-3 py-1.5 text-xs font-medium text-violet-200 hover:bg-violet-950/60 disabled:cursor-wait disabled:opacity-50"
          data-testid="button-print-runtime-audit"
        >
          {printState.kind === "pending" ? "Printing…" : "Print full list to server logs"}
        </button>
      </div>

      {printState.kind !== "idle" && printState.kind !== "pending" && (
        <div
          className={`mt-3 rounded-md border px-3 py-2 text-xs ${
            printState.kind === "success"
              ? "border-emerald-900/60 bg-emerald-950/30 text-emerald-300"
              : "border-rose-900/60 bg-rose-950/30 text-rose-300"
          }`}
          role={printState.kind === "error" ? "alert" : "status"}
          data-testid="status-print-runtime-audit"
        >
          {printState.kind === "error"
            ? `Could not print runtime list: ${printState.message}`
            : printState.message}
        </div>
      )}

      {runtimeAudit ? (
        <>
          <div className="mt-4 grid gap-2 sm:grid-cols-3">
            <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2">
              <div className="text-[10px] uppercase tracking-wider text-zinc-500">Активный список</div>
              <div
                className="mt-1 text-sm font-bold text-cyan-300"
                data-testid="text-runtime-watchlist-total"
              >
                МАТЧЕЙ В ЭФИРЕ В WATCHLIST: {displayedWatchlistTotal}
              </div>
            </div>
            <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2">
              <div className="text-[10px] uppercase tracking-wider text-zinc-500">
                Показано матчей в эфире
              </div>
              <div
                className="mt-1 font-mono text-sm text-zinc-200"
                data-testid="text-runtime-total"
              >
                {liveMatches.length}
              </div>
            </div>
            <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2">
              <div className="text-[10px] uppercase tracking-wider text-zinc-500">
                Snapshot generated
              </div>
              <time
                className="mt-1 block text-sm text-zinc-200"
                dateTime={runtimeAudit.generatedAt}
                data-testid="text-runtime-generated-at"
              >
                {formatGeneratedAt(runtimeAudit.generatedAt)}
              </time>
            </div>
          </div>

          <div className="mt-4 overflow-x-auto" data-testid="scroll-runtime-audit">
            <table className="min-w-[1560px] w-full text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-800 uppercase tracking-wider text-zinc-500">
                  <th className="px-2 py-2">Key</th>
                  <th className="px-2 py-2">NowGoal match ID</th>
                  <th className="px-2 py-2">Match name</th>
                  <th className="px-2 py-2">League name</th>
                  <th className="px-2 py-2">Status</th>
                  <th className="px-2 py-2">Excapper match ID</th>
                  <th className="px-2 py-2">Score</th>
                  <th className="px-2 py-2">Elapsed time</th>
                  <th className="px-2 py-2">Match phase</th>
                  <th className="px-2 py-2">Sources</th>
                  <th className="px-2 py-2">Binding decision · why</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/70 text-zinc-300">
                {liveMatches.map((match) => (
                  <tr key={match.key} data-testid={`row-runtime-audit-${match.key}`}>
                    <td className="whitespace-nowrap px-2 py-2 font-mono">{display(match.key)}</td>
                    <td className="whitespace-nowrap px-2 py-2 font-mono">
                      {display(match.nowGoalMatchId)}
                    </td>
                    <td className="px-2 py-2">{display(match.matchName)}</td>
                    <td className="px-2 py-2">{display(match.leagueName)}</td>
                    <td className="whitespace-nowrap px-2 py-2">
                      <span className={`rounded-full border px-2 py-0.5 ${match.bindingDecision?.status === "manual" &&
                        !match.excapperMatchId && !/^[1-9]\d*$/.test(match.bindingDecision.chosenId ?? "")
                          ? statusClass("Review Request") : statusClass(match.status)}`}>
                        {match.bindingDecision?.status === "manual"
                          ? match.excapperMatchId || /^[1-9]\d*$/.test(match.bindingDecision.chosenId ?? "")
                            ? "Verified manually" : "NowGoal подтверждён · EXC без ID"
                          : match.status}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-2 py-2 font-mono">
                      {display(match.excapperMatchId ??
                        (match.bindingDecision?.status === "manual" &&
                        /^[1-9]\d*$/.test(match.bindingDecision.chosenId ?? "")
                          ? match.bindingDecision.chosenId : null))}
                    </td>
                    <td className="whitespace-nowrap px-2 py-2">{display(match.score)}</td>
                    <td className="whitespace-nowrap px-2 py-2">{display(match.elapsedTime)}</td>
                    <td className="whitespace-nowrap px-2 py-2">{display(match.matchPhase)}</td>
                    <td className="px-2 py-2">
                      {match.sources.length ? match.sources.join(", ") : "—"}
                    </td>
                    <td className="min-w-72 px-2 py-2">
                      <BindingDecisionDiagnostic decision={match.bindingDecision} />
                    </td>
                  </tr>
                ))}
                {liveMatches.length === 0 && (
                  <tr>
                    <td colSpan={11} className="px-2 py-5 text-center text-zinc-500">
                      Сейчас нет подтверждённых матчей в прямом эфире.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <div
          className={`mt-4 rounded-lg border px-3 py-3 text-sm ${
            error
              ? "border-rose-900/60 bg-rose-950/30 text-rose-300"
              : "border-zinc-800 bg-zinc-950/40 text-zinc-400"
          }`}
          role={error ? "alert" : "status"}
          data-testid="status-runtime-audit"
        >
          {loading
            ? "Loading runtime diagnostic snapshot…"
            : error
              ? `Runtime diagnostic unavailable: ${error}`
              : "Runtime diagnostic unavailable in the latest watchlist response."}
        </div>
      )}
    </section>
  );
}