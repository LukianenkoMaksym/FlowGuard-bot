import { afterEach, expect, it } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import { ExcapperBatchNotice } from "./ExcapperBatchNotice";

afterEach(cleanup);

it("does not report a directory limitation after sequential hydration is restored", () => {
  render(<ExcapperBatchNotice status={{
    mode: "sequential", detailCapable: false, stale: false, observedAt: 1000, nextFetchAt: 14000,
  }} />);
  expect(screen.queryByRole("status")).toBeNull();
});

it("distinguishes missing batch details from fresh detailed data", () => {
  const status = { detailCapable: false, stale: false, observedAt: 1000, nextFetchAt: 14000 };
  const view = render(<ExcapperBatchNotice status={status} />);
  expect(screen.getByRole("status").textContent).toContain("автопривязка ожидает");
  view.rerender(<ExcapperBatchNotice status={{ ...status, detailCapable: true }} />);
  expect(screen.queryByRole("status")).toBeNull();
});

it("shows stale retained values on backoff without pretending freshness", () => {
  render(<ExcapperBatchNotice status={{
    detailCapable: true, stale: true, observedAt: 1000, nextFetchAt: 26000,
  }} />);
  expect(screen.getByRole("status").textContent).toContain("время наблюдения не обновляется");
});