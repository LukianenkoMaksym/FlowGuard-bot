import { afterEach, describe, expect, it } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { ExcapperBindingStatus, type ExcapperBindingDiagnostic } from "./ExcapperBindingStatus";
import { ExcapperFreshness } from "./ExcapperFreshness";

afterEach(cleanup);

describe("row Excapper diagnostics", () => {
  it.each([
    ["source_unavailable", "Review Request"],
    ["no_directory_match", "Review Request"],
    ["ambiguous_identity", "Review Request"],
    ["missing_league_alias", "Review Request"],
    ["non_live_candidate", "Review Request"],
    ["missing_live_corroboration", "Review Request"],
    ["score_period_conflict", "Review Request"],
    ["empty_market", "Review Request"],
    ["bound_pending", "Источник привязан · объёмы ожидаются"],
    ["bound_verified", "Источник привязан · объёмы ожидаются"],
    ["hydrated", "Источник привязан · объёмы идут"],
    ["identity_only", "Матч подтверждён · EXC не привязан"],
    ["pending", "Review Request"],
    ["fetch_failed", "Review Request"],
  ] as const)("renders %s distinctly", (status, label) => {
    render(<ExcapperBindingStatus diagnostic={{ status, source: null, lastSuccessfulUpdateAt: null,
      ...(status === "bound_pending" || status === "bound_verified" || status === "hydrated"
        ? { candidateExcapperId: "90001", bindingMode: "manual_override" as const } : {}) }} />);
    const button = screen.getByRole("button");
    expect(button.textContent).toBe(label);
    expect(button.getAttribute("data-status")).toBe(status);
    if (label.startsWith("Источник привязан") || status === "identity_only")
      expect(button.getAttribute("aria-label")).toContain("Excapper:");
    else expect(button.getAttribute("aria-label")).toBe("Review Request");
  });

  it("keeps source names inert and opens the review immediately during an outage", () => {
    const timestamp = 1_790_000_000_000;
    const diagnostic: ExcapperBindingDiagnostic = {
      status: "source_unavailable",
      source: { team1: '<img src=x onerror="alert(1)">', team2: "Away & Club", league: "<script>evil()</script>" },
      lastSuccessfulUpdateAt: timestamp,
    };
    const { container } = render(<ExcapperBindingStatus diagnostic={diagnostic} />);
    expect(container.querySelector("img, script")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getAllByText("Нет данных").length).toBeGreaterThan(0);
  });

  it("handles an older API response without diagnostics", () => {
    render(<ExcapperBindingStatus />);
    expect(screen.getByRole("button").textContent).toBe("Review Request");
  });

  it("uses known watchlist identity when diagnostic target is not loaded", () => {
    render(<ExcapperBindingStatus
      signature="id:123"
      fallbackTarget={{ team1: "Known Home", team2: "Known Away", league: "Known League" }}
    />);
    fireEvent.click(screen.getByRole("button", { name: "Review Request" }));
    expect(screen.getByText("Known Home — Known Away")).toBeTruthy();
    expect(screen.getByText("Known League")).toBeTruthy();
  });

  it("keeps the clickable Verified reset badge during a bound fetch failure", () => {
    render(<ExcapperBindingStatus
      signature="id:123"
      diagnostic={{
        status: "fetch_failed",
        bindingMode: "manual_override",
        candidateExcapperId: "90001",
        target: { team1: "Alpha", team2: "Beta", league: "NowGoal" },
        source: { team1: "Alpha", team2: "Beta", league: "Excapper" },
        lastSuccessfulUpdateAt: 1_790_000_000_000,
      }}
    />);
    const badge = screen.getByTestId("excapper-binding-status");
    expect(badge.textContent).toContain("Источник привязан");
    fireEvent.click(badge);
    expect(screen.getByText(/Привязка подтверждена оператором вручную/)).toBeTruthy();
    expect(screen.getByRole("button", { name: "Отменить привязку" })).toBeTruthy();
  });

  it("distinguishes a saved verified binding from hydrated live data", () => {
    render(<ExcapperBindingStatus diagnostic={{
      status: "bound_verified",
      source: { team1: "Alpha", team2: "Beta", league: "League" },
      lastSuccessfulUpdateAt: null,
      bindingMode: "manual_override",
      candidateExcapperId: "90001",
    }} />);
    expect(screen.getByRole("button", { name: /Числовая привязка источника сохранена/i }))
      .toBeTruthy();
    expect(screen.getByRole("button", { name: /образец объёмов Excapper ещё не получен/i }))
      .toBeTruthy();
  });

  it("keeps an authoritative manual decision verified after a fresh response without an Excapper ID", () => {
    const diagnostic: ExcapperBindingDiagnostic = {
      status: "fetch_failed",
      source: null,
      lastSuccessfulUpdateAt: null,
      bindingDecision: {
        status: "manual", reason: "Operator confirmed fixture; market pending",
        candidateCount: 0, chosenId: null,
        thresholds: { threshold: 35, epsilon: 3, windowMs: 300_000 },
        scored: [], evaluatedAt: "2025-02-03T04:05:06.000Z",
      },
    };
    const firstMount = render(<ExcapperBindingStatus diagnostic={diagnostic} />);
    firstMount.unmount();
    render(<ExcapperBindingStatus diagnostic={{ ...diagnostic }} />);
    const badge = screen.getByTestId("excapper-binding-status");
    expect(badge.textContent).toBe("Матч подтверждён · EXC не привязан");
    fireEvent.click(badge);
    expect(screen.getByText("Подтверждённая привязка матча")).toBeTruthy();
    expect(screen.getByText("Operator confirmed fixture; market pending")).toBeTruthy();
    expect(screen.getByRole("button", { name: /Подтвердить матч · Excapper без ID/ })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Отменить подтверждение матча" })).toBeTruthy();
  });
  it("separates manual acceptance and scored search candidates from source hydration and review actions", () => {
    render(<ExcapperBindingStatus signature="id:3094867" diagnostic={{
      status: "fetch_failed", source: null, candidates: [], lastSuccessfulUpdateAt: null,
      bindingDecision: {
        status: "manual", reason: "Manually accepted",
        candidateCount: 1, chosenId: null, scored: [],
        thresholds: { threshold: 35, epsilon: 3, windowMs: 300_000 },
        evaluatedAt: "2025-02-03T04:05:06.000Z",
      },
    }} />);
    expect(screen.getByTestId("excapper-binding-status").textContent).toBe("Матч подтверждён · EXC не привязан");
    expect(screen.queryByTestId("excapper-source-readiness")).toBeNull();
    expect(screen.queryByTestId("excapper-source-clock")).toBeNull();
    fireEvent.click(screen.getByTestId("excapper-binding-status"));
    expect(screen.getByText(/Manual review options currently supplied: 0/)).toBeTruthy();
    expect(screen.getAllByText(/Search candidates scored: 1/).length).toBeGreaterThan(0);
  });
  it("keeps source clock details in the freshness tooltip, not additional lines", () => {
    const now = Date.now();
    render(<ExcapperFreshness
      diagnostic={{
        status: "hydrated", lastSuccessfulUpdateAt: now - 5_000,
        source: { team1: "Home", team2: "Away", league: "Excapper",
          score: { home: 1, away: 1 }, minute: 57, period: "second-half" },
      }}
    />);
    expect(screen.getByTestId("excapper-source-readiness").textContent).toBe("EXC 5s");
    expect(screen.getByTestId("excapper-source-readiness").getAttribute("title")).toContain("57′ (not the NowGoal minute)");
    expect(screen.queryByTestId("excapper-source-clock")).toBeNull();
  });

  it("distinguishes stale, absent and failed samples compactly", () => {
    const now = Date.now();
    const diagnostic: ExcapperBindingDiagnostic = {
      status: "hydrated", lastSuccessfulUpdateAt: now - 5_000,
      source: { team1: "Home", team2: "Away", league: "Excapper",
        score: { home: 0, away: 2 }, minute: 57, period: "second-half" },
    };
    const { rerender } = render(<ExcapperFreshness
      diagnostic={diagnostic}
    />);
    expect(screen.getByTestId("excapper-source-readiness").textContent).toBe("EXC 5s");
    rerender(<ExcapperFreshness diagnostic={{ ...diagnostic, lastSuccessfulUpdateAt: now - 16 * 60_000 }} />);
    expect(screen.getByTestId("excapper-source-readiness").textContent).toBe("EXC 16m!");
    expect(screen.getByTestId("excapper-source-readiness").title).not.toContain("57′");
    rerender(<ExcapperFreshness diagnostic={{ ...diagnostic, lastSuccessfulUpdateAt: null }} />);
    expect(screen.getByTestId("excapper-source-readiness").textContent).toBe("EXC —");
    rerender(<ExcapperFreshness diagnostic={{ ...diagnostic, status: "fetch_failed" }} />);
    expect(screen.getByTestId("excapper-source-readiness").textContent).toBe("EXC 5s!");
    expect(screen.getByTestId("excapper-source-readiness").title).toContain("latest fetch unavailable");
    expect(screen.getByTestId("excapper-source-readiness").title).not.toContain("57′");
  });
  it.each([undefined, NaN, Infinity, Date.now() + 60_000])("does not invent freshness for invalid timestamp %s", (timestamp) => {
    render(<ExcapperFreshness diagnostic={timestamp === undefined ? undefined : {
      status: "hydrated", source: null, lastSuccessfulUpdateAt: timestamp,
    }} />);
    expect(screen.getByTestId("excapper-source-readiness").textContent).toBe("EXC —");
  });
});