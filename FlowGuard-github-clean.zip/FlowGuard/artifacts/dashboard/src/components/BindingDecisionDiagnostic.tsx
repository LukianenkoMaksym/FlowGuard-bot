export interface BindingDecisionDiagnosticData {
  status: "bound" | "unbound" | "ambiguous" | "manual";
  reason: string;
  candidateCount: number;
  chosenId: string | null;
  thresholds: {
    threshold: number;
    epsilon: number;
    windowMs: number;
  };
  scored: {
    candidate: {
      id: string;
      team1: string;
      team2: string;
      league: string;
      kickoffMs: number | null;
      homeScore?: number | null;
      awayScore?: number | null;
      period?: string | null;
    };
    home: number;
    away: number;
    time: number;
    league: boolean;
    delta: number | null;
    score: number;
    reason: string;
    normalized: {
      sourceHome: string;
      sourceAway: string;
      candidateHome: string;
      candidateAway: string;
    };
    contributions: {
      teams: number;
      time: number;
      league: number;
      corroboration: number;
    };
    gates: {
      teams: boolean;
      kickoff: boolean;
      scorePeriod: boolean;
      conflict: boolean;
    };
  }[];
  evaluatedAt: string;
}

const statusLabels: Record<BindingDecisionDiagnosticData["status"], string> = {
  bound: "Bound automatically",
  unbound: "Not bound",
  ambiguous: "Ambiguous — no binding selected",
  manual: "Verified manually",
};

function value(number: number | null): string {
  return number == null ? "No data" : String(number);
}

function gate(value: boolean): string {
  return value ? "yes" : "no";
}

export function BindingDecisionDiagnostic({ decision }: { decision?: BindingDecisionDiagnosticData | null }) {
  if (!decision) return <span className="text-zinc-500">Decision diagnostic unavailable</span>;

  return (
    <div className="space-y-1 text-xs" data-testid="binding-decision-diagnostic">
      <p className="font-semibold text-zinc-200">{statusLabels[decision.status]}</p>
      <p className="whitespace-normal break-words">{decision.reason}</p>
      <p>Search candidates scored: {decision.candidateCount} · Threshold: {decision.thresholds.threshold} ·
        Epsilon: {decision.thresholds.epsilon} · Window: {decision.thresholds.windowMs} ms
      </p>
      {decision.chosenId != null && <p>Chosen Excapper ID: {decision.chosenId}</p>}
      <time dateTime={decision.evaluatedAt} className="text-zinc-500">
        Evaluated: {decision.evaluatedAt}
      </time>
      {decision.scored.length > 0 && (
        <details className="mt-1">
          <summary className="cursor-pointer text-cyan-300">Candidate scores and gates ({decision.scored.length})</summary>
          <ol className="mt-2 space-y-2">
            {decision.scored.map((item, index) => (
              <li key={`${item.candidate.id}-${index}`} className="rounded border border-zinc-700 p-2">
                <p className="font-semibold">{item.candidate.team1} — {item.candidate.team2}
                  {" · "}{item.candidate.league}
                  {" · ID "}{item.candidate.id}
                </p>
                <p>Score: {value(item.score)} · {item.reason}</p>
                <p>Home: {value(item.home)} · Away: {value(item.away)} ·
                  Time: {value(item.time)} · League match: {gate(item.league)} · Delta: {value(item.delta)}
                </p>
                <p>Normalized: {item.normalized.sourceHome} / {item.normalized.sourceAway} →
                  {" "}{item.normalized.candidateHome} / {item.normalized.candidateAway}
                </p>
                <p>Contributions — teams: {value(item.contributions.teams)},
                  time: {value(item.contributions.time)},
                  league: {value(item.contributions.league)},
                  corroboration: {value(item.contributions.corroboration)}
                </p>
                <p>Gates — teams: {gate(item.gates.teams)}, kickoff: {gate(item.gates.kickoff)},
                  score/period: {gate(item.gates.scorePeriod)}, conflict: {gate(item.gates.conflict)}
                </p>
                <p>Kickoff: {item.candidate.kickoffMs == null
                  ? "No data" : new Date(item.candidate.kickoffMs).toLocaleString()}</p>
              </li>
            ))}
          </ol>
        </details>
      )}
    </div>
  );
}