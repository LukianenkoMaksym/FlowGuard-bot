export interface ExcapperBatchStatus {
  mode?: "batch" | "sequential";
  detailCapable: boolean;
  stale: boolean;
  observedAt: number | null;
  nextFetchAt: number | null;
}

export function ExcapperBatchNotice({ status }: { status?: ExcapperBatchStatus }) {
  if (status?.mode === "sequential" && !status.stale) return null;
  if (!status || (!status.stale && (status.detailCapable || status.observedAt === null))) return null;
  return (
    <p role="status" className="mt-2 text-xs text-amber-300">
      {status.stale
        ? "Excapper: используются последние сохранённые данные. Повторный запрос отложен; время наблюдения не обновляется."
        : "Excapper: общий ответ не содержит подробных данных матчей. Счёт, период и объёмы по линиям не обновляются; автопривязка ожидает подтверждающих данных."}
    </p>
  );
}