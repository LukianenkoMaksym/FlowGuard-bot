import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { useState } from "react";
import { DropThresholdAutoTuner, type AutoTunerStatus } from "./DropThresholdAutoTuner";

const off: AutoTunerStatus = {
  enabled: false,
  state: "off",
  sampleSize: 12,
  minSamples: 40,
  winRatePct: null,
  pausedUntil: null,
  lastAdjustment: null,
  nextAdjustmentAt: null,
  dropThreshold: 0.4,
};

const response = (body: unknown, status = 200) =>
  Promise.resolve(new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  }));

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("drop threshold auto-tuner", () => {
  it("starts from server OFF and shows progress separately from manual edits", async () => {
    vi.stubGlobal("fetch", vi.fn(() => response(off)));
    render(<DropThresholdAutoTuner apiBase="/api" manualApplyRevision={0} />);
    expect(await screen.findByText("OFF · Turn on")).toBeTruthy();
    expect(screen.getByTestId("status-drop-auto-tuner").textContent).toContain("12/40");
    expect(screen.getByTestId("text-server-drop-threshold").textContent).toBe("0.40");
    expect(screen.getByText(/last 60 real settled ODDS_DROP/)).toBeTruthy();
  });

  it("enables only after the PATCH confirms persistence, showing adjustment and cooldown", async () => {
    const on: AutoTunerStatus = {
      ...off, enabled: true, state: "cooldown", sampleSize: 44, winRatePct: 62.5,
      dropThreshold: 0.35, nextAdjustmentAt: "2026-10-02T12:00:00Z",
      lastAdjustment: {
        at: "2026-10-01T12:00:00Z", oldThreshold: 0.4, newThreshold: 0.35,
        winRatePct: 62.5, sampleSize: 44,
      },
    };
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response(off))
      .mockImplementationOnce(() => response({ ...on, persisted: true }));
    vi.stubGlobal("fetch", fetchMock);
    render(<DropThresholdAutoTuner apiBase="/api" manualApplyRevision={0} />);
    fireEvent.click(await screen.findByTestId("button-toggle-drop-auto-tuner"));
    await waitFor(() => expect(screen.getByText("ON · Turn off")).toBeTruthy());
    expect(fetchMock).toHaveBeenLastCalledWith("/api/scanner/auto-tuner", expect.objectContaining({
      method: "PATCH", credentials: "include", body: JSON.stringify({ enabled: true }),
    }));
    expect(screen.getByTestId("text-last-drop-adjustment").textContent).toContain("0.40 → 0.35 · 62.5% WIN · N=44");
    expect(screen.getByText(/Next eligible adjustment:/)).toBeTruthy();
  });

  it("does not claim success when persistence fails, and allows retry", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response(off))
      .mockImplementationOnce(() => response({ ...off, enabled: true, persisted: false }))
      .mockImplementationOnce(() => response(off));
    vi.stubGlobal("fetch", fetchMock);
    render(<DropThresholdAutoTuner apiBase="/api" manualApplyRevision={0} />);
    fireEvent.click(await screen.findByText("OFF · Turn on"));
    expect(await screen.findByRole("alert")).toBeTruthy();
    expect(screen.getByText("OFF · Turn on")).toBeTruthy();
    fireEvent.click(screen.getByTestId("button-retry-drop-auto-tuner"));
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(3));
  });

  it("keeps OFF and reports a failed PATCH", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response(off))
      .mockImplementationOnce(() => response({ error: "Storage unavailable" }, 503));
    vi.stubGlobal("fetch", fetchMock);
    render(<DropThresholdAutoTuner apiBase="/api" manualApplyRevision={0} />);
    fireEvent.click(await screen.findByText("OFF · Turn on"));
    expect((await screen.findByRole("alert")).textContent).toContain("Storage unavailable");
    expect(screen.getByText("OFF · Turn on")).toBeTruthy();
  });

  it("shows backend error explanations even when state is holding or off", async () => {
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ...off, state: "holding", error: "Threshold outside tuner bounds" }))
      .mockImplementationOnce(() => response({ ...off, error: "Startup storage failure" }));
    vi.stubGlobal("fetch", fetchMock);
    const view = render(<DropThresholdAutoTuner apiBase="/api" manualApplyRevision={0} />);
    expect((await screen.findByRole("alert")).textContent).toContain("Threshold outside tuner bounds");
    view.rerender(<DropThresholdAutoTuner apiBase="/api" manualApplyRevision={1} />);
    await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("Startup storage failure"));
  });

  it("refreshes paused state after manual Apply without changing dirty parent input", async () => {
    const paused: AutoTunerStatus = {
      ...off, enabled: true, state: "paused", pausedUntil: "2026-10-08T12:00:00Z",
    };
    const fetchMock = vi.fn()
      .mockImplementationOnce(() => response({ ...off, enabled: true, state: "collecting" }))
      .mockImplementationOnce(() => response(paused));
    vi.stubGlobal("fetch", fetchMock);
    function Parent() {
      const [draft, setDraft] = useState("0.40");
      const [revision, setRevision] = useState(0);
      return (
        <>
          <input aria-label="Manual threshold draft" value={draft} onChange={(event) => setDraft(event.target.value)} />
          <button onClick={() => setRevision((value) => value + 1)}>Manual Apply completed</button>
          <DropThresholdAutoTuner apiBase="/api" manualApplyRevision={revision} />
        </>
      );
    }
    render(<Parent />);
    await screen.findByText("ON · Turn off");
    const input = screen.getByRole("textbox", { name: "Manual threshold draft" }) as HTMLInputElement;
    fireEvent.change(input, { target: { value: "0.79" } });
    fireEvent.click(screen.getByText("Manual Apply completed"));
    expect(await screen.findByText(/Manual Apply pauses tuning for 7 days, until/)).toBeTruthy();
    expect(input.value).toBe("0.79");
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });
});