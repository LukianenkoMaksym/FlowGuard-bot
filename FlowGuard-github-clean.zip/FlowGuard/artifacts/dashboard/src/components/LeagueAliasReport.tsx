import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogTrigger } from "./ui/dialog";
import { BindingDecisionHistory } from "./BindingDecisionHistory";
import { BindingDecisionDiagnostic, type BindingDecisionDiagnosticData } from "./BindingDecisionDiagnostic";

export interface LeagueReportIdentity {
  excapperId?: string | null;
  team1: string;
  team2: string;
  league: string;
  score?: { home: number; away: number } | null;
  period?: string | null;
  minute?: number | null;
}

export interface BindingReviewCandidate {
  ref: string;
  gameId?: string | null;
  source: LeagueReportIdentity;
  score: { home: number; away: number } | null;
  period: string | null;
  minute: number | null;
  observedTime: string | null;
  capturedAt?: number;
  conflict: "none" | "score" | "timing" | "missing";
}

function label(value: string): string {
  if (/(?:https?:\/\/|www\.|(?:password|token|secret|authorization|api[_-]?key)\s*[:=]|bearer\s)/i.test(value)) {
    return "[Label withheld: sensitive or URL-like content]";
  }
  return value.replace(/[\u0000-\u001f\u007f]/g, " ").trim() || "(not provided)";
}

export function buildLeagueAliasReport(target: LeagueReportIdentity, source: LeagueReportIdentity): string {
  return [
    "Fixture binding review request",
    "Status: unresolved — no binding approved",
    "",
    `NowGoal / watchlist league: ${label(target.league)}`,
    `NowGoal / watchlist team 1: ${label(target.team1)}`,
    `NowGoal / watchlist team 2: ${label(target.team2)}`,
    "",
    `Excapper league: ${label(source.league)}`,
    `Excapper team 1: ${label(source.team1)}`,
    `Excapper team 2: ${label(source.team2)}`,
    "",
    "Review required. Full-pair, live-only, and one-to-one checks must still pass.",
  ].join("\n");
}

function score(value: { home: number; away: number } | null | undefined): string {
  return value ? `${value.home} – ${value.away}` : "Нет данных";
}

function periodLabel(value: string | null | undefined): string {
  if (!value) return "Нет данных";
  const normalized = value.trim().toLowerCase().replace(/[_\s]+/g, "-");
  const known: Record<string, string> = {
    "first-half": "первый тайм",
    "half-time": "перерыв",
    "second-half": "второй тайм",
    "extra-time": "дополнительное время",
    "penalties": "серия пенальти",
    "finished": "матч завершён",
  };
  return known[normalized] ?? `другой период: ${value.replace(/[\u0000-\u001f\u007f]/g, " ").trim()}`;
}

function localizedError(error: unknown, fallback: string): string {
  if (error instanceof Error && /[А-Яа-яЁё]/.test(error.message)) return error.message;
  return fallback;
}

interface RefreshedWatchlistRow {
  matchId?: string | null;
  signature?: string;
  label?: string;
  fragments?: string[];
  live?: {
    team1: string;
    team2: string;
    league: string;
    homeScore?: number;
    awayScore?: number;
    minute?: number | null;
    period?: string | null;
  } | null;
  excapperBinding?: {
    status?: string;
    source?: LeagueReportIdentity | null;
    target?: LeagueReportIdentity | null;
    resolvedCandidate?: string | null;
    candidateExcapperId?: string | null;
    candidates?: BindingReviewCandidate[];
    bindingMode?: "automatic" | "manual_override";
    bindingDecision?: BindingDecisionDiagnosticData | null;
  };
}

interface RefreshPayload {
  ok?: boolean;
  error?: string;
  row?: RefreshedWatchlistRow | null;
  snapshot?: {
    entries?: RefreshedWatchlistRow[];
    savedEntries?: RefreshedWatchlistRow[];
  };
}

function refreshedTarget(row: RefreshedWatchlistRow): LeagueReportIdentity | null {
  if (row.excapperBinding?.target) return row.excapperBinding.target;
  if (row.live) {
    return {
      team1: row.live.team1,
      team2: row.live.team2,
      league: row.live.league,
      score: row.live.homeScore == null || row.live.awayScore == null
        ? null
        : { home: row.live.homeScore, away: row.live.awayScore },
      minute: row.live.minute,
      period: row.live.period,
    };
  }
  if (row.fragments && row.fragments.length >= 2) {
    return { team1: row.fragments[0]!, team2: row.fragments[1]!, league: "Нет данных" };
  }
  return row.label ? { team1: row.label, team2: "Нет данных", league: "Нет данных" } : null;
}

export function LeagueAliasReport({
  target,
  source,
  signature,
  nowgoalId,
  candidateExcapperId,
  resolvedCandidate,
  candidates = [],
  verified = false,
  sourceBound = false,
  triggerLabel,
  triggerStatus,
  triggerAriaLabel,
  bindingMode,
  bindingDecision,
  onApproved,
}: {
  target?: LeagueReportIdentity | null;
  source: LeagueReportIdentity | null;
  signature?: string;
  nowgoalId?: string | null;
  candidateExcapperId?: string | null;
  resolvedCandidate?: string | null;
  candidates?: BindingReviewCandidate[];
  verified?: boolean;
  sourceBound?: boolean;
  triggerLabel?: string;
  triggerStatus?: string;
  triggerAriaLabel?: string;
  bindingMode?: "automatic" | "manual_override";
  bindingDecision?: BindingDecisionDiagnosticData | null;
  onApproved?: () => void | Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [approvalError, setApprovalError] = useState("");
  const [refreshError, setRefreshError] = useState("");
  const [freshRow, setFreshRow] = useState<RefreshedWatchlistRow | null>(null);
  const initialRef = resolvedCandidate ?? candidates[0]?.ref ?? "";
  const [selectedRef, setSelectedRef] = useState(initialRef);
  const [confirmReset, setConfirmReset] = useState(false);
  const inFlight = useRef(false);
  const refreshInFlight = useRef(false);
  const refreshController = useRef<AbortController | null>(null);
  const localDiagnostic = freshRow?.excapperBinding;
  const effectiveDecision = localDiagnostic?.bindingDecision ?? bindingDecision;
  const discovered = (effectiveDecision?.scored ?? []).filter((item) =>
    /^[1-9]\d*$/.test(item.candidate.id) && item.candidate.team1 && item.candidate.team2,
  ).map((item): BindingReviewCandidate => ({
    ref: item.candidate.id, gameId: item.candidate.id,
    source: { excapperId: item.candidate.id, team1: item.candidate.team1,
      team2: item.candidate.team2, league: item.candidate.league },
    score: item.candidate.homeScore == null || item.candidate.awayScore == null ? null :
      { home: item.candidate.homeScore, away: item.candidate.awayScore },
    period: item.candidate.period ?? null, minute: null, observedTime: null,
    conflict: item.gates.conflict ? "score" : "missing",
  }));
  const localCandidates = (localDiagnostic?.candidates ?? candidates).length
    ? localDiagnostic?.candidates ?? candidates : discovered;
  const localResolvedCandidate = localDiagnostic?.resolvedCandidate ?? resolvedCandidate;
  const selected = useMemo(
    () => localCandidates.find((candidate) => candidate.ref === selectedRef) ?? localCandidates[0],
    [localCandidates, selectedRef],
  );
  useEffect(() => {
    if (localCandidates.length > 0 && !localCandidates.some((candidate) => candidate.ref === selectedRef)) {
      setSelectedRef(localResolvedCandidate ?? localCandidates[0]!.ref);
    }
  }, [localCandidates, localResolvedCandidate, selectedRef]);
  useEffect(() => {
    setFreshRow(null);
    setRefreshError("");
    refreshController.current?.abort();
    refreshController.current = null;
    refreshInFlight.current = false;
    setRefreshing(false);
  }, [signature]);
  const selectedSource = selected?.source ?? localDiagnostic?.source ?? source;
  const sourceGameId = selected?.gameId ?? selectedSource?.excapperId ??
    localDiagnostic?.candidateExcapperId ?? candidateExcapperId;
  const explicitPair = /^[1-9]\d*$/.test(sourceGameId ?? "") &&
    !!selectedSource?.team1 && !!selectedSource?.team2;
  const localTarget = freshRow ? refreshedTarget(freshRow) ?? target : target;
  const unsafe = selected?.conflict && selected.conflict !== "none";
  const selectedScore = selected?.score ?? selectedSource?.score;
  const selectedPeriod = selected?.period ?? selectedSource?.period;
  const selectedMinute = selected?.minute ?? selectedSource?.minute;
  const missingExcapperFields = !selectedSource?.team1 || !selectedSource.team2 ||
    !selectedSource.league || !selectedScore || selectedPeriod == null || selectedMinute == null ||
    !localTarget?.score || localTarget.period == null || localTarget.minute == null;
  const hasLiveEvidence = Boolean(selectedScore && selectedPeriod);
  const effectiveVerified = verified || Boolean(localDiagnostic &&
    (["hydrated", "bound_pending", "bound_verified"].includes(localDiagnostic.status ?? "") ||
      localDiagnostic.bindingMode !== undefined || localDiagnostic.bindingDecision?.status === "manual"));
  const effectiveBindingMode = localDiagnostic?.bindingMode ?? bindingMode;
  const effectiveSourceBound = localDiagnostic
    ? localDiagnostic.status !== "identity_only" && localDiagnostic.bindingMode != null &&
      /^[1-9]\d*$/.test(localDiagnostic.candidateExcapperId ?? "")
    : sourceBound;

  const refresh = useCallback(async () => {
    if (refreshInFlight.current) return;
    if (!signature) {
      setRefreshError("Строка списка наблюдения ещё не загружена. Повторите попытку позже.");
      return;
    }
    refreshInFlight.current = true;
    setRefreshing(true);
    setRefreshError("");
    const controller = new AbortController();
    refreshController.current = controller;
    try {
      const response = await fetch(`/api/watchlist/${encodeURIComponent(signature)}/refresh`, {
        method: "POST",
        credentials: "include",
        cache: "no-store",
        headers: { "Cache-Control": "no-cache" },
        signal: controller.signal,
      });
      const payload = await response.json().catch(() => null) as RefreshPayload | null;
      if (!response.ok || !payload?.ok) throw new Error(`Не удалось обновить данные (HTTP ${response.status}).`);
      const fallbackRows = [
        ...(payload.snapshot?.entries ?? []),
        ...(payload.snapshot?.savedEntries ?? []),
      ];
      const row = payload.row ?? fallbackRows.find((entry) => entry.signature === signature);
      if (!row) throw new Error("Обновлённая строка не найдена. Повторите поиск.");
      setFreshRow(row);
      if (row.excapperBinding?.bindingDecision?.status === "manual" ||
          row.excapperBinding?.bindingMode !== undefined) {
        await onApproved?.();
      }
      const nextCandidates = row.excapperBinding?.candidates ?? [];
      const nextRef = row.excapperBinding?.resolvedCandidate ?? nextCandidates[0]?.ref;
      if (nextRef) setSelectedRef(nextRef);
    } catch (error) {
      if (!controller.signal.aborted) {
        setRefreshError(localizedError(error, "Не удалось связаться с сервером. Повторите попытку."));
      }
    } finally {
      if (refreshController.current === controller) {
        refreshController.current = null;
        refreshInFlight.current = false;
        if (!controller.signal.aborted) setRefreshing(false);
      }
    }
  }, [signature, onApproved]);

  useEffect(() => {
    if (!open || !signature || !missingExcapperFields || refreshing) return;
    const timer = window.setTimeout(() => void refresh(), 12_000);
    return () => window.clearTimeout(timer);
  }, [open, signature, missingExcapperFields, refreshing, refresh, freshRow]);

  useEffect(() => () => refreshController.current?.abort(), []);
  useEffect(() => {
    if (open) return;
    refreshController.current?.abort();
    refreshController.current = null;
    refreshInFlight.current = false;
    setRefreshing(false);
  }, [open]);

  async function mutate(path: string, body?: object) {
    if (inFlight.current) return;
    if (!signature && path !== "league-alias-approval") {
      setApprovalError("Строка списка наблюдения ещё не загружена. Повторите попытку позже.");
      return;
    }
    inFlight.current = true;
    setBusy(true);
    setApprovalError("");
    let responseStatus = 0;
    try {
      const approval = path === "league-alias-approval";
      const response = await fetch(approval ? "/api/matches/bind" : `/api/watchlist/${encodeURIComponent(signature!)}/${path}`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(approval ? {
          nowgoalId: freshRow?.matchId || nowgoalId || /^id:(\d+)$/.exec(signature ?? "")?.[1],
          excapperId: explicitPair ? sourceGameId : undefined,
          candidateId: explicitPair ? selected?.ref || localResolvedCandidate || selectedRef || undefined : undefined,
          force: true,
          signature,
          source: selectedSource,
        } : body ?? {}),
      });
      responseStatus = response.status;
      const payload = await response.json().catch(() => null) as { ok?: boolean; success?: boolean; error?: string } | null;
      if (!response.ok || !(payload?.ok || payload?.success)) {
        throw new Error(response.status === 409
          ? "Данные источника изменились. Обновите данные и повторите подтверждение."
          : `Ошибка запроса (HTTP ${response.status}). Изменения не сохранены.`);
      }
      setFreshRow(null);
      await onApproved?.();
      setOpen(false);
    } catch (error) {
      setApprovalError(localizedError(error, "Не удалось связаться с сервером. Изменения не сохранены."));
      if (responseStatus === 409) await onApproved?.();
    } finally {
      inFlight.current = false;
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(next) => {
      if (busy) return;
      setOpen(next);
      setApprovalError("");
      setRefreshError("");
      setConfirmReset(false);
      if (next) setSelectedRef(localResolvedCandidate ?? localCandidates[0]?.ref ?? initialRef);
      if (!next) {
        refreshController.current?.abort();
        refreshController.current = null;
        refreshInFlight.current = false;
        setRefreshing(false);
      }
    }}>
      <DialogTrigger asChild>
        <button type="button"
          data-testid="excapper-binding-status"
          data-status={triggerStatus}
          aria-label={triggerAriaLabel}
          className={`block mx-auto mt-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold ${sourceBound ? "border-emerald-500/60 bg-emerald-950/50 text-emerald-300" : "border-amber-500/60 bg-amber-950/50 text-amber-200"}`}>
          {triggerLabel ?? (verified ? "Verified" : "Review Request")}
        </button>
      </DialogTrigger>
      <DialogContent closeLabel="Закрыть" className="max-h-[90vh] overflow-y-auto max-w-2xl bg-zinc-900 text-zinc-100 border-zinc-700">
        <DialogTitle>{effectiveVerified ? "Подтверждённая привязка матча" : "Проверка привязки матча"}</DialogTitle>
        <DialogDescription className="sr-only">Сравните данные матча в двух источниках.</DialogDescription>

        {!effectiveSourceBound && (
          <div className={`overflow-hidden rounded border ${unsafe ? "border-red-500" : "border-zinc-700"}`}>
            <div className="grid grid-cols-[7rem_1fr_1fr] bg-zinc-950 px-3 py-2 text-xs font-semibold text-zinc-400">
              <span />
              <span>NowGoal · ID {freshRow?.matchId || nowgoalId || "—"}</span>
              <span>Excapper · ID {explicitPair ? sourceGameId : "не найден"}</span>
            </div>
            {[
              ["ЛИГА", localTarget?.league, selectedSource?.league],
              ["КОМАНДЫ", localTarget ? `${localTarget.team1} — ${localTarget.team2}` : null, selectedSource ? `${selectedSource.team1} — ${selectedSource.team2}` : null],
              ["СЧЁТ", localTarget ? score(localTarget.score) : null, score(selectedScore)],
              ["ВРЕМЯ / ПЕРИОД", localTarget ? `${localTarget.minute == null ? "Нет данных" : localTarget.minute} · ${periodLabel(localTarget.period)}` : null,
                `${selectedMinute == null ? "Нет данных" : selectedMinute} · ${periodLabel(selectedPeriod)}`],
            ].map(([field, nowGoal, excapper]) => (
              <div key={field} className="grid grid-cols-[7rem_1fr_1fr] border-t border-zinc-700 px-3 py-2 text-sm">
                <span className="text-xs font-semibold text-zinc-400">{field}</span>
                 <span>{nowGoal || "Нет данных"}</span>
                <span>
                   {field === "КОМАНДЫ" && localCandidates.length > 1 ? (
                     <select aria-label="Команды Excapper" value={selected?.ref ?? ""}
                      onChange={(event) => setSelectedRef(event.target.value)}
                      className="w-full rounded border border-zinc-600 bg-zinc-950 p-1">
                       {localCandidates.map((candidate) => (
                        <option key={candidate.ref} value={candidate.ref}>
                           ID {candidate.gameId}: {candidate.source.team1} — {candidate.source.team2}
                        </option>
                      ))}
                    </select>
                   ) : (selectedSource ? excapper : "Нет данных")}
                </span>
              </div>
            ))}
          </div>
        )}

        <button type="button" aria-busy={refreshing} onClick={() => void refresh()}
          className="self-start rounded border border-sky-600 px-3 py-2 text-sm font-medium text-sky-200">
          {refreshing ? "Обновление…" : missingExcapperFields ? "Повторить поиск" : "Обновить данные"}
        </button>
        <p className="text-xs text-zinc-400">
          Manual review options currently supplied: {localCandidates.length}.
          {effectiveDecision && ` Search candidates scored: ${effectiveDecision.candidateCount}.`}
          {" "}These are different lists; an empty review list does not erase a scored search candidate.
        </p>
        {missingExcapperFields && (
          <p className="text-xs text-zinc-400">
            Автопоиск повторяется каждые 12 секунд, пока не появятся данные. Кнопка запускает поиск сразу.
          </p>
        )}

        {effectiveSourceBound ? (
          <div className="flex flex-col gap-3">
            <p className="text-sm text-emerald-300">
              Матч подтверждён. Источник Excapper ID {localDiagnostic?.candidateExcapperId ?? candidateExcapperId} привязан.
               {(effectiveBindingMode === "manual_override" || effectiveDecision?.status === "manual") &&
                 " Привязка подтверждена оператором вручную."}
            </p>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={confirmReset} onChange={(event) => setConfirmReset(event.target.checked)} />
              Подтвердить отмену привязки
            </label>
            <button type="button" disabled={!confirmReset || busy}
              onClick={() => mutate("excapper-binding/reset")}
              className="self-end rounded bg-red-700 px-3 py-2 text-sm disabled:opacity-50">
              {busy ? "Сброс…" : "Отменить привязку"}
            </button>
          </div>
        ) : (
          <>
          {effectiveVerified && <p className="text-sm text-amber-300">
            Матч NowGoal подтверждён, но источник Excapper не привязан — объёмы не загрузятся до подтверждения конкретной пары.
          </p>}
          <button type="button"
            aria-busy={busy}
            onClick={() => mutate("league-alias-approval", {
              resolvedCandidate: selectedRef,
              explicitConfirmation: true,
            })}
             className={`self-end rounded px-3 py-2 text-sm font-medium disabled:opacity-50 ${hasLiveEvidence ? "bg-emerald-500 text-zinc-950 ring-2 ring-emerald-300" : "bg-emerald-800 text-white"}`}>
             {explicitPair ? `Подтвердить и привязать · ID ${freshRow?.matchId || nowgoalId || "—"} ↔ ${sourceGameId}` :
               "Подтвердить матч · Excapper без ID"}
          </button>
          {effectiveVerified && <>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={confirmReset} onChange={(event) => setConfirmReset(event.target.checked)} />
              Подтвердить отмену подтверждения матча
            </label>
            <button type="button" disabled={!confirmReset || busy} onClick={() => mutate("excapper-binding/reset")}
              className="self-end text-xs text-red-300 disabled:opacity-50">Отменить подтверждение матча</button>
          </>}
          </>
        )}
        <div className="rounded border border-zinc-700 p-3" aria-label="Binding decision diagnostic">
          <BindingDecisionDiagnostic decision={effectiveDecision} />
        </div>
        {!effectiveVerified && busy && <p role="status" className="text-xs text-zinc-300">Выполнение запроса…</p>}
        {refreshError && <p role="alert" className="text-xs text-red-400">{refreshError}</p>}
        {approvalError && <p role="alert" className="text-xs text-red-400">{approvalError}</p>}
        {open && signature && <BindingDecisionHistory signature={signature} />}
      </DialogContent>
    </Dialog>
  );
}
