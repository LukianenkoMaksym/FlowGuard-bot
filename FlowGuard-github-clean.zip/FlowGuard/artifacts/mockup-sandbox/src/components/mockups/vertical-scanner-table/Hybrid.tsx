import React from "react";
import { ArrowDown, ArrowUp, Activity } from "lucide-react";

// Mock Data
const MOCK_MATCHES = [
  {
    id: "m1",
    league: "Premier League",
    team1: "Manchester City",
    team2: "Arsenal",
    isLive: true,
    minute: "67'",
    homeScore: 2,
    awayScore: 1,
    masterLine: "3.5",
    provenance: { sofa: true, alt: false, consensus: true },
    signal: {
      successRate: 72.4,
      targetSide: "Over",
      patternTag: "🔥 Smart Money",
    },
    lines: [
      {
        line: "O 3.5",
        xcaper: { vol: "12.4k", delta: "+2.1k", spike: true },
        betfair: { odds: "0.85", tickDelta: "+0.10", trend: "up" },
        consensus: { pressureSide: "Over", pressureMagnitude: 75, bookCount: 12, direction: "down" },
      },
      {
        line: "U 3.5",
        xcaper: { vol: "2.1k", delta: "+100", spike: false },
        betfair: { odds: "1.05", tickDelta: "-0.05", trend: "down" },
        consensus: { pressureSide: "Under", pressureMagnitude: 25, bookCount: 12, direction: "up" },
      },
      {
        line: "O 4.5",
        xcaper: { vol: "8.2k", delta: "+500", spike: false },
        betfair: { odds: "2.10", tickDelta: "-0.20", trend: "down" },
        consensus: { pressureSide: "Over", pressureMagnitude: 50, bookCount: 12, direction: "down" },
      },
    ],
  },
  {
    id: "m2",
    league: "La Liga",
    team1: "Real Madrid",
    team2: "Barcelona",
    isLive: true,
    minute: "82'",
    homeScore: 0,
    awayScore: 0,
    masterLine: "0.5/1",
    provenance: { sofa: false, alt: true, consensus: false },
    signal: {
      successRate: 88.1,
      targetSide: "Under",
      patternTag: "🛡️ Hidden Resistance",
    },
    lines: [
      {
        line: "O 0.5",
        xcaper: { vol: "45.1k", delta: "+8.9k", spike: true },
        betfair: { odds: "0.55", tickDelta: "-0.15", trend: "down" },
        consensus: { pressureSide: "Over", pressureMagnitude: 91, bookCount: 12, direction: "down" },
      },
      {
        line: "U 0.5",
        xcaper: { vol: "15.0k", delta: "+200", spike: false },
        betfair: { odds: "1.60", tickDelta: "+0.25", trend: "up" },
        consensus: { pressureSide: "Under", pressureMagnitude: 9, bookCount: 12, direction: "up" },
      },
    ],
  },
  {
    id: "m3",
    league: "Serie A",
    team1: "Juventus",
    team2: "AC Milan",
    isLive: true,
    minute: "12'",
    homeScore: 0,
    awayScore: 0,
    masterLine: "2.0",
    provenance: { sofa: true, alt: true, consensus: true },
    signal: null,
    lines: [
      {
        line: "O 2.0",
        xcaper: { vol: "1.2k", delta: "+50", spike: false },
        betfair: { odds: "0.95", tickDelta: "+0.02", trend: "up" },
        consensus: { pressureSide: "Over", pressureMagnitude: 50, bookCount: 10, direction: "up" },
      },
      {
        line: "U 2.0",
        xcaper: { vol: "3.4k", delta: "+150", spike: false },
        betfair: { odds: "0.88", tickDelta: "-0.01", trend: "down" },
        consensus: { pressureSide: "Under", pressureMagnitude: 50, bookCount: 10, direction: "down" },
      },
    ],
  },
  {
    id: "m4",
    league: "Bundesliga",
    team1: "Bayern Munich",
    team2: "Dortmund",
    isLive: true,
    minute: "45+2'",
    homeScore: 2,
    awayScore: 2,
    masterLine: "5.5",
    provenance: { sofa: false, alt: false, consensus: true },
    signal: {
      successRate: 64.0,
      targetSide: "Over",
      patternTag: "🔥 Smart Money",
    },
    lines: [
      {
        line: "O 5.5",
        xcaper: { vol: "22.5k", delta: "+4.1k", spike: true },
        betfair: { odds: "0.75", tickDelta: "-0.08", trend: "down" },
        consensus: { pressureSide: "Over", pressureMagnitude: 81, bookCount: 11, direction: "down" },
      },
      {
        line: "U 5.5",
        xcaper: { vol: "8.1k", delta: "-500", spike: false },
        betfair: { odds: "1.15", tickDelta: "+0.10", trend: "up" },
        consensus: { pressureSide: "Under", pressureMagnitude: 18, bookCount: 11, direction: "up" },
      },
    ],
  },
  {
    id: "m5",
    league: "Ligue 1",
    team1: "PSG",
    team2: "Marseille",
    isLive: true,
    minute: "78'",
    homeScore: 3,
    awayScore: 0,
    masterLine: "4.5",
    provenance: { sofa: true, alt: false, consensus: false },
    signal: null,
    lines: [
      {
        line: "O 4.5",
        xcaper: { vol: "4.4k", delta: "+300", spike: false },
        betfair: { odds: "1.45", tickDelta: "+0.15", trend: "up" },
        consensus: { pressureSide: "Over", pressureMagnitude: 33, bookCount: 12, direction: "up" },
      },
      {
        line: "U 4.5",
        xcaper: { vol: "18.2k", delta: "+2.8k", spike: true },
        betfair: { odds: "0.65", tickDelta: "-0.10", trend: "down" },
        consensus: { pressureSide: "Under", pressureMagnitude: 66, bookCount: 12, direction: "down" },
      },
    ],
  },
];

export default function Hybrid() {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 p-4 sm:p-6 font-sans">
      <div className="max-w-7xl mx-auto space-y-4">
        <header className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <Activity className="w-5 h-5 text-zinc-400" />
            <h1 className="text-lg font-semibold tracking-tight">Scanner Ledger</h1>
          </div>
          <div className="text-xs text-zinc-500 tabular-nums font-mono">
            Monitoring {MOCK_MATCHES.length} Active Matches
          </div>
        </header>

        {/* Global Header Strip for Columns */}
        <div className="hidden lg:grid grid-cols-[280px_1fr] gap-4 px-3 py-2 text-[10px] font-bold tracking-wider text-zinc-500 uppercase">
          <div>Fixture / Status</div>
          <div className="grid grid-cols-[60px_1fr_1fr_1fr] gap-3">
            <div className="flex items-center justify-center">Line</div>
            <div>Xcaper</div>
            <div>Betfair Live</div>
            <div>Consensus</div>
          </div>
        </div>

        {/* Match List */}
        <div className="space-y-3">
          {MOCK_MATCHES.map((match) => (
            <div
              key={match.id}
              className="bg-zinc-900/40 border border-zinc-800 rounded-lg hover:border-zinc-700 transition-colors flex flex-col lg:flex-row overflow-hidden shadow-sm"
            >
              {/* Left Column: Match Info */}
              <div className="w-full lg:w-[280px] p-3 border-b lg:border-b-0 lg:border-r border-zinc-800/60 flex flex-col justify-between shrink-0">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-zinc-400 font-bold tracking-wider uppercase">
                        {match.league}
                      </span>
                    </div>
                    {match.signal && (
                      <div className="flex items-center gap-1.5 text-[10px] font-medium bg-zinc-800/50 px-1.5 py-0.5 rounded">
                        <span className="text-zinc-300">
                          {match.signal.successRate}% {match.signal.targetSide}
                        </span>
                        <span className={match.signal.patternTag.includes("Smart") ? "text-orange-400" : "text-sky-400"}>
                          {match.signal.patternTag}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex justify-between items-start mt-2">
                    <div className="flex flex-col gap-1 text-sm font-semibold text-zinc-100">
                      <span className="truncate max-w-[170px]">{match.team1}</span>
                      <span className="truncate max-w-[170px]">{match.team2}</span>
                    </div>
                    <div className="flex flex-col items-end gap-1 font-mono text-base tabular-nums font-bold">
                      <span>{match.homeScore}</span>
                      <span>{match.awayScore}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <div className="flex items-center gap-1.5 mr-1">
                      {match.isLive && (
                        <div className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-pulse" />
                      )}
                      <span className="text-xs font-mono font-medium text-rose-400">
                        {match.minute}
                      </span>
                    </div>
                    {match.provenance.sofa && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        ✓sofa
                      </span>
                    )}
                    {match.provenance.alt && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">
                        alt
                      </span>
                    )}
                    {match.provenance.consensus && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                        📡 consensus
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column: Matrix */}
              <div className="flex-1 flex flex-col p-2 gap-2">
                {/* Mobile headers (hidden on lg) */}
                <div className="lg:hidden grid grid-cols-[50px_1fr_1fr_1fr] gap-2 px-2 py-1 text-[9px] font-bold text-zinc-500 uppercase">
                  <div className="text-center">Line</div>
                  <div>Xcaper</div>
                  <div>Betfair</div>
                  <div>Consens.</div>
                </div>

                {match.lines.map((line, idx) => (
                  <div
                    key={idx}
                    className="grid grid-cols-[50px_1fr_1fr_1fr] lg:grid-cols-[60px_1fr_1fr_1fr] gap-2 lg:gap-3 items-stretch"
                  >
                    {/* Line name */}
                    <div className="flex items-center justify-center bg-zinc-900/50 rounded-md border border-zinc-800/50">
                      <span className="text-zinc-400 font-bold tracking-tight text-xs font-mono">
                        {line.line}
                      </span>
                    </div>

                    {/* Xcaper */}
                    <div
                      className={`flex flex-col p-1.5 sm:p-2 rounded-md border transition-all duration-300 ${
                        line.xcaper.spike
                          ? "bg-sky-500/25 border-sky-400/50 ring-1 ring-sky-400/70 animate-pulse"
                          : "bg-zinc-900 border-zinc-800"
                      }`}
                    >
                      <div className="text-[9px] font-bold text-zinc-500 uppercase mb-0.5">XCAPER</div>
                      <div className="flex items-end justify-between mt-auto">
                        <span className="font-mono text-sm sm:text-base font-semibold text-zinc-100 tabular-nums leading-none">
                          {line.xcaper.vol}
                        </span>
                        <span
                          className={`font-mono text-[10px] sm:text-xs tabular-nums leading-none ${
                            line.xcaper.delta.startsWith("+")
                              ? "text-sky-400"
                              : "text-zinc-500"
                          }`}
                        >
                          {line.xcaper.delta}
                        </span>
                      </div>
                    </div>

                    {/* Betfair */}
                    <div className="flex flex-col p-1.5 sm:p-2 rounded-md bg-zinc-900 border border-zinc-800">
                      <div className="text-[9px] font-bold text-zinc-500 uppercase mb-0.5">BETFAIR LIVE</div>
                      <div className="flex items-end justify-between mt-auto">
                        <span className="font-mono text-sm sm:text-base font-semibold text-zinc-100 tabular-nums leading-none">
                          {line.betfair.odds}
                        </span>
                        <div className="flex items-center gap-0.5">
                          <span
                            className={`font-mono text-[10px] sm:text-xs tabular-nums leading-none ${
                              line.betfair.trend === "up"
                                ? "text-rose-300"
                                : "text-emerald-300"
                            }`}
                          >
                            {line.betfair.tickDelta}
                          </span>
                          {line.betfair.trend === "up" ? (
                            <ArrowUp className="w-3 h-3 text-rose-400" />
                          ) : (
                            <ArrowDown className="w-3 h-3 text-emerald-400" />
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Consensus */}
                    <div className="flex flex-col p-1.5 sm:p-2 rounded-md bg-zinc-900 border border-zinc-800">
                      <div className="text-[9px] font-bold text-zinc-500 uppercase mb-0.5">CONSENSUS</div>
                      <div className="flex items-end justify-between mt-auto">
                        <div className="flex items-center gap-1">
                          <span className="font-mono text-sm sm:text-base font-semibold text-zinc-100 tabular-nums leading-none">
                            {line.consensus.pressureSide}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-zinc-400 font-mono">
                           {line.consensus.bookCount} books
                        </div>
                      </div>
                      <div className="mt-1.5 h-1 bg-zinc-800 rounded-full overflow-hidden flex">
                        <div
                          className={`h-full rounded-full ${
                            line.consensus.direction === "up"
                              ? "bg-rose-500"
                              : "bg-emerald-500"
                          }`}
                          style={{ width: `${line.consensus.pressureMagnitude}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
