const base = process.argv[2] ?? "http://127.0.0.1:8080/api";
const url = new URL(base);
if (!["127.0.0.1", "localhost", "::1"].includes(url.hostname)) {
  throw new Error("Diagnostic may only target a local running API");
}
const password = process.env.DASHBOARD_PASSWORD;
if (!password) throw new Error("DASHBOARD_PASSWORD is required");

const login = await fetch(new URL("auth/login", `${url.toString().replace(/\/?$/, "/")}`), {
  method: "POST",
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ password }),
});
if (!login.ok) throw new Error(`Login failed (${login.status})`);
const cookie = login.headers.getSetCookie()[0]?.split(";")[0];
if (!cookie) throw new Error("Login did not return a session cookie");

const response = await fetch(
  new URL("scanner/excapper-master/diagnostic", `${url.toString().replace(/\/?$/, "/")}`),
  {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ confirm: "SIMULATED_TEST" }),
  },
);
const body = await response.json();
console.log(JSON.stringify({ httpStatus: response.status, ok: body.ok, result: body.result ?? body.error }, null, 2));
if (!response.ok) process.exitCode = 1;