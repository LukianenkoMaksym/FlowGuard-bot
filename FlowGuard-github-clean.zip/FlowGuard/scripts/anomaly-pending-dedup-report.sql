-- READ ONLY dry-run. Do not delete automatically or run this at startup.
-- Review all proposed removals and take a backup before any manual cleanup.
-- A new keeper starts only after a full rolling 15 minutes since the last
-- keeper, not at a fixed clock-quarter boundary. NULL lines group together.
WITH RECURSIVE ordered AS (
  SELECT id, match_id, anomaly_type, target_side, line, created_at,
         row_number() OVER (
           PARTITION BY match_id, anomaly_type, target_side, line
           ORDER BY created_at, id
         ) AS rn
  FROM anomalies
  WHERE status = 'PENDING'
), walk AS (
  SELECT id, match_id, anomaly_type, target_side, line, created_at, rn,
         id AS keeper_id, created_at AS keeper_at
  FROM ordered
  WHERE rn = 1
  UNION ALL
  SELECT o.id, o.match_id, o.anomaly_type, o.target_side, o.line, o.created_at, o.rn,
         CASE WHEN o.created_at >= w.keeper_at + interval '15 minutes'
              THEN o.id ELSE w.keeper_id END,
         CASE WHEN o.created_at >= w.keeper_at + interval '15 minutes'
              THEN o.created_at ELSE w.keeper_at END
  FROM walk AS w
  JOIN ordered AS o
    ON o.match_id = w.match_id
   AND o.anomaly_type = w.anomaly_type
   AND o.target_side = w.target_side
   AND o.line IS NOT DISTINCT FROM w.line
   AND o.rn = w.rn + 1
)
SELECT id AS proposed_duplicate_id, keeper_id, match_id, anomaly_type,
       target_side, line, created_at
FROM walk
WHERE id <> keeper_id
ORDER BY match_id, anomaly_type, target_side, line NULLS FIRST, created_at, id;