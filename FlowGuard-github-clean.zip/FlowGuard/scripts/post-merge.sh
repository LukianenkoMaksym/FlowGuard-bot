#!/bin/bash
set -e
pnpm install --frozen-lockfile
# Additive-only development sync; checks the full schema after applying.
# Never use drizzle-kit --force here.
pnpm --filter @workspace/db run push
# Drizzle may return success after a closed-stdin create/rename prompt without
# applying a table. Fail setup rather than allowing a broken dev schema.
(
  cd lib/db
  node --input-type=module -e '
    import pg from "pg";
    const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
    try {
      const { rows } = await pool.query(
        "SELECT to_regclass($1) AS active, to_regclass($2) AS imported",
        ["public.manual_active_bindings", "public.manual_bindings_import"],
      );
      if (!rows[0]?.active || !rows[0]?.imported) {
        throw new Error("Development schema push skipped manual binding tables");
      }
    } finally {
      await pool.end();
    }
  '
)
