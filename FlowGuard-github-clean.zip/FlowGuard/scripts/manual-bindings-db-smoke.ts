// Explicit development-only smoke test. Run with the development DATABASE_URL;
// never from application startup, post-merge setup, or deployment.
import { randomUUID } from "node:crypto";
import { bindingDecisionsTable, db, manualActiveBindingsTable, manualBindingBlocksTable, pool } from "../lib/db/src/index.ts";
import { eq } from "../lib/db/node_modules/drizzle-orm/index.js";
import { createBindingDecision } from "../artifacts/api-server/src/lib/bindingDecisionAudit.ts";
import { initManualBindingBlocks, persistManualBindingReset } from "../artifacts/api-server/src/lib/manualBindingBlocks.ts";
import { savePersistedManualBinding } from "../artifacts/api-server/src/lib/manualBindingsStore.ts";
import { forceManualExcapperBinding, resetManualExcapperBinding } from "../artifacts/api-server/src/lib/excapper.ts";

if (!process.env.DATABASE_URL || process.env.REPLIT_DEPLOYMENT || process.env.NODE_ENV === "production") {
  throw new Error("This smoke test requires an explicit development DATABASE_URL");
}

const id = `task53-smoke-${randomUUID()}`;
const wildcardId = `task53-smoke-${randomUUID()}`;
const gameId = `source-${randomUUID()}`;
const binding = {
  nowgoalId: id, excapperId: gameId, boundAt: new Date().toISOString(),
  status: "Verified" as const, autoBound: false,
};
const decision = createBindingDecision({
  action: "bind", mode: "manual_override", reason: "Isolated development transaction smoke test",
  target: { id, home: null, away: null, league: null, score: null, minute: null, period: null },
  source: { id: gameId, home: null, away: null, league: null, score: null, minute: null, period: null },
});
const check = async (active: number, blocked: number, audits: number, matchId = id) => {
  const [bindings, blocks, history] = await Promise.all([
    db.select().from(manualActiveBindingsTable).where(eq(manualActiveBindingsTable.nowgoalId, matchId)),
    db.select().from(manualBindingBlocksTable).where(eq(manualBindingBlocksTable.diagnosticId, matchId)),
    db.select().from(bindingDecisionsTable).where(eq(bindingDecisionsTable.matchId, matchId)),
  ]);
  if (bindings.length !== active || blocks.length !== blocked || history.length !== audits) {
    throw new Error(`Unexpected transaction state: bindings=${bindings.length} blocks=${blocks.length} audits=${history.length}`);
  }
};

try {
  const invalid = { ...decision, id: randomUUID(), occurredAt: "not-a-timestamp" };
  try {
    await savePersistedManualBinding(binding, invalid);
    throw new Error("Invalid audit unexpectedly committed");
  } catch (error) {
    if ((error as Error).message === "Invalid audit unexpectedly committed") throw error;
  }
  await check(0, 0, 0);
  await savePersistedManualBinding(binding, decision);
  await check(1, 0, 1);
  const reset = createBindingDecision({
    ...decision, action: "reset", mode: "manual",
    reason: "Reset isolated development transaction smoke fixture",
  });
  await persistManualBindingReset([{ diagnosticId: id, gameId }], [{ matchId: id, decision: reset }], id);
  await check(0, 1, 2);
  await savePersistedManualBinding(binding).then(
    () => { throw new Error("Blocked automatic save unexpectedly succeeded"); },
    (error) => {
      if (!(error instanceof Error) || !error.message.includes("automatic reattachment is blocked")) throw error;
    },
  );
  await check(0, 1, 2);
  const rebind = createBindingDecision({ ...decision, action: "bind" });
  await savePersistedManualBinding(binding, rebind, id, true);
  await check(1, 0, 3);
  const wildcardBinding = await forceManualExcapperBinding({ nowgoalId: wildcardId });
  if (wildcardBinding.excapperId !== "FORCE_MANUAL") {
    throw new Error("Identity-only approval unexpectedly gained a source ID");
  }
  await check(1, 0, 1, wildcardId);
  await resetManualExcapperBinding(wildcardId);
  await check(0, 1, 2, wildcardId);
  // Reload durable blocks from PostgreSQL, not from an in-memory reset cache.
  const reloadedBlocks = await initManualBindingBlocks();
  if (!reloadedBlocks.some((block) => block.diagnosticId === wildcardId && block.gameId === "*")) {
    throw new Error("Wildcard block was not restored from PostgreSQL");
  }
  const reloadedAudit = await db.select({
    action: bindingDecisionsTable.action, source: bindingDecisionsTable.source,
  }).from(bindingDecisionsTable).where(eq(bindingDecisionsTable.matchId, wildcardId));
  const resets = reloadedAudit.filter((entry) => entry.action === "reset");
  if (resets.length !== 1 || resets[0]?.source.id !== null) {
    throw new Error("Wildcard reset audit fabricated a source ID");
  }
  await savePersistedManualBinding(wildcardBinding).then(
    () => { throw new Error("Identity-only reset was resurrected"); },
    (error) => {
      if (!(error instanceof Error) || !error.message.includes("automatic reattachment is blocked")) throw error;
    },
  );
  await check(0, 1, 2, wildcardId);
  console.log("Development PostgreSQL binding/reset/rollback smoke passed");
} finally {
  // Never touch any other fixture's rows.
  try {
    await db.delete(manualActiveBindingsTable).where(eq(manualActiveBindingsTable.nowgoalId, id));
    await db.delete(manualBindingBlocksTable).where(eq(manualBindingBlocksTable.diagnosticId, id));
    await db.delete(bindingDecisionsTable).where(eq(bindingDecisionsTable.matchId, id));
    await db.delete(manualActiveBindingsTable).where(eq(manualActiveBindingsTable.nowgoalId, wildcardId));
    await db.delete(manualBindingBlocksTable).where(eq(manualBindingBlocksTable.diagnosticId, wildcardId));
    await db.delete(bindingDecisionsTable).where(eq(bindingDecisionsTable.matchId, wildcardId));
  } finally {
    await pool.end();
  }
}