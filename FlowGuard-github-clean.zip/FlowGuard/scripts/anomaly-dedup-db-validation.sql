-- Run ONLY against an isolated development/scratch PostgreSQL database.
-- Exercises real PostgreSQL advisory locks, INSERT/NOT EXISTS, rolling edges,
-- and NULL equality. Uses only a transaction-local temp table; rolls back.
BEGIN;
CREATE TEMP TABLE anomaly_dedup_validation (
  match_id text NOT NULL,
  anomaly_type text NOT NULL,
  target_side text NOT NULL,
  line real,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp()
) ON COMMIT DROP;

DO $$
DECLARE
  i integer;
  key text;
BEGIN
  FOR i IN 1..5 LOOP
    key := '["dedup-validation","MONEY_SPIKE","OVER",2.5]';
    PERFORM pg_advisory_xact_lock(hashtextextended(key, 0));
    INSERT INTO anomaly_dedup_validation (match_id, anomaly_type, target_side, line)
    SELECT 'dedup-validation', 'MONEY_SPIKE', 'OVER', 2.5
    WHERE NOT EXISTS (
      SELECT 1 FROM anomaly_dedup_validation
      WHERE match_id = 'dedup-validation'
        AND anomaly_type = 'MONEY_SPIKE'
        AND target_side = 'OVER'
        AND line IS NOT DISTINCT FROM 2.5::real
        AND created_at > clock_timestamp() - (900000 * interval '1 millisecond')
    );
  END LOOP;
  IF (SELECT count(*) FROM anomaly_dedup_validation WHERE match_id = 'dedup-validation') <> 1 THEN
    RAISE EXCEPTION 'Five-repeat dedup failed';
  END IF;

  -- At exactly 15 minutes ago the old row must not suppress insertion.
  INSERT INTO anomaly_dedup_validation (match_id, anomaly_type, target_side, line, created_at)
  VALUES ('rolling-edge', 'MONEY_SPIKE', 'OVER', 2.5, clock_timestamp() - interval '15 minutes 1 second');
  INSERT INTO anomaly_dedup_validation (match_id, anomaly_type, target_side, line)
  SELECT 'rolling-edge', 'MONEY_SPIKE', 'OVER', 2.5
  WHERE NOT EXISTS (
    SELECT 1 FROM anomaly_dedup_validation
    WHERE match_id = 'rolling-edge'
      AND anomaly_type = 'MONEY_SPIKE'
      AND target_side = 'OVER'
      AND line IS NOT DISTINCT FROM 2.5::real
      AND created_at > clock_timestamp() - interval '15 minutes'
  );
  IF (SELECT count(*) FROM anomaly_dedup_validation WHERE match_id = 'rolling-edge') <> 2 THEN
    RAISE EXCEPTION 'Rolling boundary check failed';
  END IF;

  -- Legacy nullable lines are equal for the null-safe predicate.
  INSERT INTO anomaly_dedup_validation (match_id, anomaly_type, target_side, line)
  VALUES ('nullable', 'MONEY_SPIKE', 'OVER', NULL);
  INSERT INTO anomaly_dedup_validation (match_id, anomaly_type, target_side, line)
  SELECT 'nullable', 'MONEY_SPIKE', 'OVER', NULL
  WHERE NOT EXISTS (
    SELECT 1 FROM anomaly_dedup_validation
    WHERE match_id = 'nullable'
      AND anomaly_type = 'MONEY_SPIKE'
      AND target_side = 'OVER'
      AND line IS NOT DISTINCT FROM NULL::real
      AND created_at > clock_timestamp() - interval '15 minutes'
  );
  IF (SELECT count(*) FROM anomaly_dedup_validation WHERE match_id = 'nullable') <> 1 THEN
    RAISE EXCEPTION 'NULL line dedup failed';
  END IF;
END $$;
ROLLBACK;